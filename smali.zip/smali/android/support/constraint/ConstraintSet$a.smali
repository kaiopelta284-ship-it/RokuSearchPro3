.class Landroid/support/constraint/ConstraintSet$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/ConstraintSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field static final UNSET:I = -0x1


# instance fields
.field public aA:I

.field public aB:I

.field public aC:I

.field public aD:I

.field public aE:I

.field public aF:I

.field public aG:I

.field public aH:F

.field public aI:I

.field public aJ:I

.field public aK:I

.field public aL:I

.field public aM:I

.field public aN:I

.field public aO:I

.field public aP:I

.field public aQ:I

.field public aR:I

.field public aS:F

.field public aT:F

.field public aU:Ljava/lang/String;

.field public aX:I

.field public aY:I

.field public alpha:F

.field public at:I

.field public au:I

.field public av:F

.field public aw:I

.field public ax:I

.field public ay:I

.field public az:I

.field public bh:I

.field public bi:I

.field public bj:Z

.field public bk:Z

.field public bottomMargin:I

.field dW:Z

.field public dX:I

.field public dY:I

.field dZ:I

.field public eA:Ljava/lang/String;

.field public ea:I

.field public eb:I

.field public ec:Z

.field public ed:F

.field public ee:F

.field public ef:F

.field public eg:F

.field public eh:F

.field public ei:F

.field public ej:F

.field public ek:F

.field public el:F

.field public em:F

.field public en:F

.field public eo:I

.field public ep:I

.field public eq:I

.field public er:I

.field public es:I

.field public et:I

.field public eu:F

.field public ev:F

.field public ew:Z

.field public ex:I

.field public ey:I

.field public ez:[I

.field public horizontalWeight:F

.field public leftMargin:I

.field public orientation:I

.field public rightMargin:I

.field public topMargin:I

.field public verticalWeight:F

.field public visibility:I


# direct methods
.method private constructor <init>()V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->dW:Z

    const/4 v1, -0x1

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->at:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->au:I

    const/high16 v2, -0x40800000    # -1.0f

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->av:F

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aw:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->ax:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->ay:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->az:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aA:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aB:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aC:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aD:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aE:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aI:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aJ:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aK:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aL:I

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->aT:F

    const/4 v2, 0x0

    iput-object v2, p0, Landroid/support/constraint/ConstraintSet$a;->aU:Ljava/lang/String;

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aF:I

    iput v0, p0, Landroid/support/constraint/ConstraintSet$a;->aG:I

    const/4 v2, 0x0

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->aH:F

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->bh:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->bi:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->orientation:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->leftMargin:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->rightMargin:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->topMargin:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->bottomMargin:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->ea:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->eb:I

    iput v0, p0, Landroid/support/constraint/ConstraintSet$a;->visibility:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aM:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aN:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aO:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aP:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aR:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->aQ:I

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->verticalWeight:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->horizontalWeight:F

    iput v0, p0, Landroid/support/constraint/ConstraintSet$a;->aX:I

    iput v0, p0, Landroid/support/constraint/ConstraintSet$a;->aY:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Landroid/support/constraint/ConstraintSet$a;->alpha:F

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->ec:Z

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->ed:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->ee:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->ef:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->eg:F

    iput v3, p0, Landroid/support/constraint/ConstraintSet$a;->eh:F

    iput v3, p0, Landroid/support/constraint/ConstraintSet$a;->ei:F

    const/high16 v4, 0x7fc00000    # Float.NaN

    iput v4, p0, Landroid/support/constraint/ConstraintSet$a;->ej:F

    iput v4, p0, Landroid/support/constraint/ConstraintSet$a;->ek:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->el:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->em:F

    iput v2, p0, Landroid/support/constraint/ConstraintSet$a;->en:F

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->bj:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->bk:Z

    iput v0, p0, Landroid/support/constraint/ConstraintSet$a;->eo:I

    iput v0, p0, Landroid/support/constraint/ConstraintSet$a;->ep:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->eq:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->er:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->es:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->et:I

    iput v3, p0, Landroid/support/constraint/ConstraintSet$a;->eu:F

    iput v3, p0, Landroid/support/constraint/ConstraintSet$a;->ev:F

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->ew:Z

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->ex:I

    iput v1, p0, Landroid/support/constraint/ConstraintSet$a;->ey:I

    return-void
.end method

.method synthetic constructor <init>(Landroid/support/constraint/ConstraintSet$1;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/constraint/ConstraintSet$a;-><init>()V

    return-void
.end method

.method private a(ILandroid/support/constraint/ConstraintLayout$LayoutParams;)V
    .locals 1

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->dZ:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aw:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ax:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ay:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->az:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aA:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aB:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aC:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aD:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aE:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aI:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aJ:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aK:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aL:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aT:F

    iget-object p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iput-object p1, p0, Landroid/support/constraint/ConstraintSet$a;->aU:Ljava/lang/String;

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aF:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aG:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aH:F

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->bh:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->bi:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->orientation:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->av:F

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->at:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->au:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->dX:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->dY:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->leftMargin:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->leftMargin:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->rightMargin:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->rightMargin:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->topMargin:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->topMargin:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bottomMargin:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->bottomMargin:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->verticalWeight:F

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->horizontalWeight:F

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aY:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->aX:I

    iget-boolean p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean p1, p0, Landroid/support/constraint/ConstraintSet$a;->bj:Z

    iget-boolean p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iput-boolean p1, p0, Landroid/support/constraint/ConstraintSet$a;->bk:Z

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->eo:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ep:I

    iget-boolean p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean p1, p0, Landroid/support/constraint/ConstraintSet$a;->bj:Z

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->eq:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->er:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->es:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->et:I

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->eu:F

    iget p1, p2, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ev:F

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x11

    if-lt p1, v0, :cond_0

    invoke-virtual {p2}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->getMarginEnd()I

    move-result p1

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ea:I

    invoke-virtual {p2}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->getMarginStart()I

    move-result p1

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->eb:I

    :cond_0
    return-void
.end method

.method private a(ILandroid/support/constraint/Constraints$LayoutParams;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/ConstraintSet$a;->a(ILandroid/support/constraint/ConstraintLayout$LayoutParams;)V

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->alpha:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->alpha:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ee:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ee:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ef:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ef:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->eg:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->eg:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->eh:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->eh:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ei:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ei:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ej:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ej:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ek:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ek:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->el:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->el:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->em:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->em:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->en:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->en:F

    iget p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ed:F

    iput p1, p0, Landroid/support/constraint/ConstraintSet$a;->ed:F

    iget-boolean p1, p2, Landroid/support/constraint/Constraints$LayoutParams;->ec:Z

    iput-boolean p1, p0, Landroid/support/constraint/ConstraintSet$a;->ec:Z

    return-void
.end method

.method private a(Landroid/support/constraint/ConstraintHelper;ILandroid/support/constraint/Constraints$LayoutParams;)V
    .locals 0

    invoke-direct {p0, p2, p3}, Landroid/support/constraint/ConstraintSet$a;->a(ILandroid/support/constraint/Constraints$LayoutParams;)V

    instance-of p2, p1, Landroid/support/constraint/Barrier;

    if-eqz p2, :cond_0

    const/4 p2, 0x1

    iput p2, p0, Landroid/support/constraint/ConstraintSet$a;->ey:I

    check-cast p1, Landroid/support/constraint/Barrier;

    invoke-virtual {p1}, Landroid/support/constraint/Barrier;->getType()I

    move-result p2

    iput p2, p0, Landroid/support/constraint/ConstraintSet$a;->ex:I

    invoke-virtual {p1}, Landroid/support/constraint/Barrier;->getReferencedIds()[I

    move-result-object p1

    iput-object p1, p0, Landroid/support/constraint/ConstraintSet$a;->ez:[I

    :cond_0
    return-void
.end method

.method static synthetic a(Landroid/support/constraint/ConstraintSet$a;ILandroid/support/constraint/ConstraintLayout$LayoutParams;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/ConstraintSet$a;->a(ILandroid/support/constraint/ConstraintLayout$LayoutParams;)V

    return-void
.end method

.method static synthetic a(Landroid/support/constraint/ConstraintSet$a;ILandroid/support/constraint/Constraints$LayoutParams;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/ConstraintSet$a;->a(ILandroid/support/constraint/Constraints$LayoutParams;)V

    return-void
.end method

.method static synthetic a(Landroid/support/constraint/ConstraintSet$a;Landroid/support/constraint/ConstraintHelper;ILandroid/support/constraint/Constraints$LayoutParams;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Landroid/support/constraint/ConstraintSet$a;->a(Landroid/support/constraint/ConstraintHelper;ILandroid/support/constraint/Constraints$LayoutParams;)V

    return-void
.end method


# virtual methods
.method public C()Landroid/support/constraint/ConstraintSet$a;
    .locals 3

    new-instance v0, Landroid/support/constraint/ConstraintSet$a;

    invoke-direct {v0}, Landroid/support/constraint/ConstraintSet$a;-><init>()V

    iget-boolean v1, p0, Landroid/support/constraint/ConstraintSet$a;->dW:Z

    iput-boolean v1, v0, Landroid/support/constraint/ConstraintSet$a;->dW:Z

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->dX:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->dX:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->dY:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->dY:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->at:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->at:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->au:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->au:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->av:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->av:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aw:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aw:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ax:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ax:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ay:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ay:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->az:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->az:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aA:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aA:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aB:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aB:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aC:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aC:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aD:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aD:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aE:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aE:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aI:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aI:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aJ:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aJ:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aK:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aK:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aL:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aL:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aT:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aT:F

    iget-object v1, p0, Landroid/support/constraint/ConstraintSet$a;->aU:Ljava/lang/String;

    iput-object v1, v0, Landroid/support/constraint/ConstraintSet$a;->aU:Ljava/lang/String;

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->bh:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->bh:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->bi:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->bi:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->orientation:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->orientation:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->leftMargin:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->leftMargin:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->rightMargin:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->rightMargin:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->topMargin:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->topMargin:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->bottomMargin:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->bottomMargin:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ea:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ea:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->eb:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->eb:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->visibility:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->visibility:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aM:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aM:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aN:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aN:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aO:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aO:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aP:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aP:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aR:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aR:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aQ:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aQ:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->verticalWeight:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->verticalWeight:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->horizontalWeight:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->horizontalWeight:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aX:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aX:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aY:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aY:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->alpha:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->alpha:F

    iget-boolean v1, p0, Landroid/support/constraint/ConstraintSet$a;->ec:Z

    iput-boolean v1, v0, Landroid/support/constraint/ConstraintSet$a;->ec:Z

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ed:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ed:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ee:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ee:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ef:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ef:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->eg:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->eg:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->eh:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->eh:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ei:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ei:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ej:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ej:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ek:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ek:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->el:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->el:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->em:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->em:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->en:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->en:F

    iget-boolean v1, p0, Landroid/support/constraint/ConstraintSet$a;->bj:Z

    iput-boolean v1, v0, Landroid/support/constraint/ConstraintSet$a;->bj:Z

    iget-boolean v1, p0, Landroid/support/constraint/ConstraintSet$a;->bk:Z

    iput-boolean v1, v0, Landroid/support/constraint/ConstraintSet$a;->bk:Z

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->eo:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->eo:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ep:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ep:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->eq:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->eq:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->er:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->er:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->es:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->es:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->et:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->et:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->eu:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->eu:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ev:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ev:F

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ex:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ex:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->ey:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->ey:I

    iget-object v1, p0, Landroid/support/constraint/ConstraintSet$a;->ez:[I

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroid/support/constraint/ConstraintSet$a;->ez:[I

    iget-object v2, p0, Landroid/support/constraint/ConstraintSet$a;->ez:[I

    array-length v2, v2

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v1

    iput-object v1, v0, Landroid/support/constraint/ConstraintSet$a;->ez:[I

    :cond_0
    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aF:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aF:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aG:I

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aG:I

    iget v1, p0, Landroid/support/constraint/ConstraintSet$a;->aH:F

    iput v1, v0, Landroid/support/constraint/ConstraintSet$a;->aH:F

    iget-boolean v1, p0, Landroid/support/constraint/ConstraintSet$a;->ew:Z

    iput-boolean v1, v0, Landroid/support/constraint/ConstraintSet$a;->ew:Z

    return-object v0
.end method

.method public a(Landroid/support/constraint/ConstraintLayout$LayoutParams;)V
    .locals 2

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aw:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->ax:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->ay:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->az:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aA:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aB:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aC:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aD:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aE:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aI:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aJ:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aK:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aL:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->leftMargin:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->leftMargin:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->rightMargin:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->rightMargin:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->topMargin:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->topMargin:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->bottomMargin:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bottomMargin:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aQ:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aR:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aS:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aT:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aF:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aG:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aH:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iget-object v0, p0, Landroid/support/constraint/ConstraintSet$a;->aU:Ljava/lang/String;

    iput-object v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->bh:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->bi:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->verticalWeight:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->horizontalWeight:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aY:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->aX:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iget-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->bj:Z

    iput-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iget-boolean v0, p0, Landroid/support/constraint/ConstraintSet$a;->bk:Z

    iput-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->eo:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->ep:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->eq:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->er:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->es:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->et:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->eu:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->ev:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->orientation:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->av:F

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->at:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->au:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->dX:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->dY:I

    iput v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x11

    if-lt v0, v1, :cond_0

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->eb:I

    invoke-virtual {p1, v0}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->setMarginStart(I)V

    iget v0, p0, Landroid/support/constraint/ConstraintSet$a;->ea:I

    invoke-virtual {p1, v0}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->setMarginEnd(I)V

    :cond_0
    invoke-virtual {p1}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->B()V

    return-void
.end method

.method public synthetic clone()Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0}, Landroid/support/constraint/ConstraintSet$a;->C()Landroid/support/constraint/ConstraintSet$a;

    move-result-object v0

    return-object v0
.end method
