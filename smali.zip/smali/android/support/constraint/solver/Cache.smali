.class public Landroid/support/constraint/solver/Cache;
.super Ljava/lang/Object;


# instance fields
.field eX:Landroid/support/constraint/solver/a$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/constraint/solver/a$a<",
            "Landroid/support/constraint/solver/ArrayRow;",
            ">;"
        }
    .end annotation
.end field

.field eY:Landroid/support/constraint/solver/a$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/constraint/solver/a$a<",
            "Landroid/support/constraint/solver/SolverVariable;",
            ">;"
        }
    .end annotation
.end field

.field eZ:[Landroid/support/constraint/solver/SolverVariable;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/support/constraint/solver/a$b;

    const/16 v1, 0x100

    invoke-direct {v0, v1}, Landroid/support/constraint/solver/a$b;-><init>(I)V

    iput-object v0, p0, Landroid/support/constraint/solver/Cache;->eX:Landroid/support/constraint/solver/a$a;

    new-instance v0, Landroid/support/constraint/solver/a$b;

    invoke-direct {v0, v1}, Landroid/support/constraint/solver/a$b;-><init>(I)V

    iput-object v0, p0, Landroid/support/constraint/solver/Cache;->eY:Landroid/support/constraint/solver/a$a;

    const/16 v0, 0x20

    new-array v0, v0, [Landroid/support/constraint/solver/SolverVariable;

    iput-object v0, p0, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    return-void
.end method
