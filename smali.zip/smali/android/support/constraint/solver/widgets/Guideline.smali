.class public Landroid/support/constraint/solver/widgets/Guideline;
.super Landroid/support/constraint/solver/widgets/ConstraintWidget;


# static fields
.field public static final HORIZONTAL:I = 0x0

.field public static final VERTICAL:I = 0x1

.field public static final kP:I = 0x0

.field public static final kQ:I = 0x1

.field public static final kR:I = 0x2

.field public static final kS:I = -0x1


# instance fields
.field private gQ:I

.field protected kT:F

.field protected kU:I

.field protected kV:I

.field private kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field private kX:Z

.field private kY:I

.field private kZ:Landroid/support/constraint/solver/widgets/Rectangle;

.field private la:I


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;-><init>()V

    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    iput-boolean v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kX:Z

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kY:I

    new-instance v1, Landroid/support/constraint/solver/widgets/Rectangle;

    invoke-direct {v1}, Landroid/support/constraint/solver/widgets/Rectangle;-><init>()V

    iput-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kZ:Landroid/support/constraint/solver/widgets/Rectangle;

    const/16 v1, 0x8

    iput v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iR:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iR:Ljava/util/ArrayList;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    array-length v1, v1

    :goto_0
    if-ge v0, v1, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aput-object v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public Q(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kY:I

    return-void
.end method

.method public R(I)V
    .locals 1

    int-to-float p1, p1

    const/high16 v0, 0x42c80000    # 100.0f

    div-float/2addr p1, v0

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->f(F)V

    return-void
.end method

.method public S(I)V
    .locals 2

    const/4 v0, -0x1

    if-le p1, v0, :cond_0

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    :cond_0
    return-void
.end method

.method public T(I)V
    .locals 2

    const/4 v0, -0x1

    if-le p1, v0, :cond_0

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    :cond_0
    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;
    .locals 2

    sget-object v0, Landroid/support/constraint/solver/widgets/Guideline$1;->hl:[I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    const/4 p1, 0x0

    return-object p1

    :pswitch_1
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    if-nez v0, :cond_0

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_2
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :cond_0
    :goto_0
    new-instance v0, Ljava/lang/AssertionError;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->name()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public aj()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public bH()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iR:Ljava/util/ArrayList;

    return-object v0
.end method

.method public c(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 9

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v0, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v0, v2}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v3, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v3, v3, v5

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v3, v6, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    iget v6, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    if-nez v6, :cond_3

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v0, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v0, v2}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v0, v0, v4

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v3, :cond_2

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    const/4 v3, 0x0

    :cond_3
    :goto_1
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    const/4 v4, 0x6

    const/4 v6, -0x1

    const/4 v7, 0x5

    if-eq v0, v6, :cond_4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    iget v6, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    invoke-virtual {p1, v0, v1, v6, v4}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    if-eqz v3, :cond_6

    invoke-virtual {p1, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    invoke-virtual {p1, v1, v0, v5, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    return-void

    :cond_4
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq v0, v6, :cond_5

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    invoke-virtual {p1, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v2

    iget v6, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    neg-int v6, v6

    invoke-virtual {p1, v0, v2, v6, v4}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    if-eqz v3, :cond_6

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    invoke-virtual {p1, v0, v1, v5, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    invoke-virtual {p1, v2, v0, v5, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    return-void

    :cond_5
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    const/high16 v3, -0x40800000    # -1.0f

    cmpl-float v0, v0, v3

    if-eqz v0, :cond_6

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v4

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v5

    invoke-virtual {p1, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v6

    iget v7, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    iget-boolean v8, p0, Landroid/support/constraint/solver/widgets/Guideline;->kX:Z

    move-object v3, p1

    invoke-static/range {v3 .. v8}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/LinearSystem;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;FZ)Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_6
    return-void
.end method

.method public cl()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    const/high16 v1, -0x40800000    # -1.0f

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    const/4 v0, 0x1

    return v0

    :cond_1
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq v0, v1, :cond_2

    const/4 v0, 0x2

    return v0

    :cond_2
    return v1
.end method

.method public cm()Landroid/support/constraint/solver/widgets/Rectangle;
    .locals 5

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kZ:Landroid/support/constraint/solver/widgets/Rectangle;

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bu()I

    move-result v1

    iget v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    sub-int/2addr v1, v2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bv()I

    move-result v2

    iget v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    mul-int/lit8 v3, v3, 0x2

    sub-int/2addr v2, v3

    iget v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    mul-int/lit8 v3, v3, 0x2

    iget v4, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    mul-int/lit8 v4, v4, 0x2

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/support/constraint/solver/widgets/Rectangle;->setBounds(IIII)V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getOrientation()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kZ:Landroid/support/constraint/solver/widgets/Rectangle;

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bu()I

    move-result v1

    iget v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    mul-int/lit8 v2, v2, 0x2

    sub-int/2addr v1, v2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bv()I

    move-result v2

    iget v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    sub-int/2addr v2, v3

    iget v3, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    mul-int/lit8 v3, v3, 0x2

    iget v4, p0, Landroid/support/constraint/solver/widgets/Guideline;->la:I

    mul-int/lit8 v4, v4, 0x2

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/support/constraint/solver/widgets/Rectangle;->setBounds(IIII)V

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kZ:Landroid/support/constraint/solver/widgets/Rectangle;

    return-object v0
.end method

.method public cn()Landroid/support/constraint/solver/widgets/ConstraintAnchor;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object v0
.end method

.method public co()F
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    return v0
.end method

.method public cp()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    return v0
.end method

.method public cq()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    return v0
.end method

.method cr()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getX()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v0, v1

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    if-nez v1, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getY()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v0, v1

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/Guideline;->f(F)V

    return-void
.end method

.method cs()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getX()I

    move-result v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    if-nez v1, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getY()I

    move-result v0

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/Guideline;->S(I)V

    return-void
.end method

.method ct()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getX()I

    move-result v1

    sub-int/2addr v0, v1

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    if-nez v1, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getY()I

    move-result v1

    sub-int/2addr v0, v1

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/Guideline;->T(I)V

    return-void
.end method

.method public cu()V
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->cr()V

    return-void

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v0, v0, v2

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->ct()V

    return-void

    :cond_1
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq v0, v1, :cond_2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->cs()V

    :cond_2
    return-void
.end method

.method public d(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->b(Ljava/lang/Object;)I

    move-result p1

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_1

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->setX(I)V

    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/Guideline;->setY(I)V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p1

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->setHeight(I)V

    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/Guideline;->setWidth(I)V

    return-void

    :cond_1
    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/Guideline;->setX(I)V

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->setY(I)V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p1

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->setWidth(I)V

    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/Guideline;->setHeight(I)V

    return-void
.end method

.method public e(Z)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kX:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kX:Z

    return-void
.end method

.method public f(F)V
    .locals 1

    const/high16 v0, -0x40800000    # -1.0f

    cmpl-float v0, p1, v0

    if-lez v0, :cond_0

    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    const/4 p1, -0x1

    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    :cond_0
    return-void
.end method

.method public getOrientation()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    return v0
.end method

.method public getType()Ljava/lang/String;
    .locals 1

    const-string v0, "Guideline"

    return-object v0
.end method

.method public o(I)V
    .locals 6

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->getOrientation()I

    move-result v0

    const/high16 v1, -0x40800000    # -1.0f

    const/4 v2, -0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne v0, v4, :cond_3

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v5, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v5}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v5, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v5}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    if-eq v0, v2, :cond_1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    invoke-virtual {v0, v4, v1, v2}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object p1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    :goto_0
    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object p1

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    :goto_1
    invoke-virtual {v0, v4, p1, v1}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    return-void

    :cond_1
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq v0, v2, :cond_2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    neg-int v2, v2

    invoke-virtual {v0, v4, v1, v2}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object p1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    :goto_2
    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object p1

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    neg-int v1, v1

    goto :goto_1

    :cond_2
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bR()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v1, :cond_6

    iget v0, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    int-to-float v0, v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget-object v2, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v2

    invoke-virtual {v1, v4, v2, v0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget-object p1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    :goto_3
    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object p1

    invoke-virtual {v1, v4, p1, v0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    return-void

    :cond_3
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v5, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v5}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v5, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v5}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v5

    invoke-virtual {v0, v4, v5, v3}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    if-eq v0, v2, :cond_4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    invoke-virtual {v0, v4, v1, v2}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object p1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto/16 :goto_0

    :cond_4
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq v0, v2, :cond_5

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object v1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    neg-int v2, v2

    invoke-virtual {v0, v4, v1, v2}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget-object p1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto/16 :goto_2

    :cond_5
    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bS()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v1, :cond_6

    iget v0, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    int-to-float v0, v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget-object v2, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v2

    invoke-virtual {v1, v4, v2, v0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    iget-object p1, p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto/16 :goto_3

    :cond_6
    return-void
.end method

.method public setOrientation(I)V
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iR:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    :goto_0
    iput-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto :goto_1

    :cond_1
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto :goto_0

    :goto_1
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iR:Ljava/util/ArrayList;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    array-length p1, p1

    const/4 v0, 0x0

    :goto_2
    if-ge v0, p1, :cond_2

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/Guideline;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_2
    return-void
.end method

.method public y(II)V
    .locals 4

    iget v0, p0, Landroid/support/constraint/solver/widgets/Guideline;->gQ:I

    const/high16 v1, -0x40800000    # -1.0f

    const/4 v2, -0x1

    const/4 v3, 0x1

    if-ne v0, v3, :cond_2

    iget p2, p0, Landroid/support/constraint/solver/widgets/Guideline;->jj:I

    sub-int/2addr p1, p2

    iget p2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    if-eq p2, v2, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->S(I)V

    return-void

    :cond_0
    iget p2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq p2, v2, :cond_1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p2

    invoke-virtual {p2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result p2

    sub-int/2addr p2, p1

    invoke-virtual {p0, p2}, Landroid/support/constraint/solver/widgets/Guideline;->T(I)V

    return-void

    :cond_1
    iget p2, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    cmpl-float p2, p2, v1

    if-eqz p2, :cond_5

    int-to-float p1, p1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p2

    invoke-virtual {p2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result p2

    goto :goto_0

    :cond_2
    iget p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->jk:I

    sub-int/2addr p2, p1

    iget p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kU:I

    if-eq p1, v2, :cond_3

    invoke-virtual {p0, p2}, Landroid/support/constraint/solver/widgets/Guideline;->S(I)V

    return-void

    :cond_3
    iget p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kV:I

    if-eq p1, v2, :cond_4

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p1

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result p1

    sub-int/2addr p1, p2

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->T(I)V

    return-void

    :cond_4
    iget p1, p0, Landroid/support/constraint/solver/widgets/Guideline;->kT:F

    cmpl-float p1, p1, v1

    if-eqz p1, :cond_5

    int-to-float p1, p2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/Guideline;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object p2

    invoke-virtual {p2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result p2

    :goto_0
    int-to-float p2, p2

    div-float/2addr p1, p2

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/Guideline;->f(F)V

    :cond_5
    return-void
.end method
