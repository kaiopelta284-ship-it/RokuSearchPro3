.class public Landroid/support/constraint/solver/widgets/ConstraintWidget;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;,
        Landroid/support/constraint/solver/widgets/ConstraintWidget$ContentAlignment;
    }
.end annotation


# static fields
.field public static final GONE:I = 0x8

.field public static final HORIZONTAL:I = 0x0

.field public static final INVISIBLE:I = 0x4

.field public static final UNKNOWN:I = -0x1

.field public static final VERTICAL:I = 0x1

.field public static final VISIBLE:I = 0x0

.field public static final an:I = 0x1

.field public static final ao:I = 0x0

.field public static final ap:I = 0x2

.field public static final aq:I = 0x0

.field public static final ar:I = 0x1

.field public static final as:I = 0x2

.field protected static final iL:I = 0x0

.field protected static final iM:I = 0x1

.field protected static final iN:I = 0x2

.field protected static final iO:I = 0x3

.field protected static final iP:I = 0x4

.field static final iS:I = 0x0

.field static final iT:I = 0x1

.field private static final ic:Z = false

.field protected static final ie:I = 0x1

.field protected static final if:I = 0x2

.field public static final ig:I = 0x3

.field public static final ih:I = 0x4

.field private static final ik:I = -0x2

.field public static jo:F = 0.5f


# instance fields
.field protected S:I

.field protected U:I

.field dX:I

.field dY:I

.field iA:Landroid/support/constraint/solver/widgets/ConstraintWidgetGroup;

.field private iB:[I

.field private iC:F

.field iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field protected iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field protected iR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation
.end field

.field protected iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

.field iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected iW:F

.field protected iX:I

.field protected iY:I

.field protected iZ:I

.field public ii:I

.field public ij:I

.field il:Landroid/support/constraint/solver/widgets/ResolutionDimension;

.field im:Landroid/support/constraint/solver/widgets/ResolutionDimension;

.field in:I

.field io:I

.field ip:[I

.field iq:I

.field ir:I

.field is:F

.field it:I

.field iu:I

.field iv:F

.field iw:Z

.field ix:Z

.field iy:I

.field iz:F

.field jA:Z

.field jB:Z

.field jC:Z

.field jD:Z

.field jE:Z

.field jF:Z

.field jG:Z

.field jH:Z

.field jI:Z

.field jJ:I

.field jK:I

.field jL:Z

.field jM:Z

.field jN:[F

.field protected jO:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected jP:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field jQ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field jR:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field jb:I

.field jc:I

.field private jf:I

.field private jg:I

.field private jh:I

.field private ji:I

.field protected jj:I

.field protected jk:I

.field jl:I

.field private jm:I

.field private jn:I

.field jp:F

.field jq:F

.field private jr:Ljava/lang/Object;

.field private js:I

.field private jt:I

.field private ju:Ljava/lang/String;

.field private jv:Ljava/lang/String;

.field jw:I

.field jx:I

.field jy:I

.field jz:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ii:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ij:I

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    const/4 v2, 0x2

    new-array v3, v2, [I

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->is:F

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iv:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    const/4 v3, 0x0

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iA:Landroid/support/constraint/solver/widgets/ConstraintWidgetGroup;

    new-array v4, v2, [I

    fill-array-data v4, :array_0

    iput-object v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const/4 v4, 0x0

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iC:F

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hy:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v5, 0x6

    new-array v5, v5, [Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aput-object v6, v5, v1

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v7, 0x1

    aput-object v6, v5, v7

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aput-object v6, v5, v2

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v8, 0x3

    aput-object v6, v5, v8

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v8, 0x4

    aput-object v6, v5, v8

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v8, 0x5

    aput-object v6, v5, v8

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    new-array v5, v2, [Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aput-object v6, v5, v1

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aput-object v6, v5, v7

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jb:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jc:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    sget v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    sget v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->js:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    iput-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jG:Z

    iput-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jH:Z

    iput-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jI:Z

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jJ:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jK:I

    new-array v0, v2, [F

    fill-array-data v0, :array_1

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    new-array v0, v2, [Landroid/support/constraint/solver/widgets/ConstraintWidget;

    aput-object v3, v0, v1

    aput-object v3, v0, v7

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jO:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    new-array v0, v2, [Landroid/support/constraint/solver/widgets/ConstraintWidget;

    aput-object v3, v0, v1

    aput-object v3, v0, v7

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jP:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jQ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jR:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bd()V

    return-void

    :array_0
    .array-data 4
        0x7fffffff
        0x7fffffff
    .end array-data

    :array_1
    .array-data 4
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
    .end array-data
.end method

.method public constructor <init>(II)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, v0, v0, p1, p2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;-><init>(IIII)V

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ii:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ij:I

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    const/4 v2, 0x2

    new-array v3, v2, [I

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->is:F

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iv:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    const/4 v3, 0x0

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iA:Landroid/support/constraint/solver/widgets/ConstraintWidgetGroup;

    new-array v4, v2, [I

    fill-array-data v4, :array_0

    iput-object v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const/4 v4, 0x0

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iC:F

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hy:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-direct {v5, p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;-><init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v5, 0x6

    new-array v5, v5, [Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aput-object v6, v5, v1

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v7, 0x1

    aput-object v6, v5, v7

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aput-object v6, v5, v2

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v8, 0x3

    aput-object v6, v5, v8

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v8, 0x4

    aput-object v6, v5, v8

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v8, 0x5

    aput-object v6, v5, v8

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    new-array v5, v2, [Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aput-object v6, v5, v1

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aput-object v6, v5, v7

    iput-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jb:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jc:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    sget v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    sget v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->js:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    iput-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jG:Z

    iput-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jH:Z

    iput-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jI:Z

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jJ:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jK:I

    new-array v0, v2, [F

    fill-array-data v0, :array_1

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    new-array v0, v2, [Landroid/support/constraint/solver/widgets/ConstraintWidget;

    aput-object v3, v0, v1

    aput-object v3, v0, v7

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jO:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    new-array v0, v2, [Landroid/support/constraint/solver/widgets/ConstraintWidget;

    aput-object v3, v0, v1

    aput-object v3, v0, v7

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jP:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jQ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jR:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iput p4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bd()V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bJ()V

    return-void

    nop

    :array_0
    .array-data 4
        0x7fffffff
        0x7fffffff
    .end array-data

    :array_1
    .array-data 4
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
    .end array-data
.end method

.method private M(I)Z
    .locals 3

    mul-int/lit8 p1, p1, 0x2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v0, v0, p1

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v0, v0, p1

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v2, v2, p1

    if-eq v0, v2, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    add-int/2addr p1, v1

    aget-object v0, v0, p1

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v0, v0, p1

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object p1, v2, p1

    if-ne v0, p1, :cond_0

    return v1

    :cond_0
    const/4 v1, 0x0

    return v1
.end method

.method private a(Landroid/support/constraint/solver/LinearSystem;ZLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V
    .locals 31

    move-object/from16 v0, p0

    move-object/from16 v10, p1

    move-object/from16 v12, p3

    move-object/from16 v13, p4

    move-object/from16 v14, p7

    move-object/from16 v15, p8

    move/from16 v1, p11

    move/from16 v2, p12

    invoke-virtual {v10, v14}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v9

    invoke-virtual {v10, v15}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v8

    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    invoke-virtual {v10, v6}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v7

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    invoke-virtual {v10, v6}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v6

    iget-boolean v12, v10, Landroid/support/constraint/solver/LinearSystem;->fi:Z

    const-wide/16 v16, 0x1

    move-object/from16 v22, v6

    if-eqz v12, :cond_2

    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v12

    iget v12, v12, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    const/4 v6, 0x1

    if-ne v12, v6, :cond_2

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v12

    iget v12, v12, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v12, v6, :cond_2

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v1

    iget-wide v2, v1, Landroid/support/constraint/solver/Metrics;->fK:J

    add-long v5, v2, v16

    iput-wide v5, v1, Landroid/support/constraint/solver/Metrics;->fK:J

    :cond_0
    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    invoke-virtual {v1, v10}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->g(Landroid/support/constraint/solver/LinearSystem;)V

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    invoke-virtual {v1, v10}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->g(Landroid/support/constraint/solver/LinearSystem;)V

    if-nez p15, :cond_1

    if-eqz p2, :cond_1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v10, v13, v8, v1, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_1
    return-void

    :cond_2
    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v6

    if-eqz v6, :cond_3

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v6

    iget-wide v12, v6, Landroid/support/constraint/solver/Metrics;->fT:J

    add-long v1, v12, v16

    iput-wide v1, v6, Landroid/support/constraint/solver/Metrics;->fT:J

    :cond_3
    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v1

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v2

    iget-object v6, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v6

    if-eqz v1, :cond_4

    const/4 v12, 0x1

    goto :goto_0

    :cond_4
    const/4 v12, 0x0

    :goto_0
    if-eqz v2, :cond_5

    add-int/lit8 v12, v12, 0x1

    :cond_5
    if-eqz v6, :cond_6

    add-int/lit8 v12, v12, 0x1

    :cond_6
    if-eqz p14, :cond_7

    const/4 v13, 0x3

    goto :goto_1

    :cond_7
    move/from16 v13, p16

    :goto_1
    sget-object v16, Landroid/support/constraint/solver/widgets/ConstraintWidget$1;->jS:[I

    invoke-virtual/range {p5 .. p5}, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ordinal()I

    move-result v17

    aget v16, v16, v17

    const/4 v15, 0x4

    packed-switch v16, :pswitch_data_0

    :goto_2
    :pswitch_0
    const/16 v16, 0x0

    goto :goto_3

    :pswitch_1
    if-ne v13, v15, :cond_8

    goto :goto_2

    :cond_8
    const/16 v16, 0x1

    :goto_3
    iget v15, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    const/16 v3, 0x8

    if-ne v15, v3, :cond_9

    const/4 v3, 0x0

    const/16 v16, 0x0

    goto :goto_4

    :cond_9
    move/from16 v3, p10

    :goto_4
    if-eqz p20, :cond_b

    if-nez v1, :cond_a

    if-nez v2, :cond_a

    if-nez v6, :cond_a

    move/from16 v15, p9

    invoke-virtual {v10, v9, v15}, Landroid/support/constraint/solver/LinearSystem;->e(Landroid/support/constraint/solver/SolverVariable;I)V

    goto :goto_5

    :cond_a
    if-eqz v1, :cond_b

    if-nez v2, :cond_b

    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v15

    move/from16 v23, v6

    const/4 v6, 0x6

    invoke-virtual {v10, v9, v7, v15, v6}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    goto :goto_6

    :cond_b
    :goto_5
    move/from16 v23, v6

    const/4 v6, 0x6

    :goto_6
    if-nez v16, :cond_f

    if-eqz p6, :cond_d

    const/4 v6, 0x3

    const/4 v15, 0x0

    invoke-virtual {v10, v8, v9, v15, v6}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    move/from16 v6, p11

    if-lez v6, :cond_c

    const/4 v15, 0x6

    invoke-virtual {v10, v8, v9, v6, v15}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    goto :goto_7

    :cond_c
    const/4 v15, 0x6

    :goto_7
    const v3, 0x7fffffff

    move-object/from16 v24, v7

    move/from16 v7, p12

    if-ge v7, v3, :cond_e

    invoke-virtual {v10, v8, v9, v7, v15}, Landroid/support/constraint/solver/LinearSystem;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    goto :goto_8

    :cond_d
    move-object/from16 v24, v7

    move/from16 v6, p11

    const/4 v15, 0x6

    invoke-virtual {v10, v8, v9, v3, v15}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    :cond_e
    :goto_8
    move/from16 v6, p17

    move/from16 v15, p18

    move/from16 v25, v13

    goto/16 :goto_10

    :cond_f
    move-object/from16 v24, v7

    move/from16 v6, p11

    const/4 v15, 0x6

    const/4 v7, -0x2

    move/from16 v15, p17

    if-ne v15, v7, :cond_10

    move/from16 v15, p18

    move v6, v3

    goto :goto_9

    :cond_10
    move v6, v15

    move/from16 v15, p18

    :goto_9
    if-ne v15, v7, :cond_11

    move v15, v3

    :cond_11
    if-lez v6, :cond_12

    const/4 v7, 0x6

    invoke-virtual {v10, v8, v9, v6, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    move-result v3

    goto :goto_a

    :cond_12
    const/4 v7, 0x6

    :goto_a
    if-lez v15, :cond_13

    invoke-virtual {v10, v8, v9, v15, v7}, Landroid/support/constraint/solver/LinearSystem;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    invoke-static {v3, v15}, Ljava/lang/Math;->min(II)I

    move-result v3

    :cond_13
    const/4 v7, 0x1

    if-ne v13, v7, :cond_16

    if-eqz p2, :cond_14

    const/4 v7, 0x6

    :goto_b
    invoke-virtual {v10, v8, v9, v3, v7}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    goto/16 :goto_e

    :cond_14
    if-eqz p15, :cond_15

    const/4 v7, 0x4

    goto :goto_b

    :cond_15
    const/4 v7, 0x1

    goto :goto_b

    :cond_16
    const/4 v7, 0x2

    if-ne v13, v7, :cond_19

    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->az()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    move-result-object v7

    move/from16 v25, v13

    sget-object v13, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v7, v13, :cond_18

    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->az()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    move-result-object v7

    sget-object v13, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v7, v13, :cond_17

    goto :goto_c

    :cond_17
    iget-object v7, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    sget-object v13, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v13}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v7

    iget-object v13, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-object/from16 v26, v7

    sget-object v7, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v13, v7}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v7

    move-object/from16 v19, v7

    move-object/from16 v20, v26

    goto :goto_d

    :cond_18
    :goto_c
    iget-object v7, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    sget-object v13, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v13}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v7

    iget-object v13, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-object/from16 v27, v7

    sget-object v7, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v13, v7}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v7

    move-object/from16 v19, v7

    move-object/from16 v20, v27

    :goto_d
    invoke-virtual/range {p1 .. p1}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v16

    move-object/from16 v17, v8

    move-object/from16 v18, v9

    move/from16 v21, p19

    invoke-virtual/range {v16 .. v21}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;F)Landroid/support/constraint/solver/ArrayRow;

    move-result-object v7

    invoke-virtual {v10, v7}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    const/16 v16, 0x0

    goto :goto_f

    :cond_19
    :goto_e
    move/from16 v25, v13

    :goto_f
    if-eqz v16, :cond_1b

    const/4 v7, 0x2

    if-eq v12, v7, :cond_1b

    if-nez p14, :cond_1b

    invoke-static {v6, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-lez v15, :cond_1a

    invoke-static {v15, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    :cond_1a
    const/4 v13, 0x6

    invoke-virtual {v10, v8, v9, v3, v13}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    const/16 v16, 0x0

    :cond_1b
    :goto_10
    if-eqz p20, :cond_37

    if-eqz p15, :cond_1c

    goto/16 :goto_20

    :cond_1c
    const/4 v12, 0x5

    if-nez v1, :cond_1f

    if-nez v2, :cond_1f

    if-nez v23, :cond_1f

    if-eqz p2, :cond_1d

    const/4 v5, 0x0

    move-object/from16 v13, p4

    :goto_11
    invoke-virtual {v10, v13, v8, v5, v12}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_1d
    :goto_12
    move-object v1, v8

    :cond_1e
    const/4 v3, 0x0

    const/4 v4, 0x6

    goto/16 :goto_1f

    :cond_1f
    const/4 v5, 0x0

    move-object/from16 v13, p4

    if-eqz v1, :cond_20

    if-nez v2, :cond_20

    if-eqz p2, :cond_1d

    goto :goto_11

    :cond_20
    if-nez v1, :cond_21

    if-eqz v2, :cond_21

    move-object/from16 v4, p8

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v1

    neg-int v1, v1

    move-object/from16 v2, v22

    const/4 v3, 0x6

    invoke-virtual {v10, v8, v2, v1, v3}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p2, :cond_1d

    move-object/from16 v1, p3

    invoke-virtual {v10, v9, v1, v5, v12}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    goto :goto_12

    :cond_21
    move-object/from16 v12, v22

    const/4 v3, 0x4

    move-object/from16 v4, p8

    if-eqz v1, :cond_1d

    if-eqz v2, :cond_1d

    if-eqz v16, :cond_2b

    if-eqz p2, :cond_22

    move/from16 v1, p11

    if-nez v1, :cond_22

    const/4 v2, 0x6

    invoke-virtual {v10, v8, v9, v5, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    goto :goto_13

    :cond_22
    const/4 v2, 0x6

    :goto_13
    if-nez v25, :cond_27

    if-gtz v15, :cond_24

    if-lez v6, :cond_23

    goto :goto_14

    :cond_23
    const/4 v1, 0x0

    const/4 v3, 0x6

    goto :goto_15

    :cond_24
    :goto_14
    const/4 v1, 0x1

    :goto_15
    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v7

    move-object/from16 v13, v24

    invoke-virtual {v10, v9, v13, v7, v3}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v7

    neg-int v7, v7

    invoke-virtual {v10, v8, v12, v7, v3}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    if-gtz v15, :cond_26

    if-lez v6, :cond_25

    goto :goto_16

    :cond_25
    const/4 v6, 0x0

    goto :goto_17

    :cond_26
    :goto_16
    const/4 v6, 0x1

    :goto_17
    move/from16 v17, v1

    move v1, v6

    const/4 v6, 0x1

    const/4 v15, 0x5

    goto :goto_1a

    :cond_27
    move-object/from16 v13, v24

    move/from16 v1, v25

    const/4 v6, 0x1

    if-ne v1, v6, :cond_28

    const/4 v1, 0x1

    const/4 v15, 0x6

    :goto_18
    const/16 v17, 0x1

    goto :goto_1a

    :cond_28
    const/4 v2, 0x3

    if-ne v1, v2, :cond_2a

    if-nez p14, :cond_29

    iget v1, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_29

    if-gtz v15, :cond_29

    const/4 v3, 0x6

    :cond_29
    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v1

    invoke-virtual {v10, v9, v13, v1, v3}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v10, v8, v12, v1, v3}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    const/4 v1, 0x1

    const/4 v15, 0x5

    goto :goto_18

    :cond_2a
    const/4 v1, 0x0

    goto :goto_19

    :cond_2b
    move-object/from16 v13, v24

    const/4 v6, 0x1

    const/4 v1, 0x1

    :goto_19
    const/4 v15, 0x5

    const/16 v17, 0x0

    :goto_1a
    if-eqz v1, :cond_2d

    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v7

    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v18

    move-object v1, v10

    const/16 v19, 0x6

    move-object v2, v9

    move-object v3, v13

    move-object v0, v4

    move v4, v7

    const/4 v7, 0x0

    move/from16 v5, p13

    move-object/from16 v29, v13

    const/4 v13, 0x6

    const/16 v19, 0x1

    move-object v6, v12

    move-object/from16 v13, v29

    move-object v7, v8

    move-object v11, v8

    move/from16 v8, v18

    move-object/from16 v30, v11

    move-object v11, v9

    move v9, v15

    invoke-virtual/range {v1 .. v9}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IFLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    iget-object v1, v14, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v1, v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    instance-of v1, v1, Landroid/support/constraint/solver/widgets/Barrier;

    iget-object v2, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    instance-of v2, v2, Landroid/support/constraint/solver/widgets/Barrier;

    if-eqz v1, :cond_2c

    if-nez v2, :cond_2c

    move/from16 v19, p2

    const/4 v1, 0x1

    const/4 v6, 0x5

    const/16 v28, 0x6

    goto :goto_1c

    :cond_2c
    if-nez v1, :cond_2e

    if-eqz v2, :cond_2e

    move/from16 v1, p2

    const/4 v6, 0x6

    goto :goto_1b

    :cond_2d
    move-object v0, v4

    move-object/from16 v30, v8

    move-object v11, v9

    :cond_2e
    move/from16 v1, p2

    move/from16 v19, v1

    const/4 v6, 0x5

    :goto_1b
    const/16 v28, 0x5

    :goto_1c
    if-eqz v17, :cond_2f

    const/4 v2, 0x6

    const/4 v6, 0x6

    goto :goto_1d

    :cond_2f
    move/from16 v2, v28

    :goto_1d
    if-nez v16, :cond_30

    if-nez v19, :cond_31

    :cond_30
    if-eqz v17, :cond_32

    :cond_31
    invoke-virtual/range {p7 .. p7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v3

    invoke-virtual {v10, v11, v13, v3, v6}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_32
    if-nez v16, :cond_33

    if-nez v1, :cond_34

    :cond_33
    if-eqz v17, :cond_35

    :cond_34
    invoke-virtual/range {p8 .. p8}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v0

    neg-int v0, v0

    move-object/from16 v1, v30

    invoke-virtual {v10, v1, v12, v0, v2}, Landroid/support/constraint/solver/LinearSystem;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    goto :goto_1e

    :cond_35
    move-object/from16 v1, v30

    :goto_1e
    if-eqz p2, :cond_1e

    move-object/from16 v2, p3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v10, v11, v2, v3, v4}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :goto_1f
    if-eqz p2, :cond_36

    move-object/from16 v5, p4

    invoke-virtual {v10, v5, v1, v3, v4}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_36
    return-void

    :cond_37
    :goto_20
    move-object v1, v8

    move-object v11, v9

    move-object/from16 v2, p3

    const/4 v3, 0x0

    const/4 v4, 0x6

    move-object/from16 v5, p4

    const/4 v6, 0x2

    if-ge v12, v6, :cond_38

    if-eqz p2, :cond_38

    invoke-virtual {v10, v11, v2, v3, v4}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    invoke-virtual {v10, v5, v1, v3, v4}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_38
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method private bd()V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public A(I)V
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    sub-int/2addr p1, v0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    return-void
.end method

.method public A(II)V
    .locals 1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    if-ge p1, v0, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    :cond_0
    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    if-ge p1, p2, :cond_1

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    :cond_1
    return-void
.end method

.method public B(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    return-void
.end method

.method public B(II)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    sub-int/2addr p2, p1

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    if-ge p1, p2, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    :cond_0
    return-void
.end method

.method public C(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    return-void
.end method

.method public C(II)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    sub-int/2addr p2, p1

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    if-ge p1, p2, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    :cond_0
    return-void
.end method

.method public D(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jm:I

    return-void
.end method

.method D(II)V
    .locals 1

    if-nez p2, :cond_0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jb:I

    return-void

    :cond_0
    const/4 v0, 0x1

    if-ne p2, v0, :cond_1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jc:I

    :cond_1
    return-void
.end method

.method public E(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jn:I

    return-void
.end method

.method F(I)I
    .locals 1

    if-nez p1, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jb:I

    return p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jc:I

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public G(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    return-void
.end method

.method public H(I)V
    .locals 0

    if-ltz p1, :cond_0

    :goto_0
    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->js:I

    return-void

    :cond_0
    const/4 p1, 0x0

    goto :goto_0

    return-void
.end method

.method public I(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jJ:I

    return-void
.end method

.method public J(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jK:I

    return-void
.end method

.method public K(I)V
    .locals 4

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    if-eqz v0, :cond_0

    instance-of v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->aV()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    :goto_0
    if-ge v0, v1, :cond_3

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aE()I

    move-result v3

    if-ne p1, v3, :cond_2

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aG()Z

    move-result v3

    if-eqz v3, :cond_1

    sget v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    invoke-virtual {p0, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->c(F)V

    goto :goto_1

    :cond_1
    sget v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    invoke-virtual {p0, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->b(F)V

    :goto_1
    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method public L(I)Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;
    .locals 1

    if-nez p1, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bR()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bS()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object p1

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;
    .locals 2

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$1;->hl:[I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/AssertionError;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->name()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    :pswitch_0
    const/4 p1, 0x0

    return-object p1

    :pswitch_1
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_2
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_3
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_4
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_5
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_6
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_7
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    :pswitch_8
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public a(FI)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    return-void
.end method

.method public a(Landroid/support/constraint/solver/LinearSystem;Ljava/lang/String;)V
    .locals 6

    iput-object p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v3}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ".left"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/support/constraint/solver/SolverVariable;->setName(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ".top"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/support/constraint/solver/SolverVariable;->setName(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".right"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/support/constraint/solver/SolverVariable;->setName(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".bottom"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/support/constraint/solver/SolverVariable;->setName(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    if-lez v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ".baseline"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->setName(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;I)V
    .locals 1

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$1;->hl:[I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->ordinal()I

    move-result p1

    aget p1, v0, p1

    packed-switch p1, :pswitch_data_0

    return-void

    :pswitch_0
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto :goto_0

    :pswitch_1
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto :goto_0

    :pswitch_2
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    goto :goto_0

    :pswitch_3
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    :goto_0
    iput p2, p1, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hg:I

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)V
    .locals 6

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    const/4 v4, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    invoke-virtual/range {v0 .. v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;I)V
    .locals 6

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    invoke-virtual/range {v0 .. v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;II)V
    .locals 7

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {p2, p3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    const/4 v5, 0x0

    const/4 v6, 0x1

    move v2, p4

    move v3, p5

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;IILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;IZ)Z

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;)V
    .locals 7

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move-object v5, p5

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V
    .locals 15

    move-object v7, p0

    move-object/from16 v0, p1

    move-object/from16 v8, p2

    move-object/from16 v9, p3

    move/from16 v10, p6

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v11, 0x0

    if-ne v0, v1, :cond_c

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v0, :cond_8

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v9

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v12

    const/4 v13, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    if-eqz v1, :cond_2

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v14, 0x0

    goto :goto_0

    :cond_2
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v4, 0x0

    move-object v0, v7

    move-object v2, v8

    move-object/from16 v5, p5

    move v6, v10

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    const/4 v14, 0x1

    :goto_0
    if-eqz v9, :cond_3

    invoke-virtual {v9}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-nez v0, :cond_4

    :cond_3
    if-eqz v12, :cond_5

    invoke-virtual {v12}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_5

    :cond_4
    const/4 v13, 0x0

    goto :goto_1

    :cond_5
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v4, 0x0

    move-object v0, v7

    move-object v2, v8

    move-object/from16 v5, p5

    move v6, v10

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    :goto_1
    if-eqz v14, :cond_6

    if-eqz v13, :cond_6

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    :goto_2
    invoke-virtual {v8, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    goto :goto_6

    :cond_6
    if-eqz v14, :cond_7

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto :goto_2

    :cond_7
    if-eqz v13, :cond_1d

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto :goto_2

    :cond_8
    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v9, v0, :cond_b

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v0, :cond_9

    goto :goto_3

    :cond_9
    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v9, v0, :cond_a

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v0, :cond_1d

    :cond_a
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v4, 0x0

    move-object v0, v7

    move-object v2, v8

    move-object v3, v9

    move-object/from16 v5, p5

    move v6, v10

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto :goto_4

    :cond_b
    :goto_3
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v4, 0x0

    move-object v0, v7

    move-object v2, v8

    move-object v3, v9

    move-object/from16 v5, p5

    move v6, v10

    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    :goto_4
    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    :goto_5
    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual/range {p2 .. p3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    :goto_6
    invoke-virtual {v0, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    return-void

    :cond_c
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v1, :cond_e

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v9, v1, :cond_d

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v1, :cond_e

    :cond_d
    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual/range {p2 .. p3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    invoke-virtual {v0, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    invoke-virtual {v2, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    goto :goto_6

    :cond_e
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v1, :cond_10

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v9, v1, :cond_f

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v1, :cond_10

    :cond_f
    invoke-virtual/range {p2 .. p3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v1, v0, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v1, v0, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v1, v0, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    return-void

    :cond_10
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v1, :cond_11

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v1, :cond_11

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v8, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v0, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v8, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v0, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto/16 :goto_5

    :cond_11
    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v1, :cond_12

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v9, v1, :cond_12

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v8, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v0, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v8, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v0, v1, v11, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)Z

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto/16 :goto_5

    :cond_12
    invoke-virtual/range {p0 .. p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual/range {p2 .. p3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->b(Landroid/support/constraint/solver/widgets/ConstraintAnchor;)Z

    move-result v3

    if-eqz v3, :cond_1d

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hy:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v3, :cond_15

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_13
    if-eqz v3, :cond_14

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_14
    :goto_7
    move-object/from16 v0, p5

    goto/16 :goto_b

    :cond_15
    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v0, v3, :cond_19

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v3, :cond_16

    goto :goto_9

    :cond_16
    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v0, v3, :cond_17

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v3, :cond_1c

    :cond_17
    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    if-eq v4, v2, :cond_18

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_18
    invoke-virtual/range {p0 .. p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aJ()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_1c

    :goto_8
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    goto :goto_a

    :cond_19
    :goto_9
    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hy:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    if-eqz v3, :cond_1a

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_1a
    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    if-eq v4, v2, :cond_1b

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_1b
    invoke-virtual/range {p0 .. p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aJ()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v7, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_1c

    goto :goto_8

    :cond_1c
    :goto_a
    move/from16 v11, p4

    goto :goto_7

    :goto_b
    invoke-virtual {v1, v2, v11, v0, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)Z

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->e(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V

    :cond_1d
    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;I)V
    .locals 6

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    invoke-virtual/range {v0 .. v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;II)V
    .locals 6

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V
    .locals 8

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    if-ne v0, p0, :cond_0

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->az()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    move-result-object v2

    invoke-virtual {p2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v3

    invoke-virtual {p2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->az()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    move-result-object v4

    move-object v1, p0

    move v5, p3

    move-object v6, p4

    move v7, p5

    invoke-virtual/range {v1 .. v7}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)V

    :cond_0
    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne p1, v0, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jm:I

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setWidth(I)V

    :cond_0
    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintWidget;FI)V
    .locals 6

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v5, 0x0

    move-object v0, p0

    move-object v2, p1

    move v4, p3

    invoke-virtual/range {v0 .. v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;II)V

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iC:F

    return-void
.end method

.method public a(ZZZZ)V
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const/4 v3, -0x1

    const/4 v4, 0x1

    if-ne v0, v3, :cond_1

    if-eqz p3, :cond_0

    if-nez p4, :cond_0

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    goto :goto_0

    :cond_0
    if-nez p3, :cond_1

    if-eqz p4, :cond_1

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    if-ne p3, v3, :cond_1

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    div-float p3, v1, p3

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    :cond_1
    :goto_0
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-nez p3, :cond_3

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_2

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-nez p3, :cond_3

    :cond_2
    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    goto :goto_1

    :cond_3
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-ne p3, v4, :cond_5

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_4

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-nez p3, :cond_5

    :cond_4
    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    :cond_5
    :goto_1
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-ne p3, v3, :cond_8

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-nez p3, :cond_8

    :cond_6
    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_7

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_7

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    goto :goto_2

    :cond_7
    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_8

    iget-object p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result p3

    if-eqz p3, :cond_8

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    div-float p3, v1, p3

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    :cond_8
    :goto_2
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-ne p3, v3, :cond_a

    if-eqz p1, :cond_9

    if-nez p2, :cond_9

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    goto :goto_3

    :cond_9
    if-nez p1, :cond_a

    if-eqz p2, :cond_a

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    div-float p3, v1, p3

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    :cond_a
    :goto_3
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-ne p3, v3, :cond_c

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    if-lez p3, :cond_b

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    if-nez p3, :cond_b

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    goto :goto_4

    :cond_b
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    if-nez p3, :cond_c

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    if-lez p3, :cond_c

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    div-float p3, v1, p3

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    :cond_c
    :goto_4
    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-ne p3, v3, :cond_d

    if-eqz p1, :cond_d

    if-eqz p2, :cond_d

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    div-float/2addr v1, p1

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    :cond_d
    return-void
.end method

.method public aX()Z
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    const/4 v1, 0x0

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    const/4 v2, 0x0

    cmpl-float v0, v0, v2

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v0, v0, v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v2, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method public aY()Z
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    const/4 v2, 0x0

    cmpl-float v0, v0, v2

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v0, v0, v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v2, :cond_0

    return v1

    :cond_0
    const/4 v1, 0x0

    return v1
.end method

.method public aZ()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x6

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->update()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public aj()Z
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public ak()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x6

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->reset()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public al()V
    .locals 0

    return-void
.end method

.method public b(F)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    return-void
.end method

.method public b(IIIF)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    iput p4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->is:F

    const/high16 p1, 0x3f800000    # 1.0f

    cmpg-float p1, p4, p1

    if-gez p1, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    if-nez p1, :cond_0

    const/4 p1, 0x2

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    :cond_0
    return-void
.end method

.method public b(IIII)V
    .locals 1

    sub-int/2addr p3, p1

    sub-int/2addr p4, p2

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    const/4 p2, 0x0

    const/16 v0, 0x8

    if-ne p1, v0, :cond_0

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    return-void

    :cond_0
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object p1, p1, p2

    sget-object p2, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne p1, p2, :cond_1

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    if-ge p3, p1, :cond_1

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    :cond_1
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 p2, 0x1

    aget-object p1, p1, p2

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne p1, v0, :cond_2

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    if-ge p4, p1, :cond_2

    iget p4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    :cond_2
    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iput p4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    if-ge p1, p3, :cond_3

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    :cond_3
    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    if-ge p1, p3, :cond_4

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    :cond_4
    iput-boolean p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jH:Z

    return-void
.end method

.method public b(Landroid/support/constraint/solver/Cache;)V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    return-void
.end method

.method public b(Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v1, 0x1

    aput-object p1, v0, v1

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne p1, v0, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jn:I

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setHeight(I)V

    :cond_0
    return-void
.end method

.method public b(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iw:Z

    return-void
.end method

.method protected bA()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    add-int/2addr v0, v1

    return v0
.end method

.method protected bB()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    add-int/2addr v0, v1

    return v0
.end method

.method public bC()F
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    return v0
.end method

.method public bD()F
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    return v0
.end method

.method public bE()Z
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    if-lez v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public bF()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    return v0
.end method

.method public bG()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jr:Ljava/lang/Object;

    return-object v0
.end method

.method public bH()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    return-object v0
.end method

.method public bI()V
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    add-int/2addr v2, v3

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    add-int/2addr v3, v4

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    sub-int/2addr v2, v0

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    sub-int/2addr v3, v1

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    return-void
.end method

.method public bJ()V
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    add-int/2addr v2, v3

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    add-int/2addr v3, v4

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    sub-int/2addr v2, v0

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    sub-int/2addr v3, v1

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    return-void
.end method

.method public bK()F
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    return v0
.end method

.method public bL()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    return v0
.end method

.method public bM()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->js:I

    return v0
.end method

.method public bN()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jJ:I

    return v0
.end method

.method public bO()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jK:I

    return v0
.end method

.method public bP()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bQ()V

    sget v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->c(F)V

    sget v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->b(F)V

    instance-of v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bR()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v1, :cond_2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bs()I

    move-result v1

    if-ne v0, v1, :cond_1

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    :goto_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;)V

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getMinWidth()I

    move-result v1

    if-le v0, v1, :cond_2

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bS()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v1, :cond_4

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bt()I

    move-result v1

    if-ne v0, v1, :cond_3

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    :goto_2
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->b(Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;)V

    return-void

    :cond_3
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getMinHeight()I

    move-result v1

    if-le v0, v1, :cond_4

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    goto :goto_2

    :cond_4
    return-void
.end method

.method public bQ()V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    if-eqz v0, :cond_0

    instance-of v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->aV()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    :goto_0
    if-ge v0, v1, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iR:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public bR()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    return-object v0
.end method

.method public bS()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    return-object v0
.end method

.method public bT()Z
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eq v0, v1, :cond_1

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-ne v0, v1, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public bU()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 5

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bT()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    move-object v2, p0

    move-object v0, v1

    :goto_0
    if-nez v0, :cond_6

    if-eqz v2, :cond_6

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v2, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    if-nez v3, :cond_0

    move-object v3, v1

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    :goto_1
    if-nez v3, :cond_1

    move-object v3, v1

    goto :goto_2

    :cond_1
    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v3

    :goto_2
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v4

    if-ne v3, v4, :cond_2

    move-object v0, v2

    return-object v0

    :cond_2
    if-nez v3, :cond_3

    move-object v4, v1

    goto :goto_3

    :cond_3
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    :goto_3
    if-eqz v4, :cond_4

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v4

    if-eq v4, v2, :cond_4

    move-object v0, v2

    goto :goto_0

    :cond_4
    move-object v2, v3

    goto :goto_0

    :cond_5
    move-object v0, v1

    :cond_6
    return-object v0
.end method

.method public bV()Z
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eq v0, v1, :cond_1

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-ne v0, v1, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public bW()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 5

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bV()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    move-object v2, p0

    move-object v0, v1

    :goto_0
    if-nez v0, :cond_6

    if-eqz v2, :cond_6

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v2, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    if-nez v3, :cond_0

    move-object v3, v1

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    :goto_1
    if-nez v3, :cond_1

    move-object v3, v1

    goto :goto_2

    :cond_1
    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v3

    :goto_2
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v4

    if-ne v3, v4, :cond_2

    move-object v0, v2

    return-object v0

    :cond_2
    if-nez v3, :cond_3

    move-object v4, v1

    goto :goto_3

    :cond_3
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    :goto_3
    if-eqz v4, :cond_4

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v4

    if-eq v4, v2, :cond_4

    move-object v0, v2

    goto :goto_0

    :cond_4
    move-object v2, v3

    goto :goto_0

    :cond_5
    move-object v0, v1

    :cond_6
    return-object v0
.end method

.method public ba()Z
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public bb()Landroid/support/constraint/solver/widgets/ResolutionDimension;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->il:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/constraint/solver/widgets/ResolutionDimension;

    invoke-direct {v0}, Landroid/support/constraint/solver/widgets/ResolutionDimension;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->il:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->il:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    return-object v0
.end method

.method public bc()Landroid/support/constraint/solver/widgets/ResolutionDimension;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->im:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/constraint/solver/widgets/ResolutionDimension;

    invoke-direct {v0}, Landroid/support/constraint/solver/widgets/ResolutionDimension;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->im:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->im:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    return-object v0
.end method

.method public be()Z
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public bf()Z
    .locals 1

    instance-of v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    instance-of v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-nez v0, :cond_1

    :cond_0
    const/4 v0, 0x1

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public bg()Z
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    :goto_0
    if-eqz v0, :cond_2

    instance-of v2, v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v2, :cond_1

    const/4 v0, 0x1

    return v0

    :cond_1
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    goto :goto_0

    :cond_2
    return v1
.end method

.method public bh()Landroid/support/constraint/solver/widgets/WidgetContainer;
    .locals 2

    move-object v0, p0

    :goto_0
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    goto :goto_0

    :cond_0
    instance-of v1, v0, Landroid/support/constraint/solver/widgets/WidgetContainer;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/support/constraint/solver/widgets/WidgetContainer;

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public bj()Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iw:Z

    return v0
.end method

.method public bk()Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ix:Z

    return v0
.end method

.method public bl()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    return-object v0
.end method

.method bm()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    return v0
.end method

.method bn()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    return v0
.end method

.method public bo()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    add-int/2addr v0, v1

    return v0
.end method

.method public bp()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    add-int/2addr v0, v1

    return v0
.end method

.method public bq()I
    .locals 4

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v3, :cond_2

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    const/4 v3, 0x1

    if-ne v1, v3, :cond_0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    goto :goto_0

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    if-lez v0, :cond_1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    if-lez v1, :cond_2

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    if-ge v1, v0, :cond_2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    :cond_2
    return v0
.end method

.method public br()I
    .locals 4

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v2, 0x1

    aget-object v1, v1, v2

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v3, :cond_2

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    if-ne v1, v2, :cond_0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    goto :goto_0

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    if-lez v0, :cond_1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    if-lez v1, :cond_2

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    if-ge v1, v0, :cond_2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    :cond_2
    return v0
.end method

.method public bs()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jm:I

    return v0
.end method

.method public bt()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jn:I

    return v0
.end method

.method public bu()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    add-int/2addr v0, v1

    return v0
.end method

.method public bv()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    add-int/2addr v0, v1

    return v0
.end method

.method public bw()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    return v0
.end method

.method public bx()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    return v0
.end method

.method public by()I
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bv()I

    move-result v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    add-int/2addr v0, v1

    return v0
.end method

.method public bz()I
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bu()I

    move-result v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    add-int/2addr v0, v1

    return v0
.end method

.method public c(F)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    return-void
.end method

.method public c(IIIF)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    iput p3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    iput p4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iv:F

    const/high16 p1, 0x3f800000    # 1.0f

    cmpg-float p1, p4, p1

    if-gez p1, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    if-nez p1, :cond_0

    const/4 p1, 0x2

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    :cond_0
    return-void
.end method

.method public c(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 41

    move-object/from16 v15, p0

    move-object/from16 v14, p1

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v21

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v13

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v12

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v11

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v10

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    const/16 v1, 0x8

    const/4 v9, 0x1

    const/4 v8, 0x0

    if-eqz v0, :cond_6

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_0

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v0, v0, v8

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v2, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v2, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v2, :cond_1

    iget-object v2, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v2, v2, v9

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v2, v3, :cond_1

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    :goto_1
    invoke-direct {v15, v8}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->M(I)Z

    move-result v3

    if-eqz v3, :cond_2

    iget-object v3, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    check-cast v3, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    invoke-virtual {v3, v15, v8}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->c(Landroid/support/constraint/solver/widgets/ConstraintWidget;I)V

    const/4 v3, 0x1

    goto :goto_2

    :cond_2
    invoke-virtual/range {p0 .. p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bT()Z

    move-result v3

    :goto_2
    invoke-direct {v15, v9}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->M(I)Z

    move-result v4

    if-eqz v4, :cond_3

    iget-object v4, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    check-cast v4, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    invoke-virtual {v4, v15, v9}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->c(Landroid/support/constraint/solver/widgets/ConstraintWidget;I)V

    const/4 v4, 0x1

    goto :goto_3

    :cond_3
    invoke-virtual/range {p0 .. p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bV()Z

    move-result v4

    :goto_3
    if-eqz v0, :cond_4

    iget v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    if-eq v5, v1, :cond_4

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-nez v5, :cond_4

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-nez v5, :cond_4

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v5}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v5

    invoke-virtual {v14, v5, v13, v8, v9}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_4
    if-eqz v2, :cond_5

    iget v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    if-eq v5, v1, :cond_5

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-nez v5, :cond_5

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-nez v5, :cond_5

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-nez v5, :cond_5

    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v5}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v5

    invoke-virtual {v14, v5, v11, v8, v9}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V

    :cond_5
    move v7, v2

    move/from16 v16, v3

    move/from16 v22, v4

    move v2, v0

    goto :goto_4

    :cond_6
    const/4 v2, 0x0

    const/4 v7, 0x0

    const/16 v16, 0x0

    const/16 v22, 0x0

    :goto_4
    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget v3, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    if-ge v0, v3, :cond_7

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    :cond_7
    iget v3, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget v4, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    if-ge v3, v4, :cond_8

    iget v3, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    :cond_8
    iget-object v4, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v4, v4, v8

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-eq v4, v5, :cond_9

    const/4 v4, 0x1

    goto :goto_5

    :cond_9
    const/4 v4, 0x0

    :goto_5
    iget-object v5, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v5, v5, v9

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-eq v5, v6, :cond_a

    const/4 v5, 0x1

    goto :goto_6

    :cond_a
    const/4 v5, 0x0

    :goto_6
    iget v6, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    iput v6, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iget v6, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    iput v6, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iget v6, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    iget v9, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    iget v8, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    const/16 v17, 0x0

    cmpl-float v8, v8, v17

    const/16 v17, 0x4

    if-lez v8, :cond_13

    iget v8, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    const/16 v1, 0x8

    if-eq v8, v1, :cond_13

    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v8, 0x0

    aget-object v1, v1, v8

    sget-object v8, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move/from16 v27, v0

    const/4 v0, 0x3

    if-ne v1, v8, :cond_b

    if-nez v6, :cond_b

    const/4 v6, 0x3

    :cond_b
    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v8, 0x1

    aget-object v1, v1, v8

    sget-object v8, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v8, :cond_c

    if-nez v9, :cond_c

    const/4 v9, 0x3

    :cond_c
    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v8, 0x0

    aget-object v1, v1, v8

    sget-object v8, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v8, :cond_d

    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v8, 0x1

    aget-object v1, v1, v8

    sget-object v8, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v8, :cond_d

    if-ne v6, v0, :cond_d

    if-ne v9, v0, :cond_d

    invoke-virtual {v15, v2, v7, v4, v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(ZZZZ)V

    goto/16 :goto_7

    :cond_d
    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v4, 0x0

    aget-object v1, v1, v4

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v5, :cond_f

    if-ne v6, v0, :cond_f

    iput v4, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iget v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    int-to-float v1, v1

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v4, 0x1

    aget-object v1, v1, v4

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-eq v1, v5, :cond_e

    move/from16 v18, v0

    move/from16 v28, v3

    move/from16 v25, v9

    goto :goto_a

    :cond_e
    move/from16 v18, v0

    move/from16 v28, v3

    move/from16 v17, v6

    move/from16 v25, v9

    goto :goto_9

    :cond_f
    const/4 v4, 0x1

    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v1, v1, v4

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v1, v5, :cond_12

    if-ne v9, v0, :cond_12

    iput v4, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_10

    const/high16 v0, 0x3f800000    # 1.0f

    iget v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    div-float/2addr v0, v1

    iput v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    :cond_10
    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iget v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    int-to-float v1, v1

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v3, 0x0

    aget-object v1, v1, v3

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-eq v1, v3, :cond_11

    move/from16 v28, v0

    move/from16 v17, v6

    move/from16 v18, v27

    const/16 v25, 0x4

    goto :goto_a

    :cond_11
    move/from16 v28, v0

    goto :goto_8

    :cond_12
    :goto_7
    move/from16 v28, v3

    :goto_8
    move/from16 v17, v6

    move/from16 v25, v9

    move/from16 v18, v27

    :goto_9
    const/16 v27, 0x1

    goto :goto_b

    :cond_13
    move/from16 v27, v0

    move/from16 v28, v3

    move/from16 v17, v6

    move/from16 v25, v9

    move/from16 v18, v27

    :goto_a
    const/16 v27, 0x0

    :goto_b
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    const/4 v1, 0x0

    aput v17, v0, v1

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    const/4 v1, 0x1

    aput v25, v0, v1

    if-eqz v27, :cond_15

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-eqz v0, :cond_14

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_16

    goto :goto_c

    :cond_14
    const/4 v1, -0x1

    :goto_c
    const/16 v19, 0x1

    goto :goto_d

    :cond_15
    const/4 v1, -0x1

    :cond_16
    const/16 v19, 0x0

    :goto_d
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v3, 0x0

    aget-object v0, v0, v3

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v3, :cond_17

    instance-of v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_17

    const/4 v6, 0x1

    goto :goto_e

    :cond_17
    const/4 v6, 0x0

    :goto_e
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    const/4 v9, 0x1

    xor-int/lit8 v23, v0, 0x1

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ii:I

    const/4 v8, 0x2

    const/16 v26, 0x0

    if-eq v0, v8, :cond_1a

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_18

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    move-object v4, v0

    goto :goto_f

    :cond_18
    move-object/from16 v4, v26

    :goto_f
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_19

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v14, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    move-object v3, v0

    goto :goto_10

    :cond_19
    move-object/from16 v3, v26

    :goto_10
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/16 v20, 0x0

    aget-object v5, v0, v20

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v8, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget v9, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    move-object/from16 v31, v11

    iget v11, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    iget-object v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    aget v24, v1, v20

    iget v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    move-object/from16 v33, v13

    iget v13, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    move/from16 v34, v13

    iget v13, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    move/from16 v35, v13

    iget v13, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->is:F

    move-object/from16 v36, v0

    move-object v0, v15

    move/from16 v32, v1

    move-object v1, v14

    move/from16 v37, v7

    move-object/from16 v7, v36

    move-object/from16 v38, v10

    move/from16 v10, v18

    move-object/from16 v29, v31

    move-object/from16 v39, v12

    move/from16 v12, v24

    move/from16 v30, v13

    move-object/from16 v24, v33

    move/from16 v18, v34

    move/from16 v20, v35

    move/from16 v13, v32

    move/from16 v14, v19

    move/from16 v15, v16

    move/from16 v16, v17

    move/from16 v17, v18

    move/from16 v18, v20

    move/from16 v19, v30

    move/from16 v20, v23

    invoke-direct/range {v0 .. v20}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/LinearSystem;ZLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V

    move-object/from16 v15, p0

    goto :goto_11

    :cond_1a
    move/from16 v37, v7

    move-object/from16 v38, v10

    move-object/from16 v29, v11

    move-object/from16 v39, v12

    move-object/from16 v24, v13

    :goto_11
    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ij:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1b

    return-void

    :cond_1b
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v14, 0x1

    aget-object v0, v0, v14

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v1, :cond_1c

    instance-of v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_1c

    const/4 v6, 0x1

    goto :goto_12

    :cond_1c
    const/4 v6, 0x0

    :goto_12
    if-eqz v27, :cond_1e

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    if-eq v0, v14, :cond_1d

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_1e

    :cond_1d
    const/16 v16, 0x1

    goto :goto_13

    :cond_1e
    const/16 v16, 0x0

    :goto_13
    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    if-lez v0, :cond_20

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v14, :cond_1f

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    move-object/from16 v13, p1

    invoke-virtual {v0, v13}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->g(Landroid/support/constraint/solver/LinearSystem;)V

    move-object/from16 v12, v39

    goto :goto_14

    :cond_1f
    move-object/from16 v13, p1

    invoke-virtual/range {p0 .. p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bF()I

    move-result v0

    const/4 v1, 0x6

    move-object/from16 v2, v38

    move-object/from16 v12, v39

    invoke-virtual {v13, v2, v12, v0, v1}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v0, :cond_21

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v13, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    const/4 v3, 0x0

    invoke-virtual {v13, v2, v0, v3, v1}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    const/16 v20, 0x0

    goto :goto_15

    :cond_20
    move-object/from16 v12, v39

    move-object/from16 v13, p1

    :cond_21
    :goto_14
    move/from16 v20, v23

    :goto_15
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_22

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v13, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    move-object v4, v0

    goto :goto_16

    :cond_22
    move-object/from16 v4, v26

    :goto_16
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_23

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v13, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    move-object v3, v0

    goto :goto_17

    :cond_23
    move-object/from16 v3, v26

    :goto_17
    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v5, v0, v14

    iget-object v7, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v8, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget v9, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iget v11, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    iget-object v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    aget v17, v0, v14

    iget v10, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    iget v2, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    iget v1, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    iget v0, v15, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iv:F

    move/from16 v19, v0

    move-object v0, v15

    move/from16 v18, v1

    move-object v1, v13

    move/from16 v23, v2

    move/from16 v2, v37

    move/from16 v26, v10

    move/from16 v10, v28

    move-object/from16 v28, v12

    move/from16 v12, v17

    move/from16 v13, v26

    move/from16 v14, v16

    move/from16 v15, v22

    move/from16 v16, v25

    move/from16 v17, v23

    invoke-direct/range {v0 .. v20}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/LinearSystem;ZLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroid/support/constraint/solver/widgets/ConstraintAnchor;Landroid/support/constraint/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V

    if-eqz v27, :cond_25

    const/4 v6, 0x6

    move-object/from16 v7, p0

    iget v0, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_24

    iget v5, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    const/4 v6, 0x6

    move-object/from16 v0, p1

    move-object/from16 v1, v29

    move-object/from16 v2, v28

    move-object/from16 v3, v24

    move-object/from16 v4, v21

    :goto_18
    invoke-virtual/range {v0 .. v6}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;FI)V

    goto :goto_19

    :cond_24
    iget v5, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    move-object/from16 v0, p1

    move-object/from16 v1, v24

    move-object/from16 v2, v21

    move-object/from16 v3, v29

    move-object/from16 v4, v28

    goto :goto_18

    :cond_25
    move-object/from16 v7, p0

    :goto_19
    iget-object v0, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_26

    iget-object v0, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    iget v1, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iC:F

    const/high16 v2, 0x42b40000    # 90.0f

    add-float/2addr v1, v2

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v1

    double-to-float v1, v1

    iget-object v2, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v2

    move-object/from16 v3, p1

    invoke-virtual {v3, v7, v0, v1, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintWidget;FI)V

    :cond_26
    return-void
.end method

.method public c(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ix:Z

    return-void
.end method

.method public c(Landroid/support/constraint/solver/widgets/ConstraintWidget;)Z
    .locals 4

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    const/4 v1, 0x1

    if-ne v0, p1, :cond_0

    return v1

    :cond_0
    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v2

    const/4 v3, 0x0

    if-ne v0, v2, :cond_1

    return v3

    :cond_1
    :goto_0
    if-eqz v0, :cond_4

    if-ne v0, p1, :cond_2

    return v1

    :cond_2
    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v2

    if-ne v0, v2, :cond_3

    return v1

    :cond_3
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    goto :goto_0

    :cond_4
    return v3
.end method

.method public d(F)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    const/4 v1, 0x0

    aput p1, v0, v1

    return-void
.end method

.method public d(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 6

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->b(Ljava/lang/Object;)I

    move-result v0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/LinearSystem;->b(Ljava/lang/Object;)I

    move-result v1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v2}, Landroid/support/constraint/solver/LinearSystem;->b(Ljava/lang/Object;)I

    move-result v2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v3}, Landroid/support/constraint/solver/LinearSystem;->b(Ljava/lang/Object;)I

    move-result p1

    sub-int v3, v2, v0

    sub-int v4, p1, v1

    const/4 v5, 0x0

    if-ltz v3, :cond_0

    if-ltz v4, :cond_0

    const/high16 v3, -0x80000000

    if-eq v0, v3, :cond_0

    const v4, 0x7fffffff

    if-eq v0, v4, :cond_0

    if-eq v1, v3, :cond_0

    if-eq v1, v4, :cond_0

    if-eq v2, v3, :cond_0

    if-eq v2, v4, :cond_0

    if-eq p1, v3, :cond_0

    if-ne p1, v4, :cond_1

    :cond_0
    const/4 p1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :cond_1
    invoke-virtual {p0, v0, v1, v2, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->b(IIII)V

    return-void
.end method

.method public d(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-void
.end method

.method public e(F)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    const/4 v1, 0x1

    aput p1, v0, v1

    return-void
.end method

.method public e(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    if-lez v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    :cond_0
    return-void
.end method

.method public e(Landroid/support/constraint/solver/widgets/ConstraintAnchor;)V
    .locals 8

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    instance-of v0, v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bi()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->aV()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hz:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    sget-object v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hA:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v5}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v5

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hB:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {p0, v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    const/high16 v7, 0x3f000000    # 0.5f

    if-ne p1, v4, :cond_4

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v5

    if-ne v4, v5, :cond_1

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_1
    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    if-ne v0, v1, :cond_2

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_2
    iput v7, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    :cond_3
    :goto_0
    iput v7, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    goto/16 :goto_3

    :cond_4
    if-ne p1, v5, :cond_6

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v2

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v3

    if-ne v2, v3, :cond_5

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_5
    iput v7, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    goto :goto_3

    :cond_6
    if-ne p1, v6, :cond_7

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v1

    if-ne v0, v1, :cond_3

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    goto :goto_0

    :cond_7
    if-eq p1, v0, :cond_a

    if-ne p1, v1, :cond_8

    goto :goto_1

    :cond_8
    if-eq p1, v2, :cond_9

    if-ne p1, v3, :cond_b

    :cond_9
    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    if-ne v0, v1, :cond_b

    goto :goto_2

    :cond_a
    :goto_1
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v2

    if-eqz v2, :cond_b

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    if-ne v0, v1, :cond_b

    :goto_2
    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_b
    :goto_3
    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    return-void
.end method

.method public e(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 0

    return-void
.end method

.method public e(Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jr:Ljava/lang/Object;

    return-void
.end method

.method public e(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    return-void
.end method

.method public f(III)V
    .locals 1

    const/4 v0, 0x1

    if-nez p3, :cond_0

    invoke-virtual {p0, p1, p2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->B(II)V

    goto :goto_0

    :cond_0
    if-ne p3, v0, :cond_1

    invoke-virtual {p0, p1, p2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->C(II)V

    :cond_1
    :goto_0
    iput-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jH:Z

    return-void
.end method

.method public f(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 5

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bH()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v4

    if-ne v4, p1, :cond_0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public f(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    return-void
.end method

.method public g(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 6

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bH()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->isConnected()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ay()Landroid/support/constraint/solver/widgets/ConstraintWidget;

    move-result-object v4

    if-ne v4, p1, :cond_0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aE()I

    move-result v4

    const/4 v5, 0x2

    if-ne v4, v5, :cond_0

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public g(Ljava/lang/String;)V
    .locals 8

    const/4 v0, 0x0

    if-eqz p1, :cond_8

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_2

    :cond_0
    const/4 v1, -0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x2c

    invoke-virtual {p1, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-lez v3, :cond_3

    add-int/lit8 v6, v2, -0x1

    if-ge v3, v6, :cond_3

    invoke-virtual {p1, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const-string v7, "W"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    :cond_1
    const-string v4, "H"

    invoke-virtual {v6, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/4 v1, 0x1

    :cond_2
    :goto_0
    add-int/lit8 v4, v3, 0x1

    :cond_3
    const/16 v3, 0x3a

    invoke-virtual {p1, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    if-ltz v3, :cond_5

    sub-int/2addr v2, v5

    if-ge v3, v2, :cond_5

    invoke-virtual {p1, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    add-int/2addr v3, v5

    invoke-virtual {p1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_6

    :try_start_0
    invoke-static {v2}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1

    cmpl-float v3, v2, v0

    if-lez v3, :cond_6

    cmpl-float v3, p1, v0

    if-lez v3, :cond_6

    if-ne v1, v5, :cond_4

    div-float/2addr p1, v2

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    goto :goto_1

    :cond_4
    div-float/2addr v2, p1

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :cond_5
    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_6

    :try_start_1
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    :cond_6
    const/4 p1, 0x0

    :goto_1
    cmpl-float v0, p1, v0

    if-lez v0, :cond_7

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    :cond_7
    return-void

    :cond_8
    :goto_2
    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    return-void
.end method

.method public getBottom()I
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getY()I

    move-result v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    add-int/2addr v0, v1

    return v0
.end method

.method public getHeight()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    return v0
.end method

.method public getLeft()I
    .locals 1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getX()I

    move-result v0

    return v0
.end method

.method public getMaxHeight()I
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const/4 v1, 0x1

    aget v0, v0, v1

    return v0
.end method

.method public getMaxWidth()I
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const/4 v1, 0x0

    aget v0, v0, v1

    return v0
.end method

.method public getMinHeight()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    return v0
.end method

.method public getMinWidth()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    return v0
.end method

.method public getRight()I
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getX()I

    move-result v0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    add-int/2addr v0, v1

    return v0
.end method

.method public getTop()I
    .locals 1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getY()I

    move-result v0

    return v0
.end method

.method public getType()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    return-object v0
.end method

.method public getVisibility()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    return v0
.end method

.method public getWidth()I
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    return v0
.end method

.method public getX()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    return v0
.end method

.method public getY()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    return v0
.end method

.method public o(I)V
    .locals 0

    invoke-static {p1, p0}, Landroid/support/constraint/solver/widgets/Optimizer;->a(ILandroid/support/constraint/solver/widgets/ConstraintWidget;)V

    return-void
.end method

.method public reset()V
    .locals 6

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iD:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iE:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iF:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iG:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iH:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iI:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iJ:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iK:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->reset()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iV:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iC:F

    const/4 v2, 0x0

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iW:F

    const/4 v1, -0x1

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iX:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jh:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ji:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jl:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jm:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jn:I

    sget v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    sget v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jo:F

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aput-object v4, v3, v2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kc:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    const/4 v5, 0x1

    aput-object v4, v3, v5

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jr:Ljava/lang/Object;

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->js:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jE:Z

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jF:Z

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jJ:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jK:I

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jL:Z

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jM:Z

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    const/high16 v4, -0x40800000    # -1.0f

    aput v4, v3, v2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    aput v4, v3, v5

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ii:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ij:I

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const v4, 0x7fffffff

    aput v4, v3, v2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    aput v4, v3, v5

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->in:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->io:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->is:F

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iv:F

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ir:I

    iput v4, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iu:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iq:I

    iput v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->it:I

    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iy:I

    iput v3, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iz:F

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->il:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->il:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionDimension;->reset()V

    :cond_0
    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->im:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-eqz v1, :cond_1

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->im:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionDimension;->reset()V

    :cond_1
    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iA:Landroid/support/constraint/solver/widgets/ConstraintWidgetGroup;

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jG:Z

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jH:Z

    iput-boolean v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jI:Z

    return-void
.end method

.method public setHeight(I)V
    .locals 1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    if-ge p1, v0, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    :cond_0
    return-void
.end method

.method public setMaxHeight(I)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const/4 v1, 0x1

    aput p1, v0, v1

    return-void
.end method

.method public setMaxWidth(I)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iB:[I

    const/4 v1, 0x0

    aput p1, v0, v1

    return-void
.end method

.method public setMinHeight(I)V
    .locals 0

    if-gez p1, :cond_0

    const/4 p1, 0x0

    :cond_0
    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->U:I

    return-void
.end method

.method public setMinWidth(I)V
    .locals 0

    if-gez p1, :cond_0

    const/4 p1, 0x0

    :cond_0
    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    return-void
.end method

.method public setVisibility(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jt:I

    return-void
.end method

.method public setWidth(I)V
    .locals 1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    if-ge p1, v0, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->S:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    :cond_0
    return-void
.end method

.method public setX(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    return-void
.end method

.method public setY(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "type: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jv:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_0
    const-string v1, ""

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    if-eqz v1, :cond_1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "id: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ju:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_1
    const-string v1, ""

    :goto_1
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ") - ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dX:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " x "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->dY:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ") wrap: ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jm:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " x "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jn:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public w(II)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    return-void
.end method

.method public x(I)I
    .locals 1

    if-nez p1, :cond_0

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result p1

    return p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public x(II)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    return-void
.end method

.method public y(I)F
    .locals 1

    if-nez p1, :cond_0

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    return p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    return p1

    :cond_1
    const/high16 p1, -0x40800000    # -1.0f

    return p1
.end method

.method public y(II)V
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    sub-int/2addr p1, v0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jk:I

    sub-int/2addr p2, p1

    iput p2, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jg:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iZ:I

    return-void
.end method

.method public z(I)V
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jj:I

    sub-int/2addr p1, v0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iget p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jf:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iY:I

    return-void
.end method

.method public z(II)V
    .locals 1

    if-nez p2, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setWidth(I)V

    return-void

    :cond_0
    const/4 v0, 0x1

    if-ne p2, v0, :cond_1

    invoke-virtual {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setHeight(I)V

    :cond_1
    return-void
.end method
