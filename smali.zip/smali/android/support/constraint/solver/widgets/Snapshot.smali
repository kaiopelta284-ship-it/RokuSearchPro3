.class public Landroid/support/constraint/solver/widgets/Snapshot;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/constraint/solver/widgets/Snapshot$a;
    }
.end annotation


# instance fields
.field private dX:I

.field private dY:I

.field private iY:I

.field private iZ:I

.field private lJ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/Snapshot$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->lJ:Ljava/util/ArrayList;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getX()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->iY:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getY()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->iZ:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->dX:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->dY:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bH()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/Snapshot;->lJ:Ljava/util/ArrayList;

    new-instance v4, Landroid/support/constraint/solver/widgets/Snapshot$a;

    invoke-direct {v4, v2}, Landroid/support/constraint/solver/widgets/Snapshot$a;-><init>(Landroid/support/constraint/solver/widgets/ConstraintAnchor;)V

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public l(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 3

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getX()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->iY:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getY()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->iZ:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->dX:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->dY:I

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->lJ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/Snapshot;->lJ:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/Snapshot$a;

    invoke-virtual {v2, p1}, Landroid/support/constraint/solver/widgets/Snapshot$a;->l(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public m(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->iY:I

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setX(I)V

    iget v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->iZ:I

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setY(I)V

    iget v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->dX:I

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setWidth(I)V

    iget v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->dY:I

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->setHeight(I)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot;->lJ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/Snapshot;->lJ:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/Snapshot$a;

    invoke-virtual {v2, p1}, Landroid/support/constraint/solver/widgets/Snapshot$a;->m(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method
