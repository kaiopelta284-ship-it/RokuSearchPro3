.class public Landroid/support/constraint/solver/widgets/ResolutionNode;
.super Ljava/lang/Object;


# static fields
.field public static final lG:I = 0x0

.field public static final lH:I = 0x1

.field public static final lI:I = 0x2


# instance fields
.field lF:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Landroid/support/constraint/solver/widgets/ResolutionNode;",
            ">;"
        }
    .end annotation
.end field

.field state:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(I)V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->lF:Ljava/util/HashSet;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->state:I

    return-void
.end method


# virtual methods
.method public a(Landroid/support/constraint/solver/widgets/ResolutionDimension;)V
    .locals 0

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ResolutionNode;)V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->lF:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public al()V
    .locals 0

    return-void
.end method

.method public cA()V
    .locals 2

    const/4 v0, 0x1

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->state:I

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->lF:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/constraint/solver/widgets/ResolutionNode;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionNode;->al()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public cB()Z
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->state:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return v1

    :cond_0
    const/4 v1, 0x0

    return v1
.end method

.method public cz()V
    .locals 2

    instance-of v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->state:I

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->lF:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/constraint/solver/widgets/ResolutionNode;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionNode;->cz()V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public invalidate()V
    .locals 2

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->state:I

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->lF:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/constraint/solver/widgets/ResolutionNode;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ResolutionNode;->invalidate()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public reset()V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->state:I

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionNode;->lF:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    return-void
.end method
