.class Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/solver/widgets/ConstraintTableLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field hW:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field hX:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field final synthetic hY:Landroid/support/constraint/solver/widgets/ConstraintTableLayout;

.field padding:I


# direct methods
.method constructor <init>(Landroid/support/constraint/solver/widgets/ConstraintTableLayout;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hY:Landroid/support/constraint/solver/widgets/ConstraintTableLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
