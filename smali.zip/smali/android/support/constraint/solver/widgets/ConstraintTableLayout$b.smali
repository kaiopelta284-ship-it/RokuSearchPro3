.class Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/solver/widgets/ConstraintTableLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field final synthetic hY:Landroid/support/constraint/solver/widgets/ConstraintTableLayout;

.field hZ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field ia:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field ib:I

.field padding:I


# direct methods
.method constructor <init>(Landroid/support/constraint/solver/widgets/ConstraintTableLayout;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->hY:Landroid/support/constraint/solver/widgets/ConstraintTableLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    return-void
.end method
