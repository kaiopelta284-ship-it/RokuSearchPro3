.class public Landroid/support/constraint/solver/widgets/ChainHead;
.super Ljava/lang/Object;


# instance fields
.field protected gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gG:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gH:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gI:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gJ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gK:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gL:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field protected gM:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/ConstraintWidget;",
            ">;"
        }
    .end annotation
.end field

.field protected gN:I

.field protected gO:I

.field protected gP:F

.field private gQ:I

.field private gR:Z

.field protected gS:Z

.field protected gT:Z

.field protected gU:Z

.field private gV:Z


# direct methods
.method public constructor <init>(Landroid/support/constraint/solver/widgets/ConstraintWidget;IZ)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gP:F

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gR:Z

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput p2, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    iput-boolean p3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gR:Z

    return-void
.end method

.method private am()V
    .locals 13

    iget v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    const/4 v1, 0x2

    mul-int/lit8 v0, v0, 0x2

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v4, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    const/4 v4, 0x0

    move-object v5, v2

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x1

    if-nez v2, :cond_d

    iget v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gN:I

    add-int/2addr v7, v6

    iput v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gN:I

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jP:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    const/4 v9, 0x0

    aput-object v9, v7, v8

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jO:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aput-object v9, v7, v8

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getVisibility()I

    move-result v7

    const/16 v8, 0x8

    if-eq v7, v8, :cond_8

    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gG:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-nez v7, :cond_0

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gG:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :cond_0
    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gI:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aget-object v7, v7, v8

    sget-object v8, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v7, v8, :cond_8

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aget v7, v7, v8

    if-eqz v7, :cond_1

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aget v7, v7, v8

    const/4 v8, 0x3

    if-eq v7, v8, :cond_1

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aget v7, v7, v8

    if-ne v7, v1, :cond_8

    :cond_1
    iget v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gO:I

    add-int/2addr v7, v6

    iput v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gO:I

    iget-object v7, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aget v7, v7, v8

    const/4 v8, 0x0

    cmpl-float v10, v7, v8

    if-lez v10, :cond_2

    iget v10, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gP:F

    iget-object v11, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jN:[F

    iget v12, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aget v11, v11, v12

    add-float/2addr v10, v11

    iput v10, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gP:F

    :cond_2
    iget v10, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    invoke-static {v3, v10}, Landroid/support/constraint/solver/widgets/ChainHead;->b(Landroid/support/constraint/solver/widgets/ConstraintWidget;I)Z

    move-result v10

    if-eqz v10, :cond_5

    cmpg-float v7, v7, v8

    if-gez v7, :cond_3

    iput-boolean v6, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gS:Z

    goto :goto_1

    :cond_3
    iput-boolean v6, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gT:Z

    :goto_1
    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gM:Ljava/util/ArrayList;

    if-nez v7, :cond_4

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iput-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gM:Ljava/util/ArrayList;

    :cond_4
    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gM:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gK:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-nez v7, :cond_6

    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gK:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :cond_6
    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gL:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v7, :cond_7

    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gL:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v7, v7, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jO:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v8, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aput-object v3, v7, v8

    :cond_7
    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gL:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :cond_8
    if-eq v5, v3, :cond_9

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jP:[Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v7, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    aput-object v3, v5, v7

    :cond_9
    iget-object v5, v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    add-int/lit8 v7, v0, 0x1

    aget-object v5, v5, v7

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v5, :cond_b

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v7, v5, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v7, v7, v0

    iget-object v7, v7, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v7, :cond_b

    iget-object v7, v5, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iQ:[Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    aget-object v7, v7, v0

    iget-object v7, v7, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v7, v7, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eq v7, v3, :cond_a

    goto :goto_2

    :cond_a
    move-object v9, v5

    :cond_b
    :goto_2
    if-eqz v9, :cond_c

    goto :goto_3

    :cond_c
    move-object v9, v3

    const/4 v2, 0x1

    :goto_3
    move-object v5, v3

    move-object v3, v9

    goto/16 :goto_0

    :cond_d
    iput-object v3, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gH:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gQ:I

    if-nez v0, :cond_e

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gR:Z

    if-eqz v0, :cond_e

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gH:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    goto :goto_4

    :cond_e
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :goto_4
    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gJ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gT:Z

    if-eqz v0, :cond_f

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gS:Z

    if-eqz v0, :cond_f

    const/4 v4, 0x1

    :cond_f
    iput-boolean v4, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gU:Z

    return-void
.end method

.method private static b(Landroid/support/constraint/solver/widgets/ConstraintWidget;I)Z
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getVisibility()I

    move-result v0

    const/16 v1, 0x8

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->iU:[Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    aget-object v0, v0, p1

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    aget v0, v0, p1

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/constraint/solver/widgets/ConstraintWidget;->ip:[I

    aget p0, p0, p1

    const/4 p1, 0x3

    if-ne p0, p1, :cond_1

    :cond_0
    const/4 p0, 0x1

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public an()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gF:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public ao()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gG:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public ap()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gH:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public aq()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gI:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public ar()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gJ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public as()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gK:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public at()Landroid/support/constraint/solver/widgets/ConstraintWidget;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gL:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-object v0
.end method

.method public au()F
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gP:F

    return v0
.end method

.method public av()V
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gV:Z

    if-nez v0, :cond_0

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ChainHead;->am()V

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/constraint/solver/widgets/ChainHead;->gV:Z

    return-void
.end method
