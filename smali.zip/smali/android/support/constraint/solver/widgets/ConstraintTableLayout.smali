.class public Landroid/support/constraint/solver/widgets/ConstraintTableLayout;
.super Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;,
        Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;
    }
.end annotation


# static fields
.field public static final ALIGN_CENTER:I = 0x0

.field public static final ALIGN_LEFT:I = 0x1

.field public static final ALIGN_RIGHT:I = 0x2

.field private static final hU:I = 0x3


# instance fields
.field private fl:I

.field private hN:Z

.field private hO:I

.field private hP:I

.field private hQ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;",
            ">;"
        }
    .end annotation
.end field

.field private hR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;",
            ">;"
        }
    .end annotation
.end field

.field private hS:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/Guideline;",
            ">;"
        }
    .end annotation
.end field

.field private hT:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/Guideline;",
            ">;"
        }
    .end annotation
.end field

.field private hV:Landroid/support/constraint/solver/LinearSystem;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    const/16 v0, 0x8

    iput v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hR:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    return-void
.end method

.method public constructor <init>(II)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;-><init>(II)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    const/16 p1, 0x8

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hR:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;-><init>(IIII)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    const/16 p1, 0x8

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hR:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    return-void
.end method

.method private aR()V
    .locals 7

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/Guideline;

    iget-object v4, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->bl()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ".VG"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Landroid/support/constraint/solver/widgets/Guideline;->a(Landroid/support/constraint/solver/LinearSystem;Ljava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_1
    if-ge v1, v0, :cond_2

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/Guideline;

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->bl()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ".HG"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Landroid/support/constraint/solver/widgets/Guideline;->a(Landroid/support/constraint/solver/LinearSystem;Ljava/lang/String;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method private aS()V
    .locals 6

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    int-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr v1, v0

    const/4 v0, 0x0

    move-object v2, p0

    move v3, v1

    :goto_0
    iget v4, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    if-ge v0, v4, :cond_1

    new-instance v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;

    invoke-direct {v4, p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;-><init>(Landroid/support/constraint/solver/widgets/ConstraintTableLayout;)V

    iput-object v2, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->hZ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v2, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    const/4 v5, 0x1

    sub-int/2addr v2, v5

    if-ge v0, v2, :cond_0

    new-instance v2, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-direct {v2}, Landroid/support/constraint/solver/widgets/Guideline;-><init>()V

    invoke-virtual {v2, v5}, Landroid/support/constraint/solver/widgets/Guideline;->setOrientation(I)V

    invoke-virtual {v2, p0}, Landroid/support/constraint/solver/widgets/Guideline;->d(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V

    float-to-int v5, v3

    invoke-virtual {v2, v5}, Landroid/support/constraint/solver/widgets/Guideline;->R(I)V

    add-float/2addr v3, v1

    iput-object v2, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ia:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    iput-object p0, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ia:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :goto_1
    iget-object v2, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ia:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aR()V

    return-void
.end method

.method private aT()V
    .locals 7

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hR:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    int-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr v1, v0

    const/4 v0, 0x0

    move-object v3, p0

    move v4, v1

    const/4 v2, 0x0

    :goto_0
    iget v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    if-ge v2, v5, :cond_1

    new-instance v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;

    invoke-direct {v5, p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;-><init>(Landroid/support/constraint/solver/widgets/ConstraintTableLayout;)V

    iput-object v3, v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hW:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    add-int/lit8 v3, v3, -0x1

    if-ge v2, v3, :cond_0

    new-instance v3, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-direct {v3}, Landroid/support/constraint/solver/widgets/Guideline;-><init>()V

    invoke-virtual {v3, v0}, Landroid/support/constraint/solver/widgets/Guideline;->setOrientation(I)V

    invoke-virtual {v3, p0}, Landroid/support/constraint/solver/widgets/Guideline;->d(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V

    float-to-int v6, v4

    invoke-virtual {v3, v6}, Landroid/support/constraint/solver/widgets/Guideline;->R(I)V

    add-float/2addr v4, v1

    iput-object v3, v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hX:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    iput-object p0, v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hX:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :goto_1
    iget-object v3, v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hX:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hR:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aR()V

    return-void
.end method

.method private aU()V
    .locals 11

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->lM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->lM:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bM()I

    move-result v4

    add-int/2addr v2, v4

    iget v4, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    rem-int v4, v2, v4

    iget v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    div-int v5, v2, v5

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hR:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;

    iget-object v6, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->hZ:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v7, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ia:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v8, v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hW:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$a;->hX:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    sget-object v9, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v9}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v9

    sget-object v10, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v6, v10}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    iget v10, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    invoke-virtual {v9, v6, v10}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;I)Z

    instance-of v6, v7, Landroid/support/constraint/solver/widgets/Guideline;

    if-eqz v6, :cond_0

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    sget-object v9, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    :goto_1
    invoke-virtual {v7, v9}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v7

    iget v9, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    invoke-virtual {v6, v7, v9}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;I)Z

    goto :goto_2

    :cond_0
    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    sget-object v9, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto :goto_1

    :goto_2
    iget v4, v4, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    packed-switch v4, :pswitch_data_0

    goto :goto_4

    :pswitch_0
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->ke:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;)V

    goto :goto_4

    :pswitch_1
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hr:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    invoke-virtual {v4, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;)V

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    goto :goto_3

    :pswitch_2
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    invoke-virtual {v4, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;)V

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hr:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    :goto_3
    invoke-virtual {v4, v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;)V

    :goto_4
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    sget-object v6, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v8, v6}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    iget v7, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    invoke-virtual {v4, v6, v7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;I)Z

    instance-of v4, v5, Landroid/support/constraint/solver/widgets/Guideline;

    if-eqz v4, :cond_1

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    :goto_5
    invoke-virtual {v5, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    iget v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    invoke-virtual {v3, v4, v5}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;I)Z

    goto :goto_6

    :cond_1
    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    goto :goto_5

    :goto_6
    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_2
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public a(Landroid/support/constraint/solver/LinearSystem;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hV:Landroid/support/constraint/solver/LinearSystem;

    invoke-super {p0, p1, p2}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->a(Landroid/support/constraint/solver/LinearSystem;Ljava/lang/String;)V

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aR()V

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    return-void
.end method

.method public aK()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    return v0
.end method

.method public aL()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    return v0
.end method

.method public aM()Ljava/lang/String;
    .locals 6

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const-string v1, ""

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_4

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;

    iget v4, v3, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    const/4 v5, 0x1

    if-ne v4, v5, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "L"

    :goto_1
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    :cond_0
    iget v4, v3, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    if-nez v4, :cond_1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "C"

    goto :goto_1

    :cond_1
    iget v4, v3, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    const/4 v5, 0x3

    if-ne v4, v5, :cond_2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "F"

    goto :goto_1

    :cond_2
    iget v3, v3, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    const/4 v4, 0x2

    if-ne v3, v4, :cond_3

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "R"

    goto :goto_1

    :cond_3
    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_4
    return-object v1
.end method

.method public aN()Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    return v0
.end method

.method public aO()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/Guideline;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    return-object v0
.end method

.method public aP()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroid/support/constraint/solver/widgets/Guideline;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    return-object v0
.end method

.method public aQ()V
    .locals 4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->lM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->lM:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->bM()I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    add-int/2addr v0, v2

    iget-boolean v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_4

    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    if-nez v1, :cond_1

    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->t(I)V

    :cond_1
    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    div-int v1, v0, v1

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    mul-int v3, v3, v1

    if-ge v3, v0, :cond_2

    add-int/lit8 v1, v1, 0x1

    :cond_2
    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    if-ne v0, v1, :cond_3

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    sub-int/2addr v3, v2

    if-ne v0, v3, :cond_3

    return-void

    :cond_3
    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aT()V

    goto :goto_1

    :cond_4
    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    if-nez v1, :cond_5

    invoke-virtual {p0, v2}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->u(I)V

    :cond_5
    iget v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    div-int v1, v0, v1

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    mul-int v3, v3, v1

    if-ge v3, v0, :cond_6

    add-int/lit8 v1, v1, 0x1

    :cond_6
    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    if-ne v0, v1, :cond_7

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    sub-int/2addr v3, v2

    if-ne v0, v3, :cond_7

    return-void

    :cond_7
    iput v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aS()V

    :goto_1
    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aU()V

    return-void
.end method

.method public aV()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public aW()V
    .locals 4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-virtual {v3}, Landroid/support/constraint/solver/widgets/Guideline;->cr()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_1
    if-ge v1, v0, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/Guideline;->cr()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    return-void
.end method

.method public c(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->c(Landroid/support/constraint/solver/LinearSystem;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->lM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aQ()V

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->kl:Landroid/support/constraint/solver/LinearSystem;

    if-ne p1, v1, :cond_5

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x1

    if-ge v3, v1, :cond_2

    iget-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->bR()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object v6

    sget-object v7, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v6, v7, :cond_1

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    :goto_1
    invoke-virtual {v5, v4}, Landroid/support/constraint/solver/widgets/Guideline;->e(Z)V

    invoke-virtual {v5, p1}, Landroid/support/constraint/solver/widgets/Guideline;->c(Landroid/support/constraint/solver/LinearSystem;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x0

    :goto_2
    if-ge v3, v1, :cond_4

    iget-object v5, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->bS()Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    move-result-object v6

    sget-object v7, Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;->kd:Landroid/support/constraint/solver/widgets/ConstraintWidget$DimensionBehaviour;

    if-ne v6, v7, :cond_3

    const/4 v6, 0x1

    goto :goto_3

    :cond_3
    const/4 v6, 0x0

    :goto_3
    invoke-virtual {v5, v6}, Landroid/support/constraint/solver/widgets/Guideline;->e(Z)V

    invoke-virtual {v5, p1}, Landroid/support/constraint/solver/widgets/Guideline;->c(Landroid/support/constraint/solver/LinearSystem;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    :goto_4
    if-ge v2, v0, :cond_5

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->lM:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v1, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->c(Landroid/support/constraint/solver/LinearSystem;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_5
    return-void
.end method

.method public d(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/support/constraint/solver/widgets/ConstraintWidgetContainer;->d(Landroid/support/constraint/solver/LinearSystem;)V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->kl:Landroid/support/constraint/solver/LinearSystem;

    if-ne p1, v0, :cond_1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hS:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-virtual {v3, p1}, Landroid/support/constraint/solver/widgets/Guideline;->d(Landroid/support/constraint/solver/LinearSystem;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_1
    if-ge v1, v0, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hT:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-virtual {v2, p1}, Landroid/support/constraint/solver/widgets/Guideline;->d(Landroid/support/constraint/solver/LinearSystem;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_4

    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x4c

    if-ne v3, v4, :cond_0

    const/4 v3, 0x1

    :goto_1
    invoke-virtual {p0, v2, v3}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->v(II)V

    goto :goto_2

    :cond_0
    const/16 v4, 0x43

    if-ne v3, v4, :cond_2

    :cond_1
    invoke-virtual {p0, v2, v1}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->v(II)V

    goto :goto_2

    :cond_2
    const/16 v4, 0x46

    if-ne v3, v4, :cond_3

    const/4 v3, 0x3

    goto :goto_1

    :cond_3
    const/16 v4, 0x52

    if-ne v3, v4, :cond_1

    const/4 v3, 0x2

    goto :goto_1

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_4
    return-void
.end method

.method public getNumRows()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    return v0
.end method

.method public getType()Ljava/lang/String;
    .locals 1

    const-string v0, "ConstraintTableLayout"

    return-object v0
.end method

.method public s(I)Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;

    iget v0, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const-string p1, "L"

    return-object p1

    :cond_0
    iget v0, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    if-nez v0, :cond_1

    const-string p1, "C"

    return-object p1

    :cond_1
    iget v0, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    const-string p1, "F"

    return-object p1

    :cond_2
    iget p1, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    const/4 v0, 0x2

    if-ne p1, v0, :cond_3

    const-string p1, "R"

    return-object p1

    :cond_3
    const-string p1, "!"

    return-object p1
.end method

.method public t(I)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    if-eqz v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    if-eq v0, p1, :cond_0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aS()V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aQ()V

    :cond_0
    return-void
.end method

.method public u(I)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hN:Z

    if-nez v0, :cond_0

    iget v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hO:I

    if-eq v0, p1, :cond_0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->fl:I

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aT()V

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aQ()V

    :cond_0
    return-void
.end method

.method public v(I)V
    .locals 1

    const/4 v0, 0x1

    if-le p1, v0, :cond_0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hP:I

    :cond_0
    return-void
.end method

.method public v(II)V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;

    iput p2, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aU()V

    :cond_0
    return-void
.end method

.method public w(I)V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->hQ:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;

    iget v0, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    packed-switch v0, :pswitch_data_0

    goto :goto_1

    :pswitch_0
    const/4 v0, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v0, 0x0

    goto :goto_0

    :pswitch_2
    const/4 v0, 0x2

    :goto_0
    iput v0, p1, Landroid/support/constraint/solver/widgets/ConstraintTableLayout$b;->ib:I

    :goto_1
    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ConstraintTableLayout;->aU()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
