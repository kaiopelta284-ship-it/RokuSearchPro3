.class Landroid/support/constraint/solver/widgets/Snapshot$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/solver/widgets/Snapshot;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field private hf:I

.field private kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field private lK:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

.field private lL:I


# direct methods
.method public constructor <init>(Landroid/support/constraint/solver/widgets/ConstraintAnchor;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v0

    iput v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->hf:I

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aB()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    move-result-object v0

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lK:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aE()I

    move-result p1

    iput p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lL:I

    return-void
.end method


# virtual methods
.method public l(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->az()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object p1

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object p1

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result p1

    iput p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->hf:I

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aB()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    move-result-object p1

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lK:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aE()I

    move-result p1

    :goto_0
    iput p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lL:I

    return-void

    :cond_0
    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->hf:I

    sget-object v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;->hq:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lK:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    goto :goto_0

    return-void
.end method

.method public m(Landroid/support/constraint/solver/widgets/ConstraintWidget;)V
    .locals 4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->kW:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->az()Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object p1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->he:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget v1, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->hf:I

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lK:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;

    iget v3, p0, Landroid/support/constraint/solver/widgets/Snapshot$a;->lL:I

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor;ILandroid/support/constraint/solver/widgets/ConstraintAnchor$Strength;I)Z

    return-void
.end method
