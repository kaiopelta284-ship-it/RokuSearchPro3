.class public Landroid/support/constraint/solver/widgets/ResolutionAnchor;
.super Landroid/support/constraint/solver/widgets/ResolutionNode;


# static fields
.field public static final lt:I = 0x0

.field public static final lu:I = 0x1

.field public static final lv:I = 0x2

.field public static final lw:I = 0x3

.field public static final lx:I = 0x4

.field public static final ly:I = 0x5


# instance fields
.field go:F

.field private lA:F

.field private lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

.field private lC:I

.field private lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

.field private lE:I

.field lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

.field lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

.field lq:F

.field lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

.field ls:F

.field private lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

.field type:I


# direct methods
.method public constructor <init>(Landroid/support/constraint/solver/widgets/ConstraintAnchor;)V
    .locals 2

    invoke-direct {p0}, Landroid/support/constraint/solver/widgets/ResolutionNode;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    const/4 v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lC:I

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lE:I

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    return-void
.end method


# virtual methods
.method U(I)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    const-string p1, "DIRECT"

    return-object p1

    :cond_0
    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    const-string p1, "CENTER"

    return-object p1

    :cond_1
    const/4 v0, 0x3

    if-ne p1, v0, :cond_2

    const-string p1, "MATCH"

    return-object p1

    :cond_2
    const/4 v0, 0x4

    if-ne p1, v0, :cond_3

    const-string p1, "CHAIN"

    return-object p1

    :cond_3
    const/4 v0, 0x5

    if-ne p1, v0, :cond_4

    const-string p1, "BARRIER"

    return-object p1

    :cond_4
    const-string p1, "UNCONNECTED"

    return-object p1
.end method

.method public a(ILandroid/support/constraint/solver/widgets/ResolutionAnchor;I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    iput-object p2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    int-to-float p1, p3

    iput p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    invoke-virtual {p1, p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(Landroid/support/constraint/solver/widgets/ResolutionNode;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ResolutionAnchor;F)V
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eq v0, p1, :cond_2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    cmpl-float v0, v0, p2

    if-eqz v0, :cond_2

    :cond_0
    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput p2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    const/4 p2, 0x1

    if-ne p1, p2, :cond_1

    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->invalidate()V

    :cond_1
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->cA()V

    :cond_2
    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ResolutionAnchor;I)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    int-to-float p1, p2

    iput p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    invoke-virtual {p1, p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(Landroid/support/constraint/solver/widgets/ResolutionNode;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ResolutionAnchor;ILandroid/support/constraint/solver/widgets/ResolutionDimension;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    invoke-virtual {p1, p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(Landroid/support/constraint/solver/widgets/ResolutionNode;)V

    iput-object p3, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iput p2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lC:I

    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    invoke-virtual {p1, p0}, Landroid/support/constraint/solver/widgets/ResolutionDimension;->a(Landroid/support/constraint/solver/widgets/ResolutionNode;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ResolutionDimension;)V
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    const/4 v1, 0x0

    if-ne v0, p1, :cond_0

    iput-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lC:I

    int-to-float p1, p1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-ne p1, v0, :cond_1

    iput-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lE:I

    int-to-float p1, p1

    iput p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lA:F

    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->al()V

    return-void
.end method

.method public al()V
    .locals 9

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return-void

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_1

    return-void

    :cond_1
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionDimension;->state:I

    if-eq v0, v1, :cond_2

    return-void

    :cond_2
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lC:I

    int-to-float v0, v0

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget v2, v2, Landroid/support/constraint/solver/widgets/ResolutionDimension;->value:F

    mul-float v0, v0, v2

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    :cond_3
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    if-eqz v0, :cond_5

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionDimension;->state:I

    if-eq v0, v1, :cond_4

    return-void

    :cond_4
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lE:I

    int-to-float v0, v0

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iget v2, v2, Landroid/support/constraint/solver/widgets/ResolutionDimension;->value:F

    mul-float v0, v0, v2

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lA:F

    :cond_5
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    if-ne v0, v1, :cond_8

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_6

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_8

    :cond_6
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-nez v0, :cond_7

    iput-object p0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    :goto_0
    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    goto :goto_1

    :cond_7
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    add-float/2addr v0, v1

    goto :goto_0

    :goto_1
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->cA()V

    return-void

    :cond_8
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    const/4 v2, 0x2

    const-wide/16 v3, 0x1

    if-ne v0, v2, :cond_11

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_11

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_11

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_11

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_11

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_11

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v0

    iget-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fO:J

    add-long v7, v5, v3

    iput-wide v7, v0, Landroid/support/constraint/solver/Metrics;->fO:J

    :cond_9
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput-object v2, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hd:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    const/4 v3, 0x0

    if-eq v0, v2, :cond_b

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hd:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v0, v2, :cond_a

    goto :goto_2

    :cond_a
    const/4 v1, 0x0

    :cond_b
    :goto_2
    if-eqz v1, :cond_c

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    :goto_3
    iget v2, v2, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    sub-float/2addr v0, v2

    goto :goto_4

    :cond_c
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    goto :goto_3

    :goto_4
    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hd:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v2, v4, :cond_e

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hd:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v2, v4, :cond_d

    goto :goto_5

    :cond_d
    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getHeight()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v0, v2

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v2, v2, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jq:F

    goto :goto_6

    :cond_e
    :goto_5
    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v2}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->getWidth()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v0, v2

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iget v2, v2, Landroid/support/constraint/solver/widgets/ConstraintWidget;->jp:F

    :goto_6
    iget-object v4, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v4}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v4

    iget-object v5, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v5, v5, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v5}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v5

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v6}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v6

    iget-object v7, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v7, v7, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v7}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v7

    if-ne v6, v7, :cond_f

    const/high16 v2, 0x3f000000    # 0.5f

    const/4 v5, 0x0

    goto :goto_7

    :cond_f
    move v3, v4

    :goto_7
    int-to-float v3, v3

    sub-float/2addr v0, v3

    int-to-float v4, v5

    sub-float/2addr v0, v4

    const/high16 v5, 0x3f800000    # 1.0f

    if-eqz v1, :cond_10

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v6, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v6, v6, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v6, v6, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    add-float/2addr v6, v4

    mul-float v4, v0, v2

    add-float/2addr v6, v4

    iput v6, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    sub-float/2addr v1, v3

    sub-float/2addr v5, v2

    mul-float v0, v0, v5

    sub-float/2addr v1, v0

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    goto :goto_8

    :cond_10
    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    add-float/2addr v1, v3

    mul-float v3, v0, v2

    add-float/2addr v1, v3

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v3, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v3, v3, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v3, v3, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    sub-float/2addr v3, v4

    sub-float/2addr v5, v2

    mul-float v0, v0, v5

    sub-float/2addr v3, v0

    iput v3, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    goto :goto_8

    :cond_11
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    const/4 v2, 0x3

    if-ne v0, v2, :cond_13

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_13

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_13

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_13

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-eqz v0, :cond_13

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    if-ne v0, v1, :cond_13

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v0

    if-eqz v0, :cond_12

    invoke-static {}, Landroid/support/constraint/solver/LinearSystem;->N()Landroid/support/constraint/solver/Metrics;

    move-result-object v0

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fP:J

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fP:J

    :cond_12
    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput-object v1, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v0, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    add-float/2addr v0, v1

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget v2, v2, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    add-float/2addr v1, v2

    iput v1, v0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    :goto_8
    invoke-virtual {p0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->cA()V

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->cA()V

    return-void

    :cond_13
    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_14

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v0, v0, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hc:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->al()V

    :cond_14
    return-void
.end method

.method public b(Landroid/support/constraint/solver/widgets/ResolutionAnchor;F)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput p2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lA:F

    return-void
.end method

.method public b(Landroid/support/constraint/solver/widgets/ResolutionAnchor;ILandroid/support/constraint/solver/widgets/ResolutionDimension;)V
    .locals 0

    iput-object p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput-object p3, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iput p2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lE:I

    return-void
.end method

.method public cy()F
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    return v0
.end method

.method g(Landroid/support/constraint/solver/LinearSystem;)V
    .locals 4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ax()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    const/high16 v2, 0x3f000000    # 0.5f

    if-nez v1, :cond_0

    iget v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    add-float/2addr v1, v2

    float-to-int v1, v1

    invoke-virtual {p1, v0, v1}, Landroid/support/constraint/solver/LinearSystem;->e(Landroid/support/constraint/solver/SolverVariable;I)V

    return-void

    :cond_0
    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iget-object v1, v1, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    iget v3, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    add-float/2addr v3, v2

    float-to-int v2, v3

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;

    return-void
.end method

.method public reset()V
    .locals 3

    invoke-super {p0}, Landroid/support/constraint/solver/widgets/ResolutionNode;->reset()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lp:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lq:F

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lB:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    const/4 v2, 0x1

    iput v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lC:I

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lD:Landroid/support/constraint/solver/widgets/ResolutionDimension;

    iput v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lE:I

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->go:F

    iput-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lz:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lA:F

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    return-void
.end method

.method public setType(I)V
    .locals 0

    iput p1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->state:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    if-ne v0, p0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "["

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", RESOLVED: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, "]  type: "

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    invoke-virtual {p0, v1}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->U(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "["

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", RESOLVED: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lr:Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->ls:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, "] type: "

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "{ "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " UNRESOLVED} type: "

    goto :goto_0
.end method

.method public update()V
    .locals 4

    iget-object v0, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aC()Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-ne v1, v2, :cond_1

    const/4 v1, 0x4

    iput v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v2

    iput v1, v2, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->type:I

    :cond_1
    iget-object v1, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {v1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aA()I

    move-result v1

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hd:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-eq v2, v3, :cond_2

    iget-object v2, p0, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->lo:Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    iget-object v2, v2, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->hd:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    if-ne v2, v3, :cond_3

    :cond_2
    neg-int v1, v1

    :cond_3
    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->aw()Landroid/support/constraint/solver/widgets/ResolutionAnchor;

    move-result-object v0

    invoke-virtual {p0, v0, v1}, Landroid/support/constraint/solver/widgets/ResolutionAnchor;->a(Landroid/support/constraint/solver/widgets/ResolutionAnchor;I)V

    return-void
.end method
