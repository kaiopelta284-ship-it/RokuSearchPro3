.class public Landroid/support/constraint/solver/ArrayLinkedVariables;
.super Ljava/lang/Object;


# static fields
.field private static final DEBUG:Z = false

.field private static final NONE:I = -0x1

.field private static final eF:Z


# instance fields
.field eG:I

.field private final eH:Landroid/support/constraint/solver/ArrayRow;

.field private final eI:Landroid/support/constraint/solver/Cache;

.field private eJ:I

.field private eK:Landroid/support/constraint/solver/SolverVariable;

.field private eL:[I

.field private eM:[I

.field private eN:[F

.field private eO:I

.field private eP:I

.field private eQ:Z


# direct methods
.method constructor <init>(Landroid/support/constraint/solver/ArrayRow;Landroid/support/constraint/solver/Cache;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    const/16 v1, 0x8

    iput v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eK:Landroid/support/constraint/solver/SolverVariable;

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    new-array v1, v1, [I

    iput-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    new-array v1, v1, [I

    iput-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    new-array v1, v1, [F

    iput-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    const/4 v1, -0x1

    iput v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    iput v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iput-boolean v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    iput-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    iput-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    return-void
.end method

.method private a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/LinearSystem;)Z
    .locals 0

    iget p1, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    const/4 p2, 0x1

    if-gt p1, p2, :cond_0

    return p2

    :cond_0
    const/4 p2, 0x0

    return p2
.end method


# virtual methods
.method E()Z
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v3, -0x1

    if-eq v0, v3, :cond_1

    iget v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v3, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v3, v3, v0

    const/4 v4, 0x0

    cmpl-float v3, v3, v4

    if-lez v3, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method F()V
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, -0x1

    if-eq v0, v2, :cond_0

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v3, v2, v0

    const/high16 v4, -0x40800000    # -1.0f

    mul-float v3, v3, v4

    aput v3, v2, v0

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method G()Landroid/support/constraint/solver/SolverVariable;
    .locals 6

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eK:Landroid/support/constraint/solver/SolverVariable;

    if-nez v0, :cond_3

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v3, -0x1

    if-eq v0, v3, :cond_2

    iget v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v1, v3, :cond_2

    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v3, v3, v0

    const/4 v4, 0x0

    cmpg-float v3, v3, v4

    if-gez v3, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v3, v3, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v4, v4, v0

    aget-object v3, v3, v4

    if-eqz v2, :cond_0

    iget v4, v2, Landroid/support/constraint/solver/SolverVariable;->gn:I

    iget v5, v3, Landroid/support/constraint/solver/SolverVariable;->gn:I

    if-ge v4, v5, :cond_1

    :cond_0
    move-object v2, v3

    :cond_1
    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v3, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-object v2

    :cond_3
    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eK:Landroid/support/constraint/solver/SolverVariable;

    return-object v0
.end method

.method H()I
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v0, v0

    mul-int/lit8 v0, v0, 0x4

    mul-int/lit8 v0, v0, 0x3

    add-int/lit8 v0, v0, 0x0

    add-int/lit8 v0, v0, 0x24

    return v0
.end method

.method public I()V
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v2, "{ "

    invoke-virtual {v1, v2}, Ljava/io/PrintStream;->print(Ljava/lang/String;)V

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    invoke-virtual {p0, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->i(I)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v2

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " = "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->j(I)F

    move-result v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/io/PrintStream;->print(Ljava/lang/String;)V

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, " }"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public final a(Landroid/support/constraint/solver/SolverVariable;Z)F
    .locals 8

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eK:Landroid/support/constraint/solver/SolverVariable;

    if-ne v0, p1, :cond_0

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eK:Landroid/support/constraint/solver/SolverVariable;

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    const/4 v2, -0x1

    if-ne v0, v2, :cond_1

    return v1

    :cond_1
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v3, 0x0

    const/4 v4, -0x1

    :goto_0
    if-eq v0, v2, :cond_6

    iget v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v3, v5, :cond_6

    iget-object v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v5, v5, v0

    iget v6, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ne v5, v6, :cond_5

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    if-ne v0, v1, :cond_2

    iget-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v1, v1, v0

    iput v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    goto :goto_1

    :cond_2
    iget-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v3, v3, v0

    aput v3, v1, v4

    :goto_1
    if-eqz p2, :cond_3

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->f(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_3
    iget p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    add-int/lit8 p2, p2, -0x1

    iput p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aput v2, p1, v0

    iget-boolean p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-eqz p1, :cond_4

    iput v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_4
    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget p1, p1, v0

    return p1

    :cond_5
    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v4, v4, v0

    add-int/lit8 v3, v3, 0x1

    move v7, v4

    move v4, v0

    move v0, v7

    goto :goto_0

    :cond_6
    return v1
.end method

.method a(Landroid/support/constraint/solver/LinearSystem;)Landroid/support/constraint/solver/SolverVariable;
    .locals 14

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v4, v1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    :goto_0
    const/4 v9, -0x1

    if-eq v0, v9, :cond_8

    iget v9, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v9, :cond_8

    iget-object v9, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v9, v9, v0

    const v10, 0x3a83126f    # 0.001f

    iget-object v11, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v11, v11, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v12, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v12, v12, v0

    aget-object v11, v11, v12

    cmpg-float v12, v9, v3

    if-gez v12, :cond_0

    const v10, -0x457ced91    # -0.001f

    cmpl-float v10, v9, v10

    if-lez v10, :cond_1

    iget-object v9, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aput v3, v9, v0

    :goto_1
    iget-object v9, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {v11, v9}, Landroid/support/constraint/solver/SolverVariable;->f(Landroid/support/constraint/solver/ArrayRow;)V

    const/4 v9, 0x0

    goto :goto_2

    :cond_0
    cmpg-float v10, v9, v10

    if-gez v10, :cond_1

    iget-object v9, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aput v3, v9, v0

    goto :goto_1

    :cond_1
    :goto_2
    cmpl-float v10, v9, v3

    const/4 v12, 0x1

    if-eqz v10, :cond_7

    iget-object v10, v11, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v13, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    if-ne v10, v13, :cond_4

    if-nez v1, :cond_2

    :goto_3
    invoke-direct {p0, v11, p1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/LinearSystem;)Z

    move-result v1

    move v6, v1

    move v5, v9

    move-object v1, v11

    goto :goto_5

    :cond_2
    cmpl-float v10, v5, v9

    if-lez v10, :cond_3

    goto :goto_3

    :cond_3
    if-nez v6, :cond_7

    invoke-direct {p0, v11, p1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/LinearSystem;)Z

    move-result v10

    if-eqz v10, :cond_7

    move v5, v9

    move-object v1, v11

    const/4 v6, 0x1

    goto :goto_5

    :cond_4
    if-nez v1, :cond_7

    cmpg-float v10, v9, v3

    if-gez v10, :cond_7

    if-nez v4, :cond_5

    :goto_4
    invoke-direct {p0, v11, p1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/LinearSystem;)Z

    move-result v4

    move v8, v4

    move v7, v9

    move-object v4, v11

    goto :goto_5

    :cond_5
    cmpl-float v10, v7, v9

    if-lez v10, :cond_6

    goto :goto_4

    :cond_6
    if-nez v8, :cond_7

    invoke-direct {p0, v11, p1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/LinearSystem;)Z

    move-result v10

    if-eqz v10, :cond_7

    move v7, v9

    move-object v4, v11

    const/4 v8, 0x1

    :cond_7
    :goto_5
    iget-object v9, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v9, v0

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_8
    if-eqz v1, :cond_9

    return-object v1

    :cond_9
    return-object v4
.end method

.method a([ZLandroid/support/constraint/solver/SolverVariable;)Landroid/support/constraint/solver/SolverVariable;
    .locals 8

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    const/4 v5, -0x1

    if-eq v0, v5, :cond_3

    iget v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v5, :cond_3

    iget-object v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v5, v5, v0

    cmpg-float v5, v5, v1

    if-gez v5, :cond_2

    iget-object v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v5, v5, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v6, v6, v0

    aget-object v5, v5, v6

    if-eqz p1, :cond_0

    iget v6, v5, Landroid/support/constraint/solver/SolverVariable;->id:I

    aget-boolean v6, p1, v6

    if-nez v6, :cond_2

    :cond_0
    if-eq v5, p2, :cond_2

    iget-object v6, v5, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v7, Landroid/support/constraint/solver/SolverVariable$Type;->gy:Landroid/support/constraint/solver/SolverVariable$Type;

    if-eq v6, v7, :cond_1

    iget-object v6, v5, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v7, Landroid/support/constraint/solver/SolverVariable$Type;->gz:Landroid/support/constraint/solver/SolverVariable$Type;

    if-ne v6, v7, :cond_2

    :cond_1
    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v6, v6, v0

    cmpg-float v7, v6, v4

    if-gez v7, :cond_2

    move-object v3, v5

    move v4, v6

    :cond_2
    iget-object v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v5, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-object v3
.end method

.method a(F)V
    .locals 4

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, -0x1

    if-eq v0, v2, :cond_0

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v3, v2, v0

    div-float/2addr v3, p1

    aput v3, v2, v0

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method final a(Landroid/support/constraint/solver/ArrayRow;Landroid/support/constraint/solver/ArrayRow;Z)V
    .locals 8

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x0

    :goto_1
    const/4 v3, -0x1

    if-eq v0, v3, :cond_3

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v4, :cond_3

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v4, v4, v0

    iget-object v5, p2, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget v5, v5, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ne v4, v5, :cond_2

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v0, v2, v0

    iget-object v2, p2, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {p0, v2, p3}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Z)F

    iget-object v2, p2, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    check-cast v2, Landroid/support/constraint/solver/ArrayLinkedVariables;

    iget v4, v2, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v5, 0x0

    :goto_2
    if-eq v4, v3, :cond_0

    iget v6, v2, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v5, v6, :cond_0

    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v6, v6, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v7, v2, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v7, v7, v4

    aget-object v6, v6, v7

    iget-object v7, v2, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v7, v7, v4

    mul-float v7, v7, v0

    invoke-virtual {p0, v6, v7, p3}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;FZ)V

    iget-object v6, v2, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v4, v6, v4

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_0
    iget v2, p1, Landroid/support/constraint/solver/ArrayRow;->eS:F

    iget v3, p2, Landroid/support/constraint/solver/ArrayRow;->eS:F

    mul-float v3, v3, v0

    add-float/2addr v2, v3

    iput v2, p1, Landroid/support/constraint/solver/ArrayRow;->eS:F

    if-eqz p3, :cond_1

    iget-object v0, p2, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/SolverVariable;->f(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_1
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    goto :goto_0

    :cond_2
    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method a(Landroid/support/constraint/solver/ArrayRow;[Landroid/support/constraint/solver/ArrayRow;)V
    .locals 10

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x0

    :goto_1
    const/4 v3, -0x1

    if-eq v0, v3, :cond_2

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v4, :cond_2

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v4, v4, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v5, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v5, v5, v0

    aget-object v4, v4, v5

    iget v5, v4, Landroid/support/constraint/solver/SolverVariable;->gm:I

    if-eq v5, v3, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v0, v2, v0

    const/4 v2, 0x1

    invoke-virtual {p0, v4, v2}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Z)F

    iget v4, v4, Landroid/support/constraint/solver/SolverVariable;->gm:I

    aget-object v4, p2, v4

    iget-boolean v5, v4, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-nez v5, :cond_0

    iget-object v5, v4, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    check-cast v5, Landroid/support/constraint/solver/ArrayLinkedVariables;

    iget v6, v5, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v7, 0x0

    :goto_2
    if-eq v6, v3, :cond_0

    iget v8, v5, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v7, v8, :cond_0

    iget-object v8, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v8, v8, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v9, v5, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v9, v9, v6

    aget-object v8, v8, v9

    iget-object v9, v5, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v9, v9, v6

    mul-float v9, v9, v0

    invoke-virtual {p0, v8, v9, v2}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;FZ)V

    iget-object v8, v5, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v6, v8, v6

    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_0
    iget v2, p1, Landroid/support/constraint/solver/ArrayRow;->eS:F

    iget v3, v4, Landroid/support/constraint/solver/ArrayRow;->eS:F

    mul-float v3, v3, v0

    add-float/2addr v2, v3

    iput v2, p1, Landroid/support/constraint/solver/ArrayRow;->eS:F

    iget-object v0, v4, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/SolverVariable;->f(Landroid/support/constraint/solver/ArrayRow;)V

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    goto :goto_0

    :cond_1
    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public final a(Landroid/support/constraint/solver/SolverVariable;F)V
    .locals 8

    const/4 v0, 0x0

    cmpl-float v0, p2, v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p0, p1, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/SolverVariable;Z)F

    return-void

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v2, 0x0

    const/4 v3, -0x1

    if-ne v0, v3, :cond_2

    iput v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    aput p2, v0, v2

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    iget v2, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    aput v2, p2, v0

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    aput v3, p2, v0

    iget p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    add-int/2addr p2, v1

    iput p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->e(Landroid/support/constraint/solver/ArrayRow;)V

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    add-int/2addr p1, v1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-boolean p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-nez p1, :cond_1

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    add-int/2addr p1, v1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p2, p2

    if-lt p1, p2, :cond_1

    iput-boolean v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p1, p1

    sub-int/2addr p1, v1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_1
    return-void

    :cond_2
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v4, 0x0

    const/4 v5, -0x1

    :goto_0
    if-eq v0, v3, :cond_5

    iget v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v4, v6, :cond_5

    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v6, v6, v0

    iget v7, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ne v6, v7, :cond_3

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aput p2, p1, v0

    return-void

    :cond_3
    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v6, v6, v0

    iget v7, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ge v6, v7, :cond_4

    move v5, v0

    :cond_4
    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v6, v0

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_5
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    add-int/2addr v0, v1

    iget-boolean v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-eqz v4, :cond_7

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    aget v0, v0, v4

    if-ne v0, v3, :cond_6

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    goto :goto_1

    :cond_6
    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v0, v0

    :cond_7
    :goto_1
    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v4, v4

    if-lt v0, v4, :cond_9

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v6, v6

    if-ge v4, v6, :cond_9

    const/4 v4, 0x0

    :goto_2
    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v6, v6

    if-ge v4, v6, :cond_9

    iget-object v6, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v6, v6, v4

    if-ne v6, v3, :cond_8

    move v0, v4

    goto :goto_3

    :cond_8
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_9
    :goto_3
    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v4, v4

    if-lt v0, v4, :cond_a

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v0, v0

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    mul-int/lit8 v4, v4, 0x2

    iput v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    iput-boolean v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    add-int/lit8 v2, v0, -0x1

    iput v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    invoke-static {v2, v4}, Ljava/util/Arrays;->copyOf([FI)[F

    move-result-object v2

    iput-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    invoke-static {v2, v4}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v2

    iput-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    invoke-static {v2, v4}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v2

    iput-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    :cond_a
    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v4, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    aput v4, v2, v0

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aput p2, v2, v0

    if-eq v5, v3, :cond_b

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v2, v2, v5

    aput v2, p2, v0

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aput v0, p2, v5

    goto :goto_4

    :cond_b
    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    aput v2, p2, v0

    iput v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    :goto_4
    iget p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    add-int/2addr p2, v1

    iput p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->e(Landroid/support/constraint/solver/ArrayRow;)V

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    add-int/2addr p1, v1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-boolean p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-nez p1, :cond_c

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    add-int/2addr p1, v1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_c
    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p2, p2

    if-lt p1, p2, :cond_d

    iput-boolean v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    :cond_d
    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p2, p2

    if-lt p1, p2, :cond_e

    iput-boolean v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p1, p1

    sub-int/2addr p1, v1

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_e
    return-void
.end method

.method final a(Landroid/support/constraint/solver/SolverVariable;FZ)V
    .locals 9

    const/4 v0, 0x0

    cmpl-float v1, p2, v0

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v2, 0x0

    const/4 v3, -0x1

    const/4 v4, 0x1

    if-ne v1, v3, :cond_2

    iput v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    iget-object p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    aput p2, p3, v0

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    iget v0, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    aput v0, p2, p3

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    aput v3, p2, p3

    iget p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    add-int/2addr p2, v4

    iput p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->e(Landroid/support/constraint/solver/ArrayRow;)V

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    add-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-boolean p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-nez p1, :cond_1

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    add-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p2, p2

    if-lt p1, p2, :cond_1

    iput-boolean v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p1, p1

    sub-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_1
    return-void

    :cond_2
    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v5, 0x0

    const/4 v6, -0x1

    :goto_0
    if-eq v1, v3, :cond_9

    iget v7, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v5, v7, :cond_9

    iget-object v7, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v7, v7, v1

    iget v8, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ne v7, v8, :cond_7

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v3, v2, v1

    add-float/2addr v3, p2

    aput v3, v2, v1

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget p2, p2, v1

    cmpl-float p2, p2, v0

    if-nez p2, :cond_6

    iget p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    if-ne v1, p2, :cond_3

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget p2, p2, v1

    iput p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    goto :goto_1

    :cond_3
    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v0, v1

    aput v0, p2, v6

    :goto_1
    if-eqz p3, :cond_4

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->f(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_4
    iget-boolean p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-eqz p2, :cond_5

    iput v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_5
    iget p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    sub-int/2addr p2, v4

    iput p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    sub-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    :cond_6
    return-void

    :cond_7
    iget-object v7, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v7, v7, v1

    iget v8, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ge v7, v8, :cond_8

    move v6, v1

    :cond_8
    iget-object v7, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v1, v7, v1

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_9
    iget p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    add-int/2addr p3, v4

    iget-boolean v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-eqz v0, :cond_b

    iget-object p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    aget p3, p3, v0

    if-ne p3, v3, :cond_a

    iget p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    goto :goto_2

    :cond_a
    iget-object p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p3, p3

    :cond_b
    :goto_2
    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v0, v0

    if-lt p3, v0, :cond_d

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v1, v1

    if-ge v0, v1, :cond_d

    const/4 v0, 0x0

    :goto_3
    iget-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v1, v1

    if-ge v0, v1, :cond_d

    iget-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v1, v1, v0

    if-ne v1, v3, :cond_c

    move p3, v0

    goto :goto_4

    :cond_c
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_d
    :goto_4
    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length v0, v0

    if-lt p3, v0, :cond_e

    iget-object p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p3, p3

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    iput-boolean v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    add-int/lit8 v0, p3, -0x1

    iput v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([FI)[F

    move-result-object v0

    iput-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    iput-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eJ:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    iput-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    :cond_e
    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    iget v1, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    aput v1, v0, p3

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aput p2, v0, p3

    if-eq v6, v3, :cond_f

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v0, v6

    aput v0, p2, p3

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aput p3, p2, v6

    goto :goto_5

    :cond_f
    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    aput v0, p2, p3

    iput p3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    :goto_5
    iget p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    add-int/2addr p2, v4

    iput p2, p1, Landroid/support/constraint/solver/SolverVariable;->gu:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p1, p2}, Landroid/support/constraint/solver/SolverVariable;->e(Landroid/support/constraint/solver/ArrayRow;)V

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    add-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    iget-boolean p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    if-nez p1, :cond_10

    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    add-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_10
    iget p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iget-object p2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p2, p2

    if-lt p1, p2, :cond_11

    iput-boolean v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    array-length p1, p1

    sub-int/2addr p1, v4

    iput p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    :cond_11
    return-void
.end method

.method final a(Landroid/support/constraint/solver/SolverVariable;)Z
    .locals 6

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    return v2

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v3, 0x0

    :goto_0
    if-eq v0, v1, :cond_2

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v3, v4, :cond_2

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v4, v4, v0

    iget v5, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ne v4, v5, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v4, v0

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    return v2
.end method

.method public final b(Landroid/support/constraint/solver/SolverVariable;)F
    .locals 4

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, -0x1

    if-eq v0, v2, :cond_1

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v2, v2, v0

    iget v3, p1, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-ne v2, v3, :cond_0

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget p1, p1, v0

    return p1

    :cond_0
    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final clear()V
    .locals 5

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v3, -0x1

    if-eq v0, v3, :cond_1

    iget v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v4, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v3, v3, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v4, v4, v0

    aget-object v3, v3, v4

    if-eqz v3, :cond_0

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eH:Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {v3, v4}, Landroid/support/constraint/solver/SolverVariable;->f(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_0
    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v3, v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iput v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    iput v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eP:I

    iput-boolean v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eQ:Z

    iput v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    return-void
.end method

.method final i(I)Landroid/support/constraint/solver/SolverVariable;
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, -0x1

    if-eq v0, v2, :cond_1

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v1, v2, :cond_1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object p1, p1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v0, v1, v0

    aget-object p1, p1, v0

    return-object p1

    :cond_0
    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method final j(I)F
    .locals 3

    iget v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, -0x1

    if-eq v0, v2, :cond_1

    iget v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v1, v2, :cond_1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget p1, p1, v0

    return p1

    :cond_0
    iget-object v2, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v0, v2, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const-string v0, ""

    iget v1, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eO:I

    const/4 v2, 0x0

    :goto_0
    const/4 v3, -0x1

    if-eq v1, v3, :cond_0

    iget v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-ge v2, v3, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " -> "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eN:[F

    aget v0, v0, v1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v0, " : "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v0, v0, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget-object v4, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eL:[I

    aget v4, v4, v1

    aget-object v0, v0, v4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v3, p0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eM:[I

    aget v1, v3, v1

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method
