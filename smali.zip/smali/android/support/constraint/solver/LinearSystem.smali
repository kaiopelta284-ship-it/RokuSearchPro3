.class public Landroid/support/constraint/solver/LinearSystem;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/constraint/solver/LinearSystem$a;
    }
.end annotation


# static fields
.field private static final DEBUG:Z = false

.field public static final fa:Z = false

.field private static fb:I = 0x3e8

.field public static fq:Landroid/support/constraint/solver/Metrics;


# instance fields
.field final eI:Landroid/support/constraint/solver/Cache;

.field fc:I

.field private fd:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Landroid/support/constraint/solver/SolverVariable;",
            ">;"
        }
    .end annotation
.end field

.field private fe:Landroid/support/constraint/solver/LinearSystem$a;

.field private ff:I

.field private fg:I

.field fh:[Landroid/support/constraint/solver/ArrayRow;

.field public fi:Z

.field private fj:[Z

.field fk:I

.field fl:I

.field private fm:I

.field private fn:[Landroid/support/constraint/solver/SolverVariable;

.field private fo:I

.field private fp:[Landroid/support/constraint/solver/ArrayRow;

.field private final fr:Landroid/support/constraint/solver/LinearSystem$a;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    const/16 v2, 0x20

    iput v2, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iput v2, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    iput-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    iput-boolean v0, p0, Landroid/support/constraint/solver/LinearSystem;->fi:Z

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    new-array v1, v1, [Z

    iput-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    const/4 v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fm:I

    sget v1, Landroid/support/constraint/solver/LinearSystem;->fb:I

    new-array v1, v1, [Landroid/support/constraint/solver/SolverVariable;

    iput-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fn:[Landroid/support/constraint/solver/SolverVariable;

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fo:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    new-array v0, v0, [Landroid/support/constraint/solver/ArrayRow;

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fp:[Landroid/support/constraint/solver/ArrayRow;

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    new-array v0, v0, [Landroid/support/constraint/solver/ArrayRow;

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->P()V

    new-instance v0, Landroid/support/constraint/solver/Cache;

    invoke-direct {v0}, Landroid/support/constraint/solver/Cache;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    new-instance v0, Landroid/support/constraint/solver/GoalRow;

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    invoke-direct {v0, v1}, Landroid/support/constraint/solver/GoalRow;-><init>(Landroid/support/constraint/solver/Cache;)V

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    new-instance v0, Landroid/support/constraint/solver/ArrayRow;

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    invoke-direct {v0, v1}, Landroid/support/constraint/solver/ArrayRow;-><init>(Landroid/support/constraint/solver/Cache;)V

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fr:Landroid/support/constraint/solver/LinearSystem$a;

    return-void
.end method

.method public static N()Landroid/support/constraint/solver/Metrics;
    .locals 1

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    return-object v0
.end method

.method private O()V
    .locals 7

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroid/support/constraint/solver/ArrayRow;

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v1, v1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Landroid/support/constraint/solver/SolverVariable;

    iput-object v1, v0, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    new-array v0, v0, [Z

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fm:I

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fv:J

    const-wide/16 v3, 0x1

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fv:J

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    sget-object v1, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v1, Landroid/support/constraint/solver/Metrics;->fH:J

    iget v3, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    int-to-long v3, v3

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    iput-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fH:J

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    sget-object v1, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v1, Landroid/support/constraint/solver/Metrics;->fH:J

    iput-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fV:J

    :cond_0
    return-void
.end method

.method private P()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v1, v1, v0

    if-eqz v1, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v2, v2, Landroid/support/constraint/solver/Cache;->eX:Landroid/support/constraint/solver/a$a;

    invoke-interface {v2, v1}, Landroid/support/constraint/solver/a$a;->c(Ljava/lang/Object;)Z

    :cond_0
    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    const/4 v2, 0x0

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private V()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v1, v1, v0

    iget-object v2, v1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget v1, v1, Landroid/support/constraint/solver/ArrayRow;->eS:F

    iput v1, v2, Landroid/support/constraint/solver/SolverVariable;->go:F

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private W()V
    .locals 3

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->ad()V

    const-string v0, ""

    const/4 v1, 0x0

    :goto_0
    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v1, v2, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v0, v0, v1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method private final a(Landroid/support/constraint/solver/LinearSystem$a;Z)I
    .locals 13

    sget-object p2, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    const-wide/16 v0, 0x1

    if-eqz p2, :cond_0

    sget-object p2, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v2, p2, Landroid/support/constraint/solver/Metrics;->fz:J

    add-long v4, v2, v0

    iput-wide v4, p2, Landroid/support/constraint/solver/Metrics;->fz:J

    :cond_0
    const/4 p2, 0x0

    const/4 v2, 0x0

    :goto_0
    iget v3, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    if-ge v2, v3, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    aput-boolean p2, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_1
    if-nez v2, :cond_d

    sget-object v4, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v4, :cond_2

    sget-object v4, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v5, v4, Landroid/support/constraint/solver/Metrics;->fA:J

    add-long v7, v5, v0

    iput-wide v7, v4, Landroid/support/constraint/solver/Metrics;->fA:J

    :cond_2
    add-int/lit8 v3, v3, 0x1

    iget v4, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    mul-int/lit8 v4, v4, 0x2

    if-lt v3, v4, :cond_3

    return v3

    :cond_3
    invoke-interface {p1}, Landroid/support/constraint/solver/LinearSystem$a;->M()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v4

    const/4 v5, 0x1

    if-eqz v4, :cond_4

    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    invoke-interface {p1}, Landroid/support/constraint/solver/LinearSystem$a;->M()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v6

    iget v6, v6, Landroid/support/constraint/solver/SolverVariable;->id:I

    aput-boolean v5, v4, v6

    :cond_4
    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    invoke-interface {p1, p0, v4}, Landroid/support/constraint/solver/LinearSystem$a;->a(Landroid/support/constraint/solver/LinearSystem;[Z)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v4

    if-eqz v4, :cond_6

    iget-object v6, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    iget v7, v4, Landroid/support/constraint/solver/SolverVariable;->id:I

    aget-boolean v6, v6, v7

    if-eqz v6, :cond_5

    return v3

    :cond_5
    iget-object v6, p0, Landroid/support/constraint/solver/LinearSystem;->fj:[Z

    iget v7, v4, Landroid/support/constraint/solver/SolverVariable;->id:I

    aput-boolean v5, v6, v7

    :cond_6
    if-eqz v4, :cond_c

    const v6, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v7, -0x1

    const/4 v6, 0x0

    const/4 v8, -0x1

    const v9, 0x7f7fffff    # Float.MAX_VALUE

    :goto_2
    iget v10, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v6, v10, :cond_a

    iget-object v10, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v10, v10, v6

    iget-object v11, v10, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget-object v11, v11, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v12, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    if-ne v11, v12, :cond_7

    goto :goto_3

    :cond_7
    iget-boolean v11, v10, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-eqz v11, :cond_8

    goto :goto_3

    :cond_8
    invoke-virtual {v10, v4}, Landroid/support/constraint/solver/ArrayRow;->c(Landroid/support/constraint/solver/SolverVariable;)Z

    move-result v11

    if-eqz v11, :cond_9

    iget-object v11, v10, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {v11, v4}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result v11

    const/4 v12, 0x0

    cmpg-float v12, v11, v12

    if-gez v12, :cond_9

    iget v10, v10, Landroid/support/constraint/solver/ArrayRow;->eS:F

    neg-float v10, v10

    div-float/2addr v10, v11

    cmpg-float v11, v10, v9

    if-gez v11, :cond_9

    move v8, v6

    move v9, v10

    :cond_9
    :goto_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_a
    if-le v8, v7, :cond_c

    iget-object v5, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v5, v5, v8

    iget-object v6, v5, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iput v7, v6, Landroid/support/constraint/solver/SolverVariable;->gm:I

    sget-object v6, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v6, :cond_b

    sget-object v6, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v9, v6, Landroid/support/constraint/solver/Metrics;->fB:J

    add-long v11, v9, v0

    iput-wide v11, v6, Landroid/support/constraint/solver/Metrics;->fB:J

    :cond_b
    invoke-virtual {v5, v4}, Landroid/support/constraint/solver/ArrayRow;->e(Landroid/support/constraint/solver/SolverVariable;)V

    iget-object v4, v5, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iput v8, v4, Landroid/support/constraint/solver/SolverVariable;->gm:I

    iget-object v4, v5, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {v4, v5}, Landroid/support/constraint/solver/SolverVariable;->g(Landroid/support/constraint/solver/ArrayRow;)V

    goto/16 :goto_1

    :cond_c
    const/4 v2, 0x1

    goto/16 :goto_1

    :cond_d
    return v3
.end method

.method public static a(Landroid/support/constraint/solver/LinearSystem;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IFLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IZ)Landroid/support/constraint/solver/ArrayRow;
    .locals 9

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v8

    move-object v0, v8

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    move-object v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IFLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p8, :cond_0

    const/4 v0, 0x4

    move-object v1, p0

    invoke-virtual {v8, v1, v0}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/LinearSystem;I)Landroid/support/constraint/solver/ArrayRow;

    :cond_0
    return-object v8
.end method

.method public static a(Landroid/support/constraint/solver/LinearSystem;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IZ)Landroid/support/constraint/solver/ArrayRow;
    .locals 1

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p4, :cond_0

    const/4 p1, 0x1

    invoke-direct {p0, v0, p1}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;I)V

    :cond_0
    return-object v0
.end method

.method public static a(Landroid/support/constraint/solver/LinearSystem;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;FZ)Landroid/support/constraint/solver/ArrayRow;
    .locals 1

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    if-eqz p5, :cond_0

    invoke-direct {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_0
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;F)Landroid/support/constraint/solver/ArrayRow;

    move-result-object p0

    return-object p0
.end method

.method private a(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)Landroid/support/constraint/solver/SolverVariable;
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v0, v0, Landroid/support/constraint/solver/Cache;->eY:Landroid/support/constraint/solver/a$a;

    invoke-interface {v0}, Landroid/support/constraint/solver/a$a;->af()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/SolverVariable;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/constraint/solver/SolverVariable;

    invoke-direct {v0, p1, p2}, Landroid/support/constraint/solver/SolverVariable;-><init>(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)V

    :goto_0
    invoke-virtual {v0, p1, p2}, Landroid/support/constraint/solver/SolverVariable;->c(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)V

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Landroid/support/constraint/solver/SolverVariable;->reset()V

    goto :goto_0

    :goto_1
    iget p1, p0, Landroid/support/constraint/solver/LinearSystem;->fo:I

    sget p2, Landroid/support/constraint/solver/LinearSystem;->fb:I

    if-lt p1, p2, :cond_1

    sget p1, Landroid/support/constraint/solver/LinearSystem;->fb:I

    mul-int/lit8 p1, p1, 0x2

    sput p1, Landroid/support/constraint/solver/LinearSystem;->fb:I

    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->fn:[Landroid/support/constraint/solver/SolverVariable;

    sget p2, Landroid/support/constraint/solver/LinearSystem;->fb:I

    invoke-static {p1, p2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Landroid/support/constraint/solver/SolverVariable;

    iput-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->fn:[Landroid/support/constraint/solver/SolverVariable;

    :cond_1
    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->fn:[Landroid/support/constraint/solver/SolverVariable;

    iget p2, p0, Landroid/support/constraint/solver/LinearSystem;->fo:I

    add-int/lit8 v1, p2, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fo:I

    aput-object v0, p1, p2

    return-object v0
.end method

.method private a(Ljava/lang/String;Landroid/support/constraint/solver/SolverVariable$Type;)Landroid/support/constraint/solver/SolverVariable;
    .locals 7

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fD:J

    const-wide/16 v3, 0x1

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fD:J

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    if-lt v0, v1, :cond_1

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->O()V

    :cond_1
    const/4 v0, 0x0

    invoke-direct {p0, p2, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object p2

    invoke-virtual {p2, p1}, Landroid/support/constraint/solver/SolverVariable;->setName(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iput v0, p2, Landroid/support/constraint/solver/SolverVariable;->id:I

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    if-nez v0, :cond_2

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    :cond_2
    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object p1, p1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    aput-object p2, p1, v0

    return-object p2
.end method

.method private a(Landroid/support/constraint/solver/ArrayRow;)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/LinearSystem;I)Landroid/support/constraint/solver/ArrayRow;

    return-void
.end method

.method private a(Landroid/support/constraint/solver/ArrayRow;I)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;II)V

    return-void
.end method

.method private ad()V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Display Rows ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public static b(Landroid/support/constraint/solver/LinearSystem;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IZ)Landroid/support/constraint/solver/ArrayRow;
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v1

    invoke-virtual {v1, p1, p2, v0, p3}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p4, :cond_0

    iget-object p1, v1, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    invoke-direct {p0, v1, p1}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;I)V

    :cond_0
    return-object v1
.end method

.method private final b(Landroid/support/constraint/solver/ArrayRow;)V
    .locals 2

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-lez v0, :cond_0

    iget-object v0, p1, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {v0, p1, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->a(Landroid/support/constraint/solver/ArrayRow;[Landroid/support/constraint/solver/ArrayRow;)V

    iget-object v0, p1, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    iget v0, v0, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p1, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    :cond_0
    return-void
.end method

.method private c(Landroid/support/constraint/solver/LinearSystem$a;)I
    .locals 19

    move-object/from16 v0, p0

    const/4 v2, 0x0

    :goto_0
    iget v3, v0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    const/4 v4, 0x0

    if-ge v2, v3, :cond_2

    iget-object v3, v0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v3, v3, v2

    iget-object v3, v3, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget-object v3, v3, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v6, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    if-ne v3, v6, :cond_0

    goto :goto_1

    :cond_0
    iget-object v3, v0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v3, v3, v2

    iget v3, v3, Landroid/support/constraint/solver/ArrayRow;->eS:F

    cmpg-float v3, v3, v4

    if-gez v3, :cond_1

    const/4 v2, 0x1

    goto :goto_2

    :cond_1
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    :goto_2
    if-eqz v2, :cond_11

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_3
    if-nez v2, :cond_10

    sget-object v6, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    const-wide/16 v7, 0x1

    if-eqz v6, :cond_3

    sget-object v6, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v9, v6, Landroid/support/constraint/solver/Metrics;->fC:J

    add-long v11, v9, v7

    iput-wide v11, v6, Landroid/support/constraint/solver/Metrics;->fC:J

    :cond_3
    add-int/lit8 v3, v3, 0x1

    const v6, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v9, -0x1

    const/4 v6, 0x0

    const/4 v10, -0x1

    const/4 v11, -0x1

    const v12, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v13, 0x0

    :goto_4
    iget v14, v0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v6, v14, :cond_c

    iget-object v14, v0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v14, v14, v6

    iget-object v15, v14, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget-object v15, v15, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v1, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    if-ne v15, v1, :cond_4

    goto :goto_8

    :cond_4
    iget-boolean v1, v14, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-eqz v1, :cond_5

    goto :goto_8

    :cond_5
    iget v1, v14, Landroid/support/constraint/solver/ArrayRow;->eS:F

    cmpg-float v1, v1, v4

    if-gez v1, :cond_b

    const/4 v1, 0x1

    :goto_5
    iget v15, v0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    if-ge v1, v15, :cond_b

    iget-object v15, v0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v15, v15, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    aget-object v15, v15, v1

    iget-object v5, v14, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {v5, v15}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result v5

    cmpg-float v17, v5, v4

    if-gtz v17, :cond_6

    goto :goto_7

    :cond_6
    move v4, v13

    move v13, v12

    move v12, v11

    move v11, v10

    const/4 v10, 0x0

    :goto_6
    const/4 v7, 0x7

    if-ge v10, v7, :cond_a

    iget-object v7, v15, Landroid/support/constraint/solver/SolverVariable;->gq:[F

    aget v7, v7, v10

    div-float/2addr v7, v5

    cmpg-float v8, v7, v13

    if-gez v8, :cond_7

    if-eq v10, v4, :cond_8

    :cond_7
    if-le v10, v4, :cond_9

    :cond_8
    move v12, v1

    move v11, v6

    move v13, v7

    move v4, v10

    :cond_9
    add-int/lit8 v10, v10, 0x1

    goto :goto_6

    :cond_a
    move v10, v11

    move v11, v12

    move v12, v13

    move v13, v4

    :goto_7
    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const-wide/16 v7, 0x1

    goto :goto_5

    :cond_b
    :goto_8
    add-int/lit8 v6, v6, 0x1

    const/4 v4, 0x0

    const-wide/16 v7, 0x1

    goto :goto_4

    :cond_c
    if-eq v10, v9, :cond_e

    iget-object v1, v0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v1, v1, v10

    iget-object v4, v1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iput v9, v4, Landroid/support/constraint/solver/SolverVariable;->gm:I

    sget-object v4, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v4, :cond_d

    sget-object v4, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v5, v4, Landroid/support/constraint/solver/Metrics;->fB:J

    const-wide/16 v7, 0x1

    add-long v12, v5, v7

    iput-wide v12, v4, Landroid/support/constraint/solver/Metrics;->fB:J

    :cond_d
    iget-object v4, v0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v4, v4, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    aget-object v4, v4, v11

    invoke-virtual {v1, v4}, Landroid/support/constraint/solver/ArrayRow;->e(Landroid/support/constraint/solver/SolverVariable;)V

    iget-object v4, v1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iput v10, v4, Landroid/support/constraint/solver/SolverVariable;->gm:I

    iget-object v4, v1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {v4, v1}, Landroid/support/constraint/solver/SolverVariable;->g(Landroid/support/constraint/solver/ArrayRow;)V

    goto :goto_9

    :cond_e
    const/4 v2, 0x1

    :goto_9
    iget v1, v0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    div-int/lit8 v1, v1, 0x2

    if-le v3, v1, :cond_f

    const/4 v2, 0x1

    :cond_f
    const/4 v4, 0x0

    goto/16 :goto_3

    :cond_10
    move/from16 v16, v3

    return v16

    :cond_11
    const/16 v16, 0x0

    return v16
.end method

.method public static c(Landroid/support/constraint/solver/LinearSystem;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IZ)Landroid/support/constraint/solver/ArrayRow;
    .locals 2

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v1

    invoke-virtual {v1, p1, p2, v0, p3}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p4, :cond_0

    iget-object p1, v1, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    invoke-direct {p0, v1, p1}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;I)V

    :cond_0
    return-object v1
.end method

.method private final d(Landroid/support/constraint/solver/ArrayRow;)V
    .locals 3

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    aget-object v0, v0, v1

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v0, v0, Landroid/support/constraint/solver/Cache;->eX:Landroid/support/constraint/solver/a$a;

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    aget-object v1, v1, v2

    invoke-interface {v0, v1}, Landroid/support/constraint/solver/a$a;->c(Ljava/lang/Object;)Z

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    aput-object p1, v0, v1

    iget-object v0, p1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    iput v1, v0, Landroid/support/constraint/solver/SolverVariable;->gm:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    iget-object v0, p1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/SolverVariable;->g(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method private l(I)Ljava/lang/String;
    .locals 2

    mul-int/lit8 p1, p1, 0x4

    div-int/lit16 v0, p1, 0x400

    div-int/lit16 v1, v0, 0x400

    if-lez v1, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " Mb"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    if-lez v0, :cond_1

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, ""

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " Kb"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " bytes"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private m(I)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    const-string p1, "LOW"

    return-object p1

    :cond_0
    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    const-string p1, "MEDIUM"

    return-object p1

    :cond_1
    const/4 v0, 0x3

    if-ne p1, v0, :cond_2

    const-string p1, "HIGH"

    return-object p1

    :cond_2
    const/4 v0, 0x4

    if-ne p1, v0, :cond_3

    const-string p1, "HIGHEST"

    return-object p1

    :cond_3
    const/4 v0, 0x5

    if-ne p1, v0, :cond_4

    const-string p1, "EQUALITY"

    return-object p1

    :cond_4
    const/4 v0, 0x6

    if-ne p1, v0, :cond_5

    const-string p1, "FIXED"

    return-object p1

    :cond_5
    const-string p1, "NONE"

    return-object p1
.end method


# virtual methods
.method public Q()Landroid/support/constraint/solver/ArrayRow;
    .locals 2

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v0, v0, Landroid/support/constraint/solver/Cache;->eX:Landroid/support/constraint/solver/a$a;

    invoke-interface {v0}, Landroid/support/constraint/solver/a$a;->af()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/ArrayRow;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/constraint/solver/ArrayRow;

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    invoke-direct {v0, v1}, Landroid/support/constraint/solver/ArrayRow;-><init>(Landroid/support/constraint/solver/Cache;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/support/constraint/solver/ArrayRow;->reset()V

    :goto_0
    invoke-static {}, Landroid/support/constraint/solver/SolverVariable;->ag()V

    return-object v0
.end method

.method public R()Landroid/support/constraint/solver/SolverVariable;
    .locals 7

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fF:J

    const-wide/16 v3, 0x1

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fF:J

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    if-lt v0, v1, :cond_1

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->O()V

    :cond_1
    sget-object v0, Landroid/support/constraint/solver/SolverVariable$Type;->gy:Landroid/support/constraint/solver/SolverVariable$Type;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iput v1, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v1, v1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    aput-object v0, v1, v2

    return-object v0
.end method

.method public S()Landroid/support/constraint/solver/SolverVariable;
    .locals 7

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fG:J

    const-wide/16 v3, 0x1

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fG:J

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    if-lt v0, v1, :cond_1

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->O()V

    :cond_1
    sget-object v0, Landroid/support/constraint/solver/SolverVariable$Type;->gy:Landroid/support/constraint/solver/SolverVariable$Type;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iput v1, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v1, v1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    aput-object v0, v1, v2

    return-object v0
.end method

.method T()Landroid/support/constraint/solver/LinearSystem$a;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    return-object v0
.end method

.method public U()V
    .locals 7

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    const-wide/16 v1, 0x1

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v3, v0, Landroid/support/constraint/solver/Metrics;->fw:J

    add-long v5, v3, v1

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fw:J

    :cond_0
    iget-boolean v0, p0, Landroid/support/constraint/solver/LinearSystem;->fi:Z

    if-eqz v0, :cond_6

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_1

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v3, v0, Landroid/support/constraint/solver/Metrics;->fJ:J

    add-long v5, v3, v1

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fJ:J

    :cond_1
    const/4 v0, 0x0

    const/4 v3, 0x0

    :goto_0
    iget v4, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v3, v4, :cond_3

    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v4, v4, v3

    iget-boolean v4, v4, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-nez v4, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    const/4 v0, 0x1

    :goto_1
    if-nez v0, :cond_4

    goto :goto_2

    :cond_4
    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_5

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v3, v0, Landroid/support/constraint/solver/Metrics;->fI:J

    add-long v5, v3, v1

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fI:J

    :cond_5
    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->V()V

    return-void

    :cond_6
    :goto_2
    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->b(Landroid/support/constraint/solver/LinearSystem$a;)V

    return-void
.end method

.method X()V
    .locals 3

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->ad()V

    const-string v0, " #  "

    const/4 v1, 0x0

    :goto_0
    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v1, v2, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v0, v0, v1

    invoke-virtual {v0}, Landroid/support/constraint/solver/ArrayRow;->K()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n #  "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    if-eqz v1, :cond_1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public Y()V
    .locals 4

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->ad()V

    const-string v0, ""

    const/4 v1, 0x0

    :goto_0
    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v2, v2, v1

    iget-object v2, v2, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    iget-object v2, v2, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    sget-object v3, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    if-ne v2, v3, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v0, v0, v1

    invoke-virtual {v0}, Landroid/support/constraint/solver/ArrayRow;->K()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public Z()I
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v0, v2, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v2, v2, v0

    if-eqz v2, :cond_0

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroid/support/constraint/solver/ArrayRow;->H()I

    move-result v2

    add-int/2addr v1, v2

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;
    .locals 3

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v1, v1, 0x1

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    if-lt v1, v2, :cond_1

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->O()V

    :cond_1
    instance-of v1, p1, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    if-eqz v1, :cond_5

    check-cast p1, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ax()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->a(Landroid/support/constraint/solver/Cache;)V

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ax()Landroid/support/constraint/solver/SolverVariable;

    move-result-object p1

    move-object v0, p1

    :cond_2
    iget p1, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    const/4 v1, -0x1

    if-eq p1, v1, :cond_3

    iget p1, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    if-gt p1, v2, :cond_3

    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object p1, p1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v2, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    aget-object p1, p1, v2

    if-nez p1, :cond_5

    :cond_3
    iget p1, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    if-eq p1, v1, :cond_4

    invoke-virtual {v0}, Landroid/support/constraint/solver/SolverVariable;->reset()V

    :cond_4
    iget p1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iget p1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    iget p1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iput p1, v0, Landroid/support/constraint/solver/SolverVariable;->id:I

    sget-object p1, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    iput-object p1, v0, Landroid/support/constraint/solver/SolverVariable;->gr:Landroid/support/constraint/solver/SolverVariable$Type;

    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object p1, p1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    aput-object v0, p1, v1

    :cond_5
    return-object v0
.end method

.method a(Landroid/support/constraint/solver/ArrayRow;II)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p3, v0}, Landroid/support/constraint/solver/LinearSystem;->b(ILjava/lang/String;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object p3

    invoke-virtual {p1, p3, p2}, Landroid/support/constraint/solver/ArrayRow;->c(Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    return-void
.end method

.method public a(Landroid/support/constraint/solver/Metrics;)V
    .locals 0

    sput-object p1, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    return-void
.end method

.method public a(Landroid/support/constraint/solver/SolverVariable;II)V
    .locals 3

    iget v0, p1, Landroid/support/constraint/solver/SolverVariable;->gm:I

    iget v1, p1, Landroid/support/constraint/solver/SolverVariable;->gm:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_1

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v0, v1, v0

    iget-boolean v1, v0, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-eqz v1, :cond_0

    int-to-float p1, p2

    iput p1, v0, Landroid/support/constraint/solver/ArrayRow;->eS:F

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    :goto_0
    invoke-virtual {v0, p0, p3}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/LinearSystem;I)Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IFLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V
    .locals 11

    move-object v0, p0

    move/from16 v1, p8

    invoke-virtual {v0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v10

    move-object v2, v10

    move-object v3, p1

    move-object v4, p2

    move v5, p3

    move v6, p4

    move-object/from16 v7, p5

    move-object/from16 v8, p6

    move/from16 v9, p7

    invoke-virtual/range {v2 .. v9}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;IFLandroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    const/4 v2, 0x6

    if-eq v1, v2, :cond_0

    invoke-virtual {v10, v0, v1}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/LinearSystem;I)Landroid/support/constraint/solver/ArrayRow;

    :cond_0
    invoke-virtual {v0, v10}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Landroid/support/constraint/solver/SolverVariable;->gn:I

    invoke-virtual {v0, p1, p2, v1, p3}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    const/4 p1, 0x6

    if-eq p4, p1, :cond_0

    iget-object p1, v0, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    invoke-virtual {p0, v0, p1, p4}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;II)V

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;FI)V
    .locals 7

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v6

    move-object v0, v6

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;F)Landroid/support/constraint/solver/ArrayRow;

    const/4 p1, 0x6

    if-eq p6, p1, :cond_0

    invoke-virtual {v6, p0, p6}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/LinearSystem;I)Landroid/support/constraint/solver/ArrayRow;

    :cond_0
    invoke-virtual {p0, v6}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Z)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Landroid/support/constraint/solver/SolverVariable;->gn:I

    invoke-virtual {v0, p1, p2, v1, v2}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p3, :cond_0

    iget-object p1, v0, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    const/4 p2, 0x1

    invoke-virtual {p0, v0, p1, p2}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;II)V

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public a(Landroid/support/constraint/solver/widgets/ConstraintWidget;Landroid/support/constraint/solver/widgets/ConstraintWidget;FI)V
    .locals 19

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v1, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v5

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v1, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v7

    sget-object v3, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v1, v3}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v3

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v1, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v8

    sget-object v1, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hu:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v2, v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hv:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v2, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v9

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hw:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v2, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v12

    sget-object v4, Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;->hx:Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;

    invoke-virtual {v2, v4}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->a(Landroid/support/constraint/solver/widgets/ConstraintAnchor$Type;)Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/Object;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v10

    invoke-virtual/range {p0 .. p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v2

    move/from16 v4, p3

    float-to-double v13, v4

    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    move-result-wide v15

    move/from16 v4, p4

    move-object/from16 v17, v3

    int-to-double v3, v4

    move-object/from16 v18, v12

    mul-double v11, v15, v3

    double-to-float v11, v11

    move-object v6, v2

    invoke-virtual/range {v6 .. v11}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;F)Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {v0, v2}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    invoke-virtual/range {p0 .. p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v2

    invoke-static {v13, v14}, Ljava/lang/Math;->cos(D)D

    move-result-wide v6

    mul-double v6, v6, v3

    double-to-float v9, v6

    move-object v4, v2

    move-object/from16 v6, v17

    move-object v7, v1

    move-object/from16 v8, v18

    invoke-virtual/range {v4 .. v9}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;F)Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {v0, v2}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public aa()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    return v0
.end method

.method public ab()I
    .locals 1

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    return v0
.end method

.method ac()V
    .locals 7

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    iget v3, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    if-ge v1, v3, :cond_1

    iget-object v3, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v3, v3, v1

    if-eqz v3, :cond_0

    iget-object v3, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v3, v3, v1

    invoke-virtual {v3}, Landroid/support/constraint/solver/ArrayRow;->H()I

    move-result v3

    add-int/2addr v2, v3

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v3, 0x0

    :goto_1
    iget v4, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v1, v4, :cond_3

    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v4, v4, v1

    if-eqz v4, :cond_2

    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v4, v4, v1

    invoke-virtual {v4}, Landroid/support/constraint/solver/ArrayRow;->H()I

    move-result v4

    add-int/2addr v3, v4

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Linear System -> Table size: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " ("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    iget v6, p0, Landroid/support/constraint/solver/LinearSystem;->ff:I

    mul-int v5, v5, v6

    invoke-direct {p0, v5}, Landroid/support/constraint/solver/LinearSystem;->l(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ") -- row sizes: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {p0, v2}, Landroid/support/constraint/solver/LinearSystem;->l(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", actual size: "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {p0, v3}, Landroid/support/constraint/solver/LinearSystem;->l(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " rows: "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "/"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fm:I

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " cols: "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "/"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " occupied cells, "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->l(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public ae()Landroid/support/constraint/solver/Cache;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    return-object v0
.end method

.method public b(Ljava/lang/Object;)I
    .locals 1

    check-cast p1, Landroid/support/constraint/solver/widgets/ConstraintAnchor;

    invoke-virtual {p1}, Landroid/support/constraint/solver/widgets/ConstraintAnchor;->ax()Landroid/support/constraint/solver/SolverVariable;

    move-result-object p1

    if-eqz p1, :cond_0

    iget p1, p1, Landroid/support/constraint/solver/SolverVariable;->go:F

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p1, v0

    float-to-int p1, p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public b(ILjava/lang/String;)Landroid/support/constraint/solver/SolverVariable;
    .locals 7

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fE:J

    const-wide/16 v3, 0x1

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fE:J

    :cond_0
    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    if-lt v0, v1, :cond_1

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->O()V

    :cond_1
    sget-object v0, Landroid/support/constraint/solver/SolverVariable$Type;->gz:Landroid/support/constraint/solver/SolverVariable$Type;

    invoke-direct {p0, v0, p2}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/SolverVariable$Type;Ljava/lang/String;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object p2

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iput v0, p2, Landroid/support/constraint/solver/SolverVariable;->id:I

    iput p1, p2, Landroid/support/constraint/solver/SolverVariable;->gn:I

    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object p1, p1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    aput-object p2, p1, v0

    iget-object p1, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-interface {p1, p2}, Landroid/support/constraint/solver/LinearSystem$a;->f(Landroid/support/constraint/solver/SolverVariable;)V

    return-object p2
.end method

.method b(Ljava/lang/String;Landroid/support/constraint/solver/SolverVariable$Type;)Landroid/support/constraint/solver/SolverVariable;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    :cond_0
    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/constraint/solver/SolverVariable;

    if-nez v0, :cond_1

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/solver/LinearSystem;->a(Ljava/lang/String;Landroid/support/constraint/solver/SolverVariable$Type;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method b(Landroid/support/constraint/solver/LinearSystem$a;)V
    .locals 7

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v0, :cond_0

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fL:J

    const-wide/16 v3, 0x1

    add-long v5, v1, v3

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fL:J

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    sget-object v1, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v1, Landroid/support/constraint/solver/Metrics;->fM:J

    iget v3, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    int-to-long v3, v3

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    iput-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fM:J

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    sget-object v1, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v1, v1, Landroid/support/constraint/solver/Metrics;->fN:J

    iget v3, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    int-to-long v3, v3

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    iput-wide v1, v0, Landroid/support/constraint/solver/Metrics;->fN:J

    :cond_0
    move-object v0, p1

    check-cast v0, Landroid/support/constraint/solver/ArrayRow;

    invoke-direct {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->b(Landroid/support/constraint/solver/ArrayRow;)V

    invoke-direct {p0, p1}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/LinearSystem$a;)I

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/LinearSystem$a;Z)I

    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->V()V

    return-void
.end method

.method public b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Landroid/support/constraint/solver/SolverVariable;->gn:I

    invoke-virtual {v0, p1, p2, v1, p3}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    const/4 p1, 0x6

    if-eq p4, p1, :cond_0

    iget-object p1, v0, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    invoke-virtual {p0, v0, p1, p4}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;II)V

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Z)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Landroid/support/constraint/solver/SolverVariable;->gn:I

    invoke-virtual {v0, p1, p2, v1, v2}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    if-eqz p3, :cond_0

    iget-object p1, v0, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    invoke-virtual {p1, v1}, Landroid/support/constraint/solver/ArrayLinkedVariables;->b(Landroid/support/constraint/solver/SolverVariable;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    const/4 p2, 0x1

    invoke-virtual {p0, v0, p1, p2}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/ArrayRow;II)V

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method c(Ljava/lang/String;)F
    .locals 1

    sget-object v0, Landroid/support/constraint/solver/SolverVariable$Type;->gw:Landroid/support/constraint/solver/SolverVariable$Type;

    invoke-virtual {p0, p1, v0}, Landroid/support/constraint/solver/LinearSystem;->b(Ljava/lang/String;Landroid/support/constraint/solver/SolverVariable$Type;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object p1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    iget p1, p1, Landroid/support/constraint/solver/SolverVariable;->go:F

    return p1
.end method

.method public c(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;II)Landroid/support/constraint/solver/ArrayRow;
    .locals 1

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    const/4 p1, 0x6

    if-eq p4, p1, :cond_0

    invoke-virtual {v0, p0, p4}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/LinearSystem;I)Landroid/support/constraint/solver/ArrayRow;

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-object v0
.end method

.method public c(Landroid/support/constraint/solver/ArrayRow;)V
    .locals 9

    if-nez p1, :cond_0

    return-void

    :cond_0
    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    const-wide/16 v1, 0x1

    if-eqz v0, :cond_1

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v3, v0, Landroid/support/constraint/solver/Metrics;->fx:J

    add-long v5, v3, v1

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fx:J

    iget-boolean v0, p1, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-eqz v0, :cond_1

    sget-object v0, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v3, v0, Landroid/support/constraint/solver/Metrics;->fy:J

    add-long v5, v3, v1

    iput-wide v5, v0, Landroid/support/constraint/solver/Metrics;->fy:J

    :cond_1
    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    const/4 v3, 0x1

    add-int/2addr v0, v3

    iget v4, p0, Landroid/support/constraint/solver/LinearSystem;->fm:I

    if-ge v0, v4, :cond_2

    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    add-int/2addr v0, v3

    iget v4, p0, Landroid/support/constraint/solver/LinearSystem;->fg:I

    if-lt v0, v4, :cond_3

    :cond_2
    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->O()V

    :cond_3
    const/4 v0, 0x0

    iget-boolean v4, p1, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-nez v4, :cond_a

    invoke-direct {p0, p1}, Landroid/support/constraint/solver/LinearSystem;->b(Landroid/support/constraint/solver/ArrayRow;)V

    invoke-virtual {p1}, Landroid/support/constraint/solver/ArrayRow;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_4

    return-void

    :cond_4
    invoke-virtual {p1}, Landroid/support/constraint/solver/ArrayRow;->L()V

    invoke-virtual {p1, p0}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/LinearSystem;)Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->S()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    iput-object v0, p1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-direct {p0, p1}, Landroid/support/constraint/solver/LinearSystem;->d(Landroid/support/constraint/solver/ArrayRow;)V

    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fr:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-interface {v4, p1}, Landroid/support/constraint/solver/LinearSystem$a;->a(Landroid/support/constraint/solver/LinearSystem$a;)V

    iget-object v4, p0, Landroid/support/constraint/solver/LinearSystem;->fr:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-direct {p0, v4, v3}, Landroid/support/constraint/solver/LinearSystem;->a(Landroid/support/constraint/solver/LinearSystem$a;Z)I

    iget v4, v0, Landroid/support/constraint/solver/SolverVariable;->gm:I

    const/4 v5, -0x1

    if-ne v4, v5, :cond_8

    iget-object v4, p1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    if-ne v4, v0, :cond_6

    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/ArrayRow;->d(Landroid/support/constraint/solver/SolverVariable;)Landroid/support/constraint/solver/SolverVariable;

    move-result-object v0

    if-eqz v0, :cond_6

    sget-object v4, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    if-eqz v4, :cond_5

    sget-object v4, Landroid/support/constraint/solver/LinearSystem;->fq:Landroid/support/constraint/solver/Metrics;

    iget-wide v5, v4, Landroid/support/constraint/solver/Metrics;->fB:J

    add-long v7, v5, v1

    iput-wide v7, v4, Landroid/support/constraint/solver/Metrics;->fB:J

    :cond_5
    invoke-virtual {p1, v0}, Landroid/support/constraint/solver/ArrayRow;->e(Landroid/support/constraint/solver/SolverVariable;)V

    :cond_6
    iget-boolean v0, p1, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-nez v0, :cond_7

    iget-object v0, p1, Landroid/support/constraint/solver/ArrayRow;->eR:Landroid/support/constraint/solver/SolverVariable;

    invoke-virtual {v0, p1}, Landroid/support/constraint/solver/SolverVariable;->g(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_7
    iget v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    sub-int/2addr v0, v3

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    :cond_8
    const/4 v0, 0x1

    :cond_9
    invoke-virtual {p1}, Landroid/support/constraint/solver/ArrayRow;->J()Z

    move-result v1

    if-nez v1, :cond_a

    return-void

    :cond_a
    if-nez v0, :cond_b

    invoke-direct {p0, p1}, Landroid/support/constraint/solver/LinearSystem;->d(Landroid/support/constraint/solver/ArrayRow;)V

    :cond_b
    return-void
.end method

.method public d(Landroid/support/constraint/solver/SolverVariable;I)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->R()Landroid/support/constraint/solver/SolverVariable;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Landroid/support/constraint/solver/SolverVariable;->gn:I

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;ILandroid/support/constraint/solver/SolverVariable;)Landroid/support/constraint/solver/ArrayRow;

    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method public e(Landroid/support/constraint/solver/SolverVariable;I)V
    .locals 3

    iget v0, p1, Landroid/support/constraint/solver/SolverVariable;->gm:I

    iget v1, p1, Landroid/support/constraint/solver/SolverVariable;->gm:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_2

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v0, v1, v0

    iget-boolean v1, v0, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    if-eqz v1, :cond_0

    :goto_0
    int-to-float p1, p2

    iput p1, v0, Landroid/support/constraint/solver/ArrayRow;->eS:F

    return-void

    :cond_0
    iget-object v1, v0, Landroid/support/constraint/solver/ArrayRow;->eV:Landroid/support/constraint/solver/ArrayLinkedVariables;

    iget v1, v1, Landroid/support/constraint/solver/ArrayLinkedVariables;->eG:I

    if-nez v1, :cond_1

    const/4 p1, 0x1

    iput-boolean p1, v0, Landroid/support/constraint/solver/ArrayRow;->eW:Z

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Landroid/support/constraint/solver/ArrayRow;->b(Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Landroid/support/constraint/solver/LinearSystem;->Q()Landroid/support/constraint/solver/ArrayRow;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Landroid/support/constraint/solver/ArrayRow;->a(Landroid/support/constraint/solver/SolverVariable;I)Landroid/support/constraint/solver/ArrayRow;

    :goto_1
    invoke-virtual {p0, v0}, Landroid/support/constraint/solver/LinearSystem;->c(Landroid/support/constraint/solver/ArrayRow;)V

    return-void
.end method

.method k(I)Landroid/support/constraint/solver/ArrayRow;
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object p1, v0, p1

    return-object p1
.end method

.method public reset()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v2, v2, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    array-length v2, v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v2, v2, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    aget-object v2, v2, v1

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/support/constraint/solver/SolverVariable;->reset()V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v1, v1, Landroid/support/constraint/solver/Cache;->eY:Landroid/support/constraint/solver/a$a;

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->fn:[Landroid/support/constraint/solver/SolverVariable;

    iget v3, p0, Landroid/support/constraint/solver/LinearSystem;->fo:I

    invoke-interface {v1, v2, v3}, Landroid/support/constraint/solver/a$a;->a([Ljava/lang/Object;I)V

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fo:I

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->eI:Landroid/support/constraint/solver/Cache;

    iget-object v1, v1, Landroid/support/constraint/solver/Cache;->eZ:[Landroid/support/constraint/solver/SolverVariable;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    if-eqz v1, :cond_2

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fd:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_2
    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fc:I

    iget-object v1, p0, Landroid/support/constraint/solver/LinearSystem;->fe:Landroid/support/constraint/solver/LinearSystem$a;

    invoke-interface {v1}, Landroid/support/constraint/solver/LinearSystem$a;->clear()V

    const/4 v1, 0x1

    iput v1, p0, Landroid/support/constraint/solver/LinearSystem;->fk:I

    const/4 v1, 0x0

    :goto_1
    iget v2, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Landroid/support/constraint/solver/LinearSystem;->fh:[Landroid/support/constraint/solver/ArrayRow;

    aget-object v2, v2, v1

    iput-boolean v0, v2, Landroid/support/constraint/solver/ArrayRow;->eT:Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    invoke-direct {p0}, Landroid/support/constraint/solver/LinearSystem;->P()V

    iput v0, p0, Landroid/support/constraint/solver/LinearSystem;->fl:I

    return-void
.end method
