.class interface abstract Landroid/support/constraint/solver/LinearSystem$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/solver/LinearSystem;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract M()Landroid/support/constraint/solver/SolverVariable;
.end method

.method public abstract a(Landroid/support/constraint/solver/LinearSystem;[Z)Landroid/support/constraint/solver/SolverVariable;
.end method

.method public abstract a(Landroid/support/constraint/solver/LinearSystem$a;)V
.end method

.method public abstract clear()V
.end method

.method public abstract f(Landroid/support/constraint/solver/SolverVariable;)V
.end method

.method public abstract isEmpty()Z
.end method
