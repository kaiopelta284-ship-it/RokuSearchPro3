.class public Landroid/support/constraint/ConstraintLayout$LayoutParams;
.super Landroid/view/ViewGroup$MarginLayoutParams;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "LayoutParams"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/constraint/ConstraintLayout$LayoutParams$a;
    }
.end annotation


# static fields
.field public static final BOTTOM:I = 0x4

.field public static final END:I = 0x7

.field public static final HORIZONTAL:I = 0x0

.field public static final LEFT:I = 0x1

.field public static final RIGHT:I = 0x2

.field public static final START:I = 0x6

.field public static final TOP:I = 0x3

.field public static final UNSET:I = -0x1

.field public static final VERTICAL:I = 0x1

.field public static final ak:I = 0x0

.field public static final al:I = 0x0

.field public static final am:I = 0x5

.field public static final an:I = 0x1

.field public static final ao:I = 0x0

.field public static final ap:I = 0x2

.field public static final aq:I = 0x0

.field public static final ar:I = 0x1

.field public static final as:I = 0x2


# instance fields
.field public aA:I

.field public aB:I

.field public aC:I

.field public aD:I

.field public aE:I

.field public aF:I

.field public aG:I

.field public aH:F

.field public aI:I

.field public aJ:I

.field public aK:I

.field public aL:I

.field public aM:I

.field public aN:I

.field public aO:I

.field public aP:I

.field public aQ:I

.field public aR:I

.field public aS:F

.field public aT:F

.field public aU:Ljava/lang/String;

.field aV:F

.field aW:I

.field public aX:I

.field public aY:I

.field public aZ:I

.field public at:I

.field public au:I

.field public av:F

.field public aw:I

.field public ax:I

.field public ay:I

.field public az:I

.field bA:F

.field bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

.field public bC:Z

.field public ba:I

.field public bb:I

.field public bc:I

.field public bd:I

.field public be:I

.field public bf:F

.field public bg:F

.field public bh:I

.field public bi:I

.field public bj:Z

.field public bk:Z

.field bl:Z

.field bm:Z

.field bn:Z

.field bo:Z

.field bp:Z

.field bq:Z

.field br:I

.field bs:I

.field bt:I

.field bu:I

.field bv:I

.field bw:I

.field bx:F

.field by:I

.field bz:I

.field public horizontalWeight:F

.field public orientation:I

.field public verticalWeight:F


# direct methods
.method public constructor <init>(II)V
    .locals 4

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    const/4 p1, -0x1

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    const/high16 p2, -0x40800000    # -1.0f

    iput p2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    const/4 v3, 0x0

    iput-object v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    const/4 v1, 0x1

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iput p2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput p2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    const/high16 p2, 0x3f800000    # 1.0f

    iput p2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iput p2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bn:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bp:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bq:Z

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    new-instance p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-direct {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bC:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 9

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    const/4 v2, 0x0

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    const/4 v3, 0x0

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    const/high16 v4, 0x3f000000    # 0.5f

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    const/4 v5, 0x0

    iput-object v5, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    const/4 v5, 0x1

    iput v5, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iput-boolean v5, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v5, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bn:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bp:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bq:Z

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    new-instance v1, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-direct {v1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;-><init>()V

    iput-object v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bC:Z

    sget-object v1, Landroid/support/constraint/R$styleable;->ConstraintLayout_Layout:[I

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p2, :cond_6

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v4

    sget-object v6, Landroid/support/constraint/ConstraintLayout$LayoutParams$a;->cC:Landroid/util/SparseIntArray;

    invoke-virtual {v6, v4}, Landroid/util/SparseIntArray;->get(I)I

    move-result v6

    const/4 v7, -0x2

    packed-switch v6, :pswitch_data_0

    :pswitch_0
    goto/16 :goto_5

    :pswitch_1
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    goto/16 :goto_5

    :pswitch_2
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    goto/16 :goto_5

    :pswitch_3
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    goto/16 :goto_5

    :pswitch_4
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    goto/16 :goto_5

    :pswitch_5
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    goto/16 :goto_5

    :pswitch_6
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    goto/16 :goto_5

    :pswitch_7
    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    const/high16 v4, 0x7fc00000    # Float.NaN

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iget-object v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    if-eqz v4, :cond_5

    iget-object v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    iget-object v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    const/16 v7, 0x2c

    invoke-virtual {v6, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v6

    if-lez v6, :cond_2

    add-int/lit8 v7, v4, -0x1

    if-ge v6, v7, :cond_2

    iget-object v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    invoke-virtual {v7, v2, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const-string v8, "W"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_0

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    goto :goto_1

    :cond_0
    const-string v8, "H"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    iput v5, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    :cond_1
    :goto_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    const/4 v6, 0x0

    :goto_2
    iget-object v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    const/16 v8, 0x3a

    invoke-virtual {v7, v8}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    if-ltz v7, :cond_4

    add-int/lit8 v4, v4, -0x1

    if-ge v7, v4, :cond_4

    iget-object v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    invoke-virtual {v4, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    iget-object v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    add-int/lit8 v7, v7, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    :try_start_0
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v6

    cmpl-float v7, v4, v3

    if-lez v7, :cond_5

    cmpl-float v7, v6, v3

    if-lez v7, :cond_5

    iget v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    if-ne v7, v5, :cond_3

    div-float/2addr v6, v4

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v4

    :goto_3
    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    goto/16 :goto_5

    :cond_3
    div-float/2addr v4, v6

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_4

    goto :goto_3

    :cond_4
    iget-object v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_5

    :try_start_1
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_4

    goto :goto_3

    :pswitch_8
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    goto/16 :goto_5

    :pswitch_9
    :try_start_2
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_5

    :catch_0
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    goto/16 :goto_5

    :pswitch_a
    :try_start_3
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_5

    :catch_1
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    goto/16 :goto_5

    :pswitch_b
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    goto/16 :goto_5

    :pswitch_c
    :try_start_4
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto/16 :goto_5

    :catch_2
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    goto/16 :goto_5

    :pswitch_d
    :try_start_5
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto/16 :goto_5

    :catch_3
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    goto/16 :goto_5

    :pswitch_e
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iget v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    if-ne v4, v5, :cond_5

    const-string v4, "ConstraintLayout"

    const-string v6, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."

    goto :goto_4

    :pswitch_f
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iget v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    if-ne v4, v5, :cond_5

    const-string v4, "ConstraintLayout"

    const-string v6, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."

    :goto_4
    invoke-static {v4, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_5

    :pswitch_10
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    goto/16 :goto_5

    :pswitch_11
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    goto/16 :goto_5

    :pswitch_12
    iget-boolean v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    goto/16 :goto_5

    :pswitch_13
    iget-boolean v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    goto/16 :goto_5

    :pswitch_14
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    goto/16 :goto_5

    :pswitch_15
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    goto/16 :goto_5

    :pswitch_16
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    goto/16 :goto_5

    :pswitch_17
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    goto/16 :goto_5

    :pswitch_18
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    goto/16 :goto_5

    :pswitch_19
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    goto/16 :goto_5

    :pswitch_1a
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    goto/16 :goto_5

    :pswitch_1b
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    goto/16 :goto_5

    :pswitch_1c
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    goto/16 :goto_5

    :pswitch_1d
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    goto/16 :goto_5

    :pswitch_1e
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    goto/16 :goto_5

    :pswitch_1f
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    goto/16 :goto_5

    :pswitch_20
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    goto/16 :goto_5

    :pswitch_21
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    goto/16 :goto_5

    :pswitch_22
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    goto/16 :goto_5

    :pswitch_23
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    goto/16 :goto_5

    :pswitch_24
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    goto/16 :goto_5

    :pswitch_25
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    goto :goto_5

    :pswitch_26
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    goto :goto_5

    :pswitch_27
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    goto :goto_5

    :pswitch_28
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    goto :goto_5

    :pswitch_29
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    goto :goto_5

    :pswitch_2a
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    const/high16 v6, 0x43b40000    # 360.0f

    rem-float/2addr v4, v6

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iget v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    cmpg-float v4, v4, v3

    if-gez v4, :cond_5

    iget v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    sub-float v4, v6, v4

    rem-float/2addr v4, v6

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    goto :goto_5

    :pswitch_2b
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    goto :goto_5

    :pswitch_2c
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    goto :goto_5

    :pswitch_2d
    iget v6, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    :catch_4
    :cond_5
    :goto_5
    :pswitch_2e
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_6
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual {p0}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->B()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_2e
        :pswitch_2e
        :pswitch_2e
        :pswitch_2e
        :pswitch_0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public constructor <init>(Landroid/support/constraint/ConstraintLayout$LayoutParams;)V
    .locals 6

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    const/4 v2, 0x0

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    const/4 v3, 0x0

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    const/high16 v4, 0x3f000000    # 0.5f

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    const/4 v5, 0x0

    iput-object v5, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    const/4 v3, 0x1

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iput-boolean v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bn:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bp:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bq:Z

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    new-instance v0, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-direct {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bC:Z

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    iget-object v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iput-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iget-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iget-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iget-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iget-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iget-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bn:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bn:Z

    iget-boolean v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iget v0, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    iget-object p1, p1, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-object p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 5

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, -0x1

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aA:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aB:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aC:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aD:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aE:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aF:I

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aG:I

    const/4 v2, 0x0

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aH:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aN:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aP:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    const/high16 v3, 0x3f000000    # 0.5f

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aT:F

    const/4 v4, 0x0

    iput-object v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aU:Ljava/lang/String;

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aV:F

    const/4 v2, 0x1

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aW:I

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->horizontalWeight:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->verticalWeight:F

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aX:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aY:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bb:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bc:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bd:I

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->be:I

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bf:F

    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bg:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bh:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bi:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bn:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bp:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bq:Z

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    new-instance p1, Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-direct {p1}, Landroid/support/constraint/solver/widgets/ConstraintWidget;-><init>()V

    iput-object p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bC:Z

    return-void
.end method


# virtual methods
.method public B()V
    .locals 5

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    const/4 v3, -0x2

    if-ne v2, v3, :cond_0

    iget-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    if-eqz v2, :cond_0

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    :cond_0
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    if-ne v2, v3, :cond_1

    iget-boolean v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    if-eqz v2, :cond_1

    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    :cond_1
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    const/4 v4, -0x1

    if-eqz v2, :cond_2

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    if-ne v2, v4, :cond_3

    :cond_2
    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    if-nez v2, :cond_3

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aZ:I

    if-ne v2, v1, :cond_3

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->width:I

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bj:Z

    :cond_3
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    if-eqz v2, :cond_4

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    if-ne v2, v4, :cond_5

    :cond_4
    iput-boolean v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iget v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    if-nez v0, :cond_5

    iget v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ba:I

    if-ne v0, v1, :cond_5

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->height:I

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bk:Z

    :cond_5
    iget v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v0, v0, v2

    if-nez v0, :cond_6

    iget v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    if-ne v0, v4, :cond_6

    iget v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    if-eq v0, v4, :cond_8

    :cond_6
    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bl:Z

    iput-boolean v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bm:Z

    iget-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    instance-of v0, v0, Landroid/support/constraint/solver/widgets/Guideline;

    if-nez v0, :cond_7

    new-instance v0, Landroid/support/constraint/solver/widgets/Guideline;

    invoke-direct {v0}, Landroid/support/constraint/solver/widgets/Guideline;-><init>()V

    iput-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    :cond_7
    iget-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    check-cast v0, Landroid/support/constraint/solver/widgets/Guideline;

    iget v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    invoke-virtual {v0, v1}, Landroid/support/constraint/solver/widgets/Guideline;->setOrientation(I)V

    :cond_8
    return-void
.end method

.method public reset()V
    .locals 1

    iget-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bB:Landroid/support/constraint/solver/widgets/ConstraintWidget;

    invoke-virtual {v0}, Landroid/support/constraint/solver/widgets/ConstraintWidget;->reset()V

    :cond_0
    return-void
.end method

.method public resolveLayoutDirection(I)V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x11
    .end annotation

    iget v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->leftMargin:I

    iget v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->rightMargin:I

    invoke-super {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->resolveLayoutDirection(I)V

    const/4 p1, -0x1

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aM:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aO:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->by:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bz:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bA:F

    invoke-virtual {p0}, Landroid/support/constraint/ConstraintLayout$LayoutParams;->getLayoutDirection()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne v4, v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    if-eqz v2, :cond_a

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    if-eq v2, p1, :cond_1

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    :goto_1
    const/4 v3, 0x1

    goto :goto_2

    :cond_1
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    if-eq v2, p1, :cond_2

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    goto :goto_1

    :cond_2
    :goto_2
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    if-eq v2, p1, :cond_3

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    const/4 v3, 0x1

    :cond_3
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    if-eq v2, p1, :cond_4

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    const/4 v3, 0x1

    :cond_4
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    if-eq v2, p1, :cond_5

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    :cond_5
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    if-eq v2, p1, :cond_6

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    :cond_6
    const/high16 v2, 0x3f800000    # 1.0f

    if-eqz v3, :cond_7

    iget v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aS:F

    sub-float v3, v2, v3

    iput v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bx:F

    :cond_7
    iget-boolean v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bo:Z

    if-eqz v3, :cond_10

    iget v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->orientation:I

    if-ne v3, v4, :cond_10

    iget v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    const/high16 v4, -0x40800000    # -1.0f

    cmpl-float v3, v3, v4

    if-eqz v3, :cond_8

    iget v3, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->av:F

    sub-float/2addr v2, v3

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bA:F

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->by:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bz:I

    goto :goto_4

    :cond_8
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    if-eq v2, p1, :cond_9

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->at:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bz:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->by:I

    :goto_3
    iput v4, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bA:F

    goto :goto_4

    :cond_9
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    if-eq v2, p1, :cond_10

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->au:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->by:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bz:I

    goto :goto_3

    :cond_a
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    if-eq v2, p1, :cond_b

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    :cond_b
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    if-eq v2, p1, :cond_c

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    :cond_c
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    if-eq v2, p1, :cond_d

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    :cond_d
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    if-eq v2, p1, :cond_e

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    :cond_e
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    if-eq v2, p1, :cond_f

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aQ:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bv:I

    :cond_f
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    if-eq v2, p1, :cond_10

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aR:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bw:I

    :cond_10
    :goto_4
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aK:I

    if-ne v2, p1, :cond_14

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aL:I

    if-ne v2, p1, :cond_14

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aJ:I

    if-ne v2, p1, :cond_14

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aI:I

    if-ne v2, p1, :cond_14

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    if-eq v2, p1, :cond_11

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ay:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bt:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->rightMargin:I

    if-gtz v2, :cond_12

    if-lez v1, :cond_12

    :goto_5
    iput v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->rightMargin:I

    goto :goto_6

    :cond_11
    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    if-eq v2, p1, :cond_12

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->az:I

    iput v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bu:I

    iget v2, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->rightMargin:I

    if-gtz v2, :cond_12

    if-lez v1, :cond_12

    goto :goto_5

    :cond_12
    :goto_6
    iget v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    if-eq v1, p1, :cond_13

    iget p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->aw:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->br:I

    iget p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->leftMargin:I

    if-gtz p1, :cond_14

    if-lez v0, :cond_14

    :goto_7
    iput v0, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->leftMargin:I

    return-void

    :cond_13
    iget v1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    if-eq v1, p1, :cond_14

    iget p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->ax:I

    iput p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->bs:I

    iget p1, p0, Landroid/support/constraint/ConstraintLayout$LayoutParams;->leftMargin:I

    if-gtz p1, :cond_14

    if-lez v0, :cond_14

    goto :goto_7

    :cond_14
    return-void
.end method
