.class public final Landroid/support/constraint/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final bottom:I = 0x7f060009

.field public static final end:I = 0x7f0600d1

.field public static final gone:I = 0x7f0600ed

.field public static final invisible:I = 0x7f060132

.field public static final left:I = 0x7f060176

.field public static final packed:I = 0x7f0601e3

.field public static final parent:I = 0x7f0601ec

.field public static final percent:I = 0x7f0601f3

.field public static final right:I = 0x7f060221

.field public static final spread:I = 0x7f060256

.field public static final spread_inside:I = 0x7f060257

.field public static final start:I = 0x7f060261

.field public static final top:I = 0x7f0602a0

.field public static final wrap:I = 0x7f060344


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
