.class public Landroid/support/constraint/Constraints$LayoutParams;
.super Landroid/support/constraint/ConstraintLayout$LayoutParams;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/Constraints;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "LayoutParams"
.end annotation


# instance fields
.field public alpha:F

.field public ec:Z

.field public ed:F

.field public ee:F

.field public ef:F

.field public eg:F

.field public eh:F

.field public ei:F

.field public ej:F

.field public ek:F

.field public el:F

.field public em:F

.field public en:F


# direct methods
.method public constructor <init>(II)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/ConstraintLayout$LayoutParams;-><init>(II)V

    const/high16 p1, 0x3f800000    # 1.0f

    iput p1, p0, Landroid/support/constraint/Constraints$LayoutParams;->alpha:F

    const/4 p2, 0x0

    iput-boolean p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ec:Z

    const/4 p2, 0x0

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ed:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ee:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ef:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->eg:F

    iput p1, p0, Landroid/support/constraint/Constraints$LayoutParams;->eh:F

    iput p1, p0, Landroid/support/constraint/Constraints$LayoutParams;->ei:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ej:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ek:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->el:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->em:F

    iput p2, p0, Landroid/support/constraint/Constraints$LayoutParams;->en:F

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    invoke-direct {p0, p1, p2}, Landroid/support/constraint/ConstraintLayout$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->alpha:F

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroid/support/constraint/Constraints$LayoutParams;->ec:Z

    const/4 v2, 0x0

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ed:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ee:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ef:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->eg:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->eh:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ei:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ej:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ek:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->el:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->em:F

    iput v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->en:F

    sget-object v0, Landroid/support/constraint/R$styleable;->ConstraintSet:[I

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    :goto_0
    if-ge v1, p2, :cond_c

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v0

    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_alpha:I

    if-ne v0, v2, :cond_0

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->alpha:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->alpha:F

    goto/16 :goto_2

    :cond_0
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_elevation:I

    if-ne v0, v2, :cond_1

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ed:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ed:F

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ec:Z

    goto/16 :goto_2

    :cond_1
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_rotationX:I

    if-ne v0, v2, :cond_2

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ef:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ef:F

    goto/16 :goto_2

    :cond_2
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_rotationY:I

    if-ne v0, v2, :cond_3

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->eg:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->eg:F

    goto :goto_2

    :cond_3
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_rotation:I

    if-ne v0, v2, :cond_4

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ee:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ee:F

    goto :goto_2

    :cond_4
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_scaleX:I

    if-ne v0, v2, :cond_5

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->eh:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->eh:F

    goto :goto_2

    :cond_5
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_scaleY:I

    if-ne v0, v2, :cond_6

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ei:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ei:F

    goto :goto_2

    :cond_6
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_transformPivotX:I

    if-ne v0, v2, :cond_7

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ej:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ej:F

    goto :goto_2

    :cond_7
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_transformPivotY:I

    if-ne v0, v2, :cond_8

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->ek:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ek:F

    goto :goto_2

    :cond_8
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_translationX:I

    if-ne v0, v2, :cond_9

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->el:F

    :goto_1
    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->el:F

    goto :goto_2

    :cond_9
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_translationY:I

    if-ne v0, v2, :cond_a

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->em:F

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->em:F

    goto :goto_2

    :cond_a
    sget v2, Landroid/support/constraint/R$styleable;->ConstraintSet_android_translationZ:I

    if-ne v0, v2, :cond_b

    iget v2, p0, Landroid/support/constraint/Constraints$LayoutParams;->en:F

    goto :goto_1

    :cond_b
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_c
    return-void
.end method

.method public constructor <init>(Landroid/support/constraint/Constraints$LayoutParams;)V
    .locals 1

    invoke-direct {p0, p1}, Landroid/support/constraint/ConstraintLayout$LayoutParams;-><init>(Landroid/support/constraint/ConstraintLayout$LayoutParams;)V

    const/high16 p1, 0x3f800000    # 1.0f

    iput p1, p0, Landroid/support/constraint/Constraints$LayoutParams;->alpha:F

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ec:Z

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ed:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ee:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ef:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->eg:F

    iput p1, p0, Landroid/support/constraint/Constraints$LayoutParams;->eh:F

    iput p1, p0, Landroid/support/constraint/Constraints$LayoutParams;->ei:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ej:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->ek:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->el:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->em:F

    iput v0, p0, Landroid/support/constraint/Constraints$LayoutParams;->en:F

    return-void
.end method
