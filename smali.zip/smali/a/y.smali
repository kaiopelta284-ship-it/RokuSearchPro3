.class public La/y;
.super La/al;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static oV:Ljava/util/Comparator; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J = 0x1L

.field public static sr:[Ljava/lang/String;

.field public static st:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private duasVoltasMataMata:[Z

.field private pais:I

.field private sf:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ld/q;",
            ">;"
        }
    .end annotation
.end field

.field private sg:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private sh:I

.field private si:Ld/x;

.field private sj:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private sk:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private sl:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private sm:Z

.field private sn:I

.field private so:I

.field private sp:Ljava/lang/String;

.field private sq:Z

.field private ss:La/ac;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/y$1;

    invoke-direct {v0}, La/y$1;-><init>()V

    sput-object v0, La/y;->st:Ljava/util/Comparator;

    new-instance v0, La/y$2;

    invoke-direct {v0}, La/y$2;-><init>()V

    sput-object v0, La/y;->oV:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/al;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/y;->sg:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, La/y;->sh:I

    const/4 v1, 0x7

    new-array v1, v1, [Z

    fill-array-data v1, :array_0

    iput-object v1, p0, La/y;->duasVoltasMataMata:[Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/y;->sj:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/y;->sl:Ljava/util/ArrayList;

    iput-boolean v0, p0, La/y;->sm:Z

    iput v0, p0, La/y;->sn:I

    const/16 v1, 0xc

    iput v1, p0, La/y;->so:I

    const-string v1, ""

    iput-object v1, p0, La/y;->sp:Ljava/lang/String;

    iput-boolean v0, p0, La/y;->sq:Z

    const/4 v0, 0x0

    iput-object v0, p0, La/y;->ss:La/ac;

    return-void

    nop

    :array_0
    .array-data 1
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
    .end array-data
.end method

.method public constructor <init>(I)V
    .locals 3

    invoke-direct {p0}, La/al;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/y;->sg:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, La/y;->sh:I

    const/4 v1, 0x7

    new-array v1, v1, [Z

    fill-array-data v1, :array_0

    iput-object v1, p0, La/y;->duasVoltasMataMata:[Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/y;->sj:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/y;->sl:Ljava/util/ArrayList;

    iput-boolean v0, p0, La/y;->sm:Z

    iput v0, p0, La/y;->sn:I

    const/16 v1, 0xc

    iput v1, p0, La/y;->so:I

    const-string v1, ""

    iput-object v1, p0, La/y;->sp:Ljava/lang/String;

    iput-boolean v0, p0, La/y;->sq:Z

    const/4 v0, 0x0

    iput-object v0, p0, La/y;->ss:La/ac;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->getNome()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/y;->sp:Ljava/lang/String;

    iput p1, p0, La/y;->pais:I

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b010e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcomponents/bz;->dK(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, La/y;->kO()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La/y;->setNome(Ljava/lang/String;)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    iget-object p1, p1, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "pt_BR"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " ("

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, La/y;->kO()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La/y;->setNome(Ljava/lang/String;)V

    :cond_0
    const/4 p1, 0x2

    invoke-virtual {p0}, La/y;->iw()I

    move-result v0

    invoke-virtual {p0, p1, v0}, La/y;->aa(II)V

    return-void

    :array_0
    .array-data 1
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
    .end array-data
.end method

.method public static S(II)Lest/ConfigLigaType;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lest/ConfigLigaType;

    invoke-virtual {v1}, Lest/ConfigLigaType;->getPais()I

    move-result v1

    if-ne v1, p0, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lest/ConfigLigaType;

    invoke-virtual {v1}, Lest/ConfigLigaType;->getDivisao()I

    move-result v1

    if-ne v1, p1, :cond_0

    sget-object p0, Lc/a;->TF:La/b;

    iget-object p0, p0, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lest/ConfigLigaType;

    return-object p0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(ZIILjava/util/ArrayList;ZLa/y;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZII",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;Z",
            "La/y;",
            ")V"
        }
    .end annotation

    move/from16 v0, p1

    move-object/from16 v1, p3

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    :goto_0
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_1

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    invoke-virtual {v5}, La/y;->iw()I

    move-result v5

    if-ne v5, v0, :cond_0

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    sget-object v4, La/y;->oV:Ljava/util/Comparator;

    invoke-static {v2, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/16 v4, 0x8

    new-array v5, v4, [I

    fill-array-data v5, :array_0

    const/16 v6, 0x9

    new-array v7, v6, [I

    fill-array-data v7, :array_1

    const/4 v8, 0x5

    new-array v9, v8, [I

    fill-array-data v9, :array_2

    new-array v10, v8, [I

    fill-array-data v10, :array_3

    new-array v11, v8, [I

    fill-array-data v11, :array_4

    new-array v12, v8, [I

    fill-array-data v12, :array_5

    new-array v13, v8, [I

    fill-array-data v13, :array_6

    new-array v14, v4, [I

    fill-array-data v14, :array_7

    if-nez p0, :cond_2

    new-array v5, v4, [I

    fill-array-data v5, :array_8

    new-array v9, v8, [I

    fill-array-data v9, :array_9

    const/4 v4, 0x6

    new-array v10, v4, [I

    fill-array-data v10, :array_a

    new-array v11, v8, [I

    fill-array-data v11, :array_b

    const/4 v4, 0x7

    new-array v12, v4, [I

    fill-array-data v12, :array_c

    new-array v13, v8, [I

    fill-array-data v13, :array_d

    :cond_2
    const/4 v4, 0x4

    const/4 v15, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_3

    move-object v9, v5

    goto :goto_1

    :cond_3
    if-ne v0, v3, :cond_4

    goto :goto_1

    :cond_4
    const/4 v5, 0x2

    if-ne v0, v5, :cond_5

    move-object v9, v10

    goto :goto_1

    :cond_5
    if-ne v0, v15, :cond_6

    move-object v9, v11

    goto :goto_1

    :cond_6
    if-ne v0, v4, :cond_7

    move-object v9, v12

    goto :goto_1

    :cond_7
    if-ne v0, v8, :cond_8

    move-object v9, v13

    goto :goto_1

    :cond_8
    move-object v9, v14

    :goto_1
    if-eqz p4, :cond_b

    if-ne v0, v4, :cond_a

    new-array v7, v6, [I

    fill-array-data v7, :array_e

    :cond_9
    :goto_2
    move-object v9, v7

    goto :goto_3

    :cond_a
    if-ne v0, v15, :cond_9

    new-array v7, v6, [I

    fill-array-data v7, :array_f

    goto :goto_2

    :goto_3
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fe()Ld/o;

    move-result-object v0

    invoke-virtual {v0, v3}, Ld/o;->er(I)La/y;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_b
    move/from16 v4, p2

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_4
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v0, v7, :cond_f

    if-lez v4, :cond_e

    new-instance v7, Ljava/util/Random;

    invoke-direct {v7}, Ljava/util/Random;-><init>()V

    const/16 v8, 0x64

    invoke-virtual {v7, v8}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    add-int/2addr v7, v3

    if-lez v0, :cond_c

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/y;

    invoke-virtual {v8}, La/y;->getNivel()I

    move-result v8

    if-ge v8, v5, :cond_c

    add-int/lit8 v6, v6, 0x1

    array-length v5, v9

    if-lt v6, v5, :cond_c

    array-length v5, v9

    add-int/lit8 v6, v5, -0x1

    :cond_c
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v8, p5

    if-eq v5, v8, :cond_d

    aget v5, v9, v6

    if-gt v7, v5, :cond_d

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_d

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, -0x1

    :cond_d
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    iget v5, v5, La/y;->so:I

    goto :goto_5

    :cond_e
    move-object/from16 v8, p5

    :goto_5
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_f
    const/4 v0, 0x0

    :goto_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_11

    if-lez v4, :cond_10

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_10

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, -0x1

    :cond_10
    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_11
    return-void

    :array_0
    .array-data 4
        0x64
        0x5f
        0x50
        0x32
        0x1e
        0x14
        0xa
        0x5
    .end array-data

    :array_1
    .array-data 4
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x32
    .end array-data

    :array_2
    .array-data 4
        0x64
        0x32
        0x1e
        0xa
        0x5
    .end array-data

    :array_3
    .array-data 4
        0x5a
        0x32
        0x1e
        0xa
        0x5
    .end array-data

    :array_4
    .array-data 4
        0x5a
        0x32
        0x1e
        0xa
        0x5
    .end array-data

    :array_5
    .array-data 4
        0x5f
        0x32
        0x1e
        0xa
        0x5
    .end array-data

    :array_6
    .array-data 4
        0x5f
        0x32
        0x1e
        0xa
        0x5
    .end array-data

    :array_7
    .array-data 4
        0x64
        0x5f
        0x50
        0x32
        0x1e
        0x14
        0xa
        0x5
    .end array-data

    :array_8
    .array-data 4
        0x64
        0x64
        0x5a
        0x46
        0x3c
        0x14
        0xa
        0x5
    .end array-data

    :array_9
    .array-data 4
        0x64
        0x32
        0x1e
        0xa
        0x5
    .end array-data

    :array_a
    .array-data 4
        0x64
        0x64
        0x64
        0x62
        0x3c
        0x28
    .end array-data

    :array_b
    .array-data 4
        0x64
        0x64
        0x5a
        0x41
        0x3c
    .end array-data

    :array_c
    .array-data 4
        0x64
        0x64
        0x64
        0x64
        0x64
        0x5f
        0x50
    .end array-data

    :array_d
    .array-data 4
        0x64
        0x5a
        0x5a
        0xa
        0x5
    .end array-data

    :array_e
    .array-data 4
        0x64
        0x64
        0x64
        0x5f
        0x4b
        0x46
        0x46
        0x46
        0x46
    .end array-data

    :array_f
    .array-data 4
        0x64
        0x64
        0x46
        0x46
        0x46
        0x46
        0x46
        0x46
        0x46
    .end array-data
.end method

.method static synthetic b(La/y;)I
    .locals 0

    iget p0, p0, La/y;->so:I

    return p0
.end method

.method static synthetic c(La/y;)I
    .locals 0

    iget p0, p0, La/y;->sn:I

    return p0
.end method

.method private d(La/af;)V
    .locals 4

    invoke-virtual {p1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, La/af;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0}, La/b;->al(I)La/y;

    move-result-object v0

    invoke-virtual {v0}, La/y;->kS()La/af;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {p1, v2}, La/af;->v(La/ac;)V

    invoke-virtual {v0}, La/y;->li()La/ac;

    move-result-object p1

    invoke-virtual {p1, v2}, La/ac;->e(La/af;)V

    invoke-virtual {v0}, La/y;->li()La/ac;

    move-result-object p1

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {p1, v3}, La/ac;->j(Ljava/lang/Boolean;)V

    if-eqz v1, :cond_1

    invoke-virtual {v0, v1}, La/y;->c(La/af;)V

    :cond_1
    invoke-virtual {v0, v2}, La/y;->N(Z)V

    return-void
.end method

.method private kF()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    iget v3, p0, La/y;->pais:I

    if-ne v2, v3, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, p0, La/y;->sg:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2, v0}, La/ac;->setDivisao(I)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, La/y;->sg:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->RN:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method private kL()Ljava/util/ArrayList;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x3e8

    invoke-virtual {v6, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    invoke-virtual {v5, v6}, La/ac;->bY(I)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    sget-object v4, Lcomponents/ce;->oV:Ljava/util/Comparator;

    invoke-static {v1, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v4, 0x0

    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_3

    array-length v5, v0

    if-ge v4, v5, :cond_1

    aget v5, v0, v4

    goto :goto_2

    :cond_1
    const/16 v5, 0x14

    :goto_2
    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x64

    invoke-virtual {v6, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    if-gt v6, v5, :cond_2

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_3
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_5

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_5
    return-object v2

    nop

    :array_0
    .array-data 4
        0x55
        0x50
        0x4b
        0x46
        0x41
        0x3c
        0x37
        0x32
        0x2d
        0x28
        0x23
    .end array-data
.end method

.method private kM()Ljava/util/ArrayList;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    const/16 v0, 0xd

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x3e8

    invoke-virtual {v6, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    invoke-virtual {v5, v6}, La/ac;->bY(I)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    sget-object v4, Lcomponents/ce;->oV:Ljava/util/Comparator;

    invoke-static {v1, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v4, 0x0

    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_3

    array-length v5, v0

    if-ge v4, v5, :cond_1

    aget v5, v0, v4

    goto :goto_2

    :cond_1
    const/16 v5, 0x14

    :goto_2
    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x64

    invoke-virtual {v6, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    if-gt v6, v5, :cond_2

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_3
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_5

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_5
    return-object v2

    nop

    :array_0
    .array-data 4
        0x5f
        0x5a
        0x55
        0x50
        0x4b
        0x46
        0x41
        0x3c
        0x37
        0x32
        0x2d
        0x28
        0x23
    .end array-data
.end method

.method private kN()Ljava/util/ArrayList;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    const/16 v0, 0xd

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v5, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x3e8

    invoke-virtual {v6, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    invoke-virtual {v5, v6}, La/ac;->bY(I)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    sget-object v4, Lcomponents/ce;->oV:Ljava/util/Comparator;

    invoke-static {v1, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v4, 0x0

    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_3

    array-length v5, v0

    if-ge v4, v5, :cond_1

    aget v5, v0, v4

    goto :goto_2

    :cond_1
    const/16 v5, 0x14

    :goto_2
    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x64

    invoke-virtual {v6, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x1

    if-gt v6, v5, :cond_2

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_3
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_5

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_5
    return-object v2

    nop

    :array_0
    .array-data 4
        0x5f
        0x5a
        0x55
        0x50
        0x4b
        0x46
        0x41
        0x3c
        0x37
        0x32
        0x2d
        0x28
        0x23
    .end array-data
.end method


# virtual methods
.method public J(Ljava/util/ArrayList;)Z
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;)Z"
        }
    .end annotation

    move-object/from16 v7, p0

    move-object/from16 v0, p1

    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/16 v4, 0x10

    const/16 v5, 0x20

    const/16 v6, 0x40

    const/16 v8, 0x80

    const/16 v9, 0x8

    const/4 v11, 0x0

    if-lt v1, v8, :cond_0

    const/16 v4, 0x80

    goto :goto_0

    :cond_0
    if-lt v1, v6, :cond_1

    const/16 v4, 0x40

    goto :goto_0

    :cond_1
    if-lt v1, v5, :cond_2

    const/16 v4, 0x20

    goto :goto_0

    :cond_2
    if-lt v1, v4, :cond_3

    goto :goto_0

    :cond_3
    if-lt v1, v9, :cond_4

    const/16 v4, 0x8

    goto :goto_0

    :cond_4
    if-ge v1, v9, :cond_5

    return v11

    :cond_5
    const/4 v4, 0x0

    :goto_0
    const/4 v1, 0x0

    :goto_1
    const/4 v8, 0x2

    div-int/lit8 v5, v4, 0x2

    if-ge v1, v5, :cond_6

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/2addr v5, v1

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_6
    invoke-static {v2}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    invoke-static {v3}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    :goto_2
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v11, v0, :cond_7

    invoke-virtual {v3, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v11, 0x1

    goto :goto_2

    :cond_7
    new-instance v9, Ld/x;

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v5, v7, La/y;->duasVoltasMataMata:[Z

    move-object v0, v9

    move-object v1, v7

    move-object v6, v7

    invoke-direct/range {v0 .. v6}, Ld/x;-><init>(La/al;III[ZLa/al;)V

    iput-object v9, v7, La/y;->si:Ld/x;

    invoke-virtual/range {p0 .. p0}, La/y;->iw()I

    move-result v0

    invoke-virtual {v7, v8, v0}, La/y;->aa(II)V

    new-instance v8, Ld/ac;

    invoke-direct {v8}, Ld/ac;-><init>()V

    iget-object v9, v7, La/y;->si:Ld/x;

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    invoke-virtual/range {v8 .. v15}, Ld/ac;->a(Ld/x;Ljava/util/ArrayList;IZIII)V

    const/4 v0, 0x1

    return v0
.end method

.method public K(Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/be;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    :goto_0
    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_1

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    invoke-virtual {v0, p1}, Ld/q;->ac(Ljava/util/ArrayList;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    :goto_1
    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_1

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    invoke-virtual {v0, p1}, Ld/q;->K(Ljava/util/ArrayList;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    return-void
.end method

.method public L(Z)V
    .locals 0

    iput-boolean p1, p0, La/y;->sm:Z

    return-void
.end method

.method public M(Z)V
    .locals 0

    iput-boolean p1, p0, La/y;->sq:Z

    return-void
.end method

.method public N(Z)V
    .locals 10

    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    if-nez p1, :cond_0

    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object p1

    if-nez p1, :cond_1

    :cond_0
    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_1

    invoke-virtual {p0}, La/y;->kS()La/af;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {p0, p1}, La/y;->c(La/af;)V

    :cond_1
    iget-boolean p1, p0, La/y;->sm:Z

    if-nez p1, :cond_2

    invoke-virtual {p0}, La/y;->kU()Z

    move-result p1

    if-nez p1, :cond_2

    iget p1, p0, La/y;->pais:I

    iget v0, p0, La/y;->so:I

    invoke-static {p1, v0}, La/u;->Q(II)V

    :cond_2
    const/4 p1, 0x6

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    new-array v1, p1, [I

    fill-array-data v1, :array_1

    new-array p1, p1, [I

    fill-array-data p1, :array_2

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_4

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPais()I

    move-result v6

    iget v7, p0, La/y;->pais:I

    if-ne v6, v7, :cond_3

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->hE()La/ac;

    move-result-object v6

    if-eqz v6, :cond_3

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    const/4 v5, 0x0

    :goto_1
    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_6

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPais()I

    move-result v6

    iget v7, p0, La/y;->pais:I

    if-ne v6, v7, :cond_5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_6
    sget-object v5, La/y;->st:Ljava/util/Comparator;

    invoke-static {v2, v5}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v5, 0x0

    :goto_2
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ge v5, v6, :cond_10

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    const/4 v9, 0x1

    if-nez v6, :cond_7

    aget v6, v0, v4

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, v0, v4

    sub-int/2addr v6, v9

    aput v6, v0, v4

    goto/16 :goto_3

    :cond_7
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ge v6, v8, :cond_8

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-nez v6, :cond_8

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    aget v6, v1, v6

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    aget v7, v1, v6

    sub-int/2addr v7, v9

    aput v7, v1, v6

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    aget v7, v0, v6

    sub-int/2addr v7, v9

    aput v7, v0, v6

    goto/16 :goto_3

    :cond_8
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ge v6, v8, :cond_9

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-ne v6, v9, :cond_9

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    aget v6, p1, v6

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    aget v7, p1, v6

    sub-int/2addr v7, v9

    aput v7, p1, v6

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    aget v7, v0, v6

    sub-int/2addr v7, v9

    aput v7, v0, v6

    goto/16 :goto_3

    :cond_9
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ne v6, v8, :cond_a

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-nez v6, :cond_a

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->ia()I

    move-result v6

    if-ne v6, v9, :cond_a

    aget v6, v1, v8

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, v1, v8

    sub-int/2addr v6, v9

    aput v6, v1, v8

    aget v6, v0, v8

    sub-int/2addr v6, v9

    aput v6, v0, v8

    goto/16 :goto_3

    :cond_a
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ne v6, v8, :cond_b

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-ne v6, v9, :cond_b

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->ia()I

    move-result v6

    if-ne v6, v9, :cond_b

    aget v6, p1, v8

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, p1, v8

    sub-int/2addr v6, v9

    aput v6, p1, v8

    aget v6, v0, v8

    sub-int/2addr v6, v9

    aput v6, v0, v8

    goto/16 :goto_3

    :cond_b
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ne v6, v8, :cond_c

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-nez v6, :cond_c

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->ia()I

    move-result v6

    if-nez v6, :cond_c

    aget v6, v1, v7

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, v1, v7

    sub-int/2addr v6, v9

    aput v6, v1, v7

    aget v6, v0, v7

    sub-int/2addr v6, v9

    aput v6, v0, v7

    goto/16 :goto_3

    :cond_c
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ne v6, v8, :cond_d

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-ne v6, v9, :cond_d

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->ia()I

    move-result v6

    if-nez v6, :cond_d

    aget v6, p1, v7

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, p1, v7

    sub-int/2addr v6, v9

    aput v6, p1, v7

    aget v6, v0, v7

    sub-int/2addr v6, v9

    aput v6, v0, v7

    goto :goto_3

    :cond_d
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    const/4 v7, 0x4

    if-ne v6, v7, :cond_e

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-nez v6, :cond_e

    aget v6, v1, v7

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, v1, v7

    sub-int/2addr v6, v9

    aput v6, v1, v7

    aget v6, v0, v7

    sub-int/2addr v6, v9

    aput v6, v0, v7

    goto :goto_3

    :cond_e
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ne v6, v7, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getLado()I

    move-result v6

    if-ne v6, v9, :cond_f

    aget v6, p1, v7

    if-lez v6, :cond_f

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v6, p1, v7

    sub-int/2addr v6, v9

    aput v6, p1, v7

    aget v6, v0, v7

    sub-int/2addr v6, v9

    aput v6, v0, v7

    :cond_f
    :goto_3
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_2

    :cond_10
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/16 v1, 0x17

    if-ge p1, v1, :cond_14

    const/4 p1, 0x0

    :goto_4
    if-gt p1, v7, :cond_14

    if-ge p1, v7, :cond_11

    move v5, p1

    goto :goto_5

    :cond_11
    const/4 v5, 0x3

    :goto_5
    aget v6, v0, p1

    if-lez v6, :cond_13

    const/4 v6, 0x0

    :goto_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v6, v9, :cond_13

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->getPosicao()I

    move-result v9

    if-ne v9, v5, :cond_12

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_12

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_12
    add-int/lit8 v6, v6, 0x1

    goto :goto_6

    :cond_13
    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_14
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge p1, v1, :cond_16

    :goto_7
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v4, p1, :cond_16

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_15

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_15
    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    :cond_16
    sget-object p1, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {v3, p1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, La/y;->ss:La/ac;

    invoke-virtual {p1, v3}, La/ac;->L(Ljava/util/ArrayList;)V

    iget-object p1, p0, La/y;->ss:La/ac;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, La/ac;->j(La/p;)V

    iget-object p1, p0, La/y;->ss:La/ac;

    invoke-virtual {p1, v0}, La/ac;->i(La/p;)V

    iget-object p1, p0, La/y;->ss:La/ac;

    invoke-virtual {p1}, La/ac;->lY()V

    iget-object p1, p0, La/y;->ss:La/ac;

    invoke-virtual {p1}, La/ac;->lX()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->onConvoca(La/y;)V

    return-void

    nop

    :array_0
    .array-data 4
        0x3
        0x4
        0x4
        0x5
        0x4
        0x3
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x2
        0x2
        0x2
        0x2
        0x2
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x2
        0x2
        0x3
        0x2
        0x1
    .end array-data
.end method

.method public R(II)Lest/LoadLigaOptions;
    .locals 9

    const/16 v0, 0x27

    new-array v0, v0, [[I

    const/4 v1, 0x4

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_1

    const/4 v4, 0x1

    aput-object v2, v0, v4

    new-array v2, v1, [I

    fill-array-data v2, :array_2

    const/4 v5, 0x2

    aput-object v2, v0, v5

    new-array v2, v1, [I

    fill-array-data v2, :array_3

    const/4 v6, 0x3

    aput-object v2, v0, v6

    new-array v2, v1, [I

    fill-array-data v2, :array_4

    aput-object v2, v0, v1

    new-array v2, v1, [I

    fill-array-data v2, :array_5

    const/4 v7, 0x5

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_6

    const/4 v7, 0x6

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_7

    const/4 v7, 0x7

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_8

    const/16 v7, 0x8

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_9

    const/16 v7, 0x9

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_a

    const/16 v7, 0xa

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_b

    const/16 v7, 0xb

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_c

    const/16 v7, 0xc

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_d

    const/16 v7, 0xd

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_e

    const/16 v7, 0xe

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_f

    const/16 v7, 0xf

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_10

    const/16 v7, 0x10

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_11

    const/16 v7, 0x11

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_12

    const/16 v7, 0x12

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_13

    const/16 v7, 0x13

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_14

    const/16 v7, 0x14

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_15

    const/16 v7, 0x15

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_16

    const/16 v7, 0x16

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_17

    const/16 v7, 0x17

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_18

    const/16 v7, 0x18

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_19

    const/16 v7, 0x19

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_1a

    const/16 v7, 0x1a

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_1b

    const/16 v7, 0x1b

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_1c

    const/16 v7, 0x1c

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_1d

    const/16 v7, 0x1d

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_1e

    const/16 v7, 0x1e

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_1f

    const/16 v7, 0x1f

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_20

    const/16 v7, 0x20

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_21

    const/16 v7, 0x21

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_22

    const/16 v7, 0x22

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_23

    const/16 v7, 0x23

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_24

    const/16 v7, 0x24

    aput-object v2, v0, v7

    new-array v2, v1, [I

    fill-array-data v2, :array_25

    const/16 v7, 0x25

    aput-object v2, v0, v7

    new-array v1, v1, [I

    fill-array-data v1, :array_26

    const/16 v2, 0x26

    aput-object v1, v0, v2

    const/4 v1, 0x0

    move-object v2, v1

    const/4 v1, 0x0

    :goto_0
    array-length v7, v0

    if-ge v1, v7, :cond_2

    aget-object v7, v0, v1

    aget v7, v7, v3

    if-ne v7, p1, :cond_1

    aget-object v7, v0, v1

    aget v7, v7, v4

    if-eq v7, p2, :cond_0

    aget-object v7, v0, v1

    aget v7, v7, v4

    const/4 v8, -0x1

    if-ne v7, v8, :cond_1

    :cond_0
    new-instance v2, Lest/LoadLigaOptions;

    invoke-direct {v2}, Lest/LoadLigaOptions;-><init>()V

    aget-object v7, v0, v1

    aget v7, v7, v5

    iput v7, v2, Lest/LoadLigaOptions;->nTimes:I

    aget-object v7, v0, v1

    aget v7, v7, v6

    iput v7, v2, Lest/LoadLigaOptions;->nRebaixados:I

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-object v2

    nop

    :array_0
    .array-data 4
        0x3
        -0x1
        0x12
        0x3
    .end array-data

    :array_1
    .array-data 4
        0xb
        0x1
        0x14
        0x3
    .end array-data

    :array_2
    .array-data 4
        0xb
        0x2
        0x14
        0x3
    .end array-data

    :array_3
    .array-data 4
        0x15
        -0x1
        0x12
        0x1
    .end array-data

    :array_4
    .array-data 4
        0x15
        0x2
        0x10
        0x2
    .end array-data

    :array_5
    .array-data 4
        0x1b
        -0x1
        0x10
        0x2
    .end array-data

    :array_6
    .array-data 4
        0x1d
        0x1
        0x14
        0x4
    .end array-data

    :array_7
    .array-data 4
        0x1d
        0x2
        0x14
        0x4
    .end array-data

    :array_8
    .array-data 4
        0x1d
        0x3
        0x14
        0x4
    .end array-data

    :array_9
    .array-data 4
        0x1d
        0x4
        0x14
        0x4
    .end array-data

    :array_a
    .array-data 4
        0x2a
        -0x1
        0x12
        0x2
    .end array-data

    :array_b
    .array-data 4
        0x2b
        -0x1
        0x10
        0x2
    .end array-data

    :array_c
    .array-data 4
        0x2e
        -0x1
        0x10
        0x2
    .end array-data

    :array_d
    .array-data 4
        0x2e
        0x1
        0x12
        0x2
    .end array-data

    :array_e
    .array-data 4
        0x4e
        -0x1
        0xe
        0x2
    .end array-data

    :array_f
    .array-data 4
        0x4e
        0x1
        0xe
        0x2
    .end array-data

    :array_10
    .array-data 4
        0x4e
        0x2
        0xc
        0x2
    .end array-data

    :array_11
    .array-data 4
        0x55
        -0x1
        0x12
        0x3
    .end array-data

    :array_12
    .array-data 4
        0x60
        -0x1
        0x12
        0x3
    .end array-data

    :array_13
    .array-data 4
        0x60
        0x2
        0x12
        0x2
    .end array-data

    :array_14
    .array-data 4
        0x6b
        -0x1
        0x12
        0x2
    .end array-data

    :array_15
    .array-data 4
        0x6b
        0x2
        0x14
        0x2
    .end array-data

    :array_16
    .array-data 4
        0x83
        -0x1
        0x12
        0x2
    .end array-data

    :array_17
    .array-data 4
        0x83
        0x2
        0x10
        0x1
    .end array-data

    :array_18
    .array-data 4
        0x98
        -0x1
        0x10
        0x2
    .end array-data

    :array_19
    .array-data 4
        0x98
        0x2
        0x12
        0x3
    .end array-data

    :array_1a
    .array-data 4
        0x9f
        -0x1
        0x10
        0x2
    .end array-data

    :array_1b
    .array-data 4
        0xa2
        -0x1
        0x10
        0x2
    .end array-data

    :array_1c
    .array-data 4
        0xa2
        0x2
        0x14
        0x4
    .end array-data

    :array_1d
    .array-data 4
        0xab
        -0x1
        0x14
        0x4
    .end array-data

    :array_1e
    .array-data 4
        0xab
        0x2
        0x12
        0x2
    .end array-data

    :array_1f
    .array-data 4
        0xc0
        -0x1
        0x12
        0x2
    .end array-data

    :array_20
    .array-data 4
        0xc0
        0x1
        0x14
        0x4
    .end array-data

    :array_21
    .array-data 4
        0xc1
        -0x1
        0x10
        0x2
    .end array-data

    :array_22
    .array-data 4
        0xc1
        0x1
        0xe
        0x1
    .end array-data

    :array_23
    .array-data 4
        0xc1
        0x2
        0x10
        0x2
    .end array-data

    :array_24
    .array-data 4
        0xc3
        -0x1
        0x10
        0x2
    .end array-data

    :array_25
    .array-data 4
        0x9a
        -0x1
        0x12
        0x3
    .end array-data

    :array_26
    .array-data 4
        0xc6
        -0x1
        0x14
        0x2
    .end array-data
.end method

.method public a(Ld/ad;I)V
    .locals 4

    const/4 v0, 0x0

    move v1, p2

    const/4 p2, 0x0

    :goto_0
    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p2, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dR()Ld/p;

    move-result-object v2

    invoke-virtual {v2}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dR()Ld/p;

    move-result-object v2

    invoke-virtual {v2}, Ld/p;->xq()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {p1}, Ld/ad;->gh()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {p1}, Ld/ad;->gh()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, -0x1

    :cond_0
    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    if-lez v1, :cond_5

    :goto_2
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v0, p2, :cond_5

    invoke-virtual {p1}, Ld/ad;->gh()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_3

    invoke-virtual {p1}, Ld/ad;->gh()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, -0x1

    :cond_3
    if-nez v1, :cond_4

    return-void

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_5
    return-void
.end method

.method public a(Ld/ag;I)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-lez p2, :cond_2

    move v2, p2

    const/4 p2, 0x0

    :goto_0
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p2, v3, :cond_3

    if-lez v2, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dX()Ld/v;

    move-result-object v3

    invoke-virtual {v3}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, -0x1

    :cond_0
    if-ne v2, v1, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    move v2, p2

    :cond_3
    :goto_1
    if-lt v2, v1, :cond_5

    iget-object p2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lt p2, v1, :cond_5

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    sub-int/2addr p2, v1

    invoke-virtual {p0, p2}, La/y;->bL(I)[La/ac;

    move-result-object p2

    if-eqz p2, :cond_5

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dX()Ld/v;

    move-result-object v3

    invoke-virtual {v3}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object v1

    aget-object p2, p2, v0

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_2
    add-int/lit8 v2, v2, -0x1

    goto :goto_3

    :cond_4
    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dX()Ld/v;

    move-result-object v3

    invoke-virtual {v3}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object p2, p2, v1

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_5
    :goto_3
    if-lez v2, :cond_8

    :goto_4
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v0, p2, :cond_8

    if-lez v2, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dV()Ld/t;

    move-result-object p2

    invoke-virtual {p2}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dV()Ld/t;

    move-result-object p2

    invoke-virtual {p2}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dX()Ld/v;

    move-result-object p2

    invoke-virtual {p2}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    invoke-virtual {p1}, Ld/ag;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, -0x1

    :cond_6
    if-nez v2, :cond_7

    return-void

    :cond_7
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_8
    return-void
.end method

.method public a(Ld/p;IILa/ac;La/ac;)V
    .locals 5

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_0

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_1

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/y;->kL()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    :cond_1
    :goto_0
    if-lez p3, :cond_4

    move v0, p3

    const/4 p3, 0x0

    :goto_1
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p3, v3, :cond_5

    if-lez v0, :cond_2

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_2
    if-ne v0, v2, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 p3, p3, 0x1

    goto :goto_1

    :cond_4
    move v0, p3

    :cond_5
    :goto_2
    iget-object p3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-lt p3, v2, :cond_6

    if-lez v0, :cond_6

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->db()I

    move-result p3

    sub-int/2addr p3, v2

    invoke-virtual {p0, p3}, La/y;->bL(I)[La/ac;

    move-result-object p3

    if-eqz p3, :cond_6

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object v3, p3, v1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object p3, p3, v1

    invoke-virtual {v2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_6
    if-lez v0, :cond_9

    const/4 p3, 0x0

    :goto_3
    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p3, v2, :cond_9

    if-lez v0, :cond_7

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_7

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_7
    if-nez v0, :cond_8

    goto :goto_4

    :cond_8
    add-int/lit8 p3, p3, 0x1

    goto :goto_3

    :cond_9
    :goto_4
    if-lez p2, :cond_c

    :goto_5
    iget-object p3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-ge v1, p3, :cond_c

    if-lez p2, :cond_a

    invoke-virtual {p1}, Ld/p;->xn()Ljava/util/ArrayList;

    move-result-object p3

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_a

    invoke-virtual {p1}, Ld/p;->xq()Ljava/util/ArrayList;

    move-result-object p3

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_a

    iget-object p3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    if-eq p3, p4, :cond_a

    iget-object p3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    if-eq p3, p5, :cond_a

    invoke-virtual {p1}, Ld/p;->xq()Ljava/util/ArrayList;

    move-result-object p3

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, -0x1

    :cond_a
    if-nez p2, :cond_b

    return-void

    :cond_b
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_c
    return-void
.end method

.method public a(Ld/q;)V
    .locals 1

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(Ld/r;I)V
    .locals 5

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_0

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_1

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/y;->kL()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    :cond_1
    :goto_0
    if-lez p2, :cond_4

    move v0, p2

    const/4 p2, 0x0

    :goto_1
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p2, v3, :cond_5

    if-lez v0, :cond_2

    invoke-virtual {p1}, Ld/r;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {p1}, Ld/r;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_2
    if-ne v0, v2, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_4
    move v0, p2

    :cond_5
    :goto_2
    iget-object p2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lt p2, v2, :cond_6

    if-lez v0, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    sub-int/2addr p2, v2

    invoke-virtual {p0, p2}, La/y;->bL(I)[La/ac;

    move-result-object p2

    if-eqz p2, :cond_6

    invoke-virtual {p1}, Ld/r;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object v3, p2, v1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {p1}, Ld/r;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object p2, p2, v1

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_6
    if-lez v0, :cond_9

    :goto_3
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v1, p2, :cond_9

    if-lez v0, :cond_7

    invoke-virtual {p1}, Ld/r;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_7

    invoke-virtual {p1}, Ld/r;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_7
    if-nez v0, :cond_8

    return-void

    :cond_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_9
    return-void
.end method

.method public a(Ld/s;I)V
    .locals 5

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_0

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_1

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/y;->kL()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    :cond_1
    :goto_0
    if-lez p2, :cond_4

    move v0, p2

    const/4 p2, 0x0

    :goto_1
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p2, v3, :cond_5

    if-lez v0, :cond_2

    invoke-virtual {p1}, Ld/s;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {p1}, Ld/s;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_2
    if-ne v0, v2, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_4
    move v0, p2

    :cond_5
    :goto_2
    iget-object p2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lt p2, v2, :cond_6

    if-lez v0, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    sub-int/2addr p2, v2

    invoke-virtual {p0, p2}, La/y;->bL(I)[La/ac;

    move-result-object p2

    if-eqz p2, :cond_6

    invoke-virtual {p1}, Ld/s;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object v3, p2, v1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {p1}, Ld/s;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object p2, p2, v1

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_6
    if-lez v0, :cond_9

    :goto_3
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v1, p2, :cond_9

    if-lez v0, :cond_7

    invoke-virtual {p1}, Ld/s;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_7

    invoke-virtual {p1}, Ld/s;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_7
    if-nez v0, :cond_8

    return-void

    :cond_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_9
    return-void
.end method

.method public a(Ld/t;IILa/ac;La/ac;)V
    .locals 4

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_0

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_1

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/y;->kL()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    :cond_1
    :goto_0
    if-lez p3, :cond_4

    move v0, p3

    const/4 p3, 0x0

    :goto_1
    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p3, v2, :cond_4

    if-lez v0, :cond_2

    invoke-virtual {p1}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    if-eq v2, p4, :cond_2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    if-eq v2, p5, :cond_2

    invoke-virtual {p1}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_2
    if-nez v0, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 p3, p3, 0x1

    goto :goto_1

    :cond_4
    :goto_2
    if-lez p2, :cond_7

    :goto_3
    iget-object p3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-ge v1, p3, :cond_7

    if-lez p2, :cond_5

    invoke-virtual {p1}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object p3

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_5

    invoke-virtual {p1}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object p3

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_5

    iget-object p3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    if-eq p3, p4, :cond_5

    iget-object p3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    if-eq p3, p5, :cond_5

    invoke-virtual {p1}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object p3

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, -0x1

    :cond_5
    if-nez p2, :cond_6

    return-void

    :cond_6
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_7
    return-void
.end method

.method public a(Ld/u;I)V
    .locals 5

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_0

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_1

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/y;->kL()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    :cond_1
    :goto_0
    if-lez p2, :cond_4

    move v0, p2

    const/4 p2, 0x0

    :goto_1
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p2, v3, :cond_5

    if-lez v0, :cond_2

    invoke-virtual {p1}, Ld/u;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {p1}, Ld/u;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_2
    if-ne v0, v2, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_4
    move v0, p2

    :cond_5
    :goto_2
    iget-object p2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lt p2, v2, :cond_6

    if-lez v0, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    sub-int/2addr p2, v2

    invoke-virtual {p0, p2}, La/y;->bL(I)[La/ac;

    move-result-object p2

    if-eqz p2, :cond_6

    invoke-virtual {p1}, Ld/u;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object v3, p2, v1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {p1}, Ld/u;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object p2, p2, v1

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_6
    if-lez v0, :cond_9

    :goto_3
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v1, p2, :cond_9

    if-lez v0, :cond_7

    invoke-virtual {p1}, Ld/u;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_7

    invoke-virtual {p1}, Ld/u;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_7
    if-nez v0, :cond_8

    return-void

    :cond_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_9
    return-void
.end method

.method public a(Ld/v;I)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-lez p2, :cond_2

    move v2, p2

    const/4 p2, 0x0

    :goto_0
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p2, v3, :cond_3

    if-lez v2, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, -0x1

    :cond_0
    if-ne v2, v1, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    move v2, p2

    :cond_3
    :goto_1
    if-lt v2, v1, :cond_5

    iget-object p2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lt p2, v1, :cond_5

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    sub-int/2addr p2, v1

    invoke-virtual {p0, p2}, La/y;->bL(I)[La/ac;

    move-result-object p2

    if-eqz p2, :cond_5

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v1

    aget-object p2, p2, v0

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_2
    add-int/lit8 v2, v2, -0x1

    goto :goto_3

    :cond_4
    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object v3

    aget-object v4, p2, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object v3

    aget-object p2, p2, v1

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_5
    :goto_3
    if-lez v2, :cond_8

    :goto_4
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v0, p2, :cond_8

    if-lez v2, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dV()Ld/t;

    move-result-object p2

    invoke-virtual {p2}, Ld/t;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dV()Ld/t;

    move-result-object p2

    invoke-virtual {p2}, Ld/t;->yi()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    invoke-virtual {p1}, Ld/v;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v1, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, -0x1

    :cond_6
    if-nez v2, :cond_7

    return-void

    :cond_7
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_8
    return-void
.end method

.method public a(Ld/w;I)V
    .locals 5

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_0

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_1

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/y;->kL()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    :cond_1
    :goto_0
    if-lez p2, :cond_4

    move v0, p2

    const/4 p2, 0x0

    :goto_1
    iget-object v3, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p2, v3, :cond_5

    if-lez v0, :cond_2

    invoke-virtual {p1}, Ld/w;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {p1}, Ld/w;->xn()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_2
    if-ne v0, v2, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_4
    move v0, p2

    :cond_5
    :goto_2
    iget-object p2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lt p2, v2, :cond_6

    if-lez v0, :cond_6

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    sub-int/2addr p2, v2

    invoke-virtual {p0, p2}, La/y;->bL(I)[La/ac;

    move-result-object p2

    if-eqz p2, :cond_6

    invoke-virtual {p1}, Ld/w;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object v3, p2, v1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {p1}, Ld/w;->xn()Ljava/util/ArrayList;

    move-result-object v2

    aget-object p2, p2, v1

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_6
    if-lez v0, :cond_9

    :goto_3
    iget-object p2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge v1, p2, :cond_9

    if-lez v0, :cond_7

    invoke-virtual {p1}, Ld/w;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_7

    invoke-virtual {p1}, Ld/w;->xn()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v2, p0, La/y;->sk:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_7
    if-nez v0, :cond_8

    return-void

    :cond_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_9
    return-void
.end method

.method public a(Ld/x;)V
    .locals 0

    iput-object p1, p0, La/y;->si:Ld/x;

    return-void
.end method

.method public a(Ljava/util/ArrayList;La/af;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;",
            "La/af;",
            "Z)V"
        }
    .end annotation

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p0}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    invoke-virtual {p0}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {p0}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p2}, La/af;->mT()La/ac;

    move-result-object v3

    if-eq v2, v3, :cond_0

    invoke-virtual {p0}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    invoke-static {p3}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_2

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_2

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    return-void
.end method

.method public a(Ljava/util/ArrayList;La/af;ZZ)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;",
            "La/af;",
            "ZZ)V"
        }
    .end annotation

    move-object v0, p0

    const/4 v1, 0x5

    new-array v2, v1, [[I

    const/4 v3, 0x6

    new-array v4, v3, [I

    fill-array-data v4, :array_0

    const/4 v5, 0x0

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_1

    const/4 v6, 0x1

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_2

    const/4 v7, 0x2

    aput-object v4, v2, v7

    new-array v4, v3, [I

    fill-array-data v4, :array_3

    const/4 v8, 0x3

    aput-object v4, v2, v8

    new-array v4, v3, [I

    fill-array-data v4, :array_4

    const/4 v9, 0x4

    aput-object v4, v2, v9

    new-array v4, v1, [[I

    new-array v10, v3, [I

    fill-array-data v10, :array_5

    aput-object v10, v4, v5

    new-array v10, v3, [I

    fill-array-data v10, :array_6

    aput-object v10, v4, v6

    new-array v10, v3, [I

    fill-array-data v10, :array_7

    aput-object v10, v4, v7

    new-array v10, v3, [I

    fill-array-data v10, :array_8

    aput-object v10, v4, v8

    new-array v10, v3, [I

    fill-array-data v10, :array_9

    aput-object v10, v4, v9

    new-array v10, v1, [[I

    new-array v11, v3, [I

    fill-array-data v11, :array_a

    aput-object v11, v10, v5

    new-array v11, v3, [I

    fill-array-data v11, :array_b

    aput-object v11, v10, v6

    new-array v11, v3, [I

    fill-array-data v11, :array_c

    aput-object v11, v10, v7

    new-array v11, v3, [I

    fill-array-data v11, :array_d

    aput-object v11, v10, v8

    new-array v11, v3, [I

    fill-array-data v11, :array_e

    aput-object v11, v10, v9

    new-array v11, v1, [[I

    new-array v12, v3, [I

    fill-array-data v12, :array_f

    aput-object v12, v11, v5

    new-array v12, v3, [I

    fill-array-data v12, :array_10

    aput-object v12, v11, v6

    new-array v12, v3, [I

    fill-array-data v12, :array_11

    aput-object v12, v11, v7

    new-array v12, v3, [I

    fill-array-data v12, :array_12

    aput-object v12, v11, v8

    new-array v12, v3, [I

    fill-array-data v12, :array_13

    aput-object v12, v11, v9

    new-array v1, v1, [[I

    new-array v12, v3, [I

    fill-array-data v12, :array_14

    aput-object v12, v1, v5

    new-array v12, v3, [I

    fill-array-data v12, :array_15

    aput-object v12, v1, v6

    new-array v12, v3, [I

    fill-array-data v12, :array_16

    aput-object v12, v1, v7

    new-array v7, v3, [I

    fill-array-data v7, :array_17

    aput-object v7, v1, v8

    new-array v3, v3, [I

    fill-array-data v3, :array_18

    aput-object v3, v1, v9

    invoke-virtual {p2}, La/af;->hE()La/ac;

    move-result-object v3

    if-nez v3, :cond_0

    invoke-virtual {p2}, La/af;->mU()I

    move-result v3

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, La/af;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getDivisao()I

    move-result v3

    sub-int/2addr v3, v6

    :goto_0
    if-gez v3, :cond_1

    iget-object v3, v0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v6

    :cond_1
    iget-object v7, v0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    sub-int/2addr v7, v6

    if-le v3, v7, :cond_2

    iget-object v3, v0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v6

    :cond_2
    if-ltz v3, :cond_a

    aget-object v2, v2, v3

    new-instance v7, Ljava/util/Random;

    invoke-direct {v7}, Ljava/util/Random;-><init>()V

    const/16 v8, 0x3e8

    invoke-virtual {v7, v8}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    const/16 v8, 0x2bc

    const/16 v9, 0x1f4

    if-le v7, v8, :cond_4

    aget-object v2, v4, v3

    :cond_3
    :goto_1
    move-object v4, v2

    goto :goto_2

    :cond_4
    if-le v7, v9, :cond_3

    aget-object v2, v10, v3

    goto :goto_1

    :goto_2
    if-nez p4, :cond_5

    aget-object v4, v11, v3

    if-le v7, v9, :cond_5

    aget-object v4, v1, v3

    :cond_5
    :goto_3
    array-length v1, v4

    if-ge v5, v1, :cond_a

    aget v1, v4, v5

    const/16 v2, 0x8

    if-ne v1, v2, :cond_6

    iget-object v1, v0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v6

    aput v1, v4, v5

    :cond_6
    aget v1, v4, v5

    if-ltz v1, :cond_8

    aget v1, v4, v5

    iget-object v2, v0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_8

    iget-object v1, v0, La/y;->sf:Ljava/util/ArrayList;

    aget v2, v4, v5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld/q;

    invoke-virtual {v1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_7

    iget-object v1, v0, La/y;->sf:Ljava/util/ArrayList;

    aget v2, v4, v5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld/q;

    move-object v2, p1

    move-object v3, p2

    move/from16 v7, p3

    invoke-virtual {v1, v2, v3, v7}, Ld/q;->b(Ljava/util/ArrayList;La/af;Z)V

    goto :goto_4

    :cond_7
    move-object v2, p1

    move-object v3, p2

    move/from16 v7, p3

    invoke-virtual {v3}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_9

    invoke-virtual/range {p0 .. p3}, La/y;->a(Ljava/util/ArrayList;La/af;Z)V

    goto :goto_4

    :cond_8
    move-object v2, p1

    move-object v3, p2

    move/from16 v7, p3

    :cond_9
    :goto_4
    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_a
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x1
        0x2
        -0x1
        -0x1
    .end array-data

    :array_1
    .array-data 4
        0x1
        0x1
        0x2
        0x3
        -0x1
        -0x1
    .end array-data

    :array_2
    .array-data 4
        0x2
        0x2
        0x3
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_3
    .array-data 4
        0x2
        0x3
        0x3
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_4
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_5
    .array-data 4
        0x0
        -0x1
        -0x1
        0x2
        -0x1
        -0x1
    .end array-data

    :array_6
    .array-data 4
        0x1
        -0x1
        0x2
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_7
    .array-data 4
        0x2
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_8
    .array-data 4
        0x2
        0x3
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_9
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_a
    .array-data 4
        0x0
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_b
    .array-data 4
        0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_c
    .array-data 4
        0x2
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_d
    .array-data 4
        0x2
        0x3
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_e
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_f
    .array-data 4
        0x0
        0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_10
    .array-data 4
        0x1
        0x2
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_11
    .array-data 4
        0x2
        0x8
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_12
    .array-data 4
        0x3
        0x8
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_13
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_14
    .array-data 4
        0x0
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_15
    .array-data 4
        0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_16
    .array-data 4
        0x8
        0x8
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_17
    .array-data 4
        0x8
        0x8
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_18
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data
.end method

.method public bK(I)V
    .locals 0

    iput p1, p0, La/y;->pais:I

    return-void
.end method

.method public bL(I)[La/ac;
    .locals 4

    const/4 v0, 0x2

    new-array v0, v0, [La/ac;

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p0}, La/y;->nM()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-virtual {p0}, La/y;->nM()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/c;

    invoke-virtual {v3}, La/c;->db()I

    move-result v3

    if-ne v3, p1, :cond_0

    invoke-virtual {p0}, La/y;->nM()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/c;

    invoke-virtual {p1}, La/c;->fu()La/ac;

    move-result-object p1

    aput-object p1, v0, v1

    invoke-virtual {p0}, La/y;->nM()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/c;

    invoke-virtual {p1}, La/c;->fv()La/ac;

    move-result-object p1

    const/4 v1, 0x1

    aput-object p1, v0, v1

    return-object v0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public c(La/af;)V
    .locals 2

    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/af;->v(La/ac;)V

    :cond_1
    invoke-virtual {p1}, La/af;->li()La/ac;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-direct {p0, p1}, La/y;->d(La/af;)V

    :cond_2
    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0, p1}, La/ac;->e(La/af;)V

    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {p1, v0}, La/af;->v(La/ac;)V

    invoke-virtual {p0}, La/y;->li()La/ac;

    move-result-object v0

    invoke-virtual {p1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {v0, p1}, La/ac;->j(Ljava/lang/Boolean;)V

    return-void
.end method

.method public cssSk()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/y;->sk:Ljava/util/ArrayList;

    return-object v0
.end method

.method public f(Landroid/content/Context;)I
    .locals 3

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "flag_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, La/y;->pais:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v1, v2, p1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public getNivel()I
    .locals 1

    iget v0, p0, La/y;->so:I

    return v0
.end method

.method public iw()I
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/y;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    return v0
.end method

.method public kC()I
    .locals 1

    iget v0, p0, La/y;->pais:I

    return v0
.end method

.method public kD()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->getPais()I

    move-result v1

    iget v2, p0, La/y;->pais:I

    if-ne v1, v2, :cond_0

    iget-object v1, p0, La/y;->sj:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public kE()V
    .locals 22

    move-object/from16 v13, p0

    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    iget-object v0, v13, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v14, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v12, 0x0

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v11, 0x1

    if-ge v0, v1, :cond_0

    invoke-virtual {v14, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v1, v2}, La/ac;->k(Ljava/lang/Boolean;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    sget-object v0, Lcomponents/ce;->oV:Ljava/util/Comparator;

    invoke-static {v14, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-virtual {v15, v14}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x1

    :goto_1
    const/16 v0, 0x1d

    const/4 v1, 0x4

    if-gt v9, v1, :cond_10

    iget v2, v13, La/y;->pais:I

    invoke-static {v2, v9}, La/y;->S(II)Lest/ConfigLigaType;

    move-result-object v2

    new-instance v3, Lest/LoadLigaOptions;

    invoke-direct {v3}, Lest/LoadLigaOptions;-><init>()V

    invoke-virtual {v10}, Ljava/util/ArrayList;->clear()V

    if-nez v2, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v2}, Lest/ConfigLigaType;->getnTimes()I

    move-result v2

    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v4

    :goto_2
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eX()I

    move-result v2

    const/16 v4, 0xe

    const/16 v5, 0xa

    const/4 v6, 0x2

    if-ne v2, v5, :cond_2

    iput v5, v3, Lest/LoadLigaOptions;->nTimes:I

    iput v6, v3, Lest/LoadLigaOptions;->nRebaixados:I

    goto :goto_6

    :cond_2
    const/16 v2, 0x14

    iput v2, v3, Lest/LoadLigaOptions;->nTimes:I

    iput v1, v3, Lest/LoadLigaOptions;->nRebaixados:I

    iput-boolean v11, v3, Lest/LoadLigaOptions;->multiplosTurnos:Z

    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-lt v7, v2, :cond_3

    iput v2, v3, Lest/LoadLigaOptions;->nTimes:I

    goto :goto_5

    :cond_3
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v7, 0x12

    if-lt v2, v7, :cond_4

    :goto_3
    iput v7, v3, Lest/LoadLigaOptions;->nTimes:I

    :goto_4
    iput v6, v3, Lest/LoadLigaOptions;->nRebaixados:I

    goto :goto_5

    :cond_4
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v7, 0x10

    if-lt v2, v7, :cond_5

    goto :goto_3

    :cond_5
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lt v2, v4, :cond_6

    iput v4, v3, Lest/LoadLigaOptions;->nTimes:I

    goto :goto_4

    :cond_6
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v7, 0xc

    if-lt v2, v7, :cond_7

    goto :goto_3

    :cond_7
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lt v2, v5, :cond_8

    iput v5, v3, Lest/LoadLigaOptions;->nTimes:I

    goto :goto_4

    :cond_8
    :goto_5
    iget v2, v13, La/y;->pais:I

    invoke-virtual {v13, v2, v9}, La/y;->R(II)Lest/LoadLigaOptions;

    move-result-object v2

    if-eqz v2, :cond_9

    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v5

    iget v6, v2, Lest/LoadLigaOptions;->nTimes:I

    if-lt v5, v6, :cond_9

    iget v5, v2, Lest/LoadLigaOptions;->nTimes:I

    iput v5, v3, Lest/LoadLigaOptions;->nTimes:I

    iget v2, v2, Lest/LoadLigaOptions;->nRebaixados:I

    iput v2, v3, Lest/LoadLigaOptions;->nRebaixados:I

    :cond_9
    :goto_6
    sget-object v2, La/y;->sr:[Ljava/lang/String;

    if-eqz v2, :cond_a

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v5, v13, La/y;->pais:I

    invoke-static {v5}, Lcomponents/bz;->dL(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " - "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v5, La/y;->sr:[Ljava/lang/String;

    aget-object v5, v5, v9

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_7
    iput-object v2, v3, Lest/LoadLigaOptions;->nomeLiga:Ljava/lang/String;

    goto :goto_8

    :cond_a
    iget v2, v13, La/y;->pais:I

    invoke-static {v2}, Lcomponents/bz;->dL(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_7

    :goto_8
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    iget v5, v3, Lest/LoadLigaOptions;->nTimes:I

    if-lt v2, v5, :cond_e

    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-le v2, v4, :cond_b

    iput-boolean v12, v3, Lest/LoadLigaOptions;->multiplosTurnos:Z

    :cond_b
    if-ne v9, v1, :cond_c

    iget v1, v13, La/y;->pais:I

    if-ne v1, v0, :cond_c

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    if-eqz v0, :cond_c

    const/16 v0, 0x60

    iput v0, v3, Lest/LoadLigaOptions;->nTimes:I

    const/16 v0, 0x10

    iput v0, v3, Lest/LoadLigaOptions;->nGrupos:I

    const/4 v0, 0x4

    iput v0, v3, Lest/LoadLigaOptions;->numeroTimesMataMata:I

    iput-boolean v12, v3, Lest/LoadLigaOptions;->doisTurnos:Z

    const/4 v0, 0x1

    iput-boolean v0, v3, Lest/LoadLigaOptions;->jogosDentroGrupo:Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v11}, La/b;->l(Z)V

    goto :goto_a

    :cond_c
    const/4 v0, 0x0

    :goto_9
    iget v1, v3, Lest/LoadLigaOptions;->nTimes:I

    if-ge v0, v1, :cond_d

    invoke-virtual {v14, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_9

    :cond_d
    :goto_a
    new-instance v8, Ld/q;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object v0, v8

    move-object v1, v3

    move-object v2, v10

    move v3, v4

    move-object v4, v5

    move-object v5, v6

    move-object v6, v13

    move-object/from16 v20, v8

    move-object/from16 v8, v16

    move/from16 v16, v9

    move/from16 v9, v17

    move-object/from16 v21, v10

    move-object/from16 v10, v18

    const/16 v17, 0x1

    move/from16 v11, v19

    const/16 v18, 0x0

    move-object v12, v13

    invoke-direct/range {v0 .. v12}, Ld/q;-><init>(Lest/LoadLigaOptions;Ljava/util/ArrayList;ILd/q;Ld/q;La/y;ILd/m;ZLd/q;ZLa/al;)V

    iget-object v0, v13, La/y;->sf:Ljava/util/ArrayList;

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, v21

    const/4 v0, 0x0

    :goto_b
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_f

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v14, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_e
    move/from16 v16, v9

    move-object v1, v10

    const/16 v17, 0x1

    const/16 v18, 0x0

    :cond_f
    add-int/lit8 v9, v16, 0x1

    move-object v10, v1

    const/4 v11, 0x1

    const/4 v12, 0x0

    goto/16 :goto_1

    :cond_10
    invoke-direct/range {p0 .. p0}, La/y;->kF()V

    iget v1, v13, La/y;->pais:I

    if-ne v1, v0, :cond_11

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eA()Z

    move-result v1

    if-nez v1, :cond_12

    :cond_11
    invoke-virtual {v13, v15}, La/y;->J(Ljava/util/ArrayList;)Z

    :cond_12
    iget v1, v13, La/y;->pais:I

    if-ne v1, v0, :cond_13

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-static {}, Ld/m;->wX()V

    :cond_13
    return-void
.end method

.method public kG()I
    .locals 2

    iget-object v0, p0, La/y;->sj:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x80

    if-lt v0, v1, :cond_0

    const/4 v0, 0x7

    goto :goto_0

    :cond_0
    const/16 v1, 0x40

    if-lt v0, v1, :cond_1

    const/4 v0, 0x6

    goto :goto_0

    :cond_1
    const/16 v1, 0x20

    if-lt v0, v1, :cond_2

    const/4 v0, 0x5

    goto :goto_0

    :cond_2
    const/16 v1, 0x10

    if-lt v0, v1, :cond_3

    const/4 v0, 0x4

    goto :goto_0

    :cond_3
    const/16 v1, 0x8

    if-lt v0, v1, :cond_4

    const/4 v0, 0x3

    goto :goto_0

    :cond_4
    const/4 v0, 0x0

    :goto_0
    add-int/lit8 v0, v0, -0x1

    return v0
.end method

.method public kH()I
    .locals 1

    iget v0, p0, La/y;->sh:I

    return v0
.end method

.method public kI()V
    .locals 1

    iget v0, p0, La/y;->sh:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/y;->sh:I

    return-void
.end method

.method public kJ()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ld/q;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    return-object v0
.end method

.method public kK()I
    .locals 1

    iget v0, p0, La/y;->pais:I

    return v0
.end method

.method public kO()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/y;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->getNome()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public kP()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/y;->sj:Ljava/util/ArrayList;

    return-object v0
.end method

.method public kQ()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/y;->sl:Ljava/util/ArrayList;

    return-object v0
.end method

.method public kR()V
    .locals 9

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    if-lez v2, :cond_0

    iget-object v2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2, v3}, Ld/q;->eu(I)V

    :cond_0
    const/4 v2, 0x1

    const/4 v4, 0x1

    :goto_0
    iget-object v5, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_1

    iget-object v5, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/q;

    iget-object v6, p0, La/y;->sf:Ljava/util/ArrayList;

    add-int/lit8 v7, v4, -0x1

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->getnRebaixados()I

    move-result v6

    invoke-virtual {v5, v6}, Ld/q;->eu(I)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    :goto_1
    iget-object v5, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_c

    add-int/lit8 v5, v4, 0x1

    iget-object v6, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_5

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v6, 0x0

    :goto_2
    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xH()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_2

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xH()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    const/4 v6, 0x0

    :goto_3
    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xJ()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_3

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xJ()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_3
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ne v6, v7, :cond_b

    const/4 v6, 0x0

    :goto_4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_4

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_4

    :cond_4
    const/4 v6, 0x0

    :goto_5
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_b

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_5

    :cond_5
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v6, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->getnRebaixados()I

    move-result v6

    iget-object v7, p0, La/y;->sg:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v7, v6, :cond_6

    iget-object v6, p0, La/y;->sg:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    :cond_6
    if-lez v6, :cond_b

    const/4 v7, 0x0

    :goto_6
    iget-object v8, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/q;

    invoke-virtual {v8}, Ld/q;->xH()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_8

    if-ge v7, v6, :cond_7

    iget-object v8, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/q;

    invoke-virtual {v8}, Ld/q;->xH()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    add-int/lit8 v7, v7, 0x1

    goto :goto_6

    :cond_8
    const/4 v7, 0x0

    :goto_7
    if-ge v7, v6, :cond_9

    iget-object v8, p0, La/y;->sg:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v7, v7, 0x1

    goto :goto_7

    :cond_9
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ne v6, v7, :cond_b

    const/4 v6, 0x0

    :goto_8
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_a

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v7, p0, La/y;->sg:Ljava/util/ArrayList;

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7, v3}, La/ac;->setDivisao(I)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_8

    :cond_a
    const/4 v6, 0x0

    :goto_9
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_b

    iget-object v7, p0, La/y;->sg:Ljava/util/ArrayList;

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v7, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_9

    :cond_b
    iget-object v6, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xw()V

    move v4, v5

    goto/16 :goto_1

    :cond_c
    iget v0, p0, La/y;->pais:I

    const/16 v1, 0x1d

    if-ne v0, v1, :cond_d

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eA()Z

    move-result v0

    if-eqz v0, :cond_d

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    iget-object v1, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    invoke-virtual {v0}, Ld/q;->xx()V

    :cond_d
    return-void
.end method

.method public kS()La/af;
    .locals 13

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, La/y;->kK()I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x0

    :goto_0
    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v8, v9, :cond_6

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-nez v9, :cond_5

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->li()La/ac;

    move-result-object v9

    if-nez v9, :cond_5

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->mS()I

    move-result v9

    const/4 v10, 0x5

    if-ne v9, v6, :cond_0

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->getReputacao()I

    move-result v9

    if-ne v9, v10, :cond_0

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->mS()I

    move-result v9

    const/4 v11, 0x4

    if-ne v9, v6, :cond_1

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->getReputacao()I

    move-result v9

    if-ne v9, v11, :cond_1

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->mS()I

    move-result v9

    const/4 v12, 0x3

    if-ne v9, v6, :cond_2

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->getReputacao()I

    move-result v9

    if-ne v9, v12, :cond_2

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->getReputacao()I

    move-result v9

    if-ne v9, v10, :cond_3

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->getReputacao()I

    move-result v9

    if-ne v9, v11, :cond_4

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/af;

    invoke-virtual {v9}, La/af;->getReputacao()I

    move-result v9

    if-ne v9, v12, :cond_5

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_0

    :cond_6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-lez v6, :cond_7

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    :goto_1
    check-cast v0, La/af;

    return-object v0

    :cond_7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_8

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_8
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_9

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_9
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_a

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_a
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_b

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_b
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_c

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_c
    const/4 v0, 0x0

    return-object v0
.end method

.method public kT()V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPais()I

    move-result v4

    iget v5, p0, La/y;->pais:I

    if-ne v4, v5, :cond_1

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    if-nez v4, :cond_0

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/16 v1, 0xf

    if-lt v2, v1, :cond_3

    const/4 v1, 0x2

    if-lt v3, v1, :cond_3

    const/4 v0, 0x1

    :cond_3
    iput-boolean v0, p0, La/y;->sm:Z

    return-void
.end method

.method public kU()Z
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPais()I

    move-result v4

    iget v5, p0, La/y;->pais:I

    if-ne v4, v5, :cond_1

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    if-nez v4, :cond_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 v1, 0x0

    :goto_2
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_5

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPais()I

    move-result v4

    iget v5, p0, La/y;->pais:I

    if-ne v4, v5, :cond_4

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    if-nez v4, :cond_3

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_3
    add-int/lit8 v3, v3, 0x1

    :cond_4
    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_5
    const/16 v1, 0xf

    if-lt v3, v1, :cond_6

    const/4 v1, 0x2

    if-lt v2, v1, :cond_6

    const/4 v0, 0x1

    :cond_6
    return v0
.end method

.method public kV()Z
    .locals 1

    iget-boolean v0, p0, La/y;->sm:Z

    return v0
.end method

.method public kW()V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/y;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->getNivel()I

    move-result v0

    iput v0, p0, La/y;->so:I

    return-void
.end method

.method public kX()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/y;->sp:Ljava/lang/String;

    return-object v0
.end method

.method public kY()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/y;->sg:Ljava/util/ArrayList;

    return-object v0
.end method

.method public kZ()Ld/x;
    .locals 1

    iget-object v0, p0, La/y;->si:Ld/x;

    return-object v0
.end method

.method public la()Z
    .locals 1

    iget-boolean v0, p0, La/y;->sq:Z

    return v0
.end method

.method public lb()I
    .locals 1

    iget-object v0, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public lc()I
    .locals 2

    iget v0, p0, La/y;->so:I

    const/16 v1, 0x14

    if-lt v0, v1, :cond_0

    const/4 v0, 0x5

    return v0

    :cond_0
    iget v0, p0, La/y;->so:I

    const/16 v1, 0x13

    if-lt v0, v1, :cond_1

    const/4 v0, 0x4

    return v0

    :cond_1
    iget v0, p0, La/y;->so:I

    const/16 v1, 0x11

    if-lt v0, v1, :cond_2

    const/4 v0, 0x3

    return v0

    :cond_2
    iget v0, p0, La/y;->so:I

    const/16 v1, 0xf

    if-lt v0, v1, :cond_3

    const/4 v0, 0x2

    return v0

    :cond_3
    const/4 v0, 0x1

    return v0
.end method

.method public ld()Z
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->jH()La/al;

    move-result-object v2

    if-ne v2, p0, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    :cond_0
    const/4 v0, 0x1

    return v0

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return v0
.end method

.method public le()Z
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x0

    :goto_1
    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    iget-object v3, p0, La/y;->sf:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return v0
.end method

.method public lf()Z
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->jH()La/al;

    move-result-object v2

    if-ne v2, p0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public lg()Z
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/y;->sf:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jH()La/al;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public lh()La/ac;
    .locals 1

    iget-object v0, p0, La/y;->ss:La/ac;

    return-object v0
.end method

.method public li()La/ac;
    .locals 17

    move-object/from16 v0, p0

    iget-object v1, v0, La/y;->ss:La/ac;

    if-nez v1, :cond_0

    new-instance v1, La/ac;

    invoke-virtual/range {p0 .. p0}, La/y;->kO()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, -0x1

    invoke-virtual/range {p0 .. p0}, La/y;->kK()I

    move-result v6

    const/4 v7, -0x1

    invoke-virtual/range {p0 .. p0}, La/y;->getNivel()I

    move-result v8

    const/4 v9, 0x0

    invoke-virtual/range {p0 .. p0}, La/y;->lc()I

    move-result v10

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, -0x1

    const/4 v15, 0x0

    const/16 v16, 0x1

    move-object v2, v1

    invoke-direct/range {v2 .. v16}, La/ac;-><init>(Ljava/lang/String;Ljava/lang/String;IIIILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/ArrayList;Z)V

    iput-object v1, v0, La/y;->ss:La/ac;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eT()I

    move-result v2

    invoke-virtual {v1, v2}, La/ac;->cc(I)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eU()V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "P"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p0 .. p0}, La/y;->kK()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v1

    invoke-virtual {v1}, La/z;->ll()[I

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "P"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p0 .. p0}, La/y;->kK()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v2

    invoke-virtual {v2}, La/z;->lm()[I

    move-result-object v2

    const-string v3, "#%02x%02x%02x"

    const/4 v4, 0x3

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v6, 0x0

    aget v7, v1, v6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v5, v6

    const/4 v7, 0x1

    aget v8, v1, v7

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v5, v7

    const/4 v8, 0x2

    aget v1, v1, v8

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v8

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "#%02x%02x%02x"

    new-array v4, v4, [Ljava/lang/Object;

    aget v5, v2, v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v6

    aget v5, v2, v7

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v7

    aget v2, v2, v8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v4, v8

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, v0, La/y;->ss:La/ac;

    invoke-virtual {v3, v1}, La/ac;->q(Ljava/lang/String;)V

    iget-object v1, v0, La/y;->ss:La/ac;

    invoke-virtual {v1, v2}, La/ac;->p(Ljava/lang/String;)V

    :cond_0
    iget-object v1, v0, La/y;->ss:La/ac;

    return-object v1
.end method

.method public m(La/al;)V
    .locals 0

    iget-object p1, p0, La/y;->si:Ld/x;

    invoke-virtual {p1, p0}, Ld/x;->w(La/al;)V

    return-void
.end method

.method public v(La/ac;)V
    .locals 0

    iput-object p1, p0, La/y;->ss:La/ac;

    return-void
.end method
