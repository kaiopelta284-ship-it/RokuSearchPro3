.class public La/af;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private gl:I

.field private ng:I

.field private oo:I

.field private pq:Ljava/lang/String;

.field private ss:La/ac;

.field private xN:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ai;",
            ">;"
        }
    .end annotation
.end field

.field private transient xW:La/ac;

.field private transient xX:La/ac;

.field private xY:I

.field private xZ:I

.field private xh:Ljava/lang/Boolean;

.field private xo:I

.field private ya:I

.field private yb:I

.field private yc:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/d;",
            ">;"
        }
    .end annotation
.end field

.field private yd:I

.field private ye:I

.field private yf:I

.field private yg:I

.field private yh:I

.field private yi:I

.field private yj:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/co;",
            ">;"
        }
    .end annotation
.end field

.field private yk:I

.field private yl:I


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, p0, La/af;->xh:Ljava/lang/Boolean;

    const/4 v1, -0x1

    iput v1, p0, La/af;->gl:I

    const/4 v2, 0x0

    iput-object v2, p0, La/af;->xW:La/ac;

    iput-object v2, p0, La/af;->xX:La/ac;

    iput v1, p0, La/af;->oo:I

    iput v1, p0, La/af;->xY:I

    iput v0, p0, La/af;->xZ:I

    iput v1, p0, La/af;->ng:I

    iput-object v2, p0, La/af;->ss:La/ac;

    const/4 v3, 0x1

    iput v3, p0, La/af;->yb:I

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/af;->yc:Ljava/util/ArrayList;

    const/16 v3, 0x64

    iput v3, p0, La/af;->yh:I

    const/16 v3, 0x50

    iput v3, p0, La/af;->yi:I

    iput v0, p0, La/af;->xo:I

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/af;->xN:Ljava/util/ArrayList;

    iput-object v2, p0, La/af;->yj:Ljava/util/ArrayList;

    iput v1, p0, La/af;->yk:I

    iput v0, p0, La/af;->yl:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, p0, La/af;->xh:Ljava/lang/Boolean;

    const/4 v1, -0x1

    iput v1, p0, La/af;->gl:I

    const/4 v2, 0x0

    iput-object v2, p0, La/af;->xW:La/ac;

    iput-object v2, p0, La/af;->xX:La/ac;

    iput v1, p0, La/af;->oo:I

    iput v1, p0, La/af;->xY:I

    iput v0, p0, La/af;->xZ:I

    iput v1, p0, La/af;->ng:I

    iput-object v2, p0, La/af;->ss:La/ac;

    const/4 v3, 0x1

    iput v3, p0, La/af;->yb:I

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/af;->yc:Ljava/util/ArrayList;

    const/16 v3, 0x64

    iput v3, p0, La/af;->yh:I

    const/16 v3, 0x50

    iput v3, p0, La/af;->yi:I

    iput v0, p0, La/af;->xo:I

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/af;->xN:Ljava/util/ArrayList;

    iput-object v2, p0, La/af;->yj:Ljava/util/ArrayList;

    iput v1, p0, La/af;->yk:I

    iput v0, p0, La/af;->yl:I

    iput-object p1, p0, La/af;->pq:Ljava/lang/String;

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->fk()I

    move-result p1

    iput p1, p0, La/af;->gl:I

    return-void
.end method

.method public static c(Ljava/lang/String;I)V
    .locals 2

    new-instance v0, La/af;

    invoke-direct {v0, p0}, La/af;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, La/af;->cj(I)V

    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, La/af;->j(Ljava/lang/Boolean;)V

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, La/af;->setReputacao(I)V

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, La/af;->j(Ljava/lang/Boolean;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, p1}, La/b;->ah(I)La/y;

    move-result-object p1

    if-nez p1, :cond_0

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    :cond_0
    invoke-virtual {p1}, La/y;->kK()I

    move-result v1

    invoke-virtual {v0, v1}, La/af;->ao(I)V

    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, p0

    invoke-virtual {v0, p1}, La/af;->ck(I)V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0, v0}, La/b;->a(La/af;)V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private p(La/al;)V
    .locals 3

    invoke-virtual {p1}, La/al;->cG()I

    move-result v0

    new-instance v1, La/ai;

    invoke-direct {v1}, La/ai;-><init>()V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    invoke-virtual {v1, v2}, La/ai;->ad(I)V

    const/4 v2, 0x7

    if-ne v0, v2, :cond_0

    invoke-virtual {p0}, La/af;->li()La/ac;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, La/af;->li()La/ac;

    move-result-object v0

    :goto_0
    invoke-virtual {v0}, La/ac;->mE()I

    move-result v0

    invoke-virtual {v1, v0}, La/ai;->aw(I)V

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v0

    goto :goto_0

    :cond_1
    :goto_1
    iget v0, p0, La/af;->gl:I

    invoke-virtual {v1, v0}, La/ai;->cu(I)V

    invoke-virtual {p1}, La/al;->cG()I

    move-result v0

    invoke-virtual {v1, v0}, La/ai;->W(I)V

    invoke-virtual {v1, p1}, La/ai;->l(La/al;)V

    invoke-virtual {p1}, La/al;->cG()I

    move-result v0

    const/4 v2, 0x1

    if-eq v0, v2, :cond_3

    invoke-virtual {p1}, La/al;->cG()I

    move-result v0

    const/4 v2, 0x3

    if-ne v0, v2, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, La/al;->iw()I

    move-result p1

    goto :goto_3

    :cond_3
    :goto_2
    invoke-virtual {p1}, La/al;->nS()I

    move-result p1

    :goto_3
    invoke-virtual {v1, p1}, La/ai;->aJ(I)V

    iget-object p1, p0, La/af;->xN:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public A(La/ac;)V
    .locals 9

    invoke-virtual {p1, p0}, La/ac;->e(La/af;)V

    invoke-virtual {p0, p1}, La/af;->i(La/ac;)V

    const/16 v0, 0x64

    iput v0, p0, La/af;->yh:I

    const/16 v0, 0x50

    iput v0, p0, La/af;->yi:I

    const/4 v0, 0x0

    iput v0, p0, La/af;->yl:I

    invoke-virtual {p1}, La/ac;->mB()V

    invoke-virtual {p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {p1, v2}, La/ac;->j(Ljava/lang/Boolean;)V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, La/ac;->lR()V

    new-instance v3, Lcomponents/co;

    const/4 v5, 0x0

    const/16 v6, 0x4a

    invoke-virtual {p1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v7

    const-string v8, ""

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lcomponents/co;-><init>(La/af;IILjava/lang/String;Ljava/lang/String;)V

    :goto_0
    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_0

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    const-wide/16 v3, 0xb4

    invoke-virtual {v2, v3, v4, v1}, La/p;->a(JZ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/ac;->mx()V

    :cond_1
    return-void
.end method

.method public R(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/co;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/af;->yj:Ljava/util/ArrayList;

    return-void
.end method

.method public addCupTitle(La/al;II)V
    .locals 2

    new-instance v0, La/ai;

    invoke-direct {v0}, La/ai;-><init>()V

    invoke-virtual {v0, p2}, La/ai;->ad(I)V

    iget v1, p0, La/af;->gl:I

    invoke-virtual {v0, v1}, La/ai;->cu(I)V

    invoke-virtual {v0, p3}, La/ai;->W(I)V

    invoke-virtual {v0, p1}, La/ai;->l(La/al;)V

    iget-object v1, p0, La/af;->xN:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v0, p0, La/af;->yd:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/af;->yd:I

    return-void
.end method

.method public ao(I)V
    .locals 0

    iput p1, p0, La/af;->ng:I

    return-void
.end method

.method public b(La/ac;La/p;)V
    .locals 1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result v0

    invoke-virtual {p0, v0}, La/af;->ao(I)V

    :cond_0
    invoke-virtual {p2}, La/p;->getPais()I

    move-result p2

    invoke-virtual {p0, p2}, La/af;->cj(I)V

    if-eqz p1, :cond_1

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result p2

    add-int/lit8 p2, p2, -0x1

    invoke-virtual {p0, p2}, La/af;->ck(I)V

    :cond_1
    if-eqz p1, :cond_2

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result p1

    invoke-virtual {p0, p1}, La/af;->setReputacao(I)V

    :cond_2
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    invoke-virtual {p0, p1}, La/af;->cl(I)V

    return-void
.end method

.method public b(La/al;II)V
    .locals 8

    invoke-virtual {p1}, La/al;->cG()I

    move-result v7

    const/16 v0, 0xd

    new-array v0, v0, [[I

    const/16 v1, 0xb

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_1

    const/4 v3, 0x1

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_2

    const/4 v4, 0x2

    aput-object v2, v0, v4

    new-array v2, v1, [I

    fill-array-data v2, :array_3

    const/4 v5, 0x3

    aput-object v2, v0, v5

    new-array v2, v1, [I

    fill-array-data v2, :array_4

    const/4 v6, 0x4

    aput-object v2, v0, v6

    new-array v2, v1, [I

    fill-array-data v2, :array_5

    const/4 v6, 0x5

    aput-object v2, v0, v6

    new-array v2, v1, [I

    fill-array-data v2, :array_6

    const/4 v6, 0x6

    aput-object v2, v0, v6

    new-array v2, v1, [I

    fill-array-data v2, :array_7

    const/4 v6, 0x7

    aput-object v2, v0, v6

    new-array v2, v1, [I

    fill-array-data v2, :array_8

    const/16 v7, 0x8

    aput-object v2, v0, v7

    const/16 v7, 0xc

    new-array v2, v1, [I

    fill-array-data v2, :array_d

    aput-object v2, v0, v7

    aget-object v0, v0, v7

    if-ne v7, v3, :cond_1

    invoke-virtual {p1}, La/al;->nS()I

    move-result v2

    if-le v2, v3, :cond_1

    invoke-virtual {p1}, La/al;->nS()I

    move-result v0

    if-ne v0, v4, :cond_0

    new-array v0, v1, [I

    fill-array-data v0, :array_9

    goto :goto_0

    :cond_0
    new-array v0, v1, [I

    fill-array-data v0, :array_a

    :cond_1
    :goto_0
    if-ne v7, v5, :cond_2

    invoke-virtual {p1}, La/al;->nS()I

    move-result v2

    if-le v2, v3, :cond_2

    new-array v0, v1, [I

    fill-array-data v0, :array_b

    :cond_2
    if-ne v7, v6, :cond_3

    invoke-virtual {p1}, La/al;->iw()I

    move-result v2

    if-eq v2, v6, :cond_3

    new-array v0, v1, [I

    fill-array-data v0, :array_c

    :cond_3
    const/16 v1, 0xc

    if-gt v7, v1, :cond_4

    iget v1, p0, La/af;->yd:I

    aget v0, v0, p2

    add-int/2addr v1, v0

    iput v1, p0, La/af;->yd:I

    :cond_4
    if-ne p2, v3, :cond_6

    if-eq v7, v6, :cond_5

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p2

    invoke-virtual {p0, p2}, La/af;->z(La/ac;)V

    :cond_5
    invoke-direct {p0, p1}, La/af;->p(La/al;)V

    :cond_6
    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x19
        0xa
        0x8
        0x7
        0x6
        0x5
        0x4
        0x3
        0x2
        0x1
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x14
        0x7
        0x3
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x0
        0xf
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x1e
        0xf
        0x7
        0x7
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x19
        0x5
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x14
        0xa
        0x5
        0x5
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x23
        0x14
        0xa
        0x5
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x5
        0x3
        0x2
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        0x0
        0x2
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_c
    .array-data 4
        0x0
        0x19
        0xf
        0x5
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_d
    .array-data 4
        0x0
        0x14
        0x5
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public cj(I)V
    .locals 0

    iput p1, p0, La/af;->ya:I

    return-void
.end method

.method public ck(I)V
    .locals 0

    iput p1, p0, La/af;->xZ:I

    return-void
.end method

.method public cl(I)V
    .locals 0

    iput p1, p0, La/af;->yb:I

    return-void
.end method

.method public cm(I)V
    .locals 1

    iget v0, p0, La/af;->yh:I

    add-int/2addr v0, p1

    iput v0, p0, La/af;->yh:I

    iget p1, p0, La/af;->yh:I

    const/16 v0, 0x64

    if-le p1, v0, :cond_0

    iput v0, p0, La/af;->yh:I

    return-void

    :cond_0
    iget p1, p0, La/af;->yh:I

    if-gez p1, :cond_1

    const/4 p1, 0x0

    iput p1, p0, La/af;->yh:I

    :cond_1
    return-void
.end method

.method public cn(I)V
    .locals 1

    iget v0, p0, La/af;->yi:I

    add-int/2addr v0, p1

    iput v0, p0, La/af;->yi:I

    iget p1, p0, La/af;->yi:I

    const/16 v0, 0x64

    if-le p1, v0, :cond_0

    iput v0, p0, La/af;->yi:I

    return-void

    :cond_0
    iget p1, p0, La/af;->yi:I

    if-gez p1, :cond_1

    const/4 p1, 0x0

    iput p1, p0, La/af;->yi:I

    :cond_1
    return-void
.end method

.method public co(I)V
    .locals 0

    iput p1, p0, La/af;->yh:I

    return-void
.end method

.method public cp(I)V
    .locals 0

    iput p1, p0, La/af;->yi:I

    return-void
.end method

.method public cq(I)V
    .locals 0

    iput p1, p0, La/af;->yk:I

    return-void
.end method

.method public cr(I)V
    .locals 0

    iput p1, p0, La/af;->yl:I

    return-void
.end method

.method public eN()I
    .locals 1

    iget v0, p0, La/af;->ng:I

    return v0
.end method

.method public f(La/af;)V
    .locals 5

    new-instance v0, Lcomponents/bf;

    invoke-direct {v0}, Lcomponents/bf;-><init>()V

    invoke-virtual {v0, p0}, Lcomponents/bf;->i(La/af;)V

    invoke-virtual {v0, p1}, Lcomponents/bf;->j(La/af;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/a;

    invoke-virtual {p1}, La/a;->cF()Ljava/util/Calendar;

    move-result-object p1

    invoke-virtual {v0}, Lcomponents/bf;->cF()Ljava/util/Calendar;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {p1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v3, 0x2

    invoke-virtual {p1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v3

    const/4 v4, 0x5

    invoke-virtual {p1, v4}, Ljava/util/Calendar;->get(I)I

    move-result p1

    invoke-virtual {v1, v2, v3, p1}, Ljava/util/Calendar;->set(III)V

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    invoke-virtual {v0, p1}, Lcomponents/bf;->aw(I)V

    :cond_0
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->eD()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0}, La/af;->nc()V

    invoke-virtual {p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p1, :cond_2

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result p1

    const/16 v2, 0x1d

    if-ne p1, v2, :cond_1

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getEstado()I

    move-result v2

    invoke-virtual {p1, v2}, La/b;->an(I)V

    :cond_1
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    invoke-virtual {p1, v2}, La/b;->ao(I)V

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {p1, v2}, La/ac;->j(Ljava/lang/Boolean;)V

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->mB()V

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->mw()V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {p0, v1}, La/af;->R(Ljava/util/ArrayList;)V

    :cond_2
    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    if-eqz p1, :cond_3

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->mj()La/n;

    move-result-object p1

    if-eqz p1, :cond_3

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->mj()La/n;

    move-result-object p1

    invoke-virtual {p1, v0}, La/n;->aN(I)V

    :cond_3
    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1, v1}, La/ac;->e(La/af;)V

    invoke-virtual {p0, v1}, La/af;->i(La/ac;)V

    return-void
.end method

.method public f(La/t;)V
    .locals 17

    move-object/from16 v0, p0

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v2

    const/4 v4, 0x1

    if-ne v1, v2, :cond_0

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v1

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v5

    :goto_0
    const/4 v6, 0x0

    goto :goto_2

    :cond_0
    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v2

    if-ne v1, v2, :cond_1

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v1

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v5

    :goto_1
    const/4 v6, 0x1

    goto :goto_2

    :cond_1
    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v1

    iget-object v2, v0, La/af;->ss:La/ac;

    if-ne v1, v2, :cond_2

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v1

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v2

    iget-object v5, v0, La/af;->ss:La/ac;

    goto :goto_0

    :cond_2
    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v1

    iget-object v2, v0, La/af;->ss:La/ac;

    if-ne v1, v2, :cond_3

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v1

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v2

    iget-object v5, v0, La/af;->ss:La/ac;

    goto :goto_1

    :cond_3
    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :goto_2
    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v7

    const/4 v8, 0x3

    if-eqz v7, :cond_5

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v7

    invoke-virtual {v7}, La/al;->cG()I

    move-result v7

    if-ne v7, v4, :cond_4

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v9

    instance-of v9, v9, Ld/q;

    if-eqz v9, :cond_4

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v9

    check-cast v9, Ld/q;

    invoke-virtual {v9}, Ld/q;->getDivisao()I

    move-result v9

    goto :goto_3

    :cond_4
    if-ne v7, v8, :cond_6

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v9

    instance-of v9, v9, Ld/q;

    if-eqz v9, :cond_6

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v9

    check-cast v9, Ld/q;

    invoke-virtual {v9}, Ld/q;->getDivisao()I

    move-result v9

    move v10, v9

    const/4 v9, 0x0

    goto :goto_4

    :cond_5
    const/4 v7, 0x0

    :cond_6
    const/4 v9, 0x0

    :goto_3
    const/4 v10, 0x0

    :goto_4
    invoke-virtual {v0, v5}, La/af;->y(La/ac;)La/d;

    move-result-object v5

    invoke-virtual {v5}, La/d;->fD()V

    iget v11, v0, La/af;->ye:I

    add-int/2addr v11, v4

    iput v11, v0, La/af;->ye:I

    const/16 v11, 0x8

    const/4 v12, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x4

    const/4 v15, 0x5

    const/4 v3, 0x2

    if-le v1, v2, :cond_13

    invoke-virtual {v5}, La/d;->fF()V

    iget v1, v0, La/af;->yf:I

    add-int/2addr v1, v4

    iput v1, v0, La/af;->yf:I

    if-ne v7, v4, :cond_a

    if-ne v9, v4, :cond_7

    goto :goto_8

    :cond_7
    if-ne v9, v3, :cond_8

    goto :goto_6

    :cond_8
    if-ne v9, v8, :cond_9

    :goto_5
    const/4 v14, 0x2

    goto :goto_8

    :cond_9
    const/4 v14, 0x1

    goto :goto_8

    :cond_a
    if-ne v7, v3, :cond_b

    :goto_6
    const/4 v14, 0x3

    goto :goto_8

    :cond_b
    if-ne v7, v8, :cond_c

    if-ne v10, v4, :cond_9

    goto :goto_5

    :cond_c
    if-ne v7, v14, :cond_d

    :goto_7
    const/4 v14, 0x5

    goto :goto_8

    :cond_d
    if-ne v7, v15, :cond_e

    const/4 v14, 0x7

    goto :goto_8

    :cond_e
    if-ne v7, v12, :cond_f

    goto :goto_8

    :cond_f
    if-ne v7, v13, :cond_10

    goto :goto_7

    :cond_10
    if-ne v7, v11, :cond_11

    goto :goto_8

    :cond_11
    const/4 v14, 0x0

    :goto_8
    if-eqz v6, :cond_12

    if-eq v7, v13, :cond_12

    if-eq v7, v15, :cond_12

    add-int/lit8 v14, v14, 0x1

    :cond_12
    move v3, v14

    if-lez v3, :cond_1f

    :goto_9
    invoke-virtual {v5, v3}, La/d;->av(I)V

    goto :goto_e

    :cond_13
    if-ge v1, v2, :cond_14

    invoke-virtual {v5}, La/d;->fH()V

    iget v1, v0, La/af;->yg:I

    add-int/2addr v1, v4

    iput v1, v0, La/af;->yg:I

    goto :goto_d

    :cond_14
    if-ne v1, v2, :cond_1e

    if-eqz v6, :cond_15

    if-eq v7, v13, :cond_15

    if-eq v7, v15, :cond_15

    const/16 v16, 0x1

    goto :goto_a

    :cond_15
    const/16 v16, 0x0

    :goto_a
    if-ne v7, v4, :cond_17

    if-ne v9, v4, :cond_16

    goto :goto_c

    :cond_16
    if-ne v9, v3, :cond_1d

    goto :goto_b

    :cond_17
    if-ne v7, v3, :cond_18

    :goto_b
    const/4 v3, 0x1

    goto :goto_c

    :cond_18
    if-ne v7, v14, :cond_19

    goto :goto_c

    :cond_19
    if-ne v7, v15, :cond_1a

    goto :goto_c

    :cond_1a
    if-ne v7, v12, :cond_1b

    goto :goto_c

    :cond_1b
    if-ne v7, v13, :cond_1c

    goto :goto_c

    :cond_1c
    if-ne v7, v11, :cond_1d

    goto :goto_c

    :cond_1d
    move/from16 v3, v16

    :goto_c
    if-lez v3, :cond_1f

    goto :goto_9

    :cond_1e
    :goto_d
    const/4 v3, 0x0

    :cond_1f
    :goto_e
    if-lez v3, :cond_20

    iget v1, v0, La/af;->yd:I

    add-int/2addr v1, v3

    iput v1, v0, La/af;->yd:I

    :cond_20
    return-void
.end method

.method public g(La/t;)V
    .locals 18

    move-object/from16 v0, p0

    const/4 v1, 0x3

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v3

    invoke-virtual {v3}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v6

    const/4 v7, 0x1

    if-ne v5, v6, :cond_1

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v2

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v5

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v6

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v8

    invoke-virtual {v6, v8}, La/ac;->w(La/ac;)Z

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v6

    invoke-virtual {v6}, La/ac;->getNivel()I

    move-result v6

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getNivel()I

    move-result v8

    sub-int/2addr v6, v8

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v9

    invoke-virtual {v8, v9}, La/ac;->o(La/al;)[I

    move-result-object v8

    move-object v9, v8

    goto :goto_1

    :cond_1
    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v6

    if-ne v5, v6, :cond_2

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v2

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v5

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v6

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual {v6, v8}, La/ac;->w(La/ac;)Z

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v6

    invoke-virtual {v6}, La/ac;->getNivel()I

    move-result v6

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getNivel()I

    move-result v8

    sub-int/2addr v6, v8

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v8

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v9

    invoke-virtual {v8, v9}, La/ac;->o(La/al;)[I

    move-result-object v8

    move-object v9, v8

    const/4 v8, 0x1

    goto :goto_2

    :cond_2
    move-object v9, v2

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_1
    const/4 v8, 0x0

    :goto_2
    const/4 v10, 0x2

    if-eq v2, v5, :cond_6

    if-le v2, v5, :cond_4

    sub-int/2addr v2, v5

    if-lt v2, v1, :cond_3

    const/4 v2, 0x1

    :goto_3
    const/4 v5, 0x1

    goto :goto_5

    :cond_3
    const/4 v2, 0x1

    goto :goto_4

    :cond_4
    if-ge v2, v5, :cond_6

    sub-int/2addr v5, v2

    if-lt v5, v1, :cond_5

    const/4 v2, 0x2

    goto :goto_3

    :cond_5
    const/4 v2, 0x2

    goto :goto_4

    :cond_6
    const/4 v2, 0x0

    :goto_4
    const/4 v5, 0x0

    :goto_5
    const/4 v11, -0x3

    const/4 v12, -0x1

    if-nez v2, :cond_8

    if-ltz v6, :cond_7

    if-nez v8, :cond_7

    :goto_6
    invoke-virtual {v0, v12}, La/af;->cm(I)V

    goto :goto_7

    :cond_7
    if-gez v6, :cond_b

    invoke-virtual {v0, v7}, La/af;->cm(I)V

    goto :goto_7

    :cond_8
    if-ne v2, v7, :cond_9

    goto :goto_7

    :cond_9
    if-ltz v6, :cond_a

    if-nez v8, :cond_a

    invoke-virtual {v0, v11}, La/af;->cm(I)V

    goto :goto_7

    :cond_a
    if-ltz v6, :cond_b

    if-eqz v8, :cond_b

    goto :goto_6

    :cond_b
    :goto_7
    if-eq v3, v7, :cond_d

    if-ne v3, v1, :cond_c

    goto :goto_8

    :cond_c
    const/4 v6, 0x2

    goto :goto_9

    :cond_d
    :goto_8
    aget v6, v9, v7

    :goto_9
    aget v9, v9, v10

    if-ne v9, v12, :cond_e

    const/4 v9, 0x1

    goto :goto_a

    :cond_e
    const/4 v9, 0x0

    :goto_a
    const/4 v12, 0x6

    new-array v13, v12, [I

    fill-array-data v13, :array_1

    new-array v14, v12, [I

    fill-array-data v14, :array_2

    new-array v15, v12, [I

    fill-array-data v15, :array_3

    new-array v11, v12, [I

    fill-array-data v11, :array_4

    new-array v4, v12, [I

    fill-array-data v4, :array_5

    new-array v10, v12, [I

    fill-array-data v10, :array_6

    const/4 v1, -0x5

    if-nez v9, :cond_15

    const-wide/16 v16, 0x0

    if-ne v3, v7, :cond_10

    invoke-virtual/range {p0 .. p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_f

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lA()J

    move-result-wide v3

    cmp-long v9, v3, v16

    if-gez v9, :cond_f

    const/16 v3, -0xa

    invoke-virtual {v0, v3}, La/af;->cm(I)V

    :cond_f
    new-array v13, v12, [I

    fill-array-data v13, :array_7

    new-array v11, v12, [I

    fill-array-data v11, :array_8

    new-array v14, v12, [I

    fill-array-data v14, :array_9

    new-array v4, v12, [I

    fill-array-data v4, :array_a

    new-array v15, v12, [I

    fill-array-data v15, :array_b

    new-array v10, v12, [I

    fill-array-data v10, :array_c

    goto :goto_c

    :cond_10
    const/4 v9, 0x3

    if-ne v3, v9, :cond_12

    invoke-virtual/range {p0 .. p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_11

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lA()J

    move-result-wide v3

    cmp-long v9, v3, v16

    if-gez v9, :cond_11

    invoke-virtual {v0, v1}, La/af;->cm(I)V

    :cond_11
    new-array v13, v12, [I

    fill-array-data v13, :array_d

    new-array v11, v12, [I

    fill-array-data v11, :array_e

    new-array v14, v12, [I

    fill-array-data v14, :array_f

    new-array v4, v12, [I

    fill-array-data v4, :array_10

    :goto_b
    new-array v15, v12, [I

    fill-array-data v15, :array_11

    new-array v10, v12, [I

    fill-array-data v10, :array_12

    goto :goto_c

    :cond_12
    const/4 v9, 0x4

    if-eq v3, v9, :cond_13

    if-ne v3, v12, :cond_15

    :cond_13
    invoke-virtual/range {p0 .. p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_14

    invoke-virtual/range {p0 .. p0}, La/af;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lA()J

    move-result-wide v3

    cmp-long v9, v3, v16

    if-gez v9, :cond_14

    invoke-virtual {v0, v1}, La/af;->cm(I)V

    :cond_14
    new-array v13, v12, [I

    fill-array-data v13, :array_13

    new-array v11, v12, [I

    fill-array-data v11, :array_14

    new-array v14, v12, [I

    fill-array-data v14, :array_15

    new-array v4, v12, [I

    fill-array-data v4, :array_16

    goto :goto_b

    :cond_15
    :goto_c
    if-nez v2, :cond_17

    if-eqz v8, :cond_16

    aget v3, v4, v6

    :goto_d
    invoke-virtual {v0, v3}, La/af;->cm(I)V

    const/4 v3, 0x2

    goto :goto_f

    :cond_16
    aget v3, v14, v6

    goto :goto_d

    :cond_17
    if-ne v2, v7, :cond_19

    if-eqz v8, :cond_18

    aget v3, v11, v6

    goto :goto_d

    :cond_18
    aget v3, v13, v6

    goto :goto_d

    :cond_19
    const/4 v3, 0x2

    if-ne v2, v3, :cond_1b

    if-eqz v8, :cond_1a

    aget v4, v10, v6

    :goto_e
    invoke-virtual {v0, v4}, La/af;->cm(I)V

    goto :goto_f

    :cond_1a
    aget v4, v15, v6

    goto :goto_e

    :cond_1b
    :goto_f
    if-nez v2, :cond_1e

    if-eqz v8, :cond_1c

    invoke-virtual {v0, v3}, La/af;->cn(I)V

    goto :goto_13

    :cond_1c
    const/4 v2, 0x0

    :cond_1d
    :goto_10
    invoke-virtual {v0, v2}, La/af;->cn(I)V

    goto :goto_13

    :cond_1e
    if-ne v2, v7, :cond_20

    if-eqz v8, :cond_1f

    const/4 v2, 0x5

    invoke-virtual {v0, v2}, La/af;->cn(I)V

    const/4 v2, 0x3

    goto :goto_11

    :cond_1f
    const/4 v2, 0x3

    invoke-virtual {v0, v2}, La/af;->cn(I)V

    :goto_11
    if-eqz v5, :cond_23

    if-eqz v8, :cond_1d

    const/4 v2, 0x7

    goto :goto_10

    :cond_20
    const/4 v3, 0x2

    if-ne v2, v3, :cond_23

    if-eqz v8, :cond_21

    const/4 v2, -0x3

    invoke-virtual {v0, v2}, La/af;->cn(I)V

    goto :goto_12

    :cond_21
    invoke-virtual {v0, v1}, La/af;->cn(I)V

    :goto_12
    if-eqz v5, :cond_23

    if-eqz v8, :cond_22

    const/4 v2, -0x2

    goto :goto_10

    :cond_22
    invoke-virtual {v0, v1}, La/af;->cn(I)V

    :cond_23
    :goto_13
    iget v2, v0, La/af;->yi:I

    const/16 v3, 0x1e

    if-ge v2, v3, :cond_24

    invoke-virtual {v0, v1}, La/af;->cm(I)V

    :cond_24
    iget v1, v0, La/af;->yh:I

    const/16 v2, 0x64

    if-gez v1, :cond_25

    const/4 v1, 0x0

    iput v1, v0, La/af;->yh:I

    goto :goto_14

    :cond_25
    const/4 v1, 0x0

    iget v3, v0, La/af;->yh:I

    if-le v3, v2, :cond_26

    iput v2, v0, La/af;->yh:I

    :cond_26
    :goto_14
    iget v3, v0, La/af;->yi:I

    if-gez v3, :cond_27

    iput v1, v0, La/af;->yi:I

    return-void

    :cond_27
    iget v1, v0, La/af;->yi:I

    if-le v1, v2, :cond_28

    iput v2, v0, La/af;->yi:I

    :cond_28
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x5
        0x4
        0x1
        0x1
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x7
        0x6
        0x2
        0x2
        0x1
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x2
        0x1
        -0x1
        -0x1
        -0x3
    .end array-data

    :array_a
    .array-data 4
        0x0
        0x2
        0x1
        0x0
        -0x1
        -0x2
    .end array-data

    :array_b
    .array-data 4
        0x0
        -0x2
        -0x2
        -0x3
        -0x5
        -0x7
    .end array-data

    :array_c
    .array-data 4
        0x0
        -0x1
        -0x1
        -0x2
        -0x4
        -0x5
    .end array-data

    :array_d
    .array-data 4
        0x0
        0x2
        0x2
        0x1
        0x1
        0x1
    .end array-data

    :array_e
    .array-data 4
        0x0
        0x3
        0x2
        0x2
        0x2
        0x1
    .end array-data

    :array_f
    .array-data 4
        0x0
        0x1
        0x1
        0x0
        0x0
        -0x1
    .end array-data

    :array_10
    .array-data 4
        0x0
        0x1
        0x1
        0x1
        0x0
        -0x1
    .end array-data

    :array_11
    .array-data 4
        0x0
        -0x2
        -0x2
        -0x3
        -0x3
        -0x5
    .end array-data

    :array_12
    .array-data 4
        0x0
        -0x1
        -0x1
        -0x2
        -0x2
        -0x3
    .end array-data

    :array_13
    .array-data 4
        0x0
        0x5
        0x4
        0x3
        0x3
        0x3
    .end array-data

    :array_14
    .array-data 4
        0x0
        0x7
        0x6
        0x4
        0x4
        0x5
    .end array-data

    :array_15
    .array-data 4
        0x0
        0x2
        0x1
        0x0
        -0x1
        -0x3
    .end array-data

    :array_16
    .array-data 4
        0x0
        0x2
        0x1
        0x0
        0x0
        -0x2
    .end array-data
.end method

.method public g(Ld/q;)V
    .locals 0

    return-void
.end method

.method public gN()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/af;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public getReputacao()I
    .locals 2

    iget v0, p0, La/af;->xo:I

    const/4 v1, 0x5

    if-le v0, v1, :cond_0

    iput v1, p0, La/af;->xo:I

    :cond_0
    iget v0, p0, La/af;->xo:I

    return v0
.end method

.method public getUniqueId()I
    .locals 1

    iget v0, p0, La/af;->gl:I

    return v0
.end method

.method public hE()La/ac;
    .locals 3

    iget-object v0, p0, La/af;->xW:La/ac;

    if-nez v0, :cond_0

    iget v1, p0, La/af;->oo:I

    if-ltz v1, :cond_0

    iget v0, p0, La/af;->oo:I

    invoke-static {v0}, La/b;->aq(I)La/ac;

    move-result-object v0

    iput-object v0, p0, La/af;->xW:La/ac;

    return-object v0

    :cond_0
    iget v1, p0, La/af;->oo:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    const/4 v0, 0x0

    :cond_1
    return-object v0
.end method

.method public hF()V
    .locals 1

    iget-object v0, p0, La/af;->xW:La/ac;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/af;->xW:La/ac;

    invoke-virtual {v0}, La/ac;->mE()I

    move-result v0

    iput v0, p0, La/af;->oo:I

    :cond_0
    return-void
.end method

.method public i(La/ac;)V
    .locals 0

    iput-object p1, p0, La/af;->xW:La/ac;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    :goto_0
    iput p1, p0, La/af;->oo:I

    return-void

    :cond_0
    const/4 p1, -0x1

    goto :goto_0

    return-void
.end method

.method public j(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/af;->xh:Ljava/lang/Boolean;

    return-void
.end method

.method public li()La/ac;
    .locals 1

    iget-object v0, p0, La/af;->ss:La/ac;

    return-object v0
.end method

.method public ly()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/af;->xh:Ljava/lang/Boolean;

    return-object v0
.end method

.method public m(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/af;->pq:Ljava/lang/String;

    return-void
.end method

.method public mA()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ai;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/af;->xN:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mS()I
    .locals 1

    iget v0, p0, La/af;->ya:I

    return v0
.end method

.method public mT()La/ac;
    .locals 3

    iget-object v0, p0, La/af;->xX:La/ac;

    if-nez v0, :cond_0

    iget v1, p0, La/af;->xY:I

    if-ltz v1, :cond_0

    iget v0, p0, La/af;->xY:I

    invoke-static {v0}, La/b;->aq(I)La/ac;

    move-result-object v0

    iput-object v0, p0, La/af;->xX:La/ac;

    return-object v0

    :cond_0
    iget v1, p0, La/af;->xY:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    const/4 v0, 0x0

    :cond_1
    return-object v0
.end method

.method public mU()I
    .locals 1

    iget v0, p0, La/af;->xZ:I

    return v0
.end method

.method public mV()I
    .locals 1

    iget v0, p0, La/af;->yb:I

    return v0
.end method

.method public mW()I
    .locals 1

    iget v0, p0, La/af;->yd:I

    return v0
.end method

.method public mX()I
    .locals 1

    iget v0, p0, La/af;->ye:I

    return v0
.end method

.method public mY()I
    .locals 1

    iget v0, p0, La/af;->yf:I

    return v0
.end method

.method public mZ()I
    .locals 1

    iget v0, p0, La/af;->yg:I

    return v0
.end method

.method public na()I
    .locals 1

    invoke-virtual {p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x64

    return v0

    :cond_0
    iget v0, p0, La/af;->yh:I

    return v0
.end method

.method public nb()I
    .locals 1

    invoke-virtual {p0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x64

    return v0

    :cond_0
    iget v0, p0, La/af;->yi:I

    return v0
.end method

.method public nc()V
    .locals 1

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v0

    invoke-virtual {p0, v0}, La/af;->x(La/ac;)V

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    iput v0, p0, La/af;->ng:I

    invoke-virtual {p0}, La/af;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getDivisao()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/af;->xZ:I

    return-void
.end method

.method public nd()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/d;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/af;->yc:Ljava/util/ArrayList;

    return-object v0
.end method

.method public ne()V
    .locals 1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eI()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public nf()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/co;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/af;->yj:Ljava/util/ArrayList;

    return-object v0
.end method

.method public ng()I
    .locals 1

    iget v0, p0, La/af;->yk:I

    return v0
.end method

.method public nh()I
    .locals 1

    iget v0, p0, La/af;->yl:I

    return v0
.end method

.method public ni()V
    .locals 1

    iget v0, p0, La/af;->yl:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/af;->yl:I

    return-void
.end method

.method public setReputacao(I)V
    .locals 0

    iput p1, p0, La/af;->xo:I

    return-void
.end method

.method public v(La/ac;)V
    .locals 0

    iput-object p1, p0, La/af;->ss:La/ac;

    return-void
.end method

.method public x(La/ac;)V
    .locals 0

    iput-object p1, p0, La/af;->xX:La/ac;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    :goto_0
    iput p1, p0, La/af;->xY:I

    return-void

    :cond_0
    const/4 p1, -0x1

    goto :goto_0

    return-void
.end method

.method public y(La/ac;)La/d;
    .locals 3

    iget-object v0, p0, La/af;->yc:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/af;->yc:Ljava/util/ArrayList;

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/af;->yc:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    iget-object v1, p0, La/af;->yc:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, p0, La/af;->yc:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/d;

    invoke-virtual {v1}, La/d;->fL()I

    move-result v1

    invoke-virtual {p1}, La/ac;->mE()I

    move-result v2

    if-ne v1, v2, :cond_1

    iget-object v1, p0, La/af;->yc:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/d;

    invoke-virtual {v1}, La/d;->db()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    if-ne v1, v2, :cond_1

    iget-object p1, p0, La/af;->yc:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/d;

    return-object p1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    new-instance v0, La/d;

    invoke-direct {v0, p1}, La/d;-><init>(La/ac;)V

    iget-object p1, p0, La/af;->yc:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method public z(La/ac;)V
    .locals 0

    invoke-virtual {p0, p1}, La/af;->y(La/ac;)La/d;

    move-result-object p1

    invoke-virtual {p1}, La/d;->fK()V

    return-void
.end method
