.class public La/n;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static pP:[Ljava/lang/String; = null

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public loanYear:I

.field private pC:I

.field private pD:I

.field private pE:I

.field private pF:J

.field private pG:I

.field private pH:I

.field private pI:J

.field private pJ:J

.field private pK:I

.field private pL:I

.field private pM:I

.field private pN:I

.field private pO:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string v0, " mil"

    const-string v1, "M"

    const-string v2, "B"

    const-string v3, "T"

    filled-new-array {v0, v1, v2, v3}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/n;->pP:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(DI)Ljava/lang/String;
    .locals 5

    double-to-long p0, p0

    const-wide/16 v0, 0x64

    div-long/2addr p0, v0

    long-to-double p0, p0

    const-wide/high16 v0, 0x4024000000000000L    # 10.0

    div-double/2addr p0, v0

    mul-double v2, p0, v0

    rem-double/2addr v2, v0

    const-wide/16 v0, 0x0

    cmpl-double v4, v2, v0

    const/4 v0, 0x1

    if-nez v4, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    const-wide v2, 0x408f400000000000L    # 1000.0

    cmpg-double v4, p0, v2

    if-gez v4, :cond_3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-wide v2, 0x4058f9999999999aL    # 99.9

    cmpl-double v4, p0, v2

    if-gtz v4, :cond_2

    if-nez v1, :cond_2

    if-nez v1, :cond_1

    const-wide v1, 0x4023fae147ae147bL    # 9.99

    cmpl-double v3, p0, v1

    if-lez v3, :cond_1

    goto :goto_1

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p0, p1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string p0, ""

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_2
    :goto_1
    double-to-int p0, p0

    mul-int/lit8 p0, p0, 0xa

    div-int/lit8 p0, p0, 0xa

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    :goto_2
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ""

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, La/n;->pP:[Ljava/lang/String;

    aget-object p0, p0, p2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    add-int/2addr p2, v0

    invoke-static {p0, p1, p2}, La/n;->a(DI)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static aM(I)Ljava/lang/String;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public static b(J)Ljava/lang/String;
    .locals 11

    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const-string v1, "k"

    const-string v2, "M"

    const-string v3, "M"

    const-string v4, "B"

    const-string v5, "B"

    filled-new-array {v1, v2, v3, v4, v5}, [Ljava/lang/String;

    move-result-object v1

    const-wide/16 v2, 0x0

    cmp-long v4, p0, v2

    if-gez v4, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Ljava/lang/Math;->abs(J)J

    move-result-wide p0

    invoke-static {p0, p1}, La/n;->b(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    cmp-long v4, p0, v2

    const/4 v2, 0x0

    if-nez v4, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "0 "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    const-wide/16 v3, 0x3e7

    cmp-long v5, p0, v3

    if-gtz v5, :cond_2

    return-object v0

    :cond_2
    const-wide/16 v3, 0x270f

    cmp-long v5, p0, v3

    const/4 v3, 0x1

    if-gtz v5, :cond_3

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    const-wide/32 v4, 0x1869f

    cmp-long v6, p0, v4

    const/4 v4, 0x2

    if-gtz v6, :cond_4

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_4
    const-wide/32 v5, 0xf423f

    cmp-long v7, p0, v5

    const/4 v5, 0x3

    if-gtz v7, :cond_5

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_5
    const-wide/32 v6, 0x1e847f

    cmp-long v8, p0, v6

    const/4 v6, 0x4

    if-gtz v8, :cond_6

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v2

    :goto_0
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_1

    :cond_6
    const-wide/32 v7, 0x98967f

    cmp-long v9, p0, v7

    if-gtz v9, :cond_7

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v2

    goto :goto_0

    :cond_7
    const-wide/32 v7, 0x5f5e0ff

    cmp-long v9, p0, v7

    const/4 v7, 0x5

    if-gtz v9, :cond_8

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v2

    goto :goto_0

    :cond_8
    const-wide/32 v8, 0x3b9ac9ff

    cmp-long v10, p0, v8

    if-gtz v10, :cond_9

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    invoke-virtual {v0, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v2

    goto/16 :goto_0

    :cond_9
    const-wide/32 v8, 0x773593ff

    cmp-long v10, p0, v8

    if-gtz v10, :cond_a

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v4

    goto/16 :goto_0

    :cond_a
    const-wide v8, 0x2540be3ffL

    cmp-long v10, p0, v8

    if-gtz v10, :cond_b

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v4

    goto/16 :goto_0

    :cond_b
    const-wide v8, 0x174876e7ffL

    cmp-long v10, p0, v8

    if-gtz v10, :cond_e

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, v1, v6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v1, v4

    goto/16 :goto_0

    :goto_1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lt v0, v5, :cond_c

    invoke-virtual {p1, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    const-string p1, ""

    :cond_c
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lt v0, v5, :cond_d

    invoke-virtual {p1, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v1, "0"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {p1, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    :cond_d
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_e
    long-to-double p0, p0

    invoke-static {p0, p1, v2}, La/n;->a(DI)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private hq()V
    .locals 1

    iget v0, p0, La/n;->pN:I

    if-lez v0, :cond_0

    iget v0, p0, La/n;->pN:I

    mul-int/lit8 v0, v0, 0x3

    div-int/lit8 v0, v0, 0x64

    int-to-float v0, v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    :goto_0
    iput v0, p0, La/n;->pO:I

    return-void

    :cond_0
    const/4 v0, 0x0

    goto :goto_0

    return-void
.end method


# virtual methods
.method public J(II)V
    .locals 4

    const/4 v0, 0x1

    if-ne p2, v0, :cond_0

    iget-wide v0, p0, La/n;->pF:J

    int-to-long p1, p1

    add-long v2, v0, p1

    iput-wide v2, p0, La/n;->pF:J

    return-void

    :cond_0
    const/4 v0, 0x3

    if-ne p2, v0, :cond_1

    iget p2, p0, La/n;->pE:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pE:I

    return-void

    :cond_1
    const/4 v0, 0x5

    if-ne p2, v0, :cond_2

    iget p2, p0, La/n;->pD:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pD:I

    return-void

    :cond_2
    const/4 v0, 0x6

    if-ne p2, v0, :cond_3

    iget p2, p0, La/n;->pG:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pG:I

    :cond_3
    return-void
.end method

.method public K(II)V
    .locals 4

    const/4 v0, 0x1

    if-ne p2, v0, :cond_0

    iget-wide v0, p0, La/n;->pI:J

    int-to-long p1, p1

    add-long v2, v0, p1

    iput-wide v2, p0, La/n;->pI:J

    return-void

    :cond_0
    const/4 v0, 0x4

    if-ne p2, v0, :cond_1

    iget p2, p0, La/n;->pK:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pK:I

    return-void

    :cond_1
    const/4 v0, 0x2

    if-ne p2, v0, :cond_2

    iget-wide v0, p0, La/n;->pJ:J

    int-to-long p1, p1

    add-long v2, v0, p1

    iput-wide v2, p0, La/n;->pJ:J

    return-void

    :cond_2
    const/4 v0, 0x7

    if-ne p2, v0, :cond_3

    iget p2, p0, La/n;->pH:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pH:I

    return-void

    :cond_3
    const/16 v0, 0x8

    if-ne p2, v0, :cond_4

    iget p2, p0, La/n;->pM:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pM:I

    return-void

    :cond_4
    iget p2, p0, La/n;->pL:I

    add-int/2addr p2, p1

    iput p2, p0, La/n;->pL:I

    return-void
.end method

.method public aN(I)V
    .locals 0

    iput p1, p0, La/n;->pN:I

    return-void
.end method

.method public aO(I)V
    .locals 0

    iput p1, p0, La/n;->pO:I

    return-void
.end method

.method public g(La/ac;)Z
    .locals 5

    iget v0, p0, La/n;->pN:I

    if-lez v0, :cond_1

    invoke-virtual {p1}, La/ac;->lA()J

    move-result-wide v0

    const-wide/32 v2, 0x7a120

    cmp-long v4, v0, v2

    if-ltz v4, :cond_1

    iget v0, p0, La/n;->pN:I

    const v1, 0x7a120

    sub-int/2addr v0, v1

    iput v0, p0, La/n;->pN:I

    const/4 v0, -0x1

    invoke-virtual {p1, v1, v0}, La/ac;->V(II)V

    invoke-direct {p0}, La/n;->hq()V

    iget v0, p0, La/n;->pN:I

    if-gtz v0, :cond_0

    const/4 v0, 0x0

    iput v0, p0, La/n;->loanYear:I

    :cond_0
    const/4 p1, 0x1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public h(La/ac;)Z
    .locals 5

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt v1, v3, :cond_0

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v1

    const/4 v4, 0x4

    if-gt v1, v4, :cond_0

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v1

    aget v0, v0, v1

    goto :goto_0

    :cond_0
    aget v0, v0, v2

    :goto_0
    iget v1, p0, La/n;->pN:I

    if-ge v1, v0, :cond_2

    iget v0, p0, La/n;->pN:I

    const v1, 0x7a120

    add-int/2addr v0, v1

    iput v0, p0, La/n;->pN:I

    iget v4, p0, La/n;->loanYear:I

    if-gtz v4, :cond_1

    sget-object v4, Lc/a;->TF:La/b;

    if-eqz v4, :cond_1

    invoke-virtual {v4}, La/b;->db()I

    move-result v4

    iput v4, p0, La/n;->loanYear:I

    :cond_1
    const/4 v0, -0x1

    invoke-virtual {p1, v1, v0}, La/ac;->U(II)V

    invoke-direct {p0}, La/n;->hq()V

    return v3

    :cond_2
    return v2

    nop

    :array_0
    .array-data 4
        0x5b8d80
        0x1c9c380
        0x112a880
        0xb71b00
        0x895440
    .end array-data
.end method

.method public ha()J
    .locals 6

    iget v0, p0, La/n;->pD:I

    iget v1, p0, La/n;->pE:I

    add-int/2addr v0, v1

    int-to-long v0, v0

    iget-wide v2, p0, La/n;->pF:J

    add-long v4, v0, v2

    iget v0, p0, La/n;->pG:I

    int-to-long v0, v0

    add-long v2, v4, v0

    return-wide v2
.end method

.method public hb()V
    .locals 3

    const/4 v0, 0x0

    iput v0, p0, La/n;->pD:I

    const-wide/16 v1, 0x0

    iput-wide v1, p0, La/n;->pF:J

    iput v0, p0, La/n;->pE:I

    iput v0, p0, La/n;->pG:I

    iput v0, p0, La/n;->pH:I

    iput-wide v1, p0, La/n;->pJ:J

    iput v0, p0, La/n;->pK:I

    iput v0, p0, La/n;->pL:I

    iput v0, p0, La/n;->pM:I

    iput-wide v1, p0, La/n;->pI:J

    return-void
.end method

.method public hc()J
    .locals 6

    iget v0, p0, La/n;->pH:I

    int-to-long v0, v0

    iget-wide v2, p0, La/n;->pI:J

    add-long v4, v0, v2

    iget-wide v0, p0, La/n;->pJ:J

    add-long v2, v4, v0

    iget v0, p0, La/n;->pK:I

    int-to-long v0, v0

    add-long v4, v2, v0

    iget v0, p0, La/n;->pL:I

    int-to-long v0, v0

    add-long v2, v4, v0

    iget v0, p0, La/n;->pM:I

    int-to-long v0, v0

    add-long v4, v2, v0

    return-wide v4
.end method

.method public hd()J
    .locals 6

    invoke-virtual {p0}, La/n;->ha()J

    move-result-wide v0

    invoke-virtual {p0}, La/n;->hc()J

    move-result-wide v2

    sub-long v4, v0, v2

    return-wide v4
.end method

.method public he()I
    .locals 1

    iget v0, p0, La/n;->pC:I

    return v0
.end method

.method public hf()I
    .locals 1

    iget v0, p0, La/n;->pD:I

    return v0
.end method

.method public hg()I
    .locals 1

    iget v0, p0, La/n;->pE:I

    return v0
.end method

.method public hh()J
    .locals 2

    iget-wide v0, p0, La/n;->pF:J

    return-wide v0
.end method

.method public hi()I
    .locals 1

    iget v0, p0, La/n;->pG:I

    return v0
.end method

.method public hj()I
    .locals 1

    iget v0, p0, La/n;->pH:I

    return v0
.end method

.method public hk()J
    .locals 2

    iget-wide v0, p0, La/n;->pI:J

    return-wide v0
.end method

.method public hl()I
    .locals 1

    iget v0, p0, La/n;->pK:I

    return v0
.end method

.method public hm()I
    .locals 1

    iget v0, p0, La/n;->pL:I

    return v0
.end method

.method public hn()I
    .locals 1

    iget v0, p0, La/n;->pM:I

    return v0
.end method

.method public ho()I
    .locals 1

    iget v0, p0, La/n;->pN:I

    return v0
.end method

.method public hp()J
    .locals 2

    iget-wide v0, p0, La/n;->pJ:J

    return-wide v0
.end method

.method public hr()I
    .locals 1

    iget v0, p0, La/n;->pO:I

    return v0
.end method
