.class public La/t;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static rJ:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static rK:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static rL:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static rM:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static rN:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public agDone:[Z

.field public agInit:Z

.field private data:I

.field public finFlag:Z

.field private lT:Z

.field public momHist:Ljava/lang/String;

.field public narrDone:Z

.field public ntScanned:Z

.field private qQ:La/al;

.field private qS:La/al;

.field private qT:La/ac;

.field private qU:La/ac;

.field private qV:I

.field private qW:I

.field private qX:La/l;

.field private qY:[I

.field private transient qZ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private rA:I

.field private rB:I

.field private rC:[I

.field private rD:Z

.field private rE:La/ac;

.field private rF:[[I

.field private rG:[[I

.field private rH:[[I

.field public transient rI:Lcomponents/cn;

.field private transient ra:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient rb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient rc:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient rd:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient re:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private renda:I

.field private transient rf:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient rg:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient rh:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/m;",
            ">;"
        }
    .end annotation
.end field

.field private transient ri:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bk;",
            ">;"
        }
    .end annotation
.end field

.field private rj:I

.field private rk:I

.field private rl:[I

.field private rm:[I

.field private rn:I

.field private ro:I

.field private rp:I

.field private rq:[I

.field private rr:[I

.field private rs:[I

.field private rt:[I

.field private ru:[I

.field private rv:[I

.field private rw:[I

.field private rx:[I

.field private ry:Z

.field private rz:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, La/t;->lT:Z

    iput v0, p0, La/t;->qV:I

    iput v0, p0, La/t;->qW:I

    const/4 v1, 0x4

    new-array v2, v1, [I

    iput-object v2, p0, La/t;->qY:[I

    iput v0, p0, La/t;->renda:I

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->qZ:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->ra:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->rb:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->rc:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->rd:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->re:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->rf:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->rg:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->rh:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/t;->ri:Ljava/util/ArrayList;

    iput v0, p0, La/t;->rj:I

    iput v0, p0, La/t;->rk:I

    const/4 v2, 0x3

    new-array v3, v2, [I

    fill-array-data v3, :array_0

    iput-object v3, p0, La/t;->rl:[I

    const/4 v3, 0x2

    new-array v4, v3, [I

    fill-array-data v4, :array_1

    iput-object v4, p0, La/t;->rm:[I

    iput v0, p0, La/t;->rn:I

    iput v0, p0, La/t;->ro:I

    iput v0, p0, La/t;->rp:I

    new-array v4, v3, [I

    fill-array-data v4, :array_2

    iput-object v4, p0, La/t;->rq:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_3

    iput-object v4, p0, La/t;->rr:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_4

    iput-object v4, p0, La/t;->rs:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_5

    iput-object v4, p0, La/t;->rt:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_6

    iput-object v4, p0, La/t;->ru:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_7

    iput-object v4, p0, La/t;->rv:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_8

    iput-object v4, p0, La/t;->rw:[I

    new-array v4, v3, [I

    fill-array-data v4, :array_9

    iput-object v4, p0, La/t;->rx:[I

    iput-boolean v0, p0, La/t;->ry:Z

    iput-boolean v0, p0, La/t;->rz:Z

    const/4 v4, -0x1

    iput v4, p0, La/t;->rA:I

    iput v4, p0, La/t;->rB:I

    new-array v4, v3, [I

    fill-array-data v4, :array_a

    iput-object v4, p0, La/t;->rC:[I

    iput-boolean v0, p0, La/t;->rD:Z

    const/4 v4, 0x0

    iput-object v4, p0, La/t;->rE:La/ac;

    const/16 v5, 0xb

    filled-new-array {v3, v5}, [I

    move-result-object v5

    const-class v6, I

    invoke-static {v6, v5}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [[I

    iput-object v5, p0, La/t;->rF:[[I

    new-array v5, v3, [[I

    new-array v6, v1, [I

    fill-array-data v6, :array_b

    aput-object v6, v5, v0

    new-array v1, v1, [I

    fill-array-data v1, :array_c

    const/4 v6, 0x1

    aput-object v1, v5, v6

    iput-object v5, p0, La/t;->rG:[[I

    new-array v1, v3, [[I

    new-array v3, v2, [I

    fill-array-data v3, :array_d

    aput-object v3, v1, v0

    new-array v0, v2, [I

    fill-array-data v0, :array_e

    aput-object v0, v1, v6

    iput-object v1, p0, La/t;->rH:[[I

    iput-object v4, p0, La/t;->rI:Lcomponents/cn;

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        -0x1
    .end array-data

    :array_1
    .array-data 4
        0x5
        0x5
    .end array-data

    :array_2
    .array-data 4
        0x32
        0x32
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        -0x1
        -0x1
    .end array-data

    :array_b
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_c
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_d
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_e
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data
.end method

.method public constructor <init>(La/ac;La/ac;Z)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p3, 0x0

    iput-boolean p3, p0, La/t;->lT:Z

    iput p3, p0, La/t;->qV:I

    iput p3, p0, La/t;->qW:I

    const/4 v0, 0x4

    new-array v1, v0, [I

    iput-object v1, p0, La/t;->qY:[I

    iput p3, p0, La/t;->renda:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->qZ:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->ra:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rb:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rc:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rd:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->re:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rf:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rg:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rh:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->ri:Ljava/util/ArrayList;

    iput p3, p0, La/t;->rj:I

    iput p3, p0, La/t;->rk:I

    const/4 v1, 0x3

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    iput-object v2, p0, La/t;->rl:[I

    const/4 v2, 0x2

    new-array v3, v2, [I

    fill-array-data v3, :array_1

    iput-object v3, p0, La/t;->rm:[I

    iput p3, p0, La/t;->rn:I

    iput p3, p0, La/t;->ro:I

    iput p3, p0, La/t;->rp:I

    new-array v3, v2, [I

    fill-array-data v3, :array_2

    iput-object v3, p0, La/t;->rq:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_3

    iput-object v3, p0, La/t;->rr:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_4

    iput-object v3, p0, La/t;->rs:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_5

    iput-object v3, p0, La/t;->rt:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_6

    iput-object v3, p0, La/t;->ru:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_7

    iput-object v3, p0, La/t;->rv:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_8

    iput-object v3, p0, La/t;->rw:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_9

    iput-object v3, p0, La/t;->rx:[I

    iput-boolean p3, p0, La/t;->ry:Z

    iput-boolean p3, p0, La/t;->rz:Z

    const/4 v3, -0x1

    iput v3, p0, La/t;->rA:I

    iput v3, p0, La/t;->rB:I

    new-array v3, v2, [I

    fill-array-data v3, :array_a

    iput-object v3, p0, La/t;->rC:[I

    iput-boolean p3, p0, La/t;->rD:Z

    const/4 v3, 0x0

    iput-object v3, p0, La/t;->rE:La/ac;

    const/16 v4, 0xb

    filled-new-array {v2, v4}, [I

    move-result-object v4

    const-class v5, I

    invoke-static {v5, v4}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [[I

    iput-object v4, p0, La/t;->rF:[[I

    new-array v4, v2, [[I

    new-array v5, v0, [I

    fill-array-data v5, :array_b

    aput-object v5, v4, p3

    new-array v0, v0, [I

    fill-array-data v0, :array_c

    const/4 v5, 0x1

    aput-object v0, v4, v5

    iput-object v4, p0, La/t;->rG:[[I

    new-array v0, v2, [[I

    new-array v2, v1, [I

    fill-array-data v2, :array_d

    aput-object v2, v0, p3

    new-array p3, v1, [I

    fill-array-data p3, :array_e

    aput-object p3, v0, v5

    iput-object v0, p0, La/t;->rH:[[I

    iput-object v3, p0, La/t;->rI:Lcomponents/cn;

    iput-object p1, p0, La/t;->qT:La/ac;

    iput-object p2, p0, La/t;->qU:La/ac;

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        -0x1
    .end array-data

    :array_1
    .array-data 4
        0x5
        0x5
    .end array-data

    :array_2
    .array-data 4
        0x32
        0x32
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        -0x1
        -0x1
    .end array-data

    :array_b
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_c
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_d
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_e
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data
.end method

.method public constructor <init>(La/al;ILa/ac;La/ac;ILa/al;La/l;)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p2, 0x0

    iput-boolean p2, p0, La/t;->lT:Z

    iput p2, p0, La/t;->qV:I

    iput p2, p0, La/t;->qW:I

    const/4 v0, 0x4

    new-array v1, v0, [I

    iput-object v1, p0, La/t;->qY:[I

    iput p2, p0, La/t;->renda:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->qZ:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->ra:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rb:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rc:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rd:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->re:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rf:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rg:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->rh:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/t;->ri:Ljava/util/ArrayList;

    iput p2, p0, La/t;->rj:I

    iput p2, p0, La/t;->rk:I

    const/4 v1, 0x3

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    iput-object v2, p0, La/t;->rl:[I

    const/4 v2, 0x2

    new-array v3, v2, [I

    fill-array-data v3, :array_1

    iput-object v3, p0, La/t;->rm:[I

    iput p2, p0, La/t;->rn:I

    iput p2, p0, La/t;->ro:I

    iput p2, p0, La/t;->rp:I

    new-array v3, v2, [I

    fill-array-data v3, :array_2

    iput-object v3, p0, La/t;->rq:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_3

    iput-object v3, p0, La/t;->rr:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_4

    iput-object v3, p0, La/t;->rs:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_5

    iput-object v3, p0, La/t;->rt:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_6

    iput-object v3, p0, La/t;->ru:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_7

    iput-object v3, p0, La/t;->rv:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_8

    iput-object v3, p0, La/t;->rw:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_9

    iput-object v3, p0, La/t;->rx:[I

    iput-boolean p2, p0, La/t;->ry:Z

    iput-boolean p2, p0, La/t;->rz:Z

    const/4 v3, -0x1

    iput v3, p0, La/t;->rA:I

    iput v3, p0, La/t;->rB:I

    new-array v3, v2, [I

    fill-array-data v3, :array_a

    iput-object v3, p0, La/t;->rC:[I

    iput-boolean p2, p0, La/t;->rD:Z

    const/4 v3, 0x0

    iput-object v3, p0, La/t;->rE:La/ac;

    const/16 v4, 0xb

    filled-new-array {v2, v4}, [I

    move-result-object v4

    const-class v5, I

    invoke-static {v5, v4}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [[I

    iput-object v4, p0, La/t;->rF:[[I

    new-array v4, v2, [[I

    new-array v5, v0, [I

    fill-array-data v5, :array_b

    aput-object v5, v4, p2

    new-array v0, v0, [I

    fill-array-data v0, :array_c

    const/4 v5, 0x1

    aput-object v0, v4, v5

    iput-object v4, p0, La/t;->rG:[[I

    new-array v0, v2, [[I

    new-array v2, v1, [I

    fill-array-data v2, :array_d

    aput-object v2, v0, p2

    new-array p2, v1, [I

    fill-array-data p2, :array_e

    aput-object p2, v0, v5

    iput-object v0, p0, La/t;->rH:[[I

    iput-object v3, p0, La/t;->rI:Lcomponents/cn;

    iput-object p1, p0, La/t;->qQ:La/al;

    iput-object p3, p0, La/t;->qT:La/ac;

    iput-object p4, p0, La/t;->qU:La/ac;

    iput p5, p0, La/t;->data:I

    iput-object p6, p0, La/t;->qS:La/al;

    if-nez p7, :cond_0

    iget-object p2, p0, La/t;->qT:La/ac;

    invoke-virtual {p2}, La/ac;->jO()La/l;

    move-result-object p2

    iput-object p2, p0, La/t;->qX:La/l;

    goto :goto_0

    :cond_0
    iput-object p7, p0, La/t;->qX:La/l;

    :goto_0
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/a;

    invoke-virtual {p2, p0}, La/a;->a(La/t;)V

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/a;

    invoke-virtual {p2, p1}, La/a;->a(La/al;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, p5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/a;

    invoke-virtual {p1, p6}, La/a;->b(La/al;)V

    iget-object p1, p0, La/t;->qS:La/al;

    invoke-virtual {p1}, La/al;->cG()I

    move-result p1

    const/4 p2, 0x5

    if-ne p1, p2, :cond_1

    iput-object v3, p0, La/t;->qX:La/l;

    :cond_1
    invoke-direct {p0}, La/t;->jh()V

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        -0x1
    .end array-data

    :array_1
    .array-data 4
        0x5
        0x5
    .end array-data

    :array_2
    .array-data 4
        0x32
        0x32
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        -0x1
        -0x1
    .end array-data

    :array_b
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_c
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_d
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_e
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data
.end method

.method private E(Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    invoke-static {p1}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    iget-object v0, p0, La/t;->rG:[[I

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    aput v2, v0, v1

    iget-object v0, p0, La/t;->rG:[[I

    aget-object v0, v0, v1

    const/4 v2, 0x1

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    aput v3, v0, v2

    iget-object v0, p0, La/t;->rG:[[I

    aget-object v0, v0, v2

    const/4 v3, 0x2

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    aput v3, v0, v1

    iget-object v0, p0, La/t;->rG:[[I

    aget-object v0, v0, v2

    const/4 v1, 0x3

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    aput p1, v0, v2

    return-void
.end method

.method public static F(Ljava/util/ArrayList;)La/p;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)",
            "La/p;"
        }
    .end annotation

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x3e8

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v0, 0x6

    goto :goto_0

    :cond_0
    const/16 v3, 0x96

    if-ge v0, v3, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    const/16 v3, 0x15e

    if-ge v0, v3, :cond_2

    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    const/16 v3, 0x190

    if-ge v0, v3, :cond_3

    const/4 v0, 0x2

    goto :goto_0

    :cond_3
    const/16 v3, 0x1c2

    if-ge v0, v3, :cond_4

    const/4 v0, 0x3

    goto :goto_0

    :cond_4
    const/16 v3, 0x1f4

    if-ge v0, v3, :cond_5

    const/4 v0, 0x4

    goto :goto_0

    :cond_5
    const/4 v0, 0x5

    :goto_0
    sget-object v3, La/ak;->Bk:[[I

    aget-object v3, v3, v0

    aget v2, v3, v2

    sget-object v3, La/ak;->Bk:[[I

    aget-object v0, v3, v0

    aget v0, v0, v1

    invoke-static {p0, v2, v0}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object p0

    return-object p0
.end method

.method public static G(Ljava/util/ArrayList;)La/p;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)",
            "La/p;"
        }
    .end annotation

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/16 v3, 0x19

    if-ge v0, v3, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/16 v3, 0x28

    if-ge v0, v3, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/16 v3, 0x41

    if-ge v0, v3, :cond_2

    const/4 v0, 0x2

    goto :goto_0

    :cond_2
    const/16 v3, 0x49

    if-ge v0, v3, :cond_3

    const/4 v0, 0x3

    goto :goto_0

    :cond_3
    const/16 v3, 0x52

    if-ge v0, v3, :cond_4

    const/4 v0, 0x4

    goto :goto_0

    :cond_4
    const/16 v3, 0x55

    if-ge v0, v3, :cond_5

    const/4 v0, 0x6

    goto :goto_0

    :cond_5
    const/4 v0, 0x5

    :goto_0
    sget-object v3, La/ak;->Bk:[[I

    aget-object v3, v3, v0

    aget v2, v3, v2

    sget-object v3, La/ak;->Bk:[[I

    aget-object v0, v3, v0

    aget v0, v0, v1

    invoke-static {p0, v2, v0}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object p0

    return-object p0
.end method

.method public static H(Ljava/util/ArrayList;)La/p;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)",
            "La/p;"
        }
    .end annotation

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x1f4

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v0, 0x6

    goto :goto_0

    :cond_0
    const/16 v3, 0x96

    if-ge v0, v3, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    const/16 v3, 0xfa

    if-ge v0, v3, :cond_2

    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    const/16 v3, 0x140

    if-ge v0, v3, :cond_3

    const/4 v0, 0x2

    goto :goto_0

    :cond_3
    const/16 v3, 0x168

    if-ge v0, v3, :cond_4

    const/4 v0, 0x3

    goto :goto_0

    :cond_4
    const/16 v3, 0x1a4

    if-ge v0, v3, :cond_5

    const/4 v0, 0x4

    goto :goto_0

    :cond_5
    const/4 v0, 0x5

    :goto_0
    sget-object v3, La/ak;->Bk:[[I

    aget-object v3, v3, v0

    aget v2, v3, v2

    sget-object v3, La/ak;->Bk:[[I

    aget-object v0, v3, v0

    aget v0, v0, v1

    invoke-static {p0, v2, v0}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object p0

    return-object p0
.end method

.method public static I(Ljava/util/ArrayList;)La/p;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)",
            "La/p;"
        }
    .end annotation

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0xc8

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v0, 0x6

    goto :goto_0

    :cond_0
    const/16 v3, 0x50

    if-ge v0, v3, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    const/16 v3, 0x6e

    if-ge v0, v3, :cond_2

    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    const/16 v3, 0xa0

    if-ge v0, v3, :cond_3

    const/4 v0, 0x2

    goto :goto_0

    :cond_3
    const/16 v3, 0xaa

    if-ge v0, v3, :cond_4

    const/4 v0, 0x3

    goto :goto_0

    :cond_4
    const/16 v3, 0xbe

    if-ge v0, v3, :cond_5

    const/4 v0, 0x4

    goto :goto_0

    :cond_5
    const/4 v0, 0x5

    :goto_0
    sget-object v3, La/ak;->Bk:[[I

    aget-object v3, v3, v0

    aget v2, v3, v2

    sget-object v3, La/ak;->Bk:[[I

    aget-object v0, v3, v0

    aget v0, v0, v1

    invoke-static {p0, v2, v0}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object p0

    return-object p0
.end method

.method private N(II)Z
    .locals 2

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    iget p1, p0, La/t;->qW:I

    iget v1, p0, La/t;->qV:I

    sub-int/2addr p1, v1

    if-lt p1, p2, :cond_1

    return v0

    :cond_0
    iget p1, p0, La/t;->qV:I

    iget v1, p0, La/t;->qW:I

    sub-int/2addr p1, v1

    if-lt p1, p2, :cond_1

    return v0

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public static O(II)Ljava/util/ArrayList;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x1

    :goto_0
    if-gt v3, p0, :cond_0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    invoke-static {v1}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 p0, 0x0

    :goto_1
    add-int/lit8 v3, p1, -0x1

    if-gt p0, v3, :cond_1

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p0, p0, 0x1

    goto :goto_1

    :cond_1
    return-object v0
.end method

.method public static a(IILa/t;La/ac;La/p;La/p;II)La/m;
    .locals 12

    move v0, p0

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    iget-object v6, v2, La/t;->qT:La/ac;

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-ne v3, v6, :cond_0

    invoke-virtual {v2}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v2}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v6

    goto :goto_0

    :cond_0
    iget-object v6, v2, La/t;->qU:La/ac;

    if-ne v3, v6, :cond_1

    invoke-virtual {v2}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v2}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v6

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    move-object v6, v9

    :goto_0
    new-instance v10, La/m;

    invoke-direct {v10, v8}, La/m;-><init>(I)V

    invoke-virtual {v10, v0}, La/m;->W(I)V

    invoke-virtual {v10, v4}, La/m;->c(La/p;)V

    const/4 v11, 0x2

    if-ne v1, v11, :cond_3

    invoke-static {v6}, La/t;->F(Ljava/util/ArrayList;)La/p;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v10, v1}, La/m;->c(La/p;)V

    invoke-virtual {v10, v11}, La/m;->aJ(I)V

    goto :goto_1

    :cond_2
    invoke-virtual {v10, v7}, La/m;->aJ(I)V

    goto :goto_1

    :cond_3
    invoke-virtual {v10, v1}, La/m;->aJ(I)V

    :goto_1
    if-eqz v5, :cond_4

    invoke-virtual {v10, v5}, La/m;->d(La/p;)V

    :cond_4
    move/from16 v5, p7

    invoke-virtual {v10, v5}, La/m;->aK(I)V

    move/from16 v6, p6

    invoke-virtual {v10, v6}, La/m;->aL(I)V

    invoke-virtual {v10, v3}, La/m;->f(La/ac;)V

    invoke-virtual {v2}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x3

    const/4 v7, 0x4

    if-ne v0, v11, :cond_5

    invoke-virtual/range {p4 .. p4}, La/p;->iK()Lcomponents/bm;

    move-result-object v11

    invoke-virtual {v11}, Lcomponents/bm;->uw()V

    goto :goto_3

    :cond_5
    if-ne v0, v7, :cond_6

    :goto_2
    invoke-virtual/range {p4 .. p4}, La/p;->iK()Lcomponents/bm;

    move-result-object v11

    invoke-virtual {v11}, Lcomponents/bm;->ux()V

    goto :goto_3

    :cond_6
    if-ne v0, v1, :cond_7

    invoke-virtual/range {p4 .. p4}, La/p;->iK()Lcomponents/bm;

    move-result-object v11

    invoke-virtual {v11}, Lcomponents/bm;->uw()V

    goto :goto_2

    :cond_7
    :goto_3
    if-eq v0, v1, :cond_b

    if-ne v0, v7, :cond_8

    goto :goto_4

    :cond_8
    const/4 v1, 0x5

    if-ne v0, v1, :cond_c

    if-eqz v4, :cond_9

    invoke-static {p2}, Lcom/brasfoot/v2028/Recopa;->noInjuryComp(La/t;)Z

    move-result v1

    if-nez v1, :cond_9

    invoke-virtual {v4, v3}, La/p;->k(La/ac;)V

    :cond_9
    if-eqz v9, :cond_a

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_a

    invoke-virtual {v9, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_a
    if-eqz v2, :cond_c

    if-eqz v3, :cond_c

    iget-object v0, v2, La/t;->rm:[I

    aget v0, v0, v8

    if-lez v0, :cond_c

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_c

    const/4 v1, 0x0

    const/4 v7, 0x1

    goto :goto_5

    :cond_b
    :goto_4
    if-eqz v9, :cond_c

    invoke-virtual {v9, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual/range {p4 .. p4}, La/p;->io()I

    move-result v0

    const/16 v1, 0xd

    if-gt v0, v1, :cond_c

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_c

    iget-object v0, v2, La/t;->rm:[I

    aget v0, v0, v8

    if-lez v0, :cond_c

    const/4 v1, 0x1

    const/4 v7, 0x0

    :goto_5
    move v0, v8

    move-object v3, v4

    move v4, v6

    move v6, v7

    invoke-static/range {v0 .. v6}, La/t;->a(IZLa/t;La/p;IIZ)V

    :cond_c
    return-object v10
.end method

.method public static a(Ljava/util/ArrayList;II)La/p;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;II)",
            "La/p;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->io()I

    move-result v3

    if-lt v3, p1, :cond_0

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->io()I

    move-result v3

    if-gt v3, p2, :cond_0

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p0

    if-lez p0, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/p;

    return-object p0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(La/t;III)Lcomponents/bk;
    .locals 2

    iget-object v0, p0, La/t;->ri:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->ri:Ljava/util/ArrayList;

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/t;->ri:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    iget-object v1, p0, La/t;->ri:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bk;

    invoke-virtual {v1}, Lcomponents/bk;->uh()I

    move-result v1

    if-ne v1, p1, :cond_1

    iget-object v1, p0, La/t;->ri:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bk;

    invoke-virtual {v1}, Lcomponents/bk;->uf()I

    move-result v1

    if-ne v1, p3, :cond_1

    iget-object v1, p0, La/t;->ri:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bk;

    invoke-virtual {v1}, Lcomponents/bk;->gV()I

    move-result v1

    if-ne v1, p2, :cond_1

    iget-object p0, p0, La/t;->ri:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcomponents/bk;

    return-object p0

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(ILa/t;La/p;II)V
    .locals 9

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v0

    const/4 v1, 0x1

    if-ne p0, v1, :cond_0

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object v0

    :cond_0
    move-object v4, v0

    const/4 v1, 0x4

    const/4 v2, -0x1

    const/4 v6, 0x0

    move-object v3, p1

    move-object v5, p2

    move v7, p3

    move v8, p4

    invoke-static/range {v1 .. v8}, La/t;->a(IILa/t;La/ac;La/p;La/p;II)La/m;

    return-void
.end method

.method public static a(IZLa/t;La/p;IIZ)V
    .locals 8

    const/4 v0, 0x1

    const/4 v2, 0x0

    if-nez p0, :cond_0

    invoke-virtual {p2}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {p2}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v4

    :goto_0
    move-object v5, v3

    goto :goto_1

    :cond_0
    if-ne p0, v0, :cond_1

    invoke-virtual {p2}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {p2}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v4

    goto :goto_0

    :cond_1
    move-object v4, v2

    move-object v5, v4

    :goto_1
    if-eqz p1, :cond_3

    const/16 v3, 0x12

    const/16 v6, 0x19

    invoke-static {v4, v3, v6}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object v3

    if-nez v3, :cond_2

    const/16 v3, 0xe

    const/16 v7, 0x11

    invoke-static {v4, v3, v7}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object v3

    :cond_2
    if-nez v3, :cond_4

    invoke-virtual {p3}, La/p;->io()I

    move-result v7

    if-ne v7, v0, :cond_4

    const/4 v3, 0x2

    invoke-static {v4, v3, v6}, La/t;->a(Ljava/util/ArrayList;II)La/p;

    move-result-object v3

    goto :goto_2

    :cond_3
    move-object v3, p3

    :cond_4
    :goto_2
    if-eqz v5, :cond_9

    if-eqz v3, :cond_9

    invoke-virtual {p3}, La/p;->io()I

    move-result v4

    if-ltz v4, :cond_6

    invoke-virtual {p3}, La/p;->getPosicao()I

    move-result v2

    const/4 v4, 0x0

    if-nez v2, :cond_5

    const/4 v0, 0x0

    :cond_5
    invoke-virtual {p3}, La/p;->io()I

    move-result v2

    invoke-static {v5, v2, v4, v0}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v0

    move-object v4, v0

    goto :goto_3

    :cond_6
    move-object v4, v2

    :goto_3
    if-eqz v4, :cond_9

    if-eqz p6, :cond_8

    invoke-virtual {v3}, La/p;->getPosicao()I

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    invoke-virtual {p3}, La/p;->io()I

    move-result v6

    const/4 v7, 0x5

    goto :goto_4

    :cond_8
    invoke-virtual {p3}, La/p;->io()I

    move-result v6

    const/4 v7, -0x1

    :goto_4
    move-object v0, p2

    move v1, p0

    move-object v2, v3

    move-object v3, v4

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v7}, La/t;->a(ILa/p;La/p;IIII)La/m;

    :cond_9
    return-void
.end method

.method public static b(ILa/t;La/p;II)V
    .locals 9

    invoke-virtual {p2}, La/p;->iA()V

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v0

    const/4 v1, 0x1

    if-ne p0, v1, :cond_0

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object v0

    :cond_0
    move-object v4, v0

    invoke-virtual {p2}, La/p;->iz()I

    move-result p0

    const/4 v0, 0x2

    if-ne p0, v0, :cond_1

    const/4 v1, 0x3

    :goto_0
    const/4 v2, -0x1

    const/4 v6, 0x0

    move-object v3, p1

    move-object v5, p2

    move v7, p3

    move v8, p4

    invoke-static/range {v1 .. v8}, La/t;->a(IILa/t;La/ac;La/p;La/p;II)La/m;

    return-void

    :cond_1
    const/4 v1, 0x2

    goto :goto_0

    return-void
.end method

.method public static b(La/t;II)V
    .locals 16

    move-object/from16 v2, p0

    move/from16 v6, p1

    move/from16 v7, p2

    const/4 v0, 0x3

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    new-array v3, v0, [I

    fill-array-data v3, :array_1

    new-array v4, v0, [I

    fill-array-data v4, :array_2

    new-array v5, v0, [I

    fill-array-data v5, :array_3

    new-array v8, v0, [I

    fill-array-data v8, :array_4

    new-array v9, v0, [I

    fill-array-data v9, :array_5

    new-instance v9, Ljava/util/Random;

    invoke-direct {v9}, Ljava/util/Random;-><init>()V

    const/16 v10, 0x64

    invoke-virtual {v9, v10}, Ljava/util/Random;->nextInt(I)I

    move-result v9

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    const/16 v13, 0x37

    if-le v9, v13, :cond_0

    invoke-virtual/range {p0 .. p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual/range {p0 .. p0}, La/t;->ji()La/ac;

    move-result-object v13

    invoke-virtual {v13}, La/ac;->lI()[I

    move-result-object v13

    aget v13, v13, v11

    const/4 v14, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual/range {p0 .. p0}, La/t;->jj()La/ac;

    move-result-object v13

    invoke-virtual {v13}, La/ac;->lI()[I

    move-result-object v13

    aget v13, v13, v11

    const/4 v14, 0x1

    :goto_0
    new-array v0, v0, [I

    fill-array-data v0, :array_6

    array-length v15, v0

    if-lt v13, v15, :cond_1

    const/4 v13, 0x0

    :cond_1
    const/16 v15, 0xf

    if-ge v7, v15, :cond_2

    goto :goto_1

    :cond_2
    const/16 v10, 0x1e

    if-ge v7, v10, :cond_3

    const/4 v10, 0x1

    goto :goto_1

    :cond_3
    const/4 v10, 0x2

    :goto_1
    rem-int/lit8 v15, v7, 0x7

    if-nez v15, :cond_4

    invoke-virtual/range {p0 .. p2}, La/t;->L(II)V

    :cond_4
    if-ne v6, v12, :cond_5

    aget v1, v1, v10

    aget v0, v0, v13

    add-int/2addr v1, v0

    aget v0, v4, v10

    aget v3, v8, v10

    goto :goto_2

    :cond_5
    aget v1, v3, v10

    aget v0, v0, v13

    add-int/2addr v1, v0

    aget v0, v5, v10

    aget v3, v8, v10

    :goto_2
    iget v4, v2, La/t;->rn:I

    const/4 v5, 0x5

    if-le v4, v5, :cond_6

    mul-int/lit8 v1, v1, 0x2

    goto :goto_3

    :cond_6
    iget v4, v2, La/t;->rn:I

    const/16 v8, 0xa

    if-le v4, v8, :cond_7

    const/16 v1, 0x3e8

    :cond_7
    :goto_3
    iget v4, v2, La/t;->ro:I

    if-lt v4, v11, :cond_8

    mul-int/lit8 v1, v0, 0x2

    :cond_8
    iget v4, v2, La/t;->rp:I

    if-lt v4, v12, :cond_9

    mul-int/lit8 v1, v3, 0x5

    :cond_9
    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    invoke-virtual {v4, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v12, :cond_a

    invoke-static {v9}, La/t;->G(Ljava/util/ArrayList;)La/p;

    move-result-object v0

    iget v1, v2, La/t;->rn:I

    add-int/2addr v1, v12

    iput v1, v2, La/t;->rn:I

    if-eqz v0, :cond_f

    invoke-static {v14, v2, v0, v6, v7}, La/t;->b(ILa/t;La/p;II)V

    return-void

    :cond_a
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v0}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    if-ne v0, v12, :cond_c

    invoke-static {v9}, La/t;->I(Ljava/util/ArrayList;)La/p;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-static {v14, v2, v0, v6, v7}, La/t;->a(ILa/t;La/p;II)V

    :cond_b
    iget v0, v2, La/t;->ro:I

    add-int/2addr v0, v12

    iput v0, v2, La/t;->ro:I

    return-void

    :cond_c
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    if-ne v0, v12, :cond_e

    iget v0, v2, La/t;->rp:I

    add-int/2addr v0, v12

    iput v0, v2, La/t;->rp:I

    invoke-virtual/range {p0 .. p0}, La/t;->ji()La/ac;

    move-result-object v0

    if-ne v14, v12, :cond_d

    invoke-virtual/range {p0 .. p0}, La/t;->jj()La/ac;

    move-result-object v0

    :cond_d
    move-object v3, v0

    invoke-static {v9}, La/t;->H(Ljava/util/ArrayList;)La/p;

    move-result-object v4

    if-eqz v4, :cond_f

    const/4 v0, 0x5

    const/4 v1, -0x1

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, La/t;->a(IILa/t;La/ac;La/p;La/p;II)La/m;

    return-void

    :cond_e
    if-ne v6, v11, :cond_f

    if-lt v7, v5, :cond_f

    invoke-virtual/range {p0 .. p2}, La/t;->M(II)V

    :cond_f
    return-void

    nop

    :array_0
    .array-data 4
        0x46
        0x28
        0x1e
    .end array-data

    :array_1
    .array-data 4
        0x2d
        0x28
        0x1e
    .end array-data

    :array_2
    .array-data 4
        0x4b0
        0x384
        0x320
    .end array-data

    :array_3
    .array-data 4
        0x320
        0x2bc
        0x226
    .end array-data

    :array_4
    .array-data 4
        0x7d0
        0x5dc
        0x44c
    .end array-data

    :array_5
    .array-data 4
        0x3e8
        0x3e8
        0x44c
    .end array-data

    :array_6
    .array-data 4
        0x1e
        0xa
        0x0
    .end array-data
.end method

.method public static b(La/t;Z)[I
    .locals 19

    invoke-virtual/range {p0 .. p0}, La/t;->jb()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual/range {p0 .. p0}, La/t;->jb()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    if-ne v4, v1, :cond_1

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_1
    const/4 v4, 0x2

    new-array v5, v4, [I

    fill-array-data v5, :array_0

    const/4 v6, 0x5

    new-array v7, v6, [[I

    const/16 v8, 0xa

    new-array v9, v8, [I

    fill-array-data v9, :array_1

    aput-object v9, v7, v3

    new-array v9, v8, [I

    fill-array-data v9, :array_2

    aput-object v9, v7, v2

    new-array v9, v8, [I

    fill-array-data v9, :array_3

    aput-object v9, v7, v4

    new-array v9, v8, [I

    fill-array-data v9, :array_4

    const/4 v10, 0x3

    aput-object v9, v7, v10

    new-array v9, v8, [I

    fill-array-data v9, :array_5

    const/4 v11, 0x4

    aput-object v9, v7, v11

    new-array v9, v6, [[I

    new-array v12, v8, [I

    fill-array-data v12, :array_6

    aput-object v12, v9, v3

    new-array v12, v8, [I

    fill-array-data v12, :array_7

    aput-object v12, v9, v2

    new-array v12, v8, [I

    fill-array-data v12, :array_8

    aput-object v12, v9, v4

    new-array v12, v8, [I

    fill-array-data v12, :array_9

    aput-object v12, v9, v10

    new-array v12, v8, [I

    fill-array-data v12, :array_a

    aput-object v12, v9, v11

    new-array v12, v6, [[I

    new-array v13, v8, [I

    fill-array-data v13, :array_b

    aput-object v13, v12, v3

    new-array v13, v8, [I

    fill-array-data v13, :array_c

    aput-object v13, v12, v2

    new-array v13, v8, [I

    fill-array-data v13, :array_d

    aput-object v13, v12, v4

    new-array v13, v8, [I

    fill-array-data v13, :array_e

    aput-object v13, v12, v10

    new-array v13, v8, [I

    fill-array-data v13, :array_f

    aput-object v13, v12, v11

    new-array v12, v6, [[I

    new-array v13, v8, [I

    fill-array-data v13, :array_10

    aput-object v13, v12, v3

    new-array v13, v8, [I

    fill-array-data v13, :array_11

    aput-object v13, v12, v2

    new-array v13, v8, [I

    fill-array-data v13, :array_12

    aput-object v13, v12, v4

    new-array v13, v8, [I

    fill-array-data v13, :array_13

    aput-object v13, v12, v10

    new-array v13, v8, [I

    fill-array-data v13, :array_14

    aput-object v13, v12, v11

    invoke-static/range {p0 .. p0}, La/t;->e(La/t;)I

    move-result v12

    new-array v13, v10, [I

    fill-array-data v13, :array_15

    const-wide v14, -0x406147ae147ae148L    # -0.03

    const/16 v11, 0x64

    if-nez v0, :cond_6

    const-wide v16, 0x3ff8f5c28f5c28f6L    # 1.56

    if-nez v1, :cond_2

    int-to-double v0, v12

    mul-double v0, v0, v16

    const-wide v16, 0x40473c28f5c28f5cL    # 46.47

    add-double v0, v0, v16

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    aput v0, v13, v3

    goto :goto_2

    :cond_2
    int-to-double v0, v12

    mul-double v0, v0, v16

    const-wide v16, 0x40493c28f5c28f5cL    # 50.47

    add-double v0, v0, v16

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    aput v0, v13, v3

    :goto_2
    mul-int v0, v12, v12

    int-to-double v0, v0

    mul-double v0, v0, v14

    const-wide v14, 0x3fd28f5c28f5c28fL    # 0.29

    move-object/from16 v18, v9

    int-to-double v8, v12

    mul-double v8, v8, v14

    sub-double/2addr v0, v8

    const-wide v8, 0x403d7ae147ae147bL    # 29.48

    add-double/2addr v0, v8

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    aput v0, v13, v2

    aget v0, v13, v3

    if-gez v0, :cond_3

    aput v3, v13, v3

    :cond_3
    aget v0, v13, v2

    if-gez v0, :cond_4

    aput v3, v13, v2

    :cond_4
    const/16 v0, 0x18

    if-le v12, v0, :cond_5

    aput v6, v13, v2

    :cond_5
    aget v0, v13, v3

    aget v1, v13, v2

    add-int/2addr v0, v1

    rsub-int/lit8 v0, v0, 0x64

    aput v0, v13, v4

    aget v0, v13, v4

    if-gez v0, :cond_a

    aput v3, v13, v4

    goto :goto_3

    :cond_6
    move-object/from16 v18, v9

    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v12

    const-wide v0, 0x3ffc28f5c28f5c29L    # 1.76

    int-to-double v8, v12

    mul-double v0, v0, v8

    const-wide v16, 0x4041800000000000L    # 35.0

    add-double v0, v0, v16

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    aput v0, v13, v3

    mul-int v0, v12, v12

    int-to-double v0, v0

    mul-double v0, v0, v14

    const-wide v14, 0x3fc851eb851eb852L    # 0.19

    mul-double v8, v8, v14

    sub-double/2addr v0, v8

    const-wide/high16 v8, 0x403e000000000000L    # 30.0

    add-double/2addr v0, v8

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    aput v0, v13, v2

    aget v0, v13, v3

    if-gez v0, :cond_7

    aput v3, v13, v3

    :cond_7
    aget v0, v13, v2

    if-gez v0, :cond_8

    aput v3, v13, v2

    :cond_8
    aget v0, v13, v3

    aget v1, v13, v2

    add-int/2addr v0, v1

    rsub-int/lit8 v0, v0, 0x64

    aput v0, v13, v4

    aget v0, v13, v4

    if-gez v0, :cond_9

    aput v3, v13, v4

    :cond_9
    if-gez v12, :cond_a

    aget v0, v13, v2

    aget v1, v13, v4

    aput v1, v13, v3

    aput v0, v13, v4

    :cond_a
    :goto_3
    aget v0, v13, v2

    aget v1, v13, v3

    add-int/2addr v0, v1

    aput v0, v13, v2

    aput v11, v13, v4

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    invoke-virtual {v0, v11}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/2addr v0, v2

    aget v1, v13, v3

    if-gt v0, v1, :cond_b

    const/4 v0, 0x1

    goto :goto_4

    :cond_b
    aget v1, v13, v2

    if-gt v0, v1, :cond_d

    :cond_c
    const/4 v0, 0x0

    goto :goto_4

    :cond_d
    aget v1, v13, v4

    if-gt v0, v1, :cond_c

    const/4 v0, 0x2

    :goto_4
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v1

    const/16 v8, 0x1e

    const/16 v9, 0xf

    if-gt v1, v6, :cond_f

    :cond_e
    const/4 v1, 0x0

    goto :goto_5

    :cond_f
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v1

    const/16 v13, 0xa

    if-gt v1, v13, :cond_10

    const/4 v1, 0x1

    goto :goto_5

    :cond_10
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-gt v1, v9, :cond_11

    const/4 v1, 0x2

    goto :goto_5

    :cond_11
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v1

    const/16 v13, 0x19

    if-gt v1, v13, :cond_12

    const/4 v1, 0x3

    goto :goto_5

    :cond_12
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-gt v1, v8, :cond_e

    const/4 v1, 0x4

    :goto_5
    if-ltz v12, :cond_13

    if-ne v0, v2, :cond_13

    const/4 v13, 0x1

    goto :goto_6

    :cond_13
    const/4 v13, 0x0

    :goto_6
    if-gez v12, :cond_14

    if-ne v0, v4, :cond_14

    const/4 v13, 0x1

    :cond_14
    if-lez v0, :cond_21

    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    invoke-virtual {v6, v11}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    add-int/2addr v6, v2

    const/16 v14, 0x9

    if-eqz v13, :cond_16

    const/4 v13, 0x0

    :goto_7
    if-gt v13, v14, :cond_18

    aget-object v15, v7, v1

    aget v15, v15, v13

    if-gt v6, v15, :cond_15

    add-int/2addr v13, v2

    goto :goto_9

    :cond_15
    add-int/lit8 v13, v13, 0x1

    goto :goto_7

    :cond_16
    const/4 v7, 0x0

    :goto_8
    if-gt v7, v14, :cond_18

    aget-object v13, v18, v1

    aget v13, v13, v7

    if-gt v6, v13, :cond_17

    add-int/lit8 v1, v7, 0x1

    move v13, v1

    goto :goto_9

    :cond_17
    add-int/lit8 v7, v7, 0x1

    goto :goto_8

    :cond_18
    const/4 v13, 0x0

    :goto_9
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v11}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/2addr v1, v2

    const/16 v6, 0x28

    if-gt v1, v6, :cond_1a

    :cond_19
    const/4 v1, 0x0

    goto :goto_a

    :cond_1a
    const/16 v6, 0x46

    if-gt v1, v6, :cond_1b

    const/4 v1, 0x1

    goto :goto_a

    :cond_1b
    const/16 v6, 0x5a

    if-gt v1, v6, :cond_1c

    const/4 v1, 0x3

    goto :goto_a

    :cond_1c
    if-gt v1, v11, :cond_19

    const/4 v1, 0x4

    :goto_a
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v6

    if-gt v6, v9, :cond_1d

    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v6

    const/16 v7, 0xa

    if-lt v6, v7, :cond_1d

    if-le v1, v10, :cond_1d

    :goto_b
    add-int/lit8 v1, v1, -0x1

    goto :goto_c

    :cond_1d
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v6

    if-gt v6, v8, :cond_1e

    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v6

    if-lt v6, v9, :cond_1e

    if-le v1, v4, :cond_1e

    goto :goto_b

    :cond_1e
    :goto_c
    if-lt v1, v13, :cond_1f

    const/4 v1, 0x0

    :cond_1f
    if-gez v1, :cond_20

    const/4 v1, 0x0

    :cond_20
    if-gt v13, v1, :cond_28

    add-int/lit8 v13, v1, 0x1

    goto :goto_e

    :cond_21
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v7, 0x320

    invoke-virtual {v1, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/2addr v1, v2

    const/16 v7, 0xc8

    if-gt v1, v7, :cond_23

    :cond_22
    const/4 v13, 0x0

    goto :goto_d

    :cond_23
    const/16 v7, 0x1f4

    if-gt v1, v7, :cond_24

    const/4 v13, 0x1

    goto :goto_d

    :cond_24
    const/16 v7, 0x2bc

    if-gt v1, v7, :cond_25

    const/4 v13, 0x2

    goto :goto_d

    :cond_25
    const/16 v7, 0x316

    if-gt v1, v7, :cond_26

    const/4 v13, 0x3

    goto :goto_d

    :cond_26
    const/16 v7, 0x31f

    if-gt v1, v7, :cond_27

    const/4 v13, 0x4

    goto :goto_d

    :cond_27
    const/16 v7, 0x320

    if-gt v1, v7, :cond_22

    const/4 v13, 0x5

    :goto_d
    move v1, v13

    :cond_28
    :goto_e
    if-ne v0, v2, :cond_29

    aput v13, v5, v3

    aput v1, v5, v2

    return-object v5

    :cond_29
    if-ne v0, v4, :cond_2a

    aput v1, v5, v3

    aput v13, v5, v2

    return-object v5

    :cond_2a
    aput v13, v5, v3

    aput v13, v5, v2

    return-object v5

    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x23
        0x4b
        0x5d
        0x63
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2
    .array-data 4
        0x1e
        0x46
        0x5f
        0x63
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3
    .array-data 4
        0xf
        0x37
        0x50
        0x5f
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0xf
        0x23
        0x49
        0x55
        0x61
        0x64
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x5
        0x19
        0x32
        0x46
        0x57
        0x63
        0x64
        0x0
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x23
        0x55
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x28
        0x50
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x3c
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x4b
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        0x55
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_b
    .array-data 4
        0x4b
        0x5f
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_c
    .array-data 4
        0x1e
        0x46
        0x5f
        0x63
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_d
    .array-data 4
        0xf
        0x37
        0x50
        0x5f
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_e
    .array-data 4
        0xf
        0x23
        0x49
        0x55
        0x61
        0x64
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_f
    .array-data 4
        0x5
        0x19
        0x32
        0x46
        0x57
        0x63
        0x64
        0x0
        0x0
        0x0
    .end array-data

    :array_10
    .array-data 4
        0x23
        0x55
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_11
    .array-data 4
        0x28
        0x50
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_12
    .array-data 4
        0x3c
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_13
    .array-data 4
        0x4b
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_14
    .array-data 4
        0x55
        0x64
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_15
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public static e(La/t;)I
    .locals 8

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v0, v3, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, La/t;->jB()I

    move-result v3

    div-int/lit8 v3, v3, 0xa

    int-to-float v3, v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {p0}, La/t;->jC()I

    move-result v4

    div-int/lit8 v4, v4, 0xa

    int-to-float v4, v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    sub-int v5, v3, v4

    if-le v3, v4, :cond_1

    div-int/lit8 v3, v5, 0x2

    :goto_1
    int-to-float v3, v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    goto :goto_2

    :cond_1
    if-ge v3, v4, :cond_2

    div-int/lit8 v3, v5, 0x3

    goto :goto_1

    :cond_2
    int-to-double v3, v5

    const-wide/high16 v6, 0x4004000000000000L    # 2.5

    div-double/2addr v3, v6

    invoke-static {v3, v4}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    long-to-int v3, v3

    :goto_2
    if-eqz v0, :cond_3

    div-int/lit8 v5, v5, 0x3

    int-to-float v0, v5

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v3

    :cond_3
    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v4

    invoke-virtual {v4}, La/ac;->getReputacao()I

    move-result v4

    if-le v0, v4, :cond_4

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v1

    :goto_3
    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    sub-int v1, v0, v1

    goto :goto_4

    :cond_4
    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v4

    invoke-virtual {v4}, La/ac;->getReputacao()I

    move-result v4

    if-le v0, v4, :cond_5

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v1

    goto :goto_3

    :cond_5
    :goto_4
    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-nez v0, :cond_6

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-eq v0, v2, :cond_6

    add-int/lit8 v1, v1, 0x5

    :cond_6
    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-eq v0, v2, :cond_7

    add-int/lit8 v1, v1, -0x5

    :cond_7
    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-ne v0, v2, :cond_8

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-eqz v0, :cond_8

    add-int/lit8 v1, v1, 0x5

    :cond_8
    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-ne v0, v2, :cond_9

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object p0

    invoke-virtual {p0}, La/ac;->iw()I

    move-result p0

    if-eqz p0, :cond_9

    add-int/lit8 v1, v1, -0x5

    :cond_9
    add-int/2addr v3, v1

    const/16 p0, 0x1e

    if-le v3, p0, :cond_a

    goto :goto_5

    :cond_a
    move p0, v3

    :goto_5
    const/16 v0, -0x1e

    if-ge p0, v0, :cond_b

    const/16 p0, -0x1e

    :cond_b
    return p0
.end method

.method private jh()V
    .locals 12

    sget-object v0, La/t;->rJ:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/t;->rJ:Ljava/util/ArrayList;

    const/16 v0, 0x13

    :goto_0
    const/16 v1, 0x26

    if-gt v0, v1, :cond_0

    sget-object v1, La/t;->rJ:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    sget-object v0, La/t;->rJ:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    sget-object v0, La/t;->rK:Ljava/util/ArrayList;

    const/4 v1, 0x5

    if-nez v0, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/t;->rK:Ljava/util/ArrayList;

    const/4 v0, 0x5

    :goto_1
    const/16 v2, 0xf

    if-gt v0, v2, :cond_1

    sget-object v2, La/t;->rK:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1
    sget-object v0, La/t;->rL:Ljava/util/ArrayList;

    if-nez v0, :cond_2

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/t;->rL:Ljava/util/ArrayList;

    const/16 v0, 0x10

    :goto_2
    const/16 v2, 0x23

    if-gt v0, v2, :cond_2

    sget-object v2, La/t;->rL:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_2
    sget-object v0, La/t;->rM:Ljava/util/ArrayList;

    if-nez v0, :cond_3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/t;->rM:Ljava/util/ArrayList;

    const/16 v0, 0x24

    :goto_3
    const/16 v2, 0x2a

    if-gt v0, v2, :cond_3

    sget-object v2, La/t;->rM:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_3
    sget-object v0, La/t;->rN:Ljava/util/ArrayList;

    if-nez v0, :cond_4

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/t;->rN:Ljava/util/ArrayList;

    const/16 v0, 0x2b

    :goto_4
    const/16 v2, 0x2f

    if-gt v0, v2, :cond_4

    sget-object v2, La/t;->rN:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_4
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x64

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    iget-object v4, p0, La/t;->rH:[[I

    const/4 v5, 0x0

    aget-object v4, v4, v5

    sget-object v6, La/t;->rJ:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v4, v5

    iget-object v4, p0, La/t;->rH:[[I

    aget-object v4, v4, v5

    sget-object v6, La/t;->rJ:Ljava/util/ArrayList;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v4, v7

    iget-object v4, p0, La/t;->rH:[[I

    aget-object v4, v4, v7

    sget-object v6, La/t;->rJ:Ljava/util/ArrayList;

    const/4 v8, 0x2

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v4, v5

    iget-object v4, p0, La/t;->rH:[[I

    aget-object v4, v4, v7

    sget-object v6, La/t;->rJ:Ljava/util/ArrayList;

    const/4 v9, 0x3

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v4, v7

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/16 v6, 0x1e

    if-le v4, v6, :cond_5

    iget-object v4, p0, La/t;->rH:[[I

    aget-object v4, v4, v5

    sget-object v10, La/t;->rJ:Ljava/util/ArrayList;

    const/4 v11, 0x4

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    aput v10, v4, v8

    :cond_5
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    if-le v4, v6, :cond_6

    iget-object v4, p0, La/t;->rH:[[I

    aget-object v4, v4, v7

    sget-object v6, La/t;->rJ:Ljava/util/ArrayList;

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    aput v1, v4, v8

    :cond_6
    const/16 v1, 0x5a

    const/16 v4, 0x32

    if-le v3, v1, :cond_7

    sget-object v1, La/t;->rK:Ljava/util/ArrayList;

    :goto_5
    invoke-direct {p0, v1}, La/t;->E(Ljava/util/ArrayList;)V

    goto :goto_6

    :cond_7
    if-le v3, v4, :cond_8

    sget-object v1, La/t;->rL:Ljava/util/ArrayList;

    goto :goto_5

    :cond_8
    sget-object v1, La/t;->rM:Ljava/util/ArrayList;

    goto :goto_5

    :goto_6
    sget-object v1, La/t;->rN:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    const/16 v3, 0x14

    if-le v1, v3, :cond_9

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v5

    sget-object v6, La/t;->rN:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    aput v6, v1, v8

    :cond_9
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-le v1, v4, :cond_a

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v5

    sget-object v5, La/t;->rN:Ljava/util/ArrayList;

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    aput v5, v1, v9

    :cond_a
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-le v1, v3, :cond_b

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v7

    sget-object v3, La/t;->rN:Ljava/util/ArrayList;

    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    aput v3, v1, v8

    :cond_b
    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    if-le v0, v4, :cond_c

    iget-object v0, p0, La/t;->rG:[[I

    aget-object v0, v0, v7

    sget-object v1, La/t;->rN:Ljava/util/ArrayList;

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    aput v1, v0, v9

    :cond_c
    return-void
.end method

.method public static jk()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->hu()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static jl()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, La/t;->f(Z)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jn()V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jq()V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jm()V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jp()V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3, v1}, La/ac;->S(Z)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3, v1}, La/ac;->S(Z)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, La/t;->a(Lcomponents/cn;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    :goto_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->hP()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, La/b;->oe:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method private js()Z
    .locals 2

    iget v0, p0, La/t;->qV:I

    iget v1, p0, La/t;->qW:I

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method


# virtual methods
.method public I(Z)Ljava/lang/String;
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p1, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, La/t;->rC:[I

    aget v1, v2, v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->rC:[I

    aget v0, v1, v0

    :goto_0
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, La/t;->rC:[I

    aget v0, v2, v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ":"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, La/t;->rC:[I

    aget v0, v0, v1

    goto :goto_0
.end method

.method public J(Z)[Ljava/lang/String;
    .locals 3

    const-string v0, ""

    const-string v1, ""

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, La/t;->qQ:La/al;

    invoke-virtual {v1, p1}, La/al;->Z(Z)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    aput-object p1, v0, v1

    iget-object p1, p0, La/t;->qS:La/al;

    if-eqz p1, :cond_1

    iget-object p1, p0, La/t;->qS:La/al;

    instance-of p1, p1, Ld/q;

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    iget-object p1, p0, La/t;->qS:La/al;

    check-cast p1, Ld/q;

    invoke-virtual {p1}, Ld/q;->xS()I

    move-result p1

    const/16 v2, 0x70d

    if-ne p1, v2, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Grupo rebaixamento "

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, La/t;->qS:La/al;

    invoke-virtual {v2}, La/al;->nT()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v0, v1

    return-object v0

    :cond_0
    iget-object p1, p0, La/t;->qS:La/al;

    invoke-virtual {p1}, La/al;->nT()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v0, v1

    :cond_1
    return-object v0
.end method

.method public K(Z)V
    .locals 0

    iput-boolean p1, p0, La/t;->rD:Z

    return-void
.end method

.method public L(II)V
    .locals 4

    const/4 p2, 0x0

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ge v0, v1, :cond_2

    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->io()I

    move-result v1

    if-eq v1, v3, :cond_0

    :goto_1
    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->hO()V

    goto :goto_2

    :cond_0
    if-ne p1, v2, :cond_1

    goto :goto_1

    :cond_1
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    :goto_3
    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p2, v0, :cond_5

    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->io()I

    move-result v0

    if-eq v0, v3, :cond_3

    :goto_4
    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->hO()V

    goto :goto_5

    :cond_3
    if-ne p1, v2, :cond_4

    goto :goto_4

    :cond_4
    :goto_5
    add-int/lit8 p2, p2, 0x1

    goto :goto_3

    :cond_5
    return-void
.end method

.method public M(II)V
    .locals 13

    const/4 v0, 0x2

    if-ne p1, v0, :cond_a

    iget-object v1, p0, La/t;->qT:La/ac;

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v2, 0x3

    const/16 v3, 0x32

    const/16 v4, 0x64

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v1, :cond_5

    iget-object v1, p0, La/t;->rm:[I

    aget v1, v1, v5

    if-lez v1, :cond_5

    if-nez p2, :cond_1

    invoke-direct {p0, v6, v6}, La/t;->N(II)Z

    move-result v1

    if-eqz v1, :cond_1

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-le v1, v3, :cond_5

    :cond_0
    :goto_0
    const/4 v8, 0x2

    :goto_1
    const/4 v9, 0x0

    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v12

    move-object v7, p0

    move v10, p1

    move v11, p2

    invoke-virtual/range {v7 .. v12}, La/t;->a(IIIILjava/util/ArrayList;)Z

    move-result v1

    goto :goto_3

    :cond_1
    iget-object v1, p0, La/t;->rH:[[I

    aget-object v1, v1, v5

    aget v1, v1, v5

    if-eq p2, v1, :cond_4

    iget-object v1, p0, La/t;->rH:[[I

    aget-object v1, v1, v5

    aget v1, v1, v6

    if-eq p2, v1, :cond_4

    iget-object v1, p0, La/t;->rH:[[I

    aget-object v1, v1, v5

    aget v1, v1, v0

    if-ne p2, v1, :cond_2

    goto :goto_2

    :cond_2
    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v5

    aget v1, v1, v5

    if-eq p2, v1, :cond_3

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v5

    aget v1, v1, v6

    if-eq p2, v1, :cond_3

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v5

    aget v1, v1, v0

    if-eq p2, v1, :cond_3

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v5

    aget v1, v1, v2

    if-ne p2, v1, :cond_5

    :cond_3
    const/4 v8, 0x1

    goto :goto_1

    :cond_4
    :goto_2
    invoke-direct {p0, v6, v6}, La/t;->N(II)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-direct {p0}, La/t;->js()Z

    move-result v1

    if-eqz v1, :cond_5

    goto :goto_0

    :cond_5
    const/4 v1, 0x0

    :goto_3
    if-nez v1, :cond_a

    iget-object v1, p0, La/t;->qU:La/ac;

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_a

    iget-object v1, p0, La/t;->rm:[I

    aget v1, v1, v6

    if-lez v1, :cond_a

    if-nez p2, :cond_6

    invoke-direct {p0, v0, v0}, La/t;->N(II)Z

    move-result v1

    if-eqz v1, :cond_6

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    invoke-virtual {v0, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    if-le v0, v3, :cond_a

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v9

    move-object v4, p0

    move v7, p1

    move v8, p2

    invoke-virtual/range {v4 .. v9}, La/t;->a(IIIILjava/util/ArrayList;)Z

    return-void

    :cond_6
    iget-object v1, p0, La/t;->rH:[[I

    aget-object v1, v1, v6

    aget v1, v1, v5

    if-eq p2, v1, :cond_9

    iget-object v1, p0, La/t;->rH:[[I

    aget-object v1, v1, v6

    aget v1, v1, v6

    if-eq p2, v1, :cond_9

    iget-object v1, p0, La/t;->rH:[[I

    aget-object v1, v1, v6

    aget v1, v1, v0

    if-ne p2, v1, :cond_7

    goto :goto_4

    :cond_7
    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v6

    aget v1, v1, v5

    if-eq p2, v1, :cond_8

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v6

    aget v1, v1, v6

    if-eq p2, v1, :cond_8

    iget-object v1, p0, La/t;->rG:[[I

    aget-object v1, v1, v6

    aget v0, v1, v0

    if-eq p2, v0, :cond_8

    iget-object v0, p0, La/t;->rG:[[I

    aget-object v0, v0, v6

    aget v0, v0, v2

    if-ne p2, v0, :cond_a

    :cond_8
    const/4 v2, 0x1

    goto :goto_5

    :cond_9
    :goto_4
    invoke-direct {p0, v0, v6}, La/t;->N(II)Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v2, 0x2

    :goto_5
    const/4 v3, 0x1

    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v6

    move-object v1, p0

    move v4, p1

    move v5, p2

    invoke-virtual/range {v1 .. v6}, La/t;->a(IIIILjava/util/ArrayList;)Z

    :cond_a
    return-void
.end method

.method public P(II)V
    .locals 1

    iget-object v0, p0, La/t;->rI:Lcomponents/cn;

    if-nez v0, :cond_0

    new-instance v0, Lcomponents/cn;

    invoke-direct {v0, p0}, Lcomponents/cn;-><init>(La/t;)V

    invoke-virtual {p0, v0}, La/t;->a(Lcomponents/cn;)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, La/t;->rI:Lcomponents/cn;

    :goto_0
    invoke-static {p0, p2, p1}, La/t;->b(La/t;II)V

    invoke-virtual {v0}, Lcomponents/cn;->vM()La/m;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1}, La/m;->aK(I)V

    invoke-virtual {v0, p2}, La/m;->aL(I)V

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    return-void
.end method

.method public a(La/p;II)I
    .locals 10

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x3e8

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/16 v1, 0x3e3

    const/16 v2, 0x3de

    const/4 v3, 0x4

    const/16 v4, 0x3d4

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-ne p2, v8, :cond_4

    const/16 v9, 0x384

    if-ge v0, v9, :cond_0

    goto :goto_3

    :cond_0
    const/16 v9, 0x3b6

    if-ge v0, v9, :cond_1

    :goto_0
    const/4 v3, 0x3

    goto :goto_4

    :cond_1
    if-ge v0, v4, :cond_2

    goto :goto_4

    :cond_2
    if-ge v0, v2, :cond_3

    :goto_1
    const/4 v3, 0x2

    goto :goto_4

    :cond_3
    if-ge v0, v1, :cond_9

    :goto_2
    const/4 v3, 0x5

    goto :goto_4

    :cond_4
    if-ne p2, v7, :cond_9

    const/16 v9, 0x320

    if-ge v0, v9, :cond_5

    goto :goto_3

    :cond_5
    const/16 v9, 0x352

    if-ge v0, v9, :cond_6

    goto :goto_0

    :cond_6
    if-ge v0, v4, :cond_7

    goto :goto_4

    :cond_7
    if-ge v0, v2, :cond_8

    goto :goto_1

    :cond_8
    if-ge v0, v1, :cond_9

    goto :goto_2

    :cond_9
    :goto_3
    const/4 v3, 0x1

    :goto_4
    if-ne v3, v5, :cond_b

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-eqz v0, :cond_a

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-ne v0, v7, :cond_b

    :cond_a
    const/4 v3, 0x1

    :cond_b
    if-ne v3, v6, :cond_f

    const/4 v0, 0x0

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v1

    iget-object v2, p0, La/t;->qT:La/ac;

    const/4 v4, 0x0

    if-ne v1, v2, :cond_c

    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v4, 0x1

    goto :goto_5

    :cond_c
    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object p1

    iget-object v1, p0, La/t;->qU:La/ac;

    if-ne p1, v1, :cond_d

    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v0

    :cond_d
    :goto_5
    if-eqz v0, :cond_f

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x64

    invoke-virtual {p1, v1}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    const/16 v1, 0x32

    if-ge p1, v1, :cond_e

    invoke-static {v0}, La/t;->G(Ljava/util/ArrayList;)La/p;

    move-result-object p1

    if-eqz p1, :cond_f

    invoke-static {v4, p0, p1, p2, p3}, La/t;->b(ILa/t;La/p;II)V

    return v3

    :cond_e
    const/16 v1, 0x3c

    if-ge p1, v1, :cond_f

    invoke-static {v0}, La/t;->I(Ljava/util/ArrayList;)La/p;

    move-result-object p1

    if-eqz p1, :cond_f

    invoke-static {v4, p0, p1, p2, p3}, La/t;->a(ILa/t;La/p;II)V

    :cond_f
    return v3
.end method

.method public a(ILa/p;La/p;IIII)La/m;
    .locals 11

    move-object v8, p0

    move v0, p1

    move-object v4, p2

    move-object v5, p3

    move/from16 v1, p6

    const/4 v2, 0x0

    if-eqz v4, :cond_4

    if-eqz v5, :cond_4

    invoke-virtual {v8}, La/t;->ji()La/ac;

    move-result-object v3

    const/4 v6, 0x1

    if-nez v0, :cond_0

    invoke-virtual {v8}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v8}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v8}, La/t;->kq()Ljava/util/ArrayList;

    move-result-object v7

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, La/t;->bt(I)V

    goto :goto_0

    :cond_0
    if-ne v0, v6, :cond_1

    invoke-virtual {v8}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v8}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v8, v6}, La/t;->bt(I)V

    invoke-virtual {v8}, La/t;->kr()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v8}, La/t;->jj()La/ac;

    move-result-object v7

    move-object v10, v7

    move-object v7, v3

    move-object v3, v10

    goto :goto_0

    :cond_1
    move-object v0, v2

    move-object v7, v0

    :goto_0
    if-eqz v2, :cond_3

    if-eqz v0, :cond_3

    invoke-virtual {v4}, La/p;->io()I

    move-result v9

    invoke-virtual {v5, v9}, La/p;->bd(I)V

    if-lez v1, :cond_2

    invoke-virtual {v5, v1}, La/p;->bd(I)V

    :cond_2
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v5, v1}, La/p;->b(Ljava/lang/Boolean;)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_3
    const/4 v0, 0x6

    const/4 v1, -0x1

    move-object v2, v8

    move v6, p4

    move/from16 v7, p5

    invoke-static/range {v0 .. v7}, La/t;->a(IILa/t;La/ac;La/p;La/p;II)La/m;

    move-result-object v2

    :cond_4
    return-object v2
.end method

.method public a(Landroid/content/Context;Z)Ljava/lang/String;
    .locals 0

    if-nez p2, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, " "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p0, La/t;->qV:I

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "x"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p0, La/t;->qW:I

    :goto_0
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, " "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p0, La/t;->qW:I

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "x"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p0, La/t;->qV:I

    goto :goto_0
.end method

.method public a(Lcomponents/cn;)V
    .locals 0

    iput-object p1, p0, La/t;->rI:Lcomponents/cn;

    return-void
.end method

.method public a(IIIILjava/util/ArrayList;)Z
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IIII",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)Z"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v7, 0x1

    if-ne p1, v7, :cond_2

    const/16 v0, 0x3c

    const/16 v3, 0x28

    if-le p4, v3, :cond_0

    const/16 v0, 0x5a

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_0

    new-instance v3, Ljava/util/Random;

    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_5

    invoke-virtual {p5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->io()I

    move-result v4

    if-eq v4, v7, :cond_1

    invoke-virtual {p5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->hN()I

    move-result v4

    if-ge v4, v0, :cond_1

    const/4 v2, 0x0

    invoke-virtual {p5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    :goto_1
    move-object v3, v0

    check-cast v3, La/p;

    const/4 v6, 0x0

    move v0, p2

    move v1, v2

    move-object v2, p0

    move v4, p3

    move v5, p4

    invoke-static/range {v0 .. v6}, La/t;->a(IZLa/t;La/p;IIZ)V

    return v7

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    if-ne p1, v3, :cond_5

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_5

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v4

    invoke-virtual {v0, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    iget-object v6, p0, La/t;->rf:Ljava/util/ArrayList;

    if-ne p2, v3, :cond_3

    iget-object v6, p0, La/t;->rg:Ljava/util/ArrayList;

    :cond_3
    invoke-virtual {p5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    :cond_4
    invoke-virtual {p5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->io()I

    move-result v0

    if-eq v0, v7, :cond_5

    invoke-virtual {p5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    const/4 v2, 0x0

    invoke-virtual {p5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_5
    return v2
.end method

.method public bA(I)V
    .locals 0

    iput p1, p0, La/t;->renda:I

    return-void
.end method

.method public bB(I)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/t;->rt:[I

    aget p1, v0, p1

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bq(I)V
    .locals 0

    iput p1, p0, La/t;->rj:I

    return-void
.end method

.method public br(I)V
    .locals 0

    iput p1, p0, La/t;->rk:I

    return-void
.end method

.method public bs(I)I
    .locals 1

    iget-object v0, p0, La/t;->rm:[I

    aget p1, v0, p1

    return p1
.end method

.method public bt(I)V
    .locals 2

    iget-object v0, p0, La/t;->rm:[I

    aget v1, v0, p1

    add-int/lit8 v1, v1, -0x1

    aput v1, v0, p1

    return-void
.end method

.method public bu(I)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/t;->rs:[I

    aget p1, v0, p1

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bv(I)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/t;->rv:[I

    aget p1, v0, p1

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bw(I)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/t;->rw:[I

    aget p1, v0, p1

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bx(I)La/p;
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ne p1, v1, :cond_1

    :goto_0
    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_3

    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    invoke-virtual {p1}, La/p;->io()I

    move-result p1

    if-ne p1, v1, :cond_0

    invoke-virtual {p0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object p1

    :goto_1
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    if-ne p1, v2, :cond_3

    :goto_2
    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_3

    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    invoke-virtual {p1}, La/p;->io()I

    move-result p1

    if-ne p1, v1, :cond_2

    invoke-virtual {p0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object p1

    goto :goto_1

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_3
    const/4 p1, 0x0

    return-object p1
.end method

.method public by(I)V
    .locals 0

    iput p1, p0, La/t;->rA:I

    return-void
.end method

.method public bz(I)V
    .locals 0

    iput p1, p0, La/t;->rB:I

    return-void
.end method

.method public c([I)V
    .locals 0

    iput-object p1, p0, La/t;->rq:[I

    return-void
.end method

.method public cJ()Z
    .locals 1

    iget-boolean v0, p0, La/t;->lT:Z

    return v0
.end method

.method public d([I)V
    .locals 0

    iput-object p1, p0, La/t;->rs:[I

    return-void
.end method

.method public e([I)V
    .locals 0

    iput-object p1, p0, La/t;->rv:[I

    return-void
.end method

.method public f(Z)V
    .locals 0

    iput-boolean p1, p0, La/t;->lT:Z

    return-void
.end method

.method public f([I)V
    .locals 0

    iput-object p1, p0, La/t;->rw:[I

    return-void
.end method

.method public g([I)V
    .locals 0

    iput-object p1, p0, La/t;->rx:[I

    return-void
.end method

.method public h([I)V
    .locals 0

    iput-object p1, p0, La/t;->rC:[I

    return-void
.end method

.method public hu()V
    .locals 7

    new-instance v0, Lcomponents/cn;

    invoke-direct {v0, p0}, Lcomponents/cn;-><init>(La/t;)V

    invoke-virtual {p0, v0}, La/t;->a(Lcomponents/cn;)V

    const/4 v1, 0x2

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v2

    instance-of v2, v2, Ld/x;

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_3

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v2

    check-cast v2, Ld/x;

    invoke-virtual {v2}, Ld/x;->yt()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v2

    check-cast v2, Ld/x;

    invoke-virtual {v2}, Ld/x;->yq()I

    move-result v2

    if-ne v2, v1, :cond_1

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v2

    check-cast v2, Ld/x;

    invoke-virtual {v2, p0}, Ld/x;->p(La/t;)[I

    move-result-object v2

    aget v5, v2, v4

    invoke-virtual {p0, v5}, La/t;->by(I)V

    aget v2, v2, v3

    invoke-virtual {p0, v2}, La/t;->bz(I)V

    iput-boolean v4, p0, La/t;->rD:Z

    :cond_0
    iput-boolean v4, p0, La/t;->ry:Z

    :cond_1
    iget-boolean v2, p0, La/t;->ry:Z

    if-eqz v2, :cond_3

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v2

    check-cast v2, Ld/x;

    invoke-virtual {v2}, Ld/x;->yz()Z

    move-result v2

    if-eqz v2, :cond_2

    iput-boolean v3, p0, La/t;->rz:Z

    goto :goto_0

    :cond_2
    iput-boolean v4, p0, La/t;->rz:Z

    :cond_3
    :goto_0
    invoke-virtual {p0}, La/t;->jO()La/l;

    move-result-object v2

    if-eqz v2, :cond_4

    invoke-virtual {p0}, La/t;->jO()La/l;

    move-result-object v2

    invoke-virtual {v2, p0}, La/l;->b(La/t;)V

    :cond_4
    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_9

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_9

    iget-object v2, p0, La/t;->rl:[I

    new-instance v5, Ljava/util/Random;

    invoke-direct {v5}, Ljava/util/Random;-><init>()V

    const/4 v6, 0x3

    invoke-virtual {v5, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v5

    aput v5, v2, v3

    iget-object v2, p0, La/t;->rl:[I

    new-instance v5, Ljava/util/Random;

    invoke-direct {v5}, Ljava/util/Random;-><init>()V

    const/4 v6, 0x5

    invoke-virtual {v5, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v5

    add-int/2addr v5, v4

    aput v5, v2, v4

    const/4 v2, 0x0

    :goto_1
    iget-object v5, p0, La/t;->rl:[I

    aget v5, v5, v3

    add-int/lit8 v5, v5, 0x2d

    if-ge v2, v5, :cond_6

    invoke-static {p0, v4, v2}, La/t;->b(La/t;II)V

    invoke-virtual {v0}, Lcomponents/cn;->vM()La/m;

    move-result-object v5

    if-eqz v5, :cond_5

    invoke-virtual {v5, v2}, La/m;->aK(I)V

    invoke-virtual {v5, v4}, La/m;->aL(I)V

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_6
    invoke-virtual {p0, v1, v3}, La/t;->M(II)V

    const/4 v2, 0x0

    :goto_2
    iget-object v5, p0, La/t;->rl:[I

    aget v5, v5, v4

    add-int/lit8 v5, v5, 0x2d

    if-ge v2, v5, :cond_8

    invoke-static {p0, v1, v2}, La/t;->b(La/t;II)V

    invoke-virtual {v0}, Lcomponents/cn;->vM()La/m;

    move-result-object v5

    if-eqz v5, :cond_7

    invoke-virtual {v5, v2}, La/m;->aK(I)V

    invoke-virtual {v5, v1}, La/m;->aL(I)V

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_8
    iget-boolean v0, p0, La/t;->ry:Z

    if-eqz v0, :cond_9

    iget-boolean v0, p0, La/t;->rz:Z

    if-eqz v0, :cond_9

    invoke-virtual {p0}, La/t;->ju()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-virtual {p0}, La/t;->jt()V

    :cond_9
    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0, v3}, La/ac;->S(Z)V

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v0

    invoke-virtual {v0, v3}, La/ac;->S(Z)V

    return-void

    :array_0
    .array-data 4
        -0x1
        -0x1
    .end array-data
.end method

.method public i([I)V
    .locals 0

    iput-object p1, p0, La/t;->qY:[I

    return-void
.end method

.method public jA()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->re:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->re:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->re:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jB()I
    .locals 1

    iget v0, p0, La/t;->rj:I

    return v0
.end method

.method public jC()I
    .locals 1

    iget v0, p0, La/t;->rk:I

    return v0
.end method

.method public jD()I
    .locals 1

    iget v0, p0, La/t;->qV:I

    return v0
.end method

.method public jE()V
    .locals 1

    iget v0, p0, La/t;->qV:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/t;->qV:I

    return-void
.end method

.method public jF()I
    .locals 1

    iget v0, p0, La/t;->qW:I

    return v0
.end method

.method public jG()V
    .locals 1

    iget v0, p0, La/t;->qW:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/t;->qW:I

    return-void
.end method

.method public jH()La/al;
    .locals 1

    iget-object v0, p0, La/t;->qS:La/al;

    return-object v0
.end method

.method public jI()[I
    .locals 1

    iget-object v0, p0, La/t;->rq:[I

    return-object v0
.end method

.method public jJ()[I
    .locals 1

    iget-object v0, p0, La/t;->rs:[I

    return-object v0
.end method

.method public jK()[I
    .locals 1

    iget-object v0, p0, La/t;->rv:[I

    return-object v0
.end method

.method public jL()[I
    .locals 1

    iget-object v0, p0, La/t;->rw:[I

    return-object v0
.end method

.method public jM()[I
    .locals 1

    iget-object v0, p0, La/t;->rx:[I

    return-object v0
.end method

.method public jN()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/m;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->rh:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->rh:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->rh:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jO()La/l;
    .locals 1

    iget-object v0, p0, La/t;->qX:La/l;

    return-object v0
.end method

.method public jP()V
    .locals 4

    const/4 v0, 0x0

    iput v0, p0, La/t;->qV:I

    iput v0, p0, La/t;->qW:I

    :goto_0
    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->cG()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_1

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->gS()La/ac;

    move-result-object v1

    iget-object v3, p0, La/t;->qT:La/ac;

    if-ne v1, v3, :cond_0

    iget v1, p0, La/t;->qV:I

    add-int/2addr v1, v2

    iput v1, p0, La/t;->qV:I

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->gS()La/ac;

    move-result-object v1

    iget-object v3, p0, La/t;->qU:La/ac;

    if-ne v1, v3, :cond_1

    iget v1, p0, La/t;->qW:I

    add-int/2addr v1, v2

    iput v1, p0, La/t;->qW:I

    :cond_1
    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public jQ()Ljava/lang/String;
    .locals 3

    const-string v0, ""

    iget-object v1, p0, La/t;->qS:La/al;

    if-eqz v1, :cond_0

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->getNome()Ljava/lang/String;

    move-result-object v0

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " - "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, La/t;->qQ:La/al;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, La/al;->Z(Z)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public jR()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, La/t;->qV:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " x "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/t;->qW:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public jS()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/t;->qV:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/t;->qW:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public jT()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/t;->qV:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/t;->qW:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->rC:[I

    const/4 v2, 0x0

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->rC:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public jU()Ljava/lang/String;
    .locals 3

    const-string v0, ""

    iget-object v1, p0, La/t;->qS:La/al;

    if-eqz v1, :cond_0

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->getNome()Ljava/lang/String;

    move-result-object v0

    :cond_0
    iget-object v1, p0, La/t;->qS:La/al;

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    if-nez v1, :cond_1

    return-object v0

    :cond_1
    iget-object v1, p0, La/t;->qS:La/al;

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x5

    if-ne v1, v2, :cond_2

    return-object v0

    :cond_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " - "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, La/t;->qQ:La/al;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, La/al;->Z(Z)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public jV()V
    .locals 0

    return-void
.end method

.method public jW()I
    .locals 1

    iget v0, p0, La/t;->rA:I

    return v0
.end method

.method public jX()I
    .locals 1

    iget v0, p0, La/t;->rB:I

    return v0
.end method

.method public jY()I
    .locals 1

    iget v0, p0, La/t;->data:I

    return v0
.end method

.method public jZ()I
    .locals 1

    iget v0, p0, La/t;->renda:I

    return v0
.end method

.method public jb()La/al;
    .locals 1

    iget-object v0, p0, La/t;->qQ:La/al;

    return-object v0
.end method

.method public ji()La/ac;
    .locals 1

    iget-object v0, p0, La/t;->qT:La/ac;

    return-object v0
.end method

.method public jj()La/ac;
    .locals 1

    iget-object v0, p0, La/t;->qU:La/ac;

    return-object v0
.end method

.method public jm()V
    .locals 3

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    const/4 v1, 0x5

    if-eq v0, v1, :cond_0

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v0

    iget v2, p0, La/t;->renda:I

    invoke-virtual {v0, v2, v1}, La/ac;->U(II)V

    :cond_0
    return-void
.end method

.method public jn()V
    .locals 10

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->finHook(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->finScanNT(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->energyMatchTick(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->recordForm(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->bichoCharge(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->pressSet(La/t;)V

    iget-object v8, p0, La/t;->qS:La/al;

    if-eqz v8, :cond_1

    instance-of v9, v8, Ld/sm;

    if-eqz v9, :cond_0

    check-cast v8, Ld/sm;

    invoke-virtual {v8, p0}, Ld/sm;->processMatch(La/t;)V

    goto :goto_0

    :cond_0
    instance-of v9, v8, Ld/q;

    if-eqz v9, :cond_1

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->finishRecopa(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->finishSuperCopas(La/t;)V

    :cond_1
    :goto_0
    sget-object v9, Lc/a;->TF:La/b;

    if-eqz v9, :cond_4

    iget-object v8, p0, La/t;->qS:La/al;

    if-eqz v8, :cond_4

    iget-object v7, v9, La/b;->cssCopa:Ld/css;

    if-eqz v7, :cond_2

    invoke-virtual {v7}, Ld/css;->getFaseGrupos()Ld/q;

    move-result-object v6

    if-ne v6, v8, :cond_2

    invoke-virtual {v7, p0}, Ld/css;->processMatch(La/t;)V

    :cond_2
    iget-object v7, v9, La/b;->cneCopa:Ld/cne;

    if-eqz v7, :cond_3

    invoke-virtual {v7}, Ld/cne;->getFaseGrupos()Ld/q;

    move-result-object v6

    if-ne v6, v8, :cond_3

    invoke-virtual {v7, p0}, Ld/cne;->processMatch(La/t;)V

    :cond_3
    iget-object v7, v9, La/b;->cvCopa:Ld/cv;

    if-eqz v7, :cond_4

    invoke-virtual {v7}, Ld/cv;->getFaseGrupos()Ld/q;

    move-result-object v6

    if-ne v6, v8, :cond_4

    invoke-virtual {v7, p0}, Ld/cv;->processMatch(La/t;)V

    :cond_4
    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v9

    invoke-static {v9}, Lcom/brasfoot/v2028/Recopa;->chemTick(La/ac;)V

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v9

    invoke-static {v9}, Lcom/brasfoot/v2028/Recopa;->chemTick(La/ac;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->recordH2H(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->classicoEnd(La/t;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->selecaoPay(La/t;)V

    iget-object v0, p0, La/t;->qS:La/al;

    if-eqz v0, :cond_5

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    :cond_5
    iget-object v0, p0, La/t;->qT:La/ac;

    invoke-virtual {v0, p0}, La/ac;->f(La/t;)V

    iget-object v0, p0, La/t;->qU:La/ac;

    invoke-virtual {v0, p0}, La/ac;->f(La/t;)V

    iget-object v0, p0, La/t;->qT:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    const/16 v1, 0x8

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v0, :cond_7

    iget-object v0, p0, La/t;->qT:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0, p0}, La/af;->f(La/t;)V

    iget-object v0, p0, La/t;->qS:La/al;

    if-eqz v0, :cond_7

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v7, :cond_6

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v6, :cond_6

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v5, :cond_6

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v4, :cond_6

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v3, :cond_6

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v2, :cond_6

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-ne v0, v1, :cond_7

    :cond_6
    iget-object v0, p0, La/t;->qT:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0, p0}, La/af;->g(La/t;)V

    :cond_7
    iget-object v0, p0, La/t;->qU:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_9

    iget-object v0, p0, La/t;->qU:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0, p0}, La/af;->f(La/t;)V

    iget-object v0, p0, La/t;->qS:La/al;

    if-eqz v0, :cond_9

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v7, :cond_8

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v6, :cond_8

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v5, :cond_8

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v4, :cond_8

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v3, :cond_8

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-eq v0, v2, :cond_8

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-ne v0, v1, :cond_9

    :cond_8
    iget-object v0, p0, La/t;->qU:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0, p0}, La/af;->g(La/t;)V

    :cond_9
    return-void
.end method

.method public jo()La/al;
    .locals 2

    iget-object v0, p0, La/t;->qQ:La/al;

    instance-of v0, v0, Ld/q;

    if-eqz v0, :cond_2

    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/q;

    invoke-virtual {v0}, Ld/q;->xG()La/al;

    move-result-object v0

    instance-of v0, v0, La/y;

    if-nez v0, :cond_1

    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/q;

    invoke-virtual {v0}, Ld/q;->xG()La/al;

    move-result-object v0

    instance-of v0, v0, Ld/m;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/q;

    invoke-virtual {v0}, Ld/q;->xG()La/al;

    move-result-object v0

    return-object v0

    :cond_1
    :goto_0
    iget-object v0, p0, La/t;->qQ:La/al;

    return-object v0

    :cond_2
    iget-object v0, p0, La/t;->qQ:La/al;

    instance-of v0, v0, Ld/x;

    if-eqz v0, :cond_6

    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/x;

    invoke-virtual {v0}, Ld/x;->yx()La/al;

    move-result-object v0

    if-eqz v0, :cond_5

    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/x;

    invoke-virtual {v0}, Ld/x;->yx()La/al;

    move-result-object v0

    instance-of v0, v0, Ld/q;

    if-eqz v0, :cond_5

    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/x;

    invoke-virtual {v0}, Ld/x;->yx()La/al;

    move-result-object v0

    check-cast v0, Ld/q;

    invoke-virtual {v0}, Ld/q;->xG()La/al;

    move-result-object v1

    instance-of v1, v1, La/y;

    if-nez v1, :cond_4

    invoke-virtual {v0}, Ld/q;->xG()La/al;

    move-result-object v1

    instance-of v1, v1, Ld/m;

    if-eqz v1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Ld/q;->xG()La/al;

    move-result-object v0

    return-object v0

    :cond_4
    :goto_1
    iget-object v0, p0, La/t;->qQ:La/al;

    return-object v0

    :cond_5
    iget-object v0, p0, La/t;->qQ:La/al;

    check-cast v0, Ld/x;

    invoke-virtual {v0}, Ld/x;->xG()La/al;

    move-result-object v0

    return-object v0

    :cond_6
    const/4 v0, 0x0

    return-object v0
.end method

.method public jp()V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ge v1, v2, :cond_1

    invoke-virtual {p0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v4, p0, La/t;->qS:La/al;

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, La/p;->c(La/al;La/ac;)Z

    invoke-virtual {p0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, p0, v0, v3}, La/p;->a(La/t;II)V

    iget-object v2, p0, La/t;->rF:[[I

    aget-object v2, v2, v0

    array-length v2, v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/t;->rF:[[I

    aget-object v2, v2, v0

    invoke-virtual {p0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->io()I

    move-result v3

    aput v3, v2, v1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    invoke-virtual {p0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    invoke-virtual {p0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v4, p0, La/t;->qS:La/al;

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, La/p;->c(La/al;La/ac;)Z

    invoke-virtual {p0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, p0, v3, v0}, La/p;->a(La/t;II)V

    iget-object v2, p0, La/t;->rF:[[I

    aget-object v2, v2, v3

    array-length v2, v2

    if-ge v1, v2, :cond_2

    iget-object v2, p0, La/t;->rF:[[I

    aget-object v2, v2, v3

    invoke-virtual {p0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->io()I

    move-result v4

    aput v4, v2, v1

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    const/4 v1, 0x0

    :goto_2
    invoke-virtual {p0}, La/t;->kq()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    invoke-virtual {p0}, La/t;->kq()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v4, p0, La/t;->qS:La/al;

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, La/p;->c(La/al;La/ac;)Z

    invoke-virtual {p0}, La/t;->kq()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, p0, v0, v3}, La/p;->a(La/t;II)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_4
    const/4 v1, 0x0

    :goto_3
    invoke-virtual {p0}, La/t;->kr()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_5

    invoke-virtual {p0}, La/t;->kr()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v4, p0, La/t;->qS:La/al;

    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, La/p;->c(La/al;La/ac;)Z

    invoke-virtual {p0}, La/t;->kr()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, p0, v3, v0}, La/p;->a(La/t;II)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_5
    :goto_4
    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_9

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->gW()La/p;

    move-result-object v1

    if-eqz v1, :cond_8

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->cG()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v3, :cond_6

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->gT()I

    move-result v1

    if-eq v1, v2, :cond_6

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->gW()La/p;

    move-result-object v1

    iget-object v2, p0, La/t;->qS:La/al;

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/m;

    invoke-virtual {v4}, La/m;->gS()La/ac;

    move-result-object v4

    invoke-virtual {v1, v2, v4}, La/p;->a(La/al;La/ac;)Z

    goto :goto_5

    :cond_6
    iget-object v1, p0, La/t;->rh:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->cG()I

    move-result v1

    if-eq v1, v2, :cond_7

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->cG()I

    move-result v1

    const/4 v2, 0x3

    if-eq v1, v2, :cond_7

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->cG()I

    move-result v1

    const/4 v2, 0x4

    if-ne v1, v2, :cond_8

    :cond_7
    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/m;

    invoke-virtual {v1}, La/m;->gW()La/p;

    move-result-object v1

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/m;

    invoke-virtual {v2}, La/m;->cG()I

    move-result v2

    iget-object v4, p0, La/t;->qS:La/al;

    invoke-virtual {p0}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/m;

    invoke-virtual {v5}, La/m;->gS()La/ac;

    move-result-object v5

    invoke-virtual {v1, v2, v4, v5}, La/p;->a(ILa/al;La/ac;)Z

    :cond_8
    :goto_5
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_4

    :cond_9
    return-void
.end method

.method public jq()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/t;->qT:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/t;->qT:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, v0}, La/p;->bh(I)V

    iget-object v2, p0, La/t;->qT:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, La/t;->qS:La/al;

    invoke-virtual {v2, v3}, La/p;->e(La/al;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, La/t;->qT:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, La/t;->qS:La/al;

    invoke-virtual {v2, v3}, La/p;->h(La/al;)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    iget-object v2, p0, La/t;->qU:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, La/t;->qU:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, v0}, La/p;->bh(I)V

    iget-object v2, p0, La/t;->qU:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, La/t;->qS:La/al;

    invoke-virtual {v2, v3}, La/p;->e(La/al;)Z

    move-result v2

    if-eqz v2, :cond_2

    iget-object v2, p0, La/t;->qU:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, La/t;->qS:La/al;

    invoke-virtual {v2, v3}, La/p;->h(La/al;)V

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method public jr()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bk;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->ri:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->ri:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->ri:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jt()V
    .locals 4

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/4 v1, 0x7

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x2

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    invoke-virtual {v2, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    invoke-virtual {p0}, La/t;->ji()La/ac;

    move-result-object v1

    iput-object v1, p0, La/t;->rE:La/ac;

    iget-object v1, p0, La/t;->rC:[I

    aput v0, v1, v2

    iget-object v1, p0, La/t;->rC:[I

    sub-int/2addr v0, v3

    aput v0, v1, v3

    return-void

    :cond_0
    invoke-virtual {p0}, La/t;->jj()La/ac;

    move-result-object v1

    iput-object v1, p0, La/t;->rE:La/ac;

    iget-object v1, p0, La/t;->rC:[I

    aput v0, v1, v2

    iget-object v1, p0, La/t;->rC:[I

    add-int/2addr v0, v3

    aput v0, v1, v3

    return-void
.end method

.method public ju()Z
    .locals 10

    invoke-virtual {p0}, La/t;->jb()La/al;

    move-result-object v0

    check-cast v0, Ld/x;

    invoke-virtual {v0}, Ld/x;->yv()Z

    move-result v0

    invoke-virtual {p0}, La/t;->jD()I

    move-result v1

    invoke-virtual {p0}, La/t;->jF()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-le v1, v2, :cond_0

    const/4 v5, 0x1

    :goto_0
    const/4 v6, 0x0

    goto :goto_1

    :cond_0
    if-le v2, v1, :cond_1

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    goto :goto_0

    :goto_1
    iget-boolean v7, p0, La/t;->rD:Z

    if-eqz v7, :cond_4

    invoke-virtual {p0}, La/t;->jW()I

    move-result v7

    invoke-virtual {p0}, La/t;->jX()I

    move-result v8

    if-le v8, v7, :cond_2

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_2
    if-le v7, v8, :cond_3

    add-int/lit8 v6, v6, 0x1

    :cond_3
    :goto_2
    add-int/2addr v1, v8

    add-int/2addr v7, v2

    goto :goto_3

    :cond_4
    move v7, v2

    const/4 v8, 0x0

    :goto_3
    const/4 v9, 0x2

    if-le v5, v6, :cond_5

    const/4 v5, 0x1

    goto :goto_4

    :cond_5
    if-le v6, v5, :cond_6

    const/4 v5, 0x2

    goto :goto_4

    :cond_6
    const/4 v5, 0x0

    :goto_4
    if-nez v5, :cond_8

    if-le v1, v7, :cond_7

    const/4 v5, 0x1

    goto :goto_5

    :cond_7
    if-le v7, v1, :cond_8

    const/4 v5, 0x2

    :cond_8
    :goto_5
    if-nez v5, :cond_a

    iget-boolean v1, p0, La/t;->rD:Z

    if-eqz v1, :cond_a

    if-eqz v0, :cond_a

    if-le v8, v2, :cond_9

    const/4 v5, 0x1

    goto :goto_6

    :cond_9
    if-le v2, v8, :cond_a

    const/4 v5, 0x2

    :cond_a
    :goto_6
    if-nez v5, :cond_b

    return v4

    :cond_b
    return v3
.end method

.method public jv()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->qZ:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->qZ:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->qZ:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jw()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->ra:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->ra:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->ra:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jx()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->rb:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->rb:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->rb:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jy()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->rc:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->rc:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->rc:Ljava/util/ArrayList;

    return-object v0
.end method

.method public jz()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->rd:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->rd:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->rd:Ljava/util/ArrayList;

    return-object v0
.end method

.method public ka()Z
    .locals 1

    iget-boolean v0, p0, La/t;->rD:Z

    return v0
.end method

.method public kb()Z
    .locals 1

    iget-boolean v0, p0, La/t;->rz:Z

    return v0
.end method

.method public kc()[I
    .locals 1

    iget-object v0, p0, La/t;->rC:[I

    return-object v0
.end method

.method public kd()La/ac;
    .locals 1

    iget-object v0, p0, La/t;->rE:La/ac;

    return-object v0
.end method

.method public ke()Z
    .locals 1

    iget-boolean v0, p0, La/t;->ry:Z

    return v0
.end method

.method public kf()[I
    .locals 1

    iget-object v0, p0, La/t;->qY:[I

    return-object v0
.end method

.method public kg()I
    .locals 3

    iget-object v0, p0, La/t;->qY:[I

    const/4 v1, 0x0

    aget v0, v0, v1

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    add-int/2addr v0, v1

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x2

    aget v1, v1, v2

    add-int/2addr v0, v1

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x3

    aget v1, v1, v2

    add-int/2addr v0, v1

    return v0
.end method

.method public kh()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, La/t;->kg()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " (G:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x0

    aget v1, v1, v2

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ",A:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ",Cd:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x2

    aget v1, v1, v2

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ",Cm:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/t;->qY:[I

    const/4 v2, 0x3

    aget v1, v1, v2

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ki()Lcomponents/cn;
    .locals 1

    iget-object v0, p0, La/t;->rI:Lcomponents/cn;

    return-object v0
.end method

.method public kj()Z
    .locals 2

    iget-object v0, p0, La/t;->qS:La/al;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x5

    if-eq v0, v1, :cond_1

    :cond_0
    iget-object v0, p0, La/t;->qS:La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x7

    if-ne v0, v1, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public kk()[I
    .locals 1

    iget-object v0, p0, La/t;->rr:[I

    return-object v0
.end method

.method public kl()[I
    .locals 1

    iget-object v0, p0, La/t;->rt:[I

    return-object v0
.end method

.method public km()[I
    .locals 1

    iget-object v0, p0, La/t;->ru:[I

    return-object v0
.end method

.method public kn()[I
    .locals 1

    iget-object v0, p0, La/t;->rl:[I

    return-object v0
.end method

.method public ko()Z
    .locals 6

    iget-object v0, p0, La/t;->qT:La/ac;

    iget-object v1, p0, La/t;->qU:La/ac;

    invoke-static {v0, v1}, Lcom/brasfoot/v2028/Recopa;->isExtraClassico(La/ac;La/ac;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, La/ak;->yY:[[I

    array-length v3, v3

    if-ge v1, v3, :cond_3

    iget-object v3, p0, La/t;->qT:La/ac;

    invoke-virtual {v3}, La/ac;->lK()I

    move-result v3

    sget-object v4, La/ak;->yY:[[I

    aget-object v4, v4, v1

    aget v4, v4, v0

    const/4 v5, 0x1

    if-ne v3, v4, :cond_1

    iget-object v3, p0, La/t;->qU:La/ac;

    invoke-virtual {v3}, La/ac;->lK()I

    move-result v3

    sget-object v4, La/ak;->yY:[[I

    aget-object v4, v4, v1

    aget v4, v4, v5

    if-ne v3, v4, :cond_1

    const/4 v2, 0x1

    :cond_1
    iget-object v3, p0, La/t;->qU:La/ac;

    invoke-virtual {v3}, La/ac;->lK()I

    move-result v3

    sget-object v4, La/ak;->yY:[[I

    aget-object v4, v4, v1

    aget v4, v4, v0

    if-ne v3, v4, :cond_2

    iget-object v3, p0, La/t;->qT:La/ac;

    invoke-virtual {v3}, La/ac;->lK()I

    move-result v3

    sget-object v4, La/ak;->yY:[[I

    aget-object v4, v4, v1

    aget v4, v4, v5

    if-ne v3, v4, :cond_2

    const/4 v2, 0x1

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return v2
.end method

.method public kp()[[I
    .locals 1

    iget-object v0, p0, La/t;->rF:[[I

    return-object v0
.end method

.method public kq()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->rf:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->rf:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->rf:Ljava/util/ArrayList;

    return-object v0
.end method

.method public kr()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/t;->rg:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/t;->rg:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/t;->rg:Ljava/util/ArrayList;

    return-object v0
.end method

.method public l(La/al;)V
    .locals 0

    iput-object p1, p0, La/t;->qQ:La/al;

    return-void
.end method

.method public markFin()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, La/t;->finFlag:Z

    return-void
.end method

.method public r(La/ac;)V
    .locals 0

    iput-object p1, p0, La/t;->qT:La/ac;

    return-void
.end method

.method public s(La/ac;)V
    .locals 0

    iput-object p1, p0, La/t;->qU:La/ac;

    return-void
.end method

.method public setComp(La/al;)V
    .locals 0

    iput-object p1, p0, La/t;->qS:La/al;

    return-void
.end method

.method public t(La/ac;)V
    .locals 0

    iput-object p1, p0, La/t;->rE:La/ac;

    return-void
.end method
