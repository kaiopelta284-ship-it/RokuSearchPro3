.class public La/o;
.super Ljava/lang/Object;


# static fields
.field public static nE:Z = false

.field public static pQ:Landroid/content/Context; = null

.field public static pR:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field public static pS:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field public static pT:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/be;",
            ">;"
        }
    .end annotation
.end field

.field public static pU:La/af; = null

.field private static pa:I = -0x1

.field private static pb:I = -0x1

.field private static pc:La/al;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static aF(I)V
    .locals 0

    sput p0, La/o;->pa:I

    return-void
.end method

.method public static aG(I)V
    .locals 0

    sput p0, La/o;->pb:I

    return-void
.end method

.method public static d(La/al;)V
    .locals 0

    sput-object p0, La/o;->pc:La/al;

    return-void
.end method

.method public static e(Landroid/content/Context;)V
    .locals 0

    sput-object p0, La/o;->pQ:Landroid/content/Context;

    return-void
.end method

.method public static gG()V
    .locals 4

    invoke-static {}, La/i;->gH()I

    move-result v0

    if-ltz v0, :cond_0

    const/4 v1, 0x0

    sput v1, Lcom/brasfoot/v2028/ActivityJogo;->Jq:I

    const/4 v2, 0x1

    sput v2, Lcom/brasfoot/v2028/ActivityJogo;->Jr:I

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityJogo;->Jt:Z

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    sput-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-static {}, La/i;->gw()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bt;

    invoke-virtual {v2, v1}, Lcomponents/bt;->as(Z)V

    new-instance v1, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lcom/brasfoot/v2028/ActivityJogo;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const-string v3, "index"

    invoke-virtual {v2, v3, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {v1, v2}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    :cond_1
    invoke-static {}, La/o;->hw()V

    return-void
.end method

.method public static gI()I
    .locals 1

    sget v0, La/o;->pa:I

    return v0
.end method

.method public static gJ()I
    .locals 1

    sget v0, La/o;->pb:I

    return v0
.end method

.method public static gK()La/al;
    .locals 1

    sget-object v0, La/o;->pc:La/al;

    return-object v0
.end method

.method public static getContext()Landroid/content/Context;
    .locals 1

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    return-object v0
.end method

.method public static hA()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    sget-object v0, La/o;->pS:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static hs()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    sget-object v0, La/o;->pR:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static ht()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/be;",
            ">;"
        }
    .end annotation

    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static hu()V
    .locals 1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fb()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, La/o;->hv()V

    return-void

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dp()V

    return-void
.end method

.method public static hv()V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/b;->r(Z)V

    sput-boolean v1, La/o;->nE:Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dH()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eB()La/t;

    move-result-object v0

    if-eqz v0, :cond_0

    new-instance v0, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lcom/brasfoot/v2028/ActivityMainTeam;

    invoke-direct {v0, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isIgnoraLigas()Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dD()I

    move-result v0

    if-ne v0, v2, :cond_1

    invoke-static {}, La/i;->gD()Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eP()Z

    move-result v0

    if-nez v0, :cond_1

    sput-boolean v2, La/o;->nE:Z

    :cond_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eP()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->n(Z)V

    :cond_2
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isIgnoraEstadual()Z

    move-result v0

    if-eqz v0, :cond_3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dD()I

    move-result v0

    const/4 v3, 0x3

    if-ne v0, v3, :cond_3

    invoke-static {}, La/i;->gE()Z

    move-result v0

    if-nez v0, :cond_3

    sput-boolean v2, La/o;->nE:Z

    :cond_3
    invoke-static {}, La/ac;->lG()V

    invoke-static {}, La/t;->jk()V

    sget-object v0, Lc/a;->TF:La/b;

    iget-boolean v0, v0, La/b;->nt:Z

    if-eqz v0, :cond_4

    sget-boolean v0, La/o;->nE:Z

    if-nez v0, :cond_4

    invoke-static {}, La/i;->gx()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, La/i;->gy()V

    invoke-static {}, La/o;->gG()V

    goto :goto_0

    :cond_4
    invoke-static {}, La/o;->hw()V

    :goto_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eQ()Z

    move-result v0

    if-eqz v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->p(Z)V

    :cond_5
    return-void
.end method

.method public static hw()V
    .locals 3

    :try_start_0
    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->play()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    invoke-static {}, La/t;->jl()V

    invoke-static {}, La/b;->dC()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ec()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dL()V

    const/4 v0, 0x0

    sput-object v0, La/o;->pS:Ljava/util/ArrayList;

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/b;->aj(I)V

    sget-object v0, Lc/a;->TF:La/b;

    iget-boolean v0, v0, La/b;->nt:Z

    if-eqz v0, :cond_0

    sget-boolean v0, La/o;->nE:Z

    if-nez v0, :cond_0

    new-instance v0, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/brasfoot/v2028/ActivityResults;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    invoke-static {}, La/o;->hx()V

    return-void

    :catchall_0
    move-exception v0

    goto :goto_0
.end method

.method public static hx()V
    .locals 5

    const/4 v0, 0x0

    sput-object v0, La/o;->pR:Ljava/util/ArrayList;

    sput-object v0, La/o;->pU:La/af;

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cO()I

    move-result v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dK()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_1

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4, v0, v1}, La/b;->c(IZ)Ljava/util/ArrayList;

    move-result-object v4

    sput-object v4, La/o;->pR:Ljava/util/ArrayList;

    :cond_1
    if-nez v1, :cond_3

    if-eq v0, v3, :cond_2

    const/4 v3, 0x3

    if-ne v0, v3, :cond_3

    :cond_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3, v0, v1}, La/b;->c(IZ)Ljava/util/ArrayList;

    move-result-object v0

    sput-object v0, La/o;->pR:Ljava/util/ArrayList;

    :cond_3
    sget-object v0, La/o;->pS:Ljava/util/ArrayList;

    if-eqz v0, :cond_6

    sget-object v0, La/o;->pS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_6

    :goto_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v2, v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    invoke-virtual {v0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    sput-object v0, La/o;->pU:La/af;

    goto :goto_2

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_5
    :goto_2
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/brasfoot/v2028/ActivityConviteSelecao;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :goto_3
    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_6
    sget-object v0, La/o;->pR:Ljava/util/ArrayList;

    if-eqz v0, :cond_9

    sget-object v0, La/o;->pR:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_9

    :goto_4
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v2, v0, :cond_8

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    invoke-virtual {v0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_7

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    sput-object v0, La/o;->pU:La/af;

    goto :goto_5

    :cond_7
    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_8
    :goto_5
    new-instance v0, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/brasfoot/v2028/ActivityConvite;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_3

    :cond_9
    invoke-static {}, La/o;->hy()V

    return-void
.end method

.method public static hy()V
    .locals 5

    const/4 v0, 0x0

    sput-object v0, La/o;->pT:Ljava/util/ArrayList;

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cO()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    const/4 v2, 0x3

    if-ne v0, v2, :cond_1

    :cond_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2, v0}, La/b;->ag(I)Ljava/util/ArrayList;

    move-result-object v0

    sput-object v0, La/o;->pT:Ljava/util/ArrayList;

    :cond_1
    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    const/4 v2, 0x0

    if-eqz v0, :cond_5

    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_5

    const/4 v0, 0x0

    const/4 v3, 0x0

    :goto_0
    sget-object v4, La/o;->pT:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v0, v4, :cond_3

    sget-object v4, La/o;->pT:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/be;

    invoke-virtual {v4}, Lcomponents/be;->tL()La/af;

    move-result-object v4

    if-eqz v4, :cond_2

    sget-object v4, La/o;->pT:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/be;

    invoke-virtual {v4}, Lcomponents/be;->tL()La/af;

    move-result-object v4

    invoke-virtual {v4}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_2

    const/4 v3, 0x1

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    sget-object v0, Lc/a;->TF:La/b;

    iget-boolean v0, v0, La/b;->nt:Z

    if-eqz v0, :cond_4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->getVerMudancaTecnicos()I

    move-result v0

    if-ne v0, v1, :cond_4

    const/4 v2, 0x1

    :cond_4
    if-eqz v3, :cond_5

    const/4 v2, 0x1

    :cond_5
    if-eqz v2, :cond_6

    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    if-eqz v0, :cond_6

    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_6

    new-instance v0, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/brasfoot/v2028/DialogDemissoes;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_6
    invoke-static {}, La/o;->hz()V

    return-void
.end method

.method public static hz()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dJ()I

    move-result v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_0

    :try_start_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dE()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x64

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    const/16 v2, 0x32

    if-le v1, v2, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dF()V

    :cond_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    :try_start_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dG()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_2
    sget-object v1, Lc/a;->TF:La/b;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, La/b;->aj(I)V

    if-nez v0, :cond_3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v2}, La/b;->t(Z)V

    invoke-virtual {v0}, La/b;->gerarBolaDeOuro()V

    new-instance v1, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v2

    const-class v0, Lcom/brasfoot/v2028/ActivityBolaDeOuro;

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v2, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_3
    sget-object v0, Lc/a;->TF:La/b;

    iget-boolean v0, v0, La/b;->nt:Z

    if-eqz v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fb()Z

    move-result v0

    if-eqz v0, :cond_4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dA()V

    new-instance v0, Landroid/content/Intent;

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/brasfoot/v2028/ActivityFimAno;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {}, La/o;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_4
    invoke-static {}, La/o;->hv()V

    return-void

    :cond_5
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fb()Z

    move-result v0

    if-eqz v0, :cond_6

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dA()V

    :cond_6
    return-void
.end method

.method public static n(Ljava/lang/String;)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    move-object v1, v3

    :goto_1
    const/4 v2, 0x0

    :goto_2
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    move-object v3, p0

    check-cast v3, La/ac;

    goto :goto_3

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    :goto_3
    if-eqz v1, :cond_4

    if-eqz v3, :cond_4

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    invoke-virtual {v1, p0}, La/ac;->j(Ljava/lang/Boolean;)V

    invoke-virtual {v1}, La/ac;->lz()La/af;

    move-result-object p0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p0, v0}, La/af;->j(Ljava/lang/Boolean;)V

    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v3, v0}, La/ac;->j(Ljava/lang/Boolean;)V

    invoke-virtual {v3}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    invoke-virtual {v0, p0}, La/af;->j(Ljava/lang/Boolean;)V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {v3}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    return-void
.end method
