.class public La/l;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private pq:Ljava/lang/String;

.field private pr:[I

.field private ps:[I

.field private pt:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    iput-object v1, p0, La/l;->pr:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    iput-object v0, p0, La/l;->ps:[I

    const/4 v0, 0x1

    iput-boolean v0, p0, La/l;->pt:Z

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x14
        0x23
        0x37
        0x50
    .end array-data
.end method

.method public constructor <init>(Ljava/lang/String;ILa/ac;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    iput-object v1, p0, La/l;->pr:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_1

    iput-object v1, p0, La/l;->ps:[I

    const/4 v1, 0x1

    iput-boolean v1, p0, La/l;->pt:Z

    iput-object p1, p0, La/l;->pq:Ljava/lang/String;

    invoke-direct {p0, p2}, La/l;->aI(I)V

    if-eqz p3, :cond_2

    invoke-virtual {p3}, La/ac;->getDivisao()I

    move-result p1

    if-ltz p1, :cond_0

    if-le p1, v0, :cond_1

    :cond_0
    const/4 p1, 0x3

    :cond_1
    sget-object p2, La/ak;->zF:[[[I

    aget-object p2, p2, v1

    aget-object p1, p2, p1

    iput-object p1, p0, La/l;->ps:[I

    :cond_2
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x14
        0x23
        0x37
        0x50
    .end array-data
.end method

.method public static a(ILa/ac;)[I
    .locals 6

    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    invoke-virtual {p1}, La/ac;->iw()I

    move-result v2

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v3

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result p1

    const/4 v4, 0x1

    if-le v2, v4, :cond_0

    const/4 v2, 0x1

    :cond_0
    if-ne p0, v4, :cond_1

    sget-object p1, La/ak;->zF:[[[I

    aget-object p0, p1, p0

    aget-object v1, p0, v3

    return-object v1

    :cond_1
    const/4 v5, 0x2

    if-eq p0, v5, :cond_6

    const/4 v5, 0x3

    if-ne p0, v5, :cond_2

    goto :goto_1

    :cond_2
    if-eq p0, v0, :cond_5

    const/4 p1, 0x6

    if-eq p0, p1, :cond_5

    const/16 p1, 0x8

    if-ne p0, p1, :cond_3

    goto :goto_0

    :cond_3
    const/4 p1, 0x5

    if-eq p0, p1, :cond_4

    const/4 p1, 0x7

    if-ne p0, p1, :cond_7

    :cond_4
    sget-object p0, La/ak;->zF:[[[I

    aget-object p0, p0, v4

    aget-object v1, p0, v3

    return-object v1

    :cond_5
    :goto_0
    sget-object p1, La/ak;->zF:[[[I

    aget-object p0, p1, p0

    aget-object v1, p0, v2

    return-object v1

    :cond_6
    :goto_1
    sget-object v0, La/ak;->zF:[[[I

    aget-object p0, v0, p0

    aget-object v1, p0, p1

    :cond_7
    return-object v1

    nop

    :array_0
    .array-data 4
        0xa
        0x19
        0x23
        0x32
    .end array-data
.end method

.method private aI(I)V
    .locals 10

    const/16 v0, 0x3e8

    if-lt p1, v0, :cond_0

    const v0, 0x1d4c0

    if-le p1, v0, :cond_1

    :cond_0
    const/16 p1, 0x2710

    :cond_1
    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    new-array v0, v0, [D

    fill-array-data v0, :array_1

    iget-object v2, p0, La/l;->pr:[I

    int-to-double v3, p1

    const/4 v5, 0x0

    aget-wide v6, v0, v5

    mul-double v6, v6, v3

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v6

    long-to-int v6, v6

    aput v6, v2, v5

    iget-object v2, p0, La/l;->pr:[I

    const/4 v6, 0x2

    aget-wide v7, v0, v6

    mul-double v7, v7, v3

    invoke-static {v7, v8}, Ljava/lang/Math;->round(D)J

    move-result-wide v7

    long-to-int v7, v7

    aput v7, v2, v6

    iget-object v2, p0, La/l;->pr:[I

    const/4 v7, 0x3

    aget-wide v8, v0, v7

    mul-double v3, v3, v8

    invoke-static {v3, v4}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    long-to-int v0, v3

    aput v0, v2, v7

    iget-object v0, p0, La/l;->pr:[I

    iget-object v2, p0, La/l;->pr:[I

    aget v2, v2, v5

    iget-object v3, p0, La/l;->pr:[I

    aget v3, v3, v6

    add-int/2addr v2, v3

    iget-object v3, p0, La/l;->pr:[I

    aget v3, v3, v7

    add-int/2addr v2, v3

    sub-int/2addr p1, v2

    const/4 v2, 0x1

    aput p1, v0, v2

    iget-object p1, p0, La/l;->pr:[I

    aget p1, p1, v5

    aget v0, v1, v5

    if-le p1, v0, :cond_2

    iget-object p1, p0, La/l;->pr:[I

    aget v0, v1, v5

    aput v0, p1, v5

    :cond_2
    iget-object p1, p0, La/l;->pr:[I

    aget p1, p1, v2

    aget v0, v1, v2

    if-le p1, v0, :cond_3

    iget-object p1, p0, La/l;->pr:[I

    aget v0, v1, v2

    aput v0, p1, v2

    :cond_3
    iget-object p1, p0, La/l;->pr:[I

    aget p1, p1, v6

    aget v0, v1, v6

    if-le p1, v0, :cond_4

    iget-object p1, p0, La/l;->pr:[I

    aget v0, v1, v6

    aput v0, p1, v6

    :cond_4
    iget-object p1, p0, La/l;->pr:[I

    aget p1, p1, v7

    aget v0, v1, v7

    if-le p1, v0, :cond_5

    iget-object p1, p0, La/l;->pr:[I

    aget v0, v1, v7

    aput v0, p1, v7

    :cond_5
    return-void

    :array_0
    .array-data 4
        0x4650
        0x13880
        0x2328
        0x2bc
    .end array-data

    :array_1
    .array-data 8
        0x3fc3333333333333L    # 0.15
        0x3fe8000000000000L    # 0.75
        0x3fb70a3d70a3d70aL    # 0.09
        0x3f826e978d4fdf3bL    # 0.009
    .end array-data
.end method

.method public static c(La/t;)V
    .locals 1

    invoke-virtual {p0}, La/t;->jO()La/l;

    move-result-object v0

    invoke-virtual {v0, p0}, La/l;->b(La/t;)V

    return-void
.end method


# virtual methods
.method public E(Z)V
    .locals 0

    iput-boolean p1, p0, La/l;->pt:Z

    return-void
.end method

.method public I(II)V
    .locals 2

    iget-object v0, p0, La/l;->pr:[I

    array-length v0, v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, La/l;->pr:[I

    iget-object v1, p0, La/l;->pr:[I

    aget v1, v1, p1

    add-int/2addr v1, p2

    aput v1, v0, p1

    :cond_0
    return-void
.end method

.method public a([I)V
    .locals 0

    iput-object p1, p0, La/l;->pr:[I

    return-void
.end method

.method public b(La/t;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, La/l;->pr:[I

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v2, :cond_2

    iget-object v2, v0, La/l;->pr:[I

    array-length v2, v2

    if-eq v2, v4, :cond_0

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    :goto_0
    iget-object v5, v0, La/l;->pr:[I

    array-length v5, v5

    if-ge v2, v5, :cond_3

    iget-object v5, v0, La/l;->pr:[I

    aget v5, v5, v2

    if-gez v5, :cond_1

    iget-object v5, v0, La/l;->pr:[I

    aput v3, v5, v2

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    new-array v2, v4, [I

    fill-array-data v2, :array_0

    iput-object v2, v0, La/l;->pr:[I

    :cond_3
    new-array v2, v4, [I

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v2

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    new-array v5, v4, [I

    new-array v6, v4, [I

    const/4 v7, 0x0

    :goto_2
    array-length v8, v6

    if-ge v7, v8, :cond_4

    iget-object v8, v0, La/l;->pr:[I

    aget v8, v8, v7

    aput v8, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_4
    const/4 v6, 0x6

    new-array v7, v6, [[I

    new-array v8, v4, [I

    fill-array-data v8, :array_1

    aput-object v8, v7, v3

    new-array v8, v4, [I

    fill-array-data v8, :array_2

    const/4 v9, 0x1

    aput-object v8, v7, v9

    new-array v8, v4, [I

    fill-array-data v8, :array_3

    const/4 v10, 0x2

    aput-object v8, v7, v10

    new-array v8, v4, [I

    fill-array-data v8, :array_4

    const/4 v11, 0x3

    aput-object v8, v7, v11

    new-array v8, v4, [I

    fill-array-data v8, :array_5

    aput-object v8, v7, v4

    new-array v8, v4, [I

    fill-array-data v8, :array_6

    const/4 v12, 0x5

    aput-object v8, v7, v12

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getDivisao()I

    move-result v8

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v13

    invoke-virtual {v13}, La/ac;->getReputacao()I

    move-result v13

    if-ltz v13, :cond_5

    if-le v13, v12, :cond_6

    :cond_5
    const/4 v13, 0x3

    :cond_6
    const/4 v14, 0x0

    :goto_3
    array-length v15, v5

    if-ge v14, v15, :cond_7

    aget-object v15, v7, v13

    aget v15, v15, v14

    aput v15, v5, v14

    add-int/lit8 v14, v14, 0x1

    goto :goto_3

    :cond_7
    if-ne v2, v11, :cond_8

    const/4 v7, 0x0

    :goto_4
    array-length v13, v5

    if-ge v7, v13, :cond_8

    aget v13, v5, v7

    int-to-double v13, v13

    const-wide v15, 0x3fe6666666666666L    # 0.7

    mul-double v13, v13, v15

    invoke-static {v13, v14}, Ljava/lang/Math;->round(D)J

    move-result-wide v13

    long-to-int v13, v13

    aput v13, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_8
    if-nez v2, :cond_9

    const/4 v7, 0x0

    :goto_5
    array-length v13, v5

    if-ge v7, v13, :cond_9

    aget v13, v5, v7

    int-to-double v13, v13

    const-wide v15, 0x3fd999999999999aL    # 0.4

    mul-double v13, v13, v15

    invoke-static {v13, v14}, Ljava/lang/Math;->round(D)J

    move-result-wide v13

    long-to-int v13, v13

    aput v13, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :cond_9
    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v7

    instance-of v7, v7, Ld/x;

    const-wide v13, 0x3fd3333333333333L    # 0.3

    if-eqz v7, :cond_a

    const-wide v15, 0x3fdcccccccccccccL    # 0.44999999999999996

    goto :goto_6

    :cond_a
    move-wide v15, v13

    :goto_6
    const/16 v7, 0x8

    if-ne v2, v4, :cond_b

    :goto_7
    add-double/2addr v15, v13

    goto :goto_8

    :cond_b
    if-eq v2, v6, :cond_c

    if-ne v2, v7, :cond_d

    :cond_c
    const-wide v13, 0x3fc3333333333333L    # 0.15

    goto :goto_7

    :cond_d
    :goto_8
    const/4 v13, 0x0

    :goto_9
    array-length v14, v5

    if-ge v13, v14, :cond_e

    aget v14, v5, v13

    iget-object v7, v0, La/l;->pr:[I

    aget v7, v7, v13

    int-to-double v11, v7

    mul-double v11, v11, v15

    invoke-static {v11, v12}, Ljava/lang/Math;->round(D)J

    move-result-wide v11

    long-to-int v7, v11

    add-int/2addr v14, v7

    aput v14, v5, v13

    add-int/lit8 v13, v13, 0x1

    const/16 v7, 0x8

    const/4 v11, 0x3

    const/4 v12, 0x5

    goto :goto_9

    :cond_e
    const-wide/16 v11, 0x0

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v7

    invoke-virtual {v7}, La/ac;->getReputacao()I

    move-result v7

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v13

    invoke-virtual {v13}, La/ac;->getReputacao()I

    move-result v13

    sub-int/2addr v7, v13

    new-array v13, v6, [D

    fill-array-data v13, :array_7

    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v14

    aget-wide v14, v13, v14

    add-double/2addr v14, v11

    if-lez v7, :cond_f

    const/4 v7, 0x0

    :goto_a
    array-length v11, v5

    if-ge v7, v11, :cond_10

    aget v11, v5, v7

    aget v12, v5, v7

    int-to-double v12, v12

    mul-double v12, v12, v14

    invoke-static {v12, v13}, Ljava/lang/Math;->round(D)J

    move-result-wide v12

    long-to-int v12, v12

    add-int/2addr v11, v12

    aput v11, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_a

    :cond_f
    if-gez v7, :cond_10

    const/4 v7, 0x0

    :goto_b
    array-length v11, v5

    if-ge v7, v11, :cond_10

    aget v11, v5, v7

    aget v12, v5, v7

    int-to-double v12, v12

    mul-double v12, v12, v14

    invoke-static {v12, v13}, Ljava/lang/Math;->round(D)J

    move-result-wide v12

    long-to-int v12, v12

    sub-int/2addr v11, v12

    aput v11, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_b

    :cond_10
    const/16 v7, 0x50

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v11

    invoke-virtual {v11}, La/ac;->lz()La/af;

    move-result-object v11

    if-eqz v11, :cond_11

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v7

    invoke-virtual {v7}, La/ac;->lz()La/af;

    move-result-object v7

    invoke-virtual {v7}, La/af;->nb()I

    move-result v7

    :cond_11
    int-to-double v11, v7

    const-wide/high16 v13, 0x4059000000000000L    # 100.0

    div-double/2addr v11, v13

    const/4 v7, 0x0

    :goto_c
    array-length v13, v5

    if-ge v7, v13, :cond_12

    aget v13, v5, v7

    int-to-double v13, v13

    mul-double v13, v13, v11

    invoke-static {v13, v14}, Ljava/lang/Math;->round(D)J

    move-result-wide v13

    long-to-int v13, v13

    aput v13, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_c

    :cond_12
    new-array v7, v6, [[I

    new-array v11, v4, [I

    fill-array-data v11, :array_8

    aput-object v11, v7, v3

    new-array v11, v4, [I

    fill-array-data v11, :array_9

    aput-object v11, v7, v9

    new-array v11, v4, [I

    fill-array-data v11, :array_a

    aput-object v11, v7, v10

    new-array v11, v4, [I

    fill-array-data v11, :array_b

    const/4 v12, 0x3

    aput-object v11, v7, v12

    new-array v11, v4, [I

    fill-array-data v11, :array_c

    aput-object v11, v7, v4

    new-array v11, v4, [I

    fill-array-data v11, :array_d

    const/4 v12, 0x5

    aput-object v11, v7, v12

    if-ltz v8, :cond_13

    if-le v8, v4, :cond_14

    :cond_13
    const/4 v8, 0x3

    :cond_14
    const/4 v11, 0x0

    :goto_d
    array-length v12, v5

    if-ge v11, v12, :cond_16

    aget-object v12, v7, v8

    aget v12, v12, v11

    if-lez v12, :cond_15

    aget v13, v5, v11

    new-instance v14, Ljava/util/Random;

    invoke-direct {v14}, Ljava/util/Random;-><init>()V

    invoke-virtual {v14, v12}, Ljava/util/Random;->nextInt(I)I

    move-result v12

    add-int/2addr v13, v12

    aput v13, v5, v11

    :cond_15
    add-int/lit8 v11, v11, 0x1

    goto :goto_d

    :cond_16
    new-array v7, v4, [I

    iget-object v7, v0, La/l;->ps:[I

    if-eqz v7, :cond_17

    iget-object v7, v0, La/l;->ps:[I

    array-length v7, v7

    if-eq v7, v4, :cond_18

    :cond_17
    new-array v7, v4, [I

    fill-array-data v7, :array_e

    :cond_18
    new-array v7, v4, [I

    fill-array-data v7, :array_f

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->iw()I

    move-result v8

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v11

    invoke-virtual {v11}, La/ac;->getDivisao()I

    move-result v11

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v12

    invoke-virtual {v12}, La/ac;->getReputacao()I

    move-result v12

    if-le v8, v9, :cond_19

    const/4 v8, 0x1

    :cond_19
    if-ltz v11, :cond_1a

    if-le v11, v4, :cond_1b

    :cond_1a
    const/4 v11, 0x3

    :cond_1b
    if-ltz v12, :cond_1c

    const/4 v13, 0x5

    if-le v12, v13, :cond_1d

    :cond_1c
    const/4 v12, 0x0

    :cond_1d
    if-ne v2, v9, :cond_1e

    sget-object v4, La/ak;->zF:[[[I

    aget-object v2, v4, v2

    aget-object v7, v2, v11

    goto :goto_10

    :cond_1e
    if-eq v2, v10, :cond_23

    const/4 v10, 0x3

    if-ne v2, v10, :cond_1f

    goto :goto_f

    :cond_1f
    if-eq v2, v4, :cond_22

    if-eq v2, v6, :cond_22

    const/16 v4, 0x8

    if-ne v2, v4, :cond_20

    goto :goto_e

    :cond_20
    const/4 v4, 0x5

    if-eq v2, v4, :cond_21

    const/4 v4, 0x7

    if-ne v2, v4, :cond_24

    :cond_21
    sget-object v2, La/ak;->zF:[[[I

    aget-object v2, v2, v9

    aget-object v7, v2, v11

    goto :goto_10

    :cond_22
    :goto_e
    sget-object v4, La/ak;->zF:[[[I

    aget-object v2, v4, v2

    aget-object v7, v2, v8

    goto :goto_10

    :cond_23
    :goto_f
    sget-object v4, La/ak;->zF:[[[I

    aget-object v2, v4, v2

    aget-object v7, v2, v12

    :cond_24
    :goto_10
    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_11
    array-length v6, v5

    if-ge v2, v6, :cond_27

    aget v6, v5, v2

    if-gez v6, :cond_25

    aput v3, v5, v2

    :cond_25
    aget v6, v5, v2

    iget-object v8, v0, La/l;->pr:[I

    aget v8, v8, v2

    if-le v6, v8, :cond_26

    iget-object v6, v0, La/l;->pr:[I

    aget v6, v6, v2

    aput v6, v5, v2

    :cond_26
    aget v6, v5, v2

    aget v8, v7, v2

    mul-int v6, v6, v8

    add-int/2addr v4, v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    :cond_27
    iget-object v2, v0, La/l;->pr:[I

    invoke-static {v1, v5, v2, v7, v4}, Lcom/brasfoot/v2028/Recopa;->ticketAdjust(La/t;[I[I[II)I

    move-result v4

    invoke-virtual {v1, v5}, La/t;->i([I)V

    invoke-virtual {v1, v4}, La/t;->bA(I)V

    return-void

    nop

    :array_0
    .array-data 4
        0x3e8
        0x7530
        0x3e8
        0x3e8
    .end array-data

    :array_1
    .array-data 4
        0xc8
        0x1f4
        0x32
        0x0
    .end array-data

    :array_2
    .array-data 4
        0x3e8
        0x1388
        0x4b0
        0x14
    .end array-data

    :array_3
    .array-data 4
        0x7d0
        0x2710
        0x5dc
        0x32
    .end array-data

    :array_4
    .array-data 4
        0xfa0
        0x4e20
        0x9c4
        0x12c
    .end array-data

    :array_5
    .array-data 4
        0x1194
        0x7530
        0xdac
        0x190
    .end array-data

    :array_6
    .array-data 4
        0x1388
        0x9c40
        0x157c
        0x1f4
    .end array-data

    :array_7
    .array-data 8
        0x0
        0x3fa999999999999aL    # 0.05
        0x3fb999999999999aL    # 0.1
        0x3fc3333333333333L    # 0.15
        0x3fc999999999999aL    # 0.2
        0x3fd0000000000000L    # 0.25
    .end array-data

    :array_8
    .array-data 4
        0xa
        0x14
        0x5
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x64
        0x1f4
        0xc8
        0xa
    .end array-data

    :array_a
    .array-data 4
        0x12c
        0x3e8
        0x190
        0x14
    .end array-data

    :array_b
    .array-data 4
        0x190
        0x4b0
        0x1f4
        0x1e
    .end array-data

    :array_c
    .array-data 4
        0x1f4
        0x5dc
        0x3e8
        0x32
    .end array-data

    :array_d
    .array-data 4
        0x1f4
        0x5dc
        0x3e8
        0x32
    .end array-data

    :array_e
    .array-data 4
        0x14
        0x23
        0x37
        0x50
    .end array-data

    :array_f
    .array-data 4
        0xa
        0x19
        0x23
        0x32
    .end array-data
.end method

.method public b([I)V
    .locals 0

    iput-object p1, p0, La/l;->ps:[I

    return-void
.end method

.method public gN()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/l;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public gO()[I
    .locals 1

    iget-object v0, p0, La/l;->pr:[I

    return-object v0
.end method

.method public gP()[I
    .locals 1

    iget-object v0, p0, La/l;->ps:[I

    return-object v0
.end method

.method public gQ()Z
    .locals 1

    iget-boolean v0, p0, La/l;->pt:Z

    return v0
.end method

.method public gR()I
    .locals 3

    iget-object v0, p0, La/l;->pr:[I

    const/4 v1, 0x0

    aget v0, v0, v1

    iget-object v1, p0, La/l;->pr:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    add-int/2addr v0, v1

    iget-object v1, p0, La/l;->pr:[I

    const/4 v2, 0x2

    aget v1, v1, v2

    add-int/2addr v0, v1

    iget-object v1, p0, La/l;->pr:[I

    const/4 v2, 0x3

    aget v1, v1, v2

    add-int/2addr v0, v1

    return v0
.end method

.method public m(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/l;->pq:Ljava/lang/String;

    return-void
.end method
