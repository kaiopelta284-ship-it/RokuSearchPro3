.class public La/aj;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private d:I

.field private transient ox:La/p;

.field private pV:I

.field private pW:I

.field private valor:I

.field private y:I

.field private yF:I

.field private yG:I

.field private yH:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, La/aj;->d:I

    iput v0, p0, La/aj;->yF:I

    iput v0, p0, La/aj;->y:I

    const/4 v1, 0x0

    iput-object v1, p0, La/aj;->ox:La/p;

    const/4 v1, -0x1

    iput v1, p0, La/aj;->pV:I

    iput v1, p0, La/aj;->pW:I

    iput v1, p0, La/aj;->yG:I

    iput v1, p0, La/aj;->yH:I

    iput v0, p0, La/aj;->valor:I

    return-void
.end method


# virtual methods
.method public cK()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, La/aj;->d:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/aj;->yF:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/aj;->y:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public cv(I)V
    .locals 0

    iput p1, p0, La/aj;->valor:I

    return-void
.end method

.method public cw(I)V
    .locals 0

    iput p1, p0, La/aj;->yH:I

    return-void
.end method

.method public cx(I)V
    .locals 0

    iput p1, p0, La/aj;->yG:I

    return-void
.end method

.method public getY()I
    .locals 1

    iget v0, p0, La/aj;->y:I

    return v0
.end method

.method public iM()I
    .locals 1

    iget v0, p0, La/aj;->pV:I

    return v0
.end method

.method public k(La/p;)V
    .locals 0

    iput-object p1, p0, La/aj;->ox:La/p;

    return-void
.end method

.method public l(III)V
    .locals 0

    iput p1, p0, La/aj;->d:I

    add-int/lit8 p2, p2, 0x1

    iput p2, p0, La/aj;->yF:I

    iput p3, p0, La/aj;->y:I

    return-void
.end method

.method public nD()La/p;
    .locals 1

    iget-object v0, p0, La/aj;->ox:La/p;

    return-object v0
.end method

.method public nE()I
    .locals 1

    iget v0, p0, La/aj;->valor:I

    return v0
.end method

.method public nF()I
    .locals 1

    iget v0, p0, La/aj;->yH:I

    return v0
.end method

.method public nG()I
    .locals 1

    iget v0, p0, La/aj;->yG:I

    return v0
.end method

.method public nH()V
    .locals 1

    iget-object v0, p0, La/aj;->ox:La/p;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/aj;->ox:La/p;

    invoke-virtual {v0}, La/p;->iM()I

    move-result v0

    iput v0, p0, La/aj;->pV:I

    iget-object v0, p0, La/aj;->ox:La/p;

    invoke-virtual {v0}, La/p;->iR()I

    move-result v0

    iput v0, p0, La/aj;->pW:I

    return-void

    :cond_0
    const/4 v0, -0x1

    iput v0, p0, La/aj;->pV:I

    return-void
.end method

.method public nI()Ljava/lang/String;
    .locals 1

    iget v0, p0, La/aj;->yG:I

    invoke-static {v0}, La/b;->ar(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public nJ()Ljava/lang/String;
    .locals 1

    iget v0, p0, La/aj;->yH:I

    invoke-static {v0}, La/b;->ar(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public nK()V
    .locals 4

    iget v0, p0, La/aj;->pV:I

    if-ltz v0, :cond_2

    const/4 v0, 0x0

    iget v1, p0, La/aj;->pW:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v0

    :cond_0
    if-eqz v0, :cond_2

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    iget v2, p0, La/aj;->pV:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->iM()I

    move-result v3

    if-ne v2, v3, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, La/aj;->ox:La/p;

    return-void

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public setY(I)V
    .locals 0

    iput p1, p0, La/aj;->y:I

    return-void
.end method
