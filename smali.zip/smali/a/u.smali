.class public abstract La/u;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static Q(II)V
    .locals 5

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    array-length v3, v0

    if-ge v2, v3, :cond_1

    const/4 v3, 0x0

    :goto_1
    aget v4, v0, v2

    if-ge v3, v4, :cond_0

    new-instance v4, La/p;

    invoke-direct {v4, p0}, La/p;-><init>(I)V

    invoke-static {p1, v4, v2}, La/u;->a(ILa/p;I)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void

    nop

    :array_0
    .array-data 4
        0x3
        0x4
        0x4
        0x5
        0x4
    .end array-data
.end method

.method public static a(La/q;La/ac;)La/p;
    .locals 4

    new-instance v0, La/p;

    invoke-direct {v0}, La/p;-><init>()V

    invoke-virtual {p0}, La/q;->gN()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, La/p;->setNome(Ljava/lang/String;)V

    invoke-virtual {p0}, La/q;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPais(I)V

    invoke-virtual {p0}, La/q;->getPosicao()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPosicao(I)V

    invoke-virtual {p0}, La/q;->hG()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->aP(I)V

    invoke-virtual {p0}, La/q;->hS()D

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, La/p;->a(D)V

    const/4 v1, 0x1

    const-wide/16 v2, 0xb4

    invoke-virtual {v0, v2, v3, v1}, La/p;->a(JZ)V

    invoke-virtual {p0}, La/q;->hI()I

    move-result v2

    invoke-virtual {v0, v2}, La/p;->aR(I)V

    invoke-virtual {p0}, La/q;->hH()I

    move-result v2

    invoke-virtual {v0, v2}, La/p;->aQ(I)V

    invoke-virtual {v0, v1}, La/p;->H(Z)V

    invoke-virtual {p0}, La/q;->getCr1()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr1(I)V

    invoke-virtual {p0}, La/q;->getCr2()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr2(I)V

    invoke-virtual {p0}, La/q;->ic()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->ba(I)V

    invoke-virtual {p0}, La/q;->getIdade()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setIdade(I)V

    invoke-virtual {p0}, La/q;->getLado()I

    move-result p0

    invoke-virtual {v0, p0}, La/p;->setLado(I)V

    const/4 p0, 0x0

    invoke-virtual {v0, p0}, La/p;->setStatus(I)V

    invoke-virtual {v0}, La/p;->ib()V

    const/16 p0, 0x64

    invoke-virtual {v0, p0}, La/p;->aU(I)V

    invoke-virtual {v0, p1}, La/p;->i(La/ac;)V

    return-object v0
.end method

.method public static a(ILa/p;I)V
    .locals 4

    invoke-virtual {p1, p2}, La/p;->setPosicao(I)V

    const/16 v0, 0x12

    const/4 v1, 0x0

    const/16 v2, 0xf

    if-gt p0, v2, :cond_0

    goto :goto_0

    :cond_0
    packed-switch p0, :pswitch_data_0

    const/4 p0, 0x0

    goto :goto_0

    :pswitch_0
    const/16 p0, 0x1e

    goto :goto_0

    :pswitch_1
    const/16 p0, 0x1d

    goto :goto_0

    :pswitch_2
    const/16 p0, 0x1c

    goto :goto_0

    :pswitch_3
    const/16 p0, 0x1b

    goto :goto_0

    :pswitch_4
    const/16 p0, 0x1a

    goto :goto_0

    :pswitch_5
    const/16 p0, 0x19

    goto :goto_0

    :pswitch_6
    const/16 p0, 0x15

    goto :goto_0

    :pswitch_7
    const/16 p0, 0x13

    goto :goto_0

    :pswitch_8
    const/16 p0, 0x12

    goto :goto_0

    :pswitch_9
    const/16 p0, 0x11

    :goto_0
    add-int/lit8 p0, p0, -0x5

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr p0, v2

    invoke-virtual {p1, p0}, La/p;->aP(I)V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->db()I

    move-result p0

    invoke-virtual {p1, p0}, La/p;->bb(I)V

    const-wide/16 v2, 0x0

    invoke-virtual {p1, v2, v3}, La/p;->a(D)V

    const-wide/16 v2, 0xb4

    const/4 p0, 0x1

    invoke-virtual {p1, v2, v3, p0}, La/p;->a(JZ)V

    invoke-virtual {p1}, La/p;->if()V

    invoke-virtual {p1}, La/p;->ie()V

    invoke-static {p2}, La/p;->be(I)[I

    move-result-object p2

    aget v2, p2, v1

    invoke-virtual {p1, v2}, La/p;->setCr1(I)V

    aget p0, p2, p0

    invoke-virtual {p1, p0}, La/p;->setCr2(I)V

    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    const/4 p2, 0x4

    invoke-virtual {p0, p2}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x7

    invoke-virtual {p1, p0}, La/p;->ba(I)V

    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    const/16 p2, 0xc

    invoke-virtual {p0, p2}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    add-int/2addr p0, v0

    invoke-virtual {p1, p0}, La/p;->setIdade(I)V

    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    const/4 p2, 0x2

    invoke-virtual {p0, p2}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    invoke-virtual {p1, p0}, La/p;->setLado(I)V

    invoke-virtual {p1, v1}, La/p;->setStatus(I)V

    invoke-virtual {p1}, La/p;->ib()V

    invoke-virtual {p1}, La/p;->if()V

    invoke-virtual {p1}, La/p;->ie()V

    return-void

    :pswitch_data_0
    .packed-switch 0x10
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static a(ZLa/p;La/ac;)V
    .locals 5

    new-instance v0, La/p;

    invoke-direct {v0}, La/p;-><init>()V

    invoke-virtual {p1}, La/p;->getPais()I

    move-result v1

    invoke-static {v1}, La/p;->bf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, La/p;->setNome(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, La/p;->i(La/ac;)V

    invoke-virtual {p1}, La/p;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPais(I)V

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPosicao(I)V

    invoke-virtual {p1}, La/p;->getLado()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setLado(I)V

    invoke-virtual {p1}, La/p;->ic()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->ba(I)V

    invoke-virtual {p1}, La/p;->getCr1()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr1(I)V

    invoke-virtual {p1}, La/p;->getCr2()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr2(I)V

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/4 v2, 0x6

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x12

    invoke-virtual {v0, v1}, La/p;->setIdade(I)V

    invoke-virtual {v0}, La/p;->ib()V

    invoke-virtual {p1}, La/p;->hG()I

    move-result v1

    int-to-double v1, v1

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    mul-double v1, v1, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J

    move-result-wide v1

    long-to-int v1, v1

    invoke-virtual {v0, v1}, La/p;->aP(I)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->db()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->bb(I)V

    invoke-virtual {p1}, La/p;->ih()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->bc(I)V

    const/4 v1, 0x1

    const-wide/16 v2, 0x12c

    invoke-virtual {v0, v2, v3, v1}, La/p;->a(JZ)V

    invoke-virtual {v0}, La/p;->if()V

    invoke-virtual {v0}, La/p;->ie()V

    invoke-virtual {p1}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_0

    :goto_0
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {v0, p1}, La/p;->a(Ljava/lang/Boolean;)V

    goto :goto_1

    :cond_0
    invoke-virtual {p1}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    const/4 v2, 0x3

    invoke-virtual {p1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    if-ne p1, v1, :cond_3

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0xc8

    invoke-virtual {p1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    if-ne p1, v1, :cond_2

    goto :goto_0

    :cond_2
    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x12c

    invoke-virtual {p1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    if-ne p1, v1, :cond_3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {v0, p1}, La/p;->i(Ljava/lang/Boolean;)V

    :cond_3
    :goto_1
    invoke-virtual {p2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-nez p0, :cond_4

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object p0

    :goto_2
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_4
    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ds()Ljava/util/ArrayList;

    move-result-object p0

    goto :goto_2

    return-void
.end method

.method public static a(ZLa/q;La/ac;)V
    .locals 11

    new-instance v0, La/p;

    invoke-direct {v0}, La/p;-><init>()V

    invoke-virtual {p1}, La/q;->gN()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, La/p;->setNome(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, La/p;->i(La/ac;)V

    invoke-virtual {p1}, La/q;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPais(I)V

    invoke-virtual {p1}, La/q;->getPosicao()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPosicao(I)V

    invoke-virtual {p1}, La/q;->getLado()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setLado(I)V

    invoke-virtual {p1}, La/q;->ic()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->ba(I)V

    invoke-virtual {p1}, La/q;->getCr1()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr1(I)V

    invoke-virtual {p1}, La/q;->getCr2()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr2(I)V

    invoke-virtual {p1}, La/q;->getIdade()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setIdade(I)V

    invoke-virtual {v0}, La/p;->ib()V

    invoke-virtual {p2}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v1, :cond_4

    invoke-virtual {p2}, La/ac;->getDivisao()I

    move-result v1

    if-ge v1, v6, :cond_0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, La/ac;->getDivisao()I

    move-result v1

    if-ne v1, v6, :cond_1

    const/16 v2, 0x16

    goto :goto_0

    :cond_1
    invoke-virtual {p2}, La/ac;->getDivisao()I

    move-result v1

    if-ne v1, v3, :cond_2

    const/16 v2, 0x11

    goto :goto_0

    :cond_2
    invoke-virtual {p2}, La/ac;->getDivisao()I

    move-result v1

    if-ne v1, v4, :cond_3

    const/16 v2, 0xe

    :cond_3
    :goto_0
    invoke-virtual {p2}, La/ac;->iw()I

    move-result v1

    if-nez v1, :cond_9

    :goto_1
    add-int/lit8 v2, v2, 0x5

    goto :goto_3

    :cond_4
    invoke-virtual {p2}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v5, :cond_5

    const/16 v2, 0x14

    goto :goto_2

    :cond_5
    invoke-virtual {p2}, La/ac;->getReputacao()I

    move-result v1

    const/4 v7, 0x4

    if-ne v1, v7, :cond_6

    const/16 v2, 0xf

    goto :goto_2

    :cond_6
    invoke-virtual {p2}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v4, :cond_7

    const/16 v2, 0xc

    goto :goto_2

    :cond_7
    invoke-virtual {p2}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v3, :cond_8

    goto :goto_2

    :cond_8
    const/4 v2, 0x5

    :goto_2
    invoke-virtual {p2}, La/ac;->iw()I

    move-result v1

    if-nez v1, :cond_9

    goto :goto_1

    :cond_9
    :goto_3
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/2addr v2, v1

    invoke-virtual {p1}, La/q;->ih()I

    move-result v1

    int-to-double v7, v1

    const-wide/high16 v9, 0x4059000000000000L    # 100.0

    div-double/2addr v7, v9

    int-to-double v1, v2

    mul-double v1, v1, v7

    invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J

    move-result-wide v1

    long-to-int v1, v1

    invoke-virtual {p1}, La/q;->ic()I

    move-result v2

    add-int/2addr v2, v1

    invoke-virtual {p1}, La/q;->ic()I

    move-result v1

    const/16 v3, 0x9

    if-lt v1, v3, :cond_a

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v3, 0xa

    invoke-virtual {v1, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/2addr v2, v1

    :cond_a
    invoke-virtual {v0, v2}, La/p;->aP(I)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->db()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->bb(I)V

    invoke-virtual {p1}, La/q;->ih()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->bc(I)V

    const-wide/16 v1, 0x12c

    invoke-virtual {v0, v1, v2, v6}, La/p;->a(JZ)V

    invoke-virtual {v0}, La/p;->if()V

    invoke-virtual {v0}, La/p;->ie()V

    invoke-virtual {p1}, La/q;->iX()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_b

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v6, :cond_d

    :goto_4
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, La/p;->a(Ljava/lang/Boolean;)V

    goto :goto_5

    :cond_b
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0xc8

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v6, :cond_c

    goto :goto_4

    :cond_c
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x12c

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v6, :cond_d

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, La/p;->i(Ljava/lang/Boolean;)V

    goto :goto_4

    :cond_d
    :goto_5
    invoke-virtual {v0}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-virtual {v0}, La/p;->ic()I

    move-result v1

    const/16 v2, 0x8

    if-ge v1, v2, :cond_e

    invoke-virtual {v0, v2}, La/p;->ba(I)V

    :cond_e
    if-nez p0, :cond_f

    invoke-virtual {p2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_6

    :cond_f
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->du()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_6
    invoke-virtual {p2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-nez p0, :cond_10

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object p0

    :goto_7
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_10
    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ds()Ljava/util/ArrayList;

    move-result-object p0

    goto :goto_7

    return-void
.end method
