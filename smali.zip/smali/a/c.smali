.class public La/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private mo:I

.field private oh:I

.field private oi:I

.field private oj:Ljava/lang/String;

.field private ok:I

.field private ol:I

.field private om:I

.field private on:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/c;->oh:I

    iput v0, p0, La/c;->oi:I

    const/4 v1, 0x0

    iput-object v1, p0, La/c;->oj:Ljava/lang/String;

    iput v0, p0, La/c;->ok:I

    iput v0, p0, La/c;->om:I

    iput v0, p0, La/c;->on:I

    return-void
.end method

.method public constructor <init>(La/al;La/al;La/ac;La/ac;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p3}, Lcom/brasfoot/v2028/Recopa;->scanNTTitle(La/ac;)V

    const/4 v0, -0x1

    iput v0, p0, La/c;->oh:I

    iput v0, p0, La/c;->oi:I

    const/4 v1, 0x0

    iput-object v1, p0, La/c;->oj:Ljava/lang/String;

    iput v0, p0, La/c;->ok:I

    iput v0, p0, La/c;->om:I

    iput v0, p0, La/c;->on:I

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    iput v0, p0, La/c;->mo:I

    if-eqz p3, :cond_0

    invoke-virtual {p3}, La/ac;->mE()I

    move-result v0

    iput v0, p0, La/c;->oh:I

    :cond_0
    if-eqz p3, :cond_1

    invoke-virtual {p3}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p3}, La/ac;->lz()La/af;

    move-result-object p3

    invoke-virtual {p3}, La/af;->getUniqueId()I

    move-result p3

    iput p3, p0, La/c;->om:I

    :cond_1
    if-eqz p4, :cond_2

    invoke-virtual {p4}, La/ac;->mE()I

    move-result p3

    iput p3, p0, La/c;->oi:I

    :cond_2
    if-eqz p4, :cond_3

    invoke-virtual {p4}, La/ac;->lz()La/af;

    move-result-object p3

    if-eqz p3, :cond_3

    invoke-virtual {p4}, La/ac;->lz()La/af;

    move-result-object p3

    invoke-virtual {p3}, La/af;->getUniqueId()I

    move-result p3

    iput p3, p0, La/c;->on:I

    :cond_3
    instance-of p3, p1, La/y;

    if-nez p3, :cond_5

    instance-of p3, p1, Ld/m;

    if-eqz p3, :cond_4

    goto :goto_1

    :cond_4
    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_0
    :try_start_0
    invoke-virtual {p1, p1}, La/al;->m(La/al;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-virtual {p1}, La/al;->nV()Lcomponents/ay;

    move-result-object p1

    goto :goto_2

    :cond_5
    :goto_1
    instance-of p3, p2, Ld/q;

    if-eqz p3, :cond_6

    invoke-virtual {p2}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :try_start_1
    invoke-virtual {p2, p2}, La/al;->m(La/al;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    invoke-virtual {p2}, La/al;->nV()Lcomponents/ay;

    move-result-object p1

    invoke-virtual {p2}, La/al;->cG()I

    move-result p3

    const/4 p4, 0x1

    if-ne p3, p4, :cond_7

    invoke-virtual {p2}, La/al;->nS()I

    move-result p2

    if-ne p2, p4, :cond_7

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lcomponents/ay;->nD()La/p;

    move-result-object p2

    invoke-static {p4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p3

    invoke-virtual {p2, p3}, La/p;->a(Ljava/lang/Boolean;)V

    goto :goto_2

    :cond_6
    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_7
    :goto_2
    if-eqz p1, :cond_9

    invoke-virtual {p1}, Lcomponents/ay;->nD()La/p;

    move-result-object p2

    invoke-virtual {p1}, Lcomponents/ay;->fy()I

    move-result p1

    iput p1, p0, La/c;->ol:I

    if-eqz p2, :cond_8

    invoke-virtual {p2}, La/p;->getNome()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, La/c;->oj:Ljava/lang/String;

    :cond_8
    if-eqz p2, :cond_9

    invoke-virtual {p2}, La/p;->hE()La/ac;

    move-result-object p1

    if-eqz p1, :cond_9

    invoke-virtual {p2}, La/p;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    iput p1, p0, La/c;->ok:I

    :cond_9
    return-void
.end method


# virtual methods
.method public db()I
    .locals 1

    iget v0, p0, La/c;->mo:I

    return v0
.end method

.method public fA()La/af;
    .locals 2

    iget v0, p0, La/c;->on:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    iget v1, p0, La/c;->on:I

    invoke-virtual {v0, v1}, La/b;->au(I)La/af;

    move-result-object v0

    return-object v0
.end method

.method public fu()La/ac;
    .locals 1

    iget v0, p0, La/c;->oh:I

    if-ltz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    iget v0, p0, La/c;->oh:I

    invoke-static {v0}, La/b;->aq(I)La/ac;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public fv()La/ac;
    .locals 1

    iget v0, p0, La/c;->oi:I

    if-ltz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    iget v0, p0, La/c;->oi:I

    invoke-static {v0}, La/b;->aq(I)La/ac;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public fw()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/c;->oj:Ljava/lang/String;

    return-object v0
.end method

.method public fx()La/ac;
    .locals 1

    iget v0, p0, La/c;->ok:I

    if-ltz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    iget v0, p0, La/c;->ok:I

    invoke-static {v0}, La/b;->aq(I)La/ac;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public fy()I
    .locals 1

    iget v0, p0, La/c;->ol:I

    return v0
.end method

.method public fz()La/af;
    .locals 2

    iget v0, p0, La/c;->om:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    iget v1, p0, La/c;->om:I

    invoke-virtual {v0, v1}, La/b;->au(I)La/af;

    move-result-object v0

    return-object v0
.end method

.method public setFin(La/ac;La/ac;)V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    iput v0, p0, La/c;->mo:I

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/ac;->mE()I

    move-result v0

    iput v0, p0, La/c;->oh:I

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/af;->getUniqueId()I

    move-result v0

    iput v0, p0, La/c;->om:I

    :cond_0
    if-eqz p2, :cond_1

    invoke-virtual {p2}, La/ac;->mE()I

    move-result v0

    iput v0, p0, La/c;->oi:I

    invoke-virtual {p2}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, La/af;->getUniqueId()I

    move-result v0

    iput v0, p0, La/c;->on:I

    :cond_1
    return-void
.end method
