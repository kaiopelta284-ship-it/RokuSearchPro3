.class public La/ah;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private mo:I

.field private yB:I

.field private yC:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private yD:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ah;->yC:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ah;->yD:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ah;->yC:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ah;->yD:Ljava/util/ArrayList;

    iput p1, p0, La/ah;->mo:I

    return-void
.end method


# virtual methods
.method public ad(I)V
    .locals 0

    iput p1, p0, La/ah;->mo:I

    return-void
.end method

.method public ct(I)V
    .locals 0

    iput p1, p0, La/ah;->yB:I

    return-void
.end method

.method public nA()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ah;->yC:Ljava/util/ArrayList;

    return-object v0
.end method

.method public nB()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ah;->yD:Ljava/util/ArrayList;

    return-object v0
.end method

.method public nz()I
    .locals 1

    iget v0, p0, La/ah;->yB:I

    return v0
.end method
