.class public La/aa;
.super Ljava/lang/Object;


# instance fields
.field private nome:Ljava/lang/String;

.field private wN:I

.field private wO:I

.field private wP:I

.field private wQ:I

.field private wR:I

.field private wS:I

.field private wT:I

.field private wU:I

.field private wV:I

.field private wW:I

.field private wX:Z

.field private wY:Z

.field private wZ:Z

.field private xa:Z

.field private xb:[[I

.field private xc:[[I

.field private xd:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/aa;->nome:Ljava/lang/String;

    const/4 v0, -0x1

    iput v0, p0, La/aa;->wN:I

    iput v0, p0, La/aa;->wO:I

    iput v0, p0, La/aa;->wP:I

    iput v0, p0, La/aa;->wQ:I

    iput v0, p0, La/aa;->wR:I

    iput v0, p0, La/aa;->wS:I

    iput v0, p0, La/aa;->wT:I

    iput v0, p0, La/aa;->wU:I

    iput v0, p0, La/aa;->wV:I

    iput v0, p0, La/aa;->wW:I

    const/4 v0, 0x0

    iput-boolean v0, p0, La/aa;->wX:Z

    iput-boolean v0, p0, La/aa;->wY:Z

    iput-boolean v0, p0, La/aa;->wZ:Z

    iput-boolean v0, p0, La/aa;->xa:Z

    const/4 v1, 0x5

    new-array v2, v1, [[I

    const/4 v3, 0x2

    new-array v4, v3, [I

    fill-array-data v4, :array_0

    aput-object v4, v2, v0

    new-array v4, v3, [I

    fill-array-data v4, :array_1

    const/4 v5, 0x1

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_2

    aput-object v4, v2, v3

    new-array v4, v3, [I

    fill-array-data v4, :array_3

    const/4 v6, 0x3

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_4

    const/4 v7, 0x4

    aput-object v4, v2, v7

    iput-object v2, p0, La/aa;->xb:[[I

    const/4 v2, 0x7

    new-array v2, v2, [[I

    new-array v4, v3, [I

    fill-array-data v4, :array_5

    aput-object v4, v2, v0

    new-array v0, v3, [I

    fill-array-data v0, :array_6

    aput-object v0, v2, v5

    new-array v0, v3, [I

    fill-array-data v0, :array_7

    aput-object v0, v2, v3

    new-array v0, v3, [I

    fill-array-data v0, :array_8

    aput-object v0, v2, v6

    new-array v0, v3, [I

    fill-array-data v0, :array_9

    aput-object v0, v2, v7

    new-array v0, v3, [I

    fill-array-data v0, :array_a

    aput-object v0, v2, v1

    new-array v0, v3, [I

    fill-array-data v0, :array_b

    const/4 v1, 0x6

    aput-object v0, v2, v1

    iput-object v2, p0, La/aa;->xc:[[I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/aa;->xd:Ljava/util/ArrayList;

    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0xa
    .end array-data

    :array_1
    .array-data 4
        0xb
        0x1e
    .end array-data

    :array_2
    .array-data 4
        0x1f
        0x32
    .end array-data

    :array_3
    .array-data 4
        0x33
        0x46
    .end array-data

    :array_4
    .array-data 4
        0x47
        0x64
    .end array-data

    :array_5
    .array-data 4
        0x1
        0xf4240
    .end array-data

    :array_6
    .array-data 4
        0xf4240
        0x4c4b40
    .end array-data

    :array_7
    .array-data 4
        0x4c4b40
        0x989680
    .end array-data

    :array_8
    .array-data 4
        0x989680
        0x1c9c380
    .end array-data

    :array_9
    .array-data 4
        0x1c9c380
        0x2faf080
    .end array-data

    :array_a
    .array-data 4
        0x2faf080
        0x5f5e100
    .end array-data

    :array_b
    .array-data 4
        0x5f5e100
        0x3b9aca00
    .end array-data
.end method

.method private e(La/p;)Z
    .locals 5

    const/4 v1, 0x0

    invoke-virtual {p1}, La/p;->isAposentado()Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget v0, p0, La/aa;->wN:I

    if-ltz v0, :cond_1

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    iget v2, p0, La/aa;->wN:I

    if-eq v0, v2, :cond_1

    return v1

    :cond_1
    iget v0, p0, La/aa;->wO:I

    if-ltz v0, :cond_2

    invoke-virtual {p1}, La/p;->getLado()I

    move-result v0

    iget v2, p0, La/aa;->wO:I

    if-eq v0, v2, :cond_2

    return v1

    :cond_2
    iget v0, p0, La/aa;->wP:I

    const/4 v2, 0x1

    if-ltz v0, :cond_4

    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    iget-object v3, p0, La/aa;->xb:[[I

    iget v4, p0, La/aa;->wP:I

    aget-object v3, v3, v4

    aget v3, v3, v1

    if-lt v0, v3, :cond_3

    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    iget-object v3, p0, La/aa;->xb:[[I

    iget v4, p0, La/aa;->wP:I

    aget-object v3, v3, v4

    aget v3, v3, v2

    if-le v0, v3, :cond_4

    :cond_3
    return v1

    :cond_4
    iget v0, p0, La/aa;->wV:I

    const/16 v3, 0x10

    if-gt v0, v3, :cond_5

    iget v0, p0, La/aa;->wW:I

    const/16 v3, 0x30

    if-ge v0, v3, :cond_6

    :cond_5
    invoke-virtual {p1}, La/p;->getIdade()I

    move-result v0

    iget v3, p0, La/aa;->wV:I

    if-lt v0, v3, :cond_13

    invoke-virtual {p1}, La/p;->getIdade()I

    move-result v0

    iget v3, p0, La/aa;->wW:I

    if-le v0, v3, :cond_6

    return v1

    :cond_6
    iget v0, p0, La/aa;->wQ:I

    if-ltz v0, :cond_8

    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    iget-object v3, p0, La/aa;->xc:[[I

    iget v4, p0, La/aa;->wQ:I

    aget-object v3, v3, v4

    aget v3, v3, v1

    if-lt v0, v3, :cond_7

    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    iget-object v3, p0, La/aa;->xc:[[I

    iget v4, p0, La/aa;->wQ:I

    aget-object v3, v3, v4

    aget v3, v3, v2

    if-le v0, v3, :cond_8

    :cond_7
    return v1

    :cond_8
    iget v0, p0, La/aa;->wR:I

    if-ltz v0, :cond_9

    invoke-virtual {p1}, La/p;->getCr1()I

    move-result v0

    iget v3, p0, La/aa;->wR:I

    if-eq v0, v3, :cond_9

    invoke-virtual {p1}, La/p;->getCr2()I

    move-result v0

    iget v3, p0, La/aa;->wR:I

    if-eq v0, v3, :cond_9

    return v1

    :cond_9
    iget v0, p0, La/aa;->wS:I

    if-ltz v0, :cond_a

    invoke-virtual {p1}, La/p;->getCr2()I

    move-result v0

    iget v3, p0, La/aa;->wS:I

    if-eq v0, v3, :cond_a

    return v1

    :cond_a
    iget v0, p0, La/aa;->wT:I

    if-ltz v0, :cond_b

    invoke-virtual {p1}, La/p;->getPais()I

    move-result v0

    iget v3, p0, La/aa;->wT:I

    if-eq v0, v3, :cond_b

    return v1

    :cond_b
    iget v0, p0, La/aa;->wU:I

    if-ltz v0, :cond_c

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_c

    iget v0, p0, La/aa;->wU:I

    iget-object v3, p0, La/aa;->xd:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_c

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    iget-object v3, p0, La/aa;->xd:Ljava/util/ArrayList;

    iget v4, p0, La/aa;->wU:I

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-eq v0, v3, :cond_c

    return v1

    :cond_c
    iget-boolean v0, p0, La/aa;->wX:Z

    if-eqz v0, :cond_d

    invoke-virtual {p1}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_d

    return v1

    :cond_d
    iget-boolean v0, p0, La/aa;->wY:Z

    if-eqz v0, :cond_e

    invoke-virtual {p1}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_e

    return v1

    :cond_e
    iget-boolean v0, p0, La/aa;->wZ:Z

    if-eqz v0, :cond_f

    invoke-virtual {p1}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_f

    return v1

    :cond_f
    iget-boolean v0, p0, La/aa;->xa:Z

    if-eqz v0, :cond_10

    invoke-virtual {p1}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_10

    return v1

    :cond_10
    iget-object v0, p0, La/aa;->nome:Ljava/lang/String;

    if-eqz v0, :cond_12

    iget-object v0, p0, La/aa;->nome:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_12

    iget-object v0, p0, La/aa;->nome:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_12

    iget-object v0, p0, La/aa;->nome:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {p1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-gt v0, v3, :cond_11

    iget-object v0, p0, La/aa;->nome:Ljava/lang/String;

    invoke-virtual {p1}, La/p;->getNome()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lc/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v3, p0, La/aa;->nome:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    invoke-virtual {p1, v1, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_12

    :cond_11
    return v1

    :cond_12
    return v2

    :cond_13
    return v1
.end method


# virtual methods
.method public O(Z)V
    .locals 0

    iput-boolean p1, p0, La/aa;->wX:Z

    return-void
.end method

.method public P(Z)V
    .locals 0

    iput-boolean p1, p0, La/aa;->wY:Z

    return-void
.end method

.method public Q(Z)V
    .locals 0

    iput-boolean p1, p0, La/aa;->wZ:Z

    return-void
.end method

.method public R(Z)V
    .locals 0

    iput-boolean p1, p0, La/aa;->xa:Z

    return-void
.end method

.method public bN(I)V
    .locals 0

    iput p1, p0, La/aa;->wN:I

    return-void
.end method

.method public bO(I)V
    .locals 0

    iput p1, p0, La/aa;->wO:I

    return-void
.end method

.method public bP(I)V
    .locals 0

    iput p1, p0, La/aa;->wP:I

    return-void
.end method

.method public bQ(I)V
    .locals 0

    iput p1, p0, La/aa;->wQ:I

    return-void
.end method

.method public bR(I)V
    .locals 0

    iput p1, p0, La/aa;->wR:I

    return-void
.end method

.method public bS(I)V
    .locals 0

    iput p1, p0, La/aa;->wS:I

    return-void
.end method

.method public bT(I)V
    .locals 0

    iput p1, p0, La/aa;->wT:I

    return-void
.end method

.method public bU(I)V
    .locals 0

    iput p1, p0, La/aa;->wU:I

    return-void
.end method

.method public bV(I)V
    .locals 0

    iput p1, p0, La/aa;->wV:I

    return-void
.end method

.method public bW(I)V
    .locals 0

    iput p1, p0, La/aa;->wW:I

    return-void
.end method

.method public ln()Ljava/util/ArrayList;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, La/aa;->xd:Ljava/util/ArrayList;

    if-nez v1, :cond_0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/aa;->xd:Ljava/util/ArrayList;

    :cond_0
    iget v1, p0, La/aa;->wU:I

    const/4 v2, 0x0

    if-ltz v1, :cond_1

    iget-object v1, p0, La/aa;->xd:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_1

    iget-object v3, p0, La/aa;->xd:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kK()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v2, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-direct {p0, v1}, La/aa;->e(La/p;)Z

    move-result v1

    if-eqz v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    return-object v0
.end method

.method public lo()I
    .locals 1

    iget v0, p0, La/aa;->wV:I

    return v0
.end method

.method public lp()I
    .locals 1

    iget v0, p0, La/aa;->wW:I

    return v0
.end method

.method public setNome(Ljava/lang/String;)V
    .locals 1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {p1}, Lc/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_0
    iput-object p1, p0, La/aa;->nome:Ljava/lang/String;

    return-void
.end method
