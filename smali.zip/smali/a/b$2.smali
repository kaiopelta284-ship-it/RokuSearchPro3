.class final La/b$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "La/af;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public b(La/af;La/af;)I
    .locals 4

    invoke-virtual {p1}, La/af;->mW()I

    move-result v0

    invoke-virtual {p2}, La/af;->mW()I

    move-result v1

    invoke-virtual {p1}, La/af;->mY()I

    move-result v2

    invoke-virtual {p2}, La/af;->mY()I

    move-result v3

    invoke-virtual {p1}, La/af;->mX()I

    move-result p1

    invoke-virtual {p2}, La/af;->mX()I

    move-result p2

    if-eq v0, v1, :cond_0

    sub-int/2addr v1, v0

    return v1

    :cond_0
    if-eq v2, v3, :cond_1

    sub-int/2addr v3, v2

    return v3

    :cond_1
    if-eq p1, p2, :cond_2

    sub-int/2addr p1, p2

    return p1

    :cond_2
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, La/af;

    check-cast p2, La/af;

    invoke-virtual {p0, p1, p2}, La/b$2;->b(La/af;La/af;)I

    move-result p1

    return p1
.end method
