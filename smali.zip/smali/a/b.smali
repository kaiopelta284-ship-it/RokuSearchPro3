.class public La/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La/b$a;
    }
.end annotation


# static fields
.field public static oa:Ljava/util/Comparator; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "La/b$a;",
            ">;"
        }
    .end annotation
.end field

.field public static oe:Ljava/util/Comparator; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "La/af;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public africaCopa:Ld/africa;

.field public africaElimCopa:Ld/elimaf;

.field public transient africaWcSeeds:Ljava/util/ArrayList;

.field public asiaCopa:Ld/asia;

.field public asiaElimCopa:Ld/elimas;

.field public transient asiaWcSeeds:Ljava/util/ArrayList;

.field private autoRenovaContrato:Z

.field private autoSalvar:I

.field private avisoTerminoContrato:I

.field public awardsReset:Z

.field public awardsSeeded:Z

.field public bichoAno:I

.field public bichoTemporada:I

.field private bolaDeOuroAno:I

.field private bolaDeOuroHistory:Ljava/lang/String;

.field public cneCopa:Ld/cne;

.field public transient concacafWcSeeds:Ljava/util/ArrayList;

.field private corPlacar:I

.field private coresLista:[Landroid/graphics/Color;

.field public cpaulistaChamp:La/ac;

.field public cpaulistaCopa:Ld/cpaulista;

.field public cssCopa:Ld/css;

.field public cvCopa:Ld/cv;

.field public dynYear:I

.field public elimccCopa:Ld/elimcc;

.field public finComp:Ld/a;

.field public finPendAway:La/ac;

.field public finPendHome:La/ac;

.field public finPendYear:I

.field public finYear:I

.field public finalChamps:Ljava/util/ArrayList;

.field private gruposIntPadrao:Z

.field private h2h:Ljava/util/HashMap;

.field private ignoraEstadual:Z

.field private ignoraLigas:Z

.field private jogaEstadual:Z

.field private jogaIntClubes:Z

.field private jogaIntano1:Z

.field private jogaSelecoesAll:Z

.field public lastAwardYear:I

.field public lastBoardMsg:Ljava/lang/String;

.field public lastNewsMonth:I

.field private mA:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field

.field private mB:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ld/m;",
            ">;"
        }
    .end annotation
.end field

.field private mC:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ld/ae;",
            ">;"
        }
    .end annotation
.end field

.field private mD:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/a;",
            ">;"
        }
    .end annotation
.end field

.field private mE:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bf;",
            ">;"
        }
    .end annotation
.end field

.field private mF:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/aj;",
            ">;"
        }
    .end annotation
.end field

.field private mG:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bn;",
            ">;"
        }
    .end annotation
.end field

.field private mH:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bi;",
            ">;"
        }
    .end annotation
.end field

.field private mI:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/w;",
            ">;"
        }
    .end annotation
.end field

.field private mJ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cr;",
            ">;"
        }
    .end annotation
.end field

.field private mK:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/ax;",
            ">;"
        }
    .end annotation
.end field

.field private mL:Ld/y;

.field private mM:Ld/t;

.field private mN:Ld/p;

.field private mO:Ld/a;

.field private mP:Ld/aa;

.field private mQ:Ld/z;

.field private mR:Ld/v;

.field private mS:Ld/s;

.field private mT:Ld/r;

.field private mU:Ld/u;

.field private mV:Ld/w;

.field private mW:Ld/ad;

.field private mX:[Ld/ab;

.field private mY:[Z

.field private mZ:Z

.field private ma:Ld/ag;

.field public metaAno:I

.field public metaAskedAno:I

.field public metaBonusAno:I

.field public metaBonusVal:I

.field public metaTier:I

.field public metaTipo:I

.field private mm:Lest/InfoArquivoSalvoType;

.field private mn:I

.field private mo:I

.field private mp:I

.field private mq:I

.field private mr:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private ms:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private mt:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private mu:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private mv:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation
.end field

.field private mw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation
.end field

.field private mx:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation
.end field

.field private my:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/l;",
            ">;"
        }
    .end annotation
.end field

.field private mz:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field

.field public transient nA:[I

.field public transient nB:[I

.field public transient nC:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bv;",
            ">;"
        }
    .end annotation
.end field

.field public transient nD:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lest/ConfigLigaType;",
            ">;"
        }
    .end annotation
.end field

.field public transient nE:Z

.field public transient nF:Z

.field public transient nG:I

.field public transient nH:Z

.field public transient nI:Z

.field public transient nJ:Z

.field private nK:Z

.field private nL:Ld/c;

.field private nM:Ld/n;

.field private nN:Ld/b;

.field private nO:Ld/d;

.field private nP:Ld/f;

.field private nQ:Ld/e;

.field private nR:Ld/o;

.field private nS:Ld/l;

.field private nT:Ld/j;

.field private nU:Ld/g;

.field private nV:Ld/h;

.field private nW:Ld/k;

.field private nX:Ld/i;

.field private nY:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private transient nZ:I

.field private na:Z

.field private nb:Z

.field private nc:Z

.field private nd:Z

.field private ne:Z

.field private negritoCasa:Z

.field public newsLog:Ljava/util/ArrayList;

.field private nf:I

.field private ng:I

.field private nh:I

.field private ni:Ljava/lang/String;

.field public nj:Z

.field private nk:I

.field private nl:I

.field private nm:I

.field private nn:I

.field private no:I

.field private np:I

.field private nq:I

.field private nr:I

.field private ns:I

.field public nt:Z

.field private nu:I

.field private nv:I

.field private transient nw:La/ac;

.field private transient nx:La/t;

.field public transient ny:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public transient nz:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Le/t;",
            ">;"
        }
    .end annotation
.end field

.field private transient ob:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private transient oc:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;"
        }
    .end annotation
.end field

.field private transient od:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;"
        }
    .end annotation
.end field

.field public ofcCopa:Ld/ofc;

.field public ouroCopa:Ld/ouro;

.field public pressPending:I

.field private prizeMap:Ljava/util/HashMap;

.field private prizeSeason:I

.field public rcBaseLog:Ljava/lang/String;

.field public rcBaseLogClub:I

.field public rcClasLoss:I

.field public rcClasLossY:I

.field public rcClasYear:I

.field public rcCneChamp:La/ac;

.field public rcCssChamp:La/ac;

.field public rcCvChamp:La/ac;

.field public rcSpMode:I

.field public rcSpPct:I

.field public rcSpRenegY:I

.field public rcSpUntil:I

.field public rcSupCopaYear:I

.field public rcSupQ:Ld/q;

.field private recopaArr:[Ld/q;

.field public repCopa:Ld/q;

.field public repRound:I

.field public repWinners:Ljava/util/ArrayList;

.field public repYear:I

.field private salarioMensal:Z

.field public socios:I

.field public superMundial:Ld/sm;

.field public tbBanYear:I

.field public transHist:Ljava/util/ArrayList;

.field private usaCorPlacar:Z

.field private usaCoresLista:Z

.field private usaGrupoPadraoEstadual:Z

.field private usaSons:Z

.field private velocidade:I

.field private velocidadeNH:I

.field private verDecisaoPenNaoHumano:I

.field private verEstaduaisAgrupados:Z

.field private verJanelaSubs:I

.field private verJint:[Z

.field private verMudancaTecnicos:I

.field public worldBest:La/p;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/b$1;

    invoke-direct {v0}, La/b$1;-><init>()V

    sput-object v0, La/b;->oa:Ljava/util/Comparator;

    new-instance v0, La/b$2;

    invoke-direct {v0}, La/b$2;-><init>()V

    sput-object v0, La/b;->oe:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lest/InfoArquivoSalvoType;

    invoke-direct {v0}, Lest/InfoArquivoSalvoType;-><init>()V

    iput-object v0, p0, La/b;->mm:Lest/InfoArquivoSalvoType;

    const/16 v0, 0x15

    iput v0, p0, La/b;->mn:I

    const/4 v0, 0x1

    iput v0, p0, La/b;->mo:I

    iput v0, p0, La/b;->mp:I

    const/16 v1, 0xa

    iput v1, p0, La/b;->mq:I

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/b;->mr:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/b;->ms:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/b;->mu:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/b;->mv:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/b;->mw:Ljava/util/ArrayList;

    const/4 v2, 0x0

    iput-object v2, p0, La/b;->mx:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->my:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mz:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mA:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mB:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mC:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mD:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mE:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mF:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mG:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mH:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mI:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mJ:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La/b;->mK:Ljava/util/ArrayList;

    iput-object v2, p0, La/b;->mL:Ld/y;

    iput-object v2, p0, La/b;->mM:Ld/t;

    iput-object v2, p0, La/b;->mN:Ld/p;

    new-instance v3, Ld/a;

    invoke-direct {v3}, Ld/a;-><init>()V

    iput-object v3, p0, La/b;->mO:Ld/a;

    iput-object v2, p0, La/b;->mP:Ld/aa;

    iput-object v2, p0, La/b;->mQ:Ld/z;

    iput-object v2, p0, La/b;->mR:Ld/v;

    iput-object v2, p0, La/b;->mS:Ld/s;

    iput-object v2, p0, La/b;->mT:Ld/r;

    iput-object v2, p0, La/b;->mU:Ld/u;

    iput-object v2, p0, La/b;->mV:Ld/w;

    iput-object v2, p0, La/b;->mW:Ld/ad;

    iput-object v2, p0, La/b;->ma:Ld/ag;

    const/4 v3, 0x4

    new-array v4, v3, [Ld/ab;

    const/4 v5, 0x0

    aput-object v2, v4, v5

    aput-object v2, v4, v0

    const/4 v6, 0x2

    aput-object v2, v4, v6

    const/4 v7, 0x3

    aput-object v2, v4, v7

    iput-object v4, p0, La/b;->mX:[Ld/ab;

    new-array v4, v3, [Z

    fill-array-data v4, :array_0

    iput-object v4, p0, La/b;->mY:[Z

    iput-boolean v0, p0, La/b;->mZ:Z

    iput-boolean v0, p0, La/b;->jogaEstadual:Z

    iput-boolean v0, p0, La/b;->usaGrupoPadraoEstadual:Z

    iput-boolean v0, p0, La/b;->jogaIntClubes:Z

    iput-boolean v5, p0, La/b;->na:Z

    iput-boolean v5, p0, La/b;->nb:Z

    iput-boolean v0, p0, La/b;->salarioMensal:Z

    iput-boolean v0, p0, La/b;->jogaIntano1:Z

    iput-boolean v5, p0, La/b;->gruposIntPadrao:Z

    iput-boolean v0, p0, La/b;->jogaSelecoesAll:Z

    new-array v1, v1, [Z

    fill-array-data v1, :array_1

    iput-object v1, p0, La/b;->verJint:[Z

    iput-boolean v5, p0, La/b;->nc:Z

    iput-boolean v5, p0, La/b;->nd:Z

    iput-boolean v0, p0, La/b;->ne:Z

    const/4 v1, -0x1

    iput v1, p0, La/b;->nf:I

    iput v1, p0, La/b;->ng:I

    iput v1, p0, La/b;->nh:I

    iput v5, p0, La/b;->autoSalvar:I

    iput v7, p0, La/b;->velocidade:I

    iput v3, p0, La/b;->velocidadeNH:I

    iput v5, p0, La/b;->verDecisaoPenNaoHumano:I

    iput v0, p0, La/b;->verMudancaTecnicos:I

    iput v0, p0, La/b;->verJanelaSubs:I

    iput v5, p0, La/b;->avisoTerminoContrato:I

    iput-boolean v0, p0, La/b;->ignoraEstadual:Z

    iput-boolean v0, p0, La/b;->autoRenovaContrato:Z

    iput-boolean v0, p0, La/b;->usaCorPlacar:Z

    iput v5, p0, La/b;->corPlacar:I

    iput-boolean v0, p0, La/b;->usaSons:Z

    iput-boolean v0, p0, La/b;->negritoCasa:Z

    iput-boolean v0, p0, La/b;->usaCoresLista:Z

    iput-object v2, p0, La/b;->coresLista:[Landroid/graphics/Color;

    iput-boolean v5, p0, La/b;->verEstaduaisAgrupados:Z

    iput-boolean v0, p0, La/b;->ignoraLigas:Z

    iput-object v2, p0, La/b;->ni:Ljava/lang/String;

    iput-boolean v5, p0, La/b;->nj:Z

    const/4 v6, 0x1

    iput v6, p0, La/b;->nk:I

    iput v5, p0, La/b;->nl:I

    iput v5, p0, La/b;->nm:I

    iput v5, p0, La/b;->nn:I

    iput v5, p0, La/b;->no:I

    iput v5, p0, La/b;->np:I

    iput v5, p0, La/b;->nq:I

    const/4 v0, 0x2

    iput v0, p0, La/b;->nr:I

    const/4 v0, 0x2

    iput v0, p0, La/b;->ns:I

    const/4 v0, 0x1

    iput-boolean v0, p0, La/b;->nt:Z

    iput v1, p0, La/b;->nu:I

    iput v5, p0, La/b;->nv:I

    iput-object v2, p0, La/b;->nw:La/ac;

    iput-object v2, p0, La/b;->nx:La/t;

    iput-object v2, p0, La/b;->ny:Ljava/util/ArrayList;

    iput-boolean v5, p0, La/b;->nE:Z

    iput-boolean v5, p0, La/b;->nF:Z

    iput v5, p0, La/b;->nG:I

    iput-boolean v5, p0, La/b;->nH:Z

    iput-boolean v5, p0, La/b;->nI:Z

    iput-boolean v5, p0, La/b;->nJ:Z

    iput-boolean v5, p0, La/b;->nK:Z

    iput-object v2, p0, La/b;->nL:Ld/c;

    iput-object v2, p0, La/b;->nM:Ld/n;

    iput-object v2, p0, La/b;->nN:Ld/b;

    iput-object v2, p0, La/b;->nO:Ld/d;

    iput-object v2, p0, La/b;->nP:Ld/f;

    iput-object v2, p0, La/b;->nQ:Ld/e;

    iput-object v2, p0, La/b;->nR:Ld/o;

    iput-object v2, p0, La/b;->nS:Ld/l;

    iput-object v2, p0, La/b;->nT:Ld/j;

    iput-object v2, p0, La/b;->nU:Ld/g;

    iput-object v2, p0, La/b;->nV:Ld/h;

    iput-object v2, p0, La/b;->nW:Ld/k;

    iput-object v2, p0, La/b;->nX:Ld/i;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->nY:Ljava/util/ArrayList;

    iput v5, p0, La/b;->nZ:I

    iput-object v2, p0, La/b;->ob:Ljava/util/ArrayList;

    iput-object v2, p0, La/b;->oc:Ljava/util/ArrayList;

    iput-object v2, p0, La/b;->od:Ljava/util/ArrayList;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVerJint()[Z

    move-result-object v0

    invoke-virtual {p0, v0}, La/b;->setVerJint([Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isJogaIntano1()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setJogaIntano1(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isGruposIntPadrao()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setGruposIntPadrao(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isJogaIntClubes()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setJogaIntClubes(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isJogaSelecoesAll()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setJogaSelecoesAll(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isJogaEstadual()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setJogaEstadual(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isSalarioMensal()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setSalarioMensal(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isIgnoraEstadual()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setIgnoraEstadual(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isUsaGrupoPadraoEstadual()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setUsaGrupoPadraoEstadual(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAutoSalvar()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setAutoSalvar(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVelocidade()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setVelocidade(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVelocidadeNH()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setVelocidadeNH(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVerDecisaoPenNaoHumano()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setVerDecisaoPenNaoHumano(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVerMudancaTecnicos()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setVerMudancaTecnicos(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVerJanelaSubs()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setVerJanelaSubs(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAvisoTerminoContrato()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setAvisoTerminoContrato(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isIgnoraLigas()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setIgnoraLigas(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isAutoRenovaContrato()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setAutoRenovaContrato(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isUsaCorPlacar()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setUsaCorPlacar(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getCorPlacar()I

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setCorPlacar(I)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isUsaSons()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setUsaSons(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isUsaCoresLista()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setUsaCoresLista(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isNegritoCasa()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setNegritoCasa(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isVerEstaduaisAgrupados()Z

    move-result v0

    invoke-virtual {p0, v0}, La/b;->setVerEstaduaisAgrupados(Z)V

    :cond_0
    const-string v0, ""

    iput-object v0, p0, La/b;->bolaDeOuroHistory:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, La/b;->bolaDeOuroAno:I

    invoke-virtual {p0}, La/b;->da()V

    return-void

    nop

    :array_0
    .array-data 1
        0x0t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_1
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method

.method public static aq(I)La/ac;
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->mE()I

    move-result v2

    if-ne v2, p0, :cond_0

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/ac;

    return-object p0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->lh()La/ac;

    move-result-object v1

    if-eqz v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->lh()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->mE()I

    move-result v1

    if-ne v1, p0, :cond_2

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/y;

    invoke-virtual {p0}, La/y;->lh()La/ac;

    move-result-object p0

    return-object p0

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method public static ar(I)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->mE()I

    move-result v1

    if-ne v1, p0, :cond_0

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/ac;

    invoke-virtual {p0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const-string p0, ""

    return-object p0
.end method

.method private dB()V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kR()V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->nZ()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x0

    :goto_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3, v0}, Ld/q;->aD(Z)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    const/4 v1, 0x0

    :goto_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_a

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kK()I

    move-result v2

    const/16 v3, 0x1d

    if-ne v2, v3, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eA()Z

    move-result v2

    if-nez v2, :cond_3

    goto :goto_4

    :cond_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kK()I

    move-result v2

    if-ne v2, v3, :cond_9

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, La/y;->a(Ld/x;)V

    goto/16 :goto_8

    :cond_4
    :goto_4
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    :goto_5
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_6

    const/4 v4, 0x0

    :goto_6
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    invoke-virtual {v5}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/q;

    invoke-virtual {v5}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_5

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    invoke-virtual {v5}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/q;

    invoke-virtual {v5}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_6

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    :cond_6
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    sget-object v4, Lcomponents/ce;->oV:Ljava/util/Comparator;

    invoke-static {v3, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v4, 0x0

    :goto_7
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_8

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    :cond_8
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3, v2}, La/y;->J(Ljava/util/ArrayList;)Z

    :cond_9
    :goto_8
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_3

    :cond_a
    return-void
.end method

.method public static dC()V
    .locals 4

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    iget v1, v1, La/b;->mp:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cP()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Ld/q;

    if-eqz v2, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->xM()V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private do()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eE()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eE()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/aj;

    invoke-virtual {v3}, La/aj;->getY()I

    move-result v3

    add-int/lit8 v3, v3, 0x5

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->db()I

    move-result v4

    add-int/lit16 v4, v4, 0x7e0

    if-ge v3, v4, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eE()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eE()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method private dv()V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/b;->ms:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/b;->ms:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->iu()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/b;->ob:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/b;->od:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/b;->oc:Ljava/util/ArrayList;

    const/4 v1, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    iget-object v2, p0, La/b;->od:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iget-object v2, p0, La/b;->oc:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/q;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v3, v4}, La/q;->n(La/ac;)V

    goto :goto_2

    :cond_1
    iget-object v2, p0, La/b;->od:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/b;->od:Ljava/util/ArrayList;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    :cond_2
    iget-object v2, p0, La/b;->oc:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_3

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/b;->oc:Ljava/util/ArrayList;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_1

    :cond_4
    iget-object v1, p0, La/b;->od:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, La/b;->oc:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, La/b;->mr:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->iv()V

    goto :goto_3

    :cond_5
    iget-object v1, p0, La/b;->mr:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_6
    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-nez v2, :cond_6

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    goto :goto_4

    :cond_7
    iget-object v1, p0, La/b;->mr:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    goto :goto_5

    :cond_8
    iget-object v1, p0, La/b;->mr:Ljava/util/ArrayList;

    iget-object v2, p0, La/b;->ob:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v1, 0x0

    iput-object v1, p0, La/b;->ob:Ljava/util/ArrayList;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, La/b;->h(Z)V

    :goto_6
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_9

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->if()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_9
    return-void
.end method

.method private dw()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lM()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lJ()V

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lO()V

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lY()V

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lX()V

    :cond_0
    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    if-eqz v2, :cond_1

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    const/16 v3, 0x32

    invoke-virtual {v2, v3}, La/af;->cm(I)V

    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v2, v3}, La/af;->cn(I)V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_2
    :goto_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->me()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method private dy()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, La/b;->nt:Z

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dX()Ld/v;

    move-result-object v1

    invoke-virtual {v1, v0}, Ld/v;->cz(I)La/ac;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dV()Ld/t;

    move-result-object v1

    invoke-virtual {v1, v0}, Ld/t;->R(La/ac;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dX()Ld/v;

    move-result-object v1

    invoke-virtual {v1, v0}, Ld/v;->L(La/ac;)V

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dR()Ld/p;

    move-result-object v0

    if-eqz v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-boolean v0, p0, La/b;->nt:Z

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dU()Ld/ad;

    move-result-object v1

    invoke-virtual {v1, v0}, Ld/ad;->cz(I)La/ac;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dU()Ld/ad;

    move-result-object v1

    invoke-virtual {v1, v0}, Ld/ad;->L(La/ac;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dR()Ld/p;

    move-result-object v1

    invoke-virtual {v1, v0}, Ld/p;->M(La/ac;)V

    :cond_1
    return-void
.end method

.method private dz()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->kR()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x0

    :goto_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/m;

    invoke-virtual {v3}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/m;

    invoke-virtual {v3}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3, v0}, Ld/q;->aD(Z)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method private ef()V
    .locals 7

    invoke-static {}, La/a;->cI()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1}, La/a;->Y(I)Ljava/util/ArrayList;

    move-result-object v2

    iget-boolean v3, p0, La/b;->salarioMensal:Z

    if-ne v3, v1, :cond_0

    move-object v1, v0

    goto :goto_0

    :cond_0
    move-object v1, v2

    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_1

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x2

    invoke-static {v5, v6, v3}, La/a;->h(III)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x5

    invoke-static {v4, v5, v3}, La/a;->h(III)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_2
    const/4 v0, 0x0

    :goto_3
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x3

    invoke-static {v1, v4, v3}, La/a;->h(III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_3
    return-void
.end method

.method private fl()V
    .locals 6

    iget-object v0, p0, La/b;->mC:Ljava/util/ArrayList;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, La/b;->mC:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    :goto_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fm()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fm()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/ae;

    invoke-virtual {v0}, Ld/ae;->yM()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fm()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/ae;

    invoke-virtual {v0}, Ld/ae;->nZ()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v0, 0x0

    :goto_2
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kZ()Ld/x;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->db()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    invoke-virtual {v2, v3}, Ld/x;->cz(I)La/ac;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->db()I

    move-result v5

    sub-int/2addr v5, v4

    invoke-virtual {v3, v5}, La/y;->bL(I)[La/ac;

    move-result-object v3

    if-eqz v3, :cond_3

    aget-object v5, v3, v1

    if-eq v2, v5, :cond_2

    aget-object v2, v3, v1

    goto :goto_3

    :cond_2
    aget-object v2, v3, v4

    :cond_3
    :goto_3
    new-instance v2, Ld/ae;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kK()I

    move-result v3

    invoke-direct {v2, v3}, Ld/ae;-><init>(I)V

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mC:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2}, Ld/ae;->yM()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method public static newDay()La/a;
    .locals 1

    new-instance v0, La/a;

    invoke-direct {v0}, La/a;-><init>()V

    return-object v0
.end method

.method public static newJunior()La/q;
    .locals 1

    new-instance v0, La/q;

    invoke-direct {v0}, La/q;-><init>()V

    return-object v0
.end method


# virtual methods
.method public a(La/ac;I)La/af;
    .locals 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v2, v5, :cond_6

    const/4 v5, -0x1

    if-ne p2, v5, :cond_0

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_2

    :cond_0
    if-nez p2, :cond_1

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v3

    :goto_1
    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v4

    goto :goto_2

    :cond_1
    const/4 v5, 0x1

    if-ne p2, v5, :cond_2

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v3

    sub-int/2addr v3, v5

    goto :goto_1

    :cond_2
    const/4 v6, 0x2

    if-ne p2, v6, :cond_3

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v3

    sub-int/2addr v3, v6

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v4

    add-int/2addr v4, v5

    :cond_3
    :goto_2
    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->hE()La/ac;

    move-result-object v5

    if-nez v5, :cond_5

    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-nez v5, :cond_5

    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->hE()La/ac;

    move-result-object v5

    if-eq v5, p1, :cond_5

    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->eN()I

    move-result v5

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result v6

    if-eq v5, v6, :cond_4

    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->mS()I

    move-result v5

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result v6

    if-ne v5, v6, :cond_5

    :cond_4
    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->getReputacao()I

    move-result v5

    if-lt v5, v3, :cond_5

    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/af;

    invoke-virtual {v5}, La/af;->getReputacao()I

    move-result v5

    if-gt v5, v4, :cond_5

    iget-object v5, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_8

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    const/16 p2, 0x64

    invoke-virtual {p1, p2}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    const/16 p2, 0x32

    if-ge p1, p2, :cond_7

    sget-object p1, La/b;->oe:Ljava/util/Comparator;

    invoke-static {v0, p1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    goto :goto_3

    :cond_7
    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    :cond_8
    :goto_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_9

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/af;

    return-object p1

    :cond_9
    const/4 p1, 0x0

    return-object p1
.end method

.method public a(La/af;Z)Ljava/util/ArrayList;
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La/af;",
            "Z)",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    move-object/from16 v0, p0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iget v5, v0, La/b;->nk:I

    const/4 v6, 0x1

    sub-int/2addr v5, v6

    iget v7, v0, La/b;->mo:I

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x0

    if-ne v5, v7, :cond_7

    new-array v5, v12, [Ld/q;

    aput-object v11, v5, v14

    aput-object v11, v5, v6

    aput-object v11, v5, v10

    aput-object v11, v5, v9

    aput-object v11, v5, v8

    aput-object v11, v5, v13

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->fp()Ld/j;

    move-result-object v7

    if-eqz v7, :cond_0

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->fp()Ld/j;

    move-result-object v7

    invoke-virtual {v7}, Ld/j;->getFaseGrupos()Ld/q;

    move-result-object v7

    aput-object v7, v5, v14

    :cond_0
    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->fo()Ld/l;

    move-result-object v7

    if-eqz v7, :cond_1

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->fo()Ld/l;

    move-result-object v7

    invoke-virtual {v7}, Ld/l;->getFaseGrupos()Ld/q;

    move-result-object v7

    aput-object v7, v5, v6

    :cond_1
    sget-object v7, Lc/a;->TF:La/b;

    iget-object v7, v7, La/b;->elimccCopa:Ld/elimcc;

    if-eqz v7, :cond_2

    invoke-virtual {v7}, Ld/elimcc;->getFaseGrupos()Ld/q;

    move-result-object v7

    invoke-static {v7, v2}, Lcom/brasfoot/v2028/Recopa;->addConcacafQualifiers(Ld/q;Ljava/util/ArrayList;)V

    :cond_2
    sget-object v7, Lc/a;->TF:La/b;

    iget-object v7, v7, La/b;->africaElimCopa:Ld/elimaf;

    if-eqz v7, :cond_3

    invoke-virtual {v7}, Ld/elimaf;->getFaseGrupos()Ld/q;

    move-result-object v7

    invoke-static {v7, v2}, Lcom/brasfoot/v2028/Recopa;->addAfricaQualifiers(Ld/q;Ljava/util/ArrayList;)V

    :cond_3
    const/4 v7, 0x0

    :goto_0
    array-length v15, v5

    if-ge v7, v15, :cond_6

    aget-object v15, v5, v7

    if-eqz v15, :cond_5

    const/4 v15, 0x0

    :goto_1
    aget-object v11, v5, v7

    invoke-virtual {v11}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v15, v11, :cond_5

    aget-object v11, v5, v7

    invoke-virtual {v11}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/ac;

    invoke-virtual {v11}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v11

    if-nez v11, :cond_4

    aget-object v11, v5, v7

    invoke-virtual {v11}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v15, v15, 0x1

    goto :goto_1

    :cond_5
    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x0

    goto :goto_0

    :cond_6
    const/4 v5, 0x1

    goto :goto_2

    :cond_7
    const/4 v5, 0x0

    :goto_2
    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->fe()Ld/o;

    move-result-object v7

    if-eqz v7, :cond_a

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->fe()Ld/o;

    move-result-object v7

    invoke-virtual {v7}, Ld/o;->getFaseGrupos()Ld/q;

    move-result-object v7

    if-eqz v7, :cond_a

    const/4 v7, 0x0

    :goto_3
    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->fe()Ld/o;

    move-result-object v11

    invoke-virtual {v11}, Ld/o;->getFaseGrupos()Ld/q;

    move-result-object v11

    invoke-virtual {v11}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v7, v11, :cond_9

    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->fe()Ld/o;

    move-result-object v11

    invoke-virtual {v11}, Ld/o;->getFaseGrupos()Ld/q;

    move-result-object v11

    invoke-virtual {v11}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/ac;

    invoke-virtual {v11}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v11

    if-nez v11, :cond_8

    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->fe()Ld/o;

    move-result-object v11

    invoke-virtual {v11}, Ld/o;->getFaseGrupos()Ld/q;

    move-result-object v11

    invoke-virtual {v11}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_9
    const/4 v7, 0x1

    goto :goto_4

    :cond_a
    const/4 v7, 0x0

    :goto_4
    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->fg()Ld/n;

    move-result-object v11

    if-eqz v11, :cond_d

    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->fg()Ld/n;

    move-result-object v11

    invoke-virtual {v11}, Ld/n;->getFaseGrupos()Ld/q;

    move-result-object v11

    if-eqz v11, :cond_d

    const/4 v11, 0x0

    :goto_5
    sget-object v15, Lc/a;->TF:La/b;

    invoke-virtual {v15}, La/b;->fg()Ld/n;

    move-result-object v15

    invoke-virtual {v15}, Ld/n;->getFaseGrupos()Ld/q;

    move-result-object v15

    invoke-virtual {v15}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v15

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-ge v11, v15, :cond_c

    sget-object v15, Lc/a;->TF:La/b;

    invoke-virtual {v15}, La/b;->fg()Ld/n;

    move-result-object v15

    invoke-virtual {v15}, Ld/n;->getFaseGrupos()Ld/q;

    move-result-object v15

    invoke-virtual {v15}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v15

    invoke-virtual {v15, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, La/ac;

    invoke-virtual {v15}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    if-nez v15, :cond_b

    sget-object v15, Lc/a;->TF:La/b;

    invoke-virtual {v15}, La/b;->fg()Ld/n;

    move-result-object v15

    invoke-virtual {v15}, Ld/n;->getFaseGrupos()Ld/q;

    move-result-object v15

    invoke-virtual {v15}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v15

    invoke-virtual {v15, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_b
    add-int/lit8 v11, v11, 0x1

    goto :goto_5

    :cond_c
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_d
    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->ff()Ld/c;

    move-result-object v11

    if-eqz v11, :cond_10

    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->ff()Ld/c;

    move-result-object v11

    invoke-virtual {v11}, Ld/c;->getFaseGrupos()Ld/q;

    move-result-object v11

    if-eqz v11, :cond_10

    const/4 v11, 0x0

    :goto_6
    sget-object v15, Lc/a;->TF:La/b;

    invoke-virtual {v15}, La/b;->ff()Ld/c;

    move-result-object v15

    invoke-virtual {v15}, Ld/c;->getFaseGrupos()Ld/q;

    move-result-object v15

    invoke-virtual {v15}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v15

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-ge v11, v15, :cond_f

    sget-object v15, Lc/a;->TF:La/b;

    invoke-virtual {v15}, La/b;->ff()Ld/c;

    move-result-object v15

    invoke-virtual {v15}, Ld/c;->getFaseGrupos()Ld/q;

    move-result-object v15

    invoke-virtual {v15}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v15

    invoke-virtual {v15, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, La/ac;

    invoke-virtual {v15}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    if-nez v15, :cond_e

    sget-object v15, Lc/a;->TF:La/b;

    invoke-virtual {v15}, La/b;->ff()Ld/c;

    move-result-object v15

    invoke-virtual {v15}, Ld/c;->getFaseGrupos()Ld/q;

    move-result-object v15

    invoke-virtual {v15}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v15

    invoke-virtual {v15, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_e
    add-int/lit8 v11, v11, 0x1

    goto :goto_6

    :cond_f
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_10
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-lez v11, :cond_28

    invoke-static {v2}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    new-array v11, v12, [[I

    new-array v15, v13, [I

    fill-array-data v15, :array_0

    aput-object v15, v11, v14

    new-array v15, v13, [I

    fill-array-data v15, :array_1

    aput-object v15, v11, v6

    new-array v15, v13, [I

    fill-array-data v15, :array_2

    aput-object v15, v11, v10

    new-array v15, v13, [I

    fill-array-data v15, :array_3

    aput-object v15, v11, v9

    new-array v15, v13, [I

    fill-array-data v15, :array_4

    aput-object v15, v11, v8

    new-array v15, v13, [I

    fill-array-data v15, :array_5

    aput-object v15, v11, v13

    new-array v15, v12, [[I

    new-array v8, v13, [I

    fill-array-data v8, :array_6

    aput-object v8, v15, v14

    new-array v8, v12, [I

    fill-array-data v8, :array_7

    aput-object v8, v15, v6

    new-array v8, v12, [I

    fill-array-data v8, :array_8

    aput-object v8, v15, v10

    new-array v8, v12, [I

    fill-array-data v8, :array_9

    aput-object v8, v15, v9

    new-array v8, v12, [I

    fill-array-data v8, :array_a

    const/16 v16, 0x4

    aput-object v8, v15, v16

    new-array v8, v12, [I

    fill-array-data v8, :array_b

    aput-object v8, v15, v13

    invoke-virtual/range {p1 .. p1}, La/af;->getReputacao()I

    move-result v8

    invoke-virtual/range {p1 .. p1}, La/af;->hE()La/ac;

    move-result-object v17

    if-eqz v17, :cond_11

    invoke-virtual/range {p1 .. p1}, La/af;->hE()La/ac;

    move-result-object v9

    invoke-virtual {v9}, La/ac;->getReputacao()I

    move-result v9

    if-le v9, v8, :cond_11

    invoke-virtual/range {p1 .. p1}, La/af;->hE()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getReputacao()I

    move-result v8

    :cond_11
    aget-object v9, v11, v8

    if-eqz v5, :cond_18

    aget-object v9, v15, v8

    new-array v8, v12, [I

    fill-array-data v8, :array_c

    new-array v11, v12, [I

    fill-array-data v11, :array_d

    invoke-virtual/range {p1 .. p1}, La/af;->mS()I

    move-result v12

    invoke-virtual {v0, v12}, La/b;->al(I)La/y;

    move-result-object v12

    invoke-virtual {v12}, La/y;->iw()I

    move-result v12

    invoke-virtual/range {p1 .. p1}, La/af;->hE()La/ac;

    move-result-object v15

    if-eqz v15, :cond_13

    invoke-virtual/range {p1 .. p1}, La/af;->hE()La/ac;

    move-result-object v15

    invoke-virtual {v15}, La/ac;->iw()I

    move-result v15

    if-nez v15, :cond_12

    const/16 v15, 0xc

    aput v15, v8, v14

    const/4 v15, 0x7

    aput v15, v8, v14

    goto :goto_7

    :cond_12
    invoke-virtual/range {p1 .. p1}, La/af;->hE()La/ac;

    move-result-object v15

    invoke-virtual {v15}, La/ac;->iw()I

    move-result v15

    if-ne v15, v6, :cond_13

    const/16 v15, 0x9

    aput v15, v8, v14

    const/16 v15, 0xa

    aput v15, v8, v6

    :cond_13
    :goto_7
    const/4 v15, 0x0

    :goto_8
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v14

    if-ge v15, v14, :cond_17

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La/ac;

    invoke-virtual {v14}, La/ac;->iw()I

    move-result v14

    aget v14, v11, v14

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v13, v17

    check-cast v13, La/ac;

    invoke-virtual {v13}, La/ac;->iw()I

    move-result v13

    aget v13, v8, v13

    if-ge v14, v13, :cond_14

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_14

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/ac;

    invoke-virtual {v13}, La/ac;->iw()I

    move-result v13

    aget v14, v11, v13

    add-int/2addr v14, v6

    aput v14, v11, v13

    :cond_14
    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/ac;

    invoke-virtual {v13}, La/ac;->iw()I

    move-result v13

    if-ne v12, v13, :cond_15

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/ac;

    invoke-virtual {v13}, La/ac;->getReputacao()I

    move-result v13

    const/4 v14, 0x4

    if-lt v13, v14, :cond_16

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_16

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_15
    const/4 v14, 0x4

    :cond_16
    :goto_9
    add-int/lit8 v15, v15, 0x1

    const/4 v13, 0x5

    goto :goto_8

    :cond_17
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-lez v8, :cond_18

    move-object v2, v3

    :cond_18
    if-nez v7, :cond_25

    if-nez v5, :cond_25

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-gtz v3, :cond_19

    goto/16 :goto_12

    :cond_19
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_28

    const/4 v3, 0x0

    const/4 v5, 0x0

    :goto_a
    if-ge v3, v10, :cond_20

    move v8, v5

    const/4 v5, 0x0

    const/4 v7, 0x0

    :goto_b
    array-length v11, v9

    if-ge v5, v11, :cond_1f

    aget v11, v9, v5

    if-lt v11, v6, :cond_1e

    const/4 v11, 0x0

    :goto_c
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v12

    if-ge v11, v12, :cond_1e

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/ac;

    invoke-virtual {v12}, La/ac;->getReputacao()I

    move-result v12

    aget v13, v9, v5

    if-ne v12, v13, :cond_1d

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/ac;

    invoke-virtual {v12}, La/ac;->iw()I

    move-result v12

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Integer;

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    if-ne v12, v13, :cond_1d

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_1d

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    const/4 v13, 0x5

    if-ne v12, v13, :cond_1a

    if-nez v8, :cond_1a

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x1

    goto :goto_d

    :cond_1a
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-eq v12, v13, :cond_1b

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1b
    :goto_d
    add-int/lit8 v7, v7, 0x1

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v7, v11, :cond_1c

    goto :goto_e

    :cond_1c
    const/4 v7, 0x0

    goto :goto_e

    :cond_1d
    add-int/lit8 v11, v11, 0x1

    goto :goto_c

    :cond_1e
    :goto_e
    add-int/lit8 v5, v5, 0x1

    goto :goto_b

    :cond_1f
    add-int/lit8 v3, v3, 0x1

    move v5, v8

    goto/16 :goto_a

    :cond_20
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    array-length v4, v9

    if-ge v3, v4, :cond_28

    const/4 v3, 0x0

    :goto_f
    array-length v4, v9

    if-ge v3, v4, :cond_28

    aget v4, v9, v3

    if-lt v4, v6, :cond_23

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    array-length v7, v9

    if-ge v4, v7, :cond_23

    const/4 v4, 0x0

    :goto_10
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_23

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->getReputacao()I

    move-result v7

    aget v8, v9, v3

    if-ne v7, v8, :cond_22

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_22

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->iw()I

    move-result v7

    const/4 v8, 0x5

    if-ne v7, v8, :cond_21

    if-nez v5, :cond_21

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    goto :goto_11

    :cond_21
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->iw()I

    move-result v7

    if-eq v7, v8, :cond_24

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_11

    :cond_22
    const/4 v8, 0x5

    add-int/lit8 v4, v4, 0x1

    goto :goto_10

    :cond_23
    const/4 v8, 0x5

    :cond_24
    :goto_11
    add-int/lit8 v3, v3, 0x1

    goto :goto_f

    :cond_25
    :goto_12
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_28

    const/4 v3, 0x0

    :goto_13
    array-length v4, v9

    if-ge v3, v4, :cond_28

    aget v4, v9, v3

    if-lt v4, v6, :cond_27

    const/4 v4, 0x0

    :goto_14
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_27

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    invoke-virtual {v5}, La/ac;->getReputacao()I

    move-result v5

    aget v7, v9, v3

    if-ne v5, v7, :cond_26

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_26

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_15

    :cond_26
    add-int/lit8 v4, v4, 0x1

    goto :goto_14

    :cond_27
    :goto_15
    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    :cond_28
    const/4 v3, -0x1

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_29

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/af;

    invoke-virtual {v3}, La/af;->mS()I

    move-result v3

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    move-object v11, v5

    check-cast v11, La/af;

    goto :goto_16

    :cond_29
    const/4 v4, 0x0

    const/4 v11, 0x0

    :goto_16
    if-ltz v3, :cond_2f

    const/4 v5, 0x0

    const/4 v7, 0x0

    :goto_17
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v4, v8, :cond_2d

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/ac;

    invoke-virtual {v8}, La/ac;->getPais()I

    move-result v8

    if-ne v8, v3, :cond_2a

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/ac;

    invoke-virtual {v8}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-nez v8, :cond_2a

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_2a

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/ac;

    invoke-virtual {v8}, La/ac;->getNivel()I

    move-result v8

    const/16 v9, 0x12

    if-ge v8, v9, :cond_2b

    const/4 v5, 0x1

    :cond_2a
    const/4 v9, 0x3

    goto :goto_18

    :cond_2b
    if-eqz v11, :cond_2a

    invoke-virtual {v11}, La/af;->hE()La/ac;

    move-result-object v8

    if-eqz v8, :cond_2a

    invoke-virtual {v11}, La/af;->hE()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getReputacao()I

    move-result v8

    const/4 v9, 0x3

    if-lt v8, v9, :cond_2c

    const/4 v5, 0x1

    :cond_2c
    :goto_18
    add-int/lit8 v4, v4, 0x1

    goto :goto_17

    :cond_2d
    if-eqz v5, :cond_2f

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-nez v2, :cond_2e

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v1

    :cond_2e
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v6

    invoke-virtual {v1, v2, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_2f
    return-object v1

    nop

    :array_0
    .array-data 4
        0x2
        0x1
        0x1
        -0x1
        -0x1
    .end array-data

    :array_1
    .array-data 4
        0x2
        0x2
        0x1
        0x1
        0x1
    .end array-data

    :array_2
    .array-data 4
        0x3
        0x2
        0x2
        0x1
        0x1
    .end array-data

    :array_3
    .array-data 4
        0x4
        0x3
        0x2
        0x2
        0x1
    .end array-data

    :array_4
    .array-data 4
        0x5
        0x4
        0x5
        0x3
        0x2
    .end array-data

    :array_5
    .array-data 4
        0x5
        0x4
        0x4
        0x3
        0x2
    .end array-data

    :array_6
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_7
    .array-data 4
        0x2
        0x2
        0x1
        0x1
        0x1
        0x1
    .end array-data

    :array_8
    .array-data 4
        0x2
        0x2
        0x1
        0x1
        0x1
        0x1
    .end array-data

    :array_9
    .array-data 4
        0x4
        0x3
        0x2
        0x2
        0x2
        0x1
    .end array-data

    :array_a
    .array-data 4
        0x5
        0x4
        0x4
        0x3
        0x2
        0x1
    .end array-data

    :array_b
    .array-data 4
        0x5
        0x5
        0x4
        0x4
        0x3
        0x2
    .end array-data

    :array_c
    .array-data 4
        0xc
        0x7
        0x7
        0x8
        0xa
        0xa
    .end array-data

    :array_d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public a(La/a;)V
    .locals 1

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(La/ac;La/af;La/af;)V
    .locals 0

    if-eqz p2, :cond_0

    invoke-virtual {p2, p3}, La/af;->f(La/af;)V

    :cond_0
    if-eqz p3, :cond_1

    invoke-virtual {p3, p1}, La/af;->A(La/ac;)V

    :cond_1
    return-void
.end method

.method public a(La/ac;La/t;)V
    .locals 0

    iput-object p1, p0, La/b;->nw:La/ac;

    iput-object p2, p0, La/b;->nx:La/t;

    return-void
.end method

.method public a(La/af;)V
    .locals 1

    iget-object v0, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(La/af;La/af;)V
    .locals 2

    invoke-virtual {p1}, La/af;->hE()La/ac;

    move-result-object v0

    invoke-virtual {p2}, La/af;->hE()La/ac;

    move-result-object v1

    invoke-virtual {p1, p2}, La/af;->f(La/af;)V

    invoke-virtual {p2, p1}, La/af;->f(La/af;)V

    invoke-virtual {p1, v1}, La/af;->A(La/ac;)V

    invoke-virtual {p2, v0}, La/af;->A(La/ac;)V

    return-void
.end method

.method public a(La/p;)V
    .locals 1

    iget-object v0, p0, La/b;->mr:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(La/y;)V
    .locals 1

    iget-object v0, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(Ld/aa;)V
    .locals 0

    iput-object p1, p0, La/b;->mP:Ld/aa;

    return-void
.end method

.method public a(Ld/ab;I)V
    .locals 1

    iget-object v0, p0, La/b;->mX:[Ld/ab;

    aput-object p1, v0, p2

    return-void
.end method

.method public a(Ld/ad;)V
    .locals 0

    iput-object p1, p0, La/b;->mW:Ld/ad;

    return-void
.end method

.method public a(Ld/ag;)V
    .locals 0

    iput-object p1, p0, La/b;->ma:Ld/ag;

    return-void
.end method

.method public a(Ld/b;)V
    .locals 0

    iput-object p1, p0, La/b;->nN:Ld/b;

    return-void
.end method

.method public a(Ld/c;)V
    .locals 0

    iput-object p1, p0, La/b;->nL:Ld/c;

    return-void
.end method

.method public a(Ld/d;)V
    .locals 0

    iput-object p1, p0, La/b;->nO:Ld/d;

    return-void
.end method

.method public a(Ld/f;)V
    .locals 0

    iput-object p1, p0, La/b;->nP:Ld/f;

    return-void
.end method

.method public a(Ld/j;)V
    .locals 0

    iput-object p1, p0, La/b;->nT:Ld/j;

    return-void
.end method

.method public a(Ld/l;)V
    .locals 0

    iput-object p1, p0, La/b;->nS:Ld/l;

    return-void
.end method

.method public a(Ld/n;)V
    .locals 0

    iput-object p1, p0, La/b;->nM:Ld/n;

    return-void
.end method

.method public a(Ld/o;)V
    .locals 0

    iput-object p1, p0, La/b;->nR:Ld/o;

    return-void
.end method

.method public a(Ld/p;)V
    .locals 0

    iput-object p1, p0, La/b;->mN:Ld/p;

    return-void
.end method

.method public a(Ld/r;)V
    .locals 0

    iput-object p1, p0, La/b;->mT:Ld/r;

    return-void
.end method

.method public a(Ld/s;)V
    .locals 0

    iput-object p1, p0, La/b;->mS:Ld/s;

    return-void
.end method

.method public a(Ld/t;)V
    .locals 0

    iput-object p1, p0, La/b;->mM:Ld/t;

    return-void
.end method

.method public a(Ld/u;)V
    .locals 0

    iput-object p1, p0, La/b;->mU:Ld/u;

    return-void
.end method

.method public a(Ld/v;)V
    .locals 0

    iput-object p1, p0, La/b;->mR:Ld/v;

    return-void
.end method

.method public a(Ld/w;)V
    .locals 0

    iput-object p1, p0, La/b;->mV:Ld/w;

    return-void
.end method

.method public a(Ld/y;)V
    .locals 0

    iput-object p1, p0, La/b;->mL:Ld/y;

    return-void
.end method

.method public a(Ld/z;)V
    .locals 0

    iput-object p1, p0, La/b;->mQ:Ld/z;

    return-void
.end method

.method public a(Lest/InfoArquivoSalvoType;)V
    .locals 0

    iput-object p1, p0, La/b;->mm:Lest/InfoArquivoSalvoType;

    return-void
.end method

.method public a([Z)V
    .locals 0

    iput-object p1, p0, La/b;->mY:[Z

    return-void
.end method

.method public ac(I)V
    .locals 0

    iput p1, p0, La/b;->nZ:I

    return-void
.end method

.method public ad(I)V
    .locals 0

    iput p1, p0, La/b;->mo:I

    return-void
.end method

.method public ae(I)V
    .locals 0

    iput p1, p0, La/b;->mp:I

    return-void
.end method

.method public af(I)Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/a;

    invoke-virtual {p1}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method

.method public ag(I)Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/ArrayList<",
            "Lcomponents/be;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v2, :cond_0

    :goto_0
    iget-object p1, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v1, p1, :cond_1

    iget-object p1, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    invoke-virtual {p1, v0}, La/y;->K(Ljava/util/ArrayList;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    if-ne p1, v2, :cond_1

    :goto_1
    iget-object p1, p0, La/b;->mB:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v1, p1, :cond_1

    iget-object p1, p0, La/b;->mB:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld/m;

    invoke-virtual {p1, v0}, Ld/m;->K(Ljava/util/ArrayList;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_2

    return-object v0

    :cond_2
    const/4 p1, 0x0

    return-object p1
.end method

.method public ah(I)La/y;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kK()I

    move-result v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public ai(I)Ld/m;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mB:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/b;->mB:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld/m;

    invoke-virtual {v1}, Ld/m;->getEstado()I

    move-result v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/b;->mB:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld/m;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public aj(I)V
    .locals 2

    const/4 v0, 0x0

    if-nez p1, :cond_1

    const/4 p1, 0x0

    :goto_0
    iget v1, p0, La/b;->mp:I

    if-gt p1, v1, :cond_3

    iget-object v1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cW()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_0

    iget-object v1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1, v0}, La/a;->ab(I)V

    :cond_0
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    iget p1, p0, La/b;->mp:I

    if-gt v0, p1, :cond_3

    iget-object p1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/a;

    invoke-virtual {p1}, La/a;->cX()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_2

    iget-object p1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/a;

    const/4 v1, 0x1

    invoke-virtual {p1, v1}, La/a;->ab(I)V

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method public ak(I)V
    .locals 10

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v7

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, v7

    move v1, p1

    invoke-virtual/range {v0 .. v6}, Ljava/util/Calendar;->set(IIIIII)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x1

    invoke-virtual {v7, v2}, Ljava/util/Calendar;->get(I)I

    move-result v3

    if-ne v3, p1, :cond_1

    new-instance v3, La/a;

    invoke-direct {v3}, La/a;-><init>()V

    invoke-virtual {v7, v2}, Ljava/util/Calendar;->get(I)I

    move-result v4

    const/4 v5, 0x2

    invoke-virtual {v7, v5}, Ljava/util/Calendar;->get(I)I

    move-result v6

    const/4 v8, 0x5

    invoke-virtual {v7, v8}, Ljava/util/Calendar;->get(I)I

    move-result v9

    invoke-virtual {v3, v4, v6, v9}, La/a;->g(III)V

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4, v3}, La/b;->a(La/a;)V

    invoke-virtual {v7, v5}, Ljava/util/Calendar;->get(I)I

    move-result v3

    if-nez v3, :cond_0

    const/4 v3, 0x7

    invoke-virtual {v7, v3}, Ljava/util/Calendar;->get(I)I

    move-result v3

    if-ne v3, v2, :cond_0

    add-int/lit8 v0, v0, 0x1

    if-ne v0, v2, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3, v1}, La/b;->ae(I)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v7, v8, v2}, Ljava/util/Calendar;->add(II)V

    goto :goto_0

    :cond_1
    invoke-direct {p0}, La/b;->ef()V

    return-void
.end method

.method public al(I)La/y;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/b;->mA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kK()I

    move-result v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/b;->mA:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public am(I)Z
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bv;

    invoke-virtual {v2}, Lcomponents/bv;->getPais()I

    move-result v2

    if-ne v2, p1, :cond_0

    iget-object v2, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bv;

    invoke-virtual {v2}, Lcomponents/bv;->uU()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public an(I)V
    .locals 0

    iput p1, p0, La/b;->nf:I

    return-void
.end method

.method public ao(I)V
    .locals 0

    iput p1, p0, La/b;->ng:I

    return-void
.end method

.method public ap(I)V
    .locals 0

    iput p1, p0, La/b;->nh:I

    return-void
.end method

.method public appendBolaDeOuroHistory(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, La/b;->bolaDeOuroHistory:Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, ""

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_1
    const-string v0, "\n---\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_0
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/b;->bolaDeOuroHistory:Ljava/lang/String;

    return-void
.end method

.method public as(I)V
    .locals 0

    iput p1, p0, La/b;->mq:I

    return-void
.end method

.method public at(I)V
    .locals 0

    iput p1, p0, La/b;->nv:I

    return-void
.end method

.method public au(I)La/af;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->getUniqueId()I

    move-result v1

    if-ne v1, p1, :cond_0

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->df()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/af;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public b(La/af;Z)Ljava/util/ArrayList;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La/af;",
            "Z)",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, La/af;->mS()I

    move-result v1

    invoke-virtual {p0, v1}, La/b;->ah(I)La/y;

    move-result-object v1

    invoke-virtual {p1}, La/af;->eN()I

    move-result v2

    invoke-virtual {p0, v2}, La/b;->al(I)La/y;

    move-result-object v2

    const/4 v3, 0x1

    if-eqz v2, :cond_0

    invoke-virtual {v2, v0, p1, p2, v3}, La/y;->a(Ljava/util/ArrayList;La/af;ZZ)V

    :cond_0
    const/4 v4, 0x0

    if-eqz v1, :cond_1

    if-eq v1, v2, :cond_1

    invoke-virtual {v1, v0, p1, p2, v4}, La/y;->a(Ljava/util/ArrayList;La/af;ZZ)V

    :cond_1
    invoke-virtual {p1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-virtual {p1}, La/af;->mU()I

    move-result v5

    const/4 v6, 0x2

    if-lt v5, v6, :cond_3

    invoke-virtual {p1}, La/af;->getReputacao()I

    move-result v5

    const/4 v6, 0x3

    if-le v5, v6, :cond_2

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    :cond_3
    :goto_0
    if-eqz v3, :cond_7

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iget-object v5, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_7

    const/4 v5, 0x0

    :goto_1
    iget-object v6, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_5

    iget-object v6, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-eq v6, v2, :cond_4

    iget-object v6, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-eq v6, v1, :cond_4

    iget-object v6, p0, La/b;->mz:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_5
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_7

    invoke-static {v3}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 v1, 0x0

    :goto_2
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_7

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2, v0, p1, p2, v4}, La/y;->a(Ljava/util/ArrayList;La/af;ZZ)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v5, 0x6

    if-le v2, v5, :cond_6

    return-object v0

    :cond_6
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_7
    return-object v0
.end method

.method public b(La/ac;)V
    .locals 1

    iget-object v0, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public b(La/af;)V
    .locals 1

    iget-object v0, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public b(La/p;)V
    .locals 2

    iget-object v0, p0, La/b;->mG:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bn;

    invoke-virtual {v1}, Lcomponents/bn;->nD()La/p;

    move-result-object v1

    if-ne v1, p1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_1
    if-ltz v0, :cond_2

    sget-object p1, Lc/a;->TF:La/b;

    iget-object p1, p1, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public b(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mv:Ljava/util/ArrayList;

    return-void
.end method

.method public c(La/ac;)I
    .locals 12

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    array-length v4, v0

    if-ge v2, v4, :cond_1

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/4 v5, 0x3

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {p1}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/16 v5, 0x12

    if-ge v4, v5, :cond_0

    aget v7, v0, v2

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    move-object v6, p1

    invoke-static/range {v6 .. v11}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    add-int/lit8 v3, v3, 0x1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v3

    nop

    :array_0
    .array-data 4
        0x0
        0x1
        0x2
        0x3
        0x3
        0x4
    .end array-data
.end method

.method public c(IZ)Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ)",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    move-object v0, v2

    :goto_1
    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/af;->hE()La/ac;

    move-result-object v1

    if-nez v1, :cond_2

    :goto_2
    invoke-virtual {p0, v0, p1}, La/b;->b(La/af;Z)Ljava/util/ArrayList;

    move-result-object v2

    return-object v2

    :cond_2
    if-eqz p2, :cond_3

    const/4 p1, 0x1

    goto :goto_2

    :cond_3
    return-object v2
.end method

.method public c(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mw:Ljava/util/ArrayList;

    return-void
.end method

.method public cZ()I
    .locals 1

    iget v0, p0, La/b;->nZ:I

    return v0
.end method

.method public d(La/ac;)V
    .locals 1

    iget-object v0, p0, La/b;->mu:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public d(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mr:Ljava/util/ArrayList;

    return-void
.end method

.method public d0()Ld/ag;
    .locals 1

    iget-object v0, p0, La/b;->ma:Ld/ag;

    return-object v0
.end method

.method public dA()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    const/4 v2, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3, v2}, Ld/q;->cB(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_2
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2, v0}, La/p;->bj(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_2
    const/4 v1, 0x0

    :goto_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    const/4 v2, 0x0

    :goto_4
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->oc()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->oc()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->hB()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_4
    return-void
.end method

.method public dD()I
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    return v0

    :cond_0
    const/4 v0, -0x1

    return v0
.end method

.method public dE()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, La/b;->mG:Ljava/util/ArrayList;

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    const/4 v1, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_2

    :try_start_0
    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bn;

    invoke-virtual {v3}, Lcomponents/bn;->uC()Ljava/util/Calendar;

    move-result-object v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->en()Ljava/util/Calendar;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/Calendar;->before(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bn;

    invoke-virtual {v3}, Lcomponents/bn;->nD()La/p;

    move-result-object v3

    if-eqz v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bn;

    invoke-virtual {v3}, Lcomponents/bn;->uD()La/ac;

    move-result-object v3

    if-eqz v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bn;

    invoke-virtual {v3}, Lcomponents/bn;->nD()La/p;

    move-result-object v3

    sget-object v4, Lc/a;->TF:La/b;

    iget-object v4, v4, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bn;

    invoke-virtual {v4}, Lcomponents/bn;->uD()La/ac;

    move-result-object v4

    invoke-virtual {v3, v4}, La/p;->m(La/ac;)V

    :cond_0
    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_3

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v2, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->mG:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    return-void
.end method

.method public dF()V
    .locals 7

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_0

    new-instance v3, Lcomponents/ck;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    invoke-virtual {v5}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->hJ()I

    move-result v5

    const/4 v6, 0x1

    invoke-direct {v3, v4, v5, v6, v6}, Lcomponents/ck;-><init>(La/p;IZZ)V

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public dG()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, La/b;->mH:Ljava/util/ArrayList;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->mH:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_1

    const/4 v1, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mH:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mH:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bi;

    invoke-virtual {v3}, Lcomponents/bi;->ub()Ljava/util/Calendar;

    move-result-object v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->en()Ljava/util/Calendar;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/Calendar;->before(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mH:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bi;

    invoke-virtual {v3}, Lcomponents/bi;->uc()V

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->mH:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v2, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->mH:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public dH()Z
    .locals 5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    iget v1, v1, La/b;->mp:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_2

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lE()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    :goto_1
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/t;

    invoke-virtual {p0, v1, v0}, La/b;->a(La/ac;La/t;)V

    return v4

    :cond_0
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lE()Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public dI()La/ac;
    .locals 1

    iget-object v0, p0, La/b;->nw:La/ac;

    return-object v0
.end method

.method public dJ()I
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget v0, v0, La/b;->mp:I

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cJ()Z

    move-result v1

    if-nez v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cG()I

    move-result v1

    if-lez v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0}, La/b;->ae(I)V

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public dK()I
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget v0, v0, La/b;->mp:I

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cJ()Z

    move-result v1

    if-nez v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cG()I

    move-result v1

    if-lez v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public dL()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    iget v1, p0, La/b;->mp:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cP()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Ld/q;

    if-eqz v2, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->xA()V

    goto :goto_1

    :cond_0
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Ld/x;

    if-eqz v2, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/x;

    invoke-virtual {v2}, Ld/x;->xA()V

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public dM()V
    .locals 3

    new-instance v0, Ld/o;

    invoke-direct {v0}, Ld/o;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/o;)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b010d

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/o;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/n;

    invoke-direct {v0}, Ld/n;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/n;)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b010b

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/n;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/c;

    invoke-direct {v0}, Ld/c;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/c;)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0108

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/c;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/ouro;

    invoke-direct {v0}, Ld/ouro;-><init>()V

    iput-object v0, p0, La/b;->ouroCopa:Ld/ouro;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b010c

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/ouro;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/africa;

    invoke-direct {v0}, Ld/africa;-><init>()V

    iput-object v0, p0, La/b;->africaCopa:Ld/africa;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0106

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/africa;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/asia;

    invoke-direct {v0}, Ld/asia;-><init>()V

    iput-object v0, p0, La/b;->asiaCopa:Ld/asia;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0107

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/asia;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/ofc;

    invoke-direct {v0}, Ld/ofc;-><init>()V

    iput-object v0, p0, La/b;->ofcCopa:Ld/ofc;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b00e1

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/ofc;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/elimcc;

    invoke-direct {v0}, Ld/elimcc;-><init>()V

    iput-object v0, p0, La/b;->elimccCopa:Ld/elimcc;

    const-string v1, "Elimin. Concacaf"

    invoke-virtual {v0, v1}, Ld/elimcc;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/elimaf;

    invoke-direct {v0}, Ld/elimaf;-><init>()V

    iput-object v0, p0, La/b;->africaElimCopa:Ld/elimaf;

    const-string v1, "Elimin. \u00c1frica"

    invoke-virtual {v0, v1}, Ld/elimaf;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/elimas;

    invoke-direct {v0}, Ld/elimas;-><init>()V

    iput-object v0, p0, La/b;->asiaElimCopa:Ld/elimas;

    const-string v1, "Elimin. \u00c1sia"

    invoke-virtual {v0, v1}, Ld/elimas;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/l;

    invoke-direct {v0}, Ld/l;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/l;)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0109

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/l;->setNome(Ljava/lang/String;)V

    new-instance v0, Ld/j;

    invoke-direct {v0}, Ld/j;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/j;)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b010a

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/j;->setNome(Ljava/lang/String;)V

    iget v0, p0, La/b;->mn:I

    const/16 v1, 0x16

    if-ne v0, v1, :cond_0

    new-instance v0, Ld/e;

    invoke-direct {v0}, Ld/e;-><init>()V

    iput-object v0, p0, La/b;->nQ:Ld/e;

    new-instance v0, Ld/f;

    invoke-direct {v0}, Ld/f;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/f;)V

    new-instance v0, Ld/d;

    invoke-direct {v0}, Ld/d;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/d;)V

    new-instance v0, Ld/b;

    invoke-direct {v0}, Ld/b;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/b;)V

    new-instance v0, Ld/g;

    invoke-direct {v0}, Ld/g;-><init>()V

    iput-object v0, p0, La/b;->nU:Ld/g;

    new-instance v0, Ld/k;

    invoke-direct {v0}, Ld/k;-><init>()V

    iput-object v0, p0, La/b;->nW:Ld/k;

    new-instance v0, Ld/h;

    invoke-direct {v0}, Ld/h;-><init>()V

    iput-object v0, p0, La/b;->nV:Ld/h;

    new-instance v0, Ld/i;

    invoke-direct {v0}, Ld/i;-><init>()V

    iput-object v0, p0, La/b;->nX:Ld/i;

    :cond_0
    return-void
.end method

.method public dN()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, La/b;->mA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kW()V

    iget-object v1, p0, La/b;->mA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kT()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public dO()V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dN()V

    iget-object v0, p0, La/b;->nR:Ld/o;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/b;->nR:Ld/o;

    invoke-virtual {v0}, Ld/o;->wT()V

    iget-object v0, p0, La/b;->nR:Ld/o;

    invoke-virtual {v0}, Ld/o;->nZ()V

    :cond_0
    iget-object v0, p0, La/b;->nM:Ld/n;

    if-eqz v0, :cond_1

    iget-object v0, p0, La/b;->nM:Ld/n;

    invoke-virtual {v0}, Ld/n;->wT()V

    iget-object v0, p0, La/b;->nM:Ld/n;

    invoke-virtual {v0}, Ld/n;->nZ()V

    :cond_1
    iget-object v0, p0, La/b;->nL:Ld/c;

    if-eqz v0, :cond_5

    iget-object v0, p0, La/b;->nL:Ld/c;

    invoke-virtual {v0}, Ld/c;->wT()V

    iget-object v0, p0, La/b;->nL:Ld/c;

    invoke-virtual {v0}, Ld/c;->nZ()V

    iget-object v0, p0, La/b;->ouroCopa:Ld/ouro;

    if-eqz v0, :cond_2

    iget-object v0, p0, La/b;->ouroCopa:Ld/ouro;

    invoke-virtual {v0}, Ld/ouro;->wT()V

    iget-object v0, p0, La/b;->ouroCopa:Ld/ouro;

    invoke-virtual {v0}, Ld/ouro;->nZ()V

    :cond_2
    iget-object v0, p0, La/b;->africaCopa:Ld/africa;

    if-eqz v0, :cond_3

    iget-object v0, p0, La/b;->africaCopa:Ld/africa;

    invoke-virtual {v0}, Ld/africa;->wT()V

    iget-object v0, p0, La/b;->africaCopa:Ld/africa;

    invoke-virtual {v0}, Ld/africa;->nZ()V

    :cond_3
    iget-object v0, p0, La/b;->asiaCopa:Ld/asia;

    if-eqz v0, :cond_4

    iget-object v0, p0, La/b;->asiaCopa:Ld/asia;

    invoke-virtual {v0}, Ld/asia;->wT()V

    iget-object v0, p0, La/b;->asiaCopa:Ld/asia;

    invoke-virtual {v0}, Ld/asia;->nZ()V

    :cond_4
    iget-object v0, p0, La/b;->ofcCopa:Ld/ofc;

    if-eqz v0, :cond_5

    iget-object v0, p0, La/b;->ofcCopa:Ld/ofc;

    invoke-virtual {v0}, Ld/ofc;->wT()V

    iget-object v0, p0, La/b;->ofcCopa:Ld/ofc;

    invoke-virtual {v0}, Ld/ofc;->nZ()V

    :cond_5
    iget-object v0, p0, La/b;->nS:Ld/l;

    if-eqz v0, :cond_6

    iget-object v0, p0, La/b;->nS:Ld/l;

    invoke-virtual {v0}, Ld/l;->wT()V

    :cond_6
    iget-object v0, p0, La/b;->elimccCopa:Ld/elimcc;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ld/elimcc;->wT()V

    :cond_7
    iget-object v0, p0, La/b;->africaElimCopa:Ld/elimaf;

    if-eqz v0, :cond_8

    invoke-virtual {v0}, Ld/elimaf;->wT()V

    :cond_8
    iget-object v0, p0, La/b;->asiaElimCopa:Ld/elimas;

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Ld/elimas;->wT()V

    :cond_9
    iget-object v0, p0, La/b;->nT:Ld/j;

    if-eqz v0, :cond_a

    iget-object v0, p0, La/b;->nT:Ld/j;

    invoke-virtual {v0}, Ld/j;->wT()V

    :cond_a
    iget-object v0, p0, La/b;->nS:Ld/l;

    if-eqz v0, :cond_d

    iget-object v0, p0, La/b;->nS:Ld/l;

    invoke-virtual {v0}, Ld/l;->nZ()V

    iget-object v0, p0, La/b;->elimccCopa:Ld/elimcc;

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Ld/elimcc;->nZ()V

    :cond_b
    iget-object v0, p0, La/b;->africaElimCopa:Ld/elimaf;

    if-eqz v0, :cond_c

    invoke-virtual {v0}, Ld/elimaf;->nZ()V

    :cond_c
    iget-object v0, p0, La/b;->asiaElimCopa:Ld/elimas;

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Ld/elimas;->nZ()V

    :cond_d
    iget-object v0, p0, La/b;->nT:Ld/j;

    if-eqz v0, :cond_e

    iget-object v0, p0, La/b;->nT:Ld/j;

    invoke-virtual {v0}, Ld/j;->nZ()V

    :cond_e
    iget v0, p0, La/b;->nk:I

    iget v1, p0, La/b;->mo:I

    const/4 v2, 0x0

    if-ne v0, v1, :cond_10

    iget-object v0, p0, La/b;->nR:Ld/o;

    if-eqz v0, :cond_f

    :goto_0
    iget-object v0, p0, La/b;->nR:Ld/o;

    invoke-virtual {v0}, Ld/o;->wU()V

    goto :goto_1

    :cond_f
    new-instance v0, Ld/o;

    invoke-direct {v0}, Ld/o;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/o;)V

    goto :goto_0

    :goto_1
    iget v0, p0, La/b;->nk:I

    add-int/lit8 v0, v0, 0x4

    iput v0, p0, La/b;->nk:I

    goto :goto_2

    :cond_10
    iget-object v0, p0, La/b;->nR:Ld/o;

    if-eqz v0, :cond_11

    iget-object v0, p0, La/b;->nR:Ld/o;

    invoke-virtual {v0, v2}, Ld/o;->l(Ld/q;)V

    :cond_11
    :goto_2
    iget v0, p0, La/b;->nk:I

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    iget v3, p0, La/b;->mo:I

    if-ne v0, v3, :cond_17

    iget-object v0, p0, La/b;->nS:Ld/l;

    if-eqz v0, :cond_15

    :goto_3
    iget-object v0, p0, La/b;->nS:Ld/l;

    invoke-virtual {v0}, Ld/l;->wU()V

    iget-object v0, p0, La/b;->elimccCopa:Ld/elimcc;

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Ld/elimcc;->wU()V

    :cond_12
    iget-object v0, p0, La/b;->africaElimCopa:Ld/elimaf;

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Ld/elimaf;->wU()V

    :cond_13
    iget-object v0, p0, La/b;->asiaElimCopa:Ld/elimas;

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Ld/elimas;->wU()V

    :cond_14
    goto :goto_4

    :cond_15
    new-instance v0, Ld/l;

    invoke-direct {v0}, Ld/l;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/l;)V

    goto :goto_3

    :goto_4
    iget-object v0, p0, La/b;->nT:Ld/j;

    if-eqz v0, :cond_16

    :goto_5
    iget-object v0, p0, La/b;->nT:Ld/j;

    invoke-virtual {v0}, Ld/j;->wU()V

    goto :goto_6

    :cond_16
    new-instance v0, Ld/j;

    invoke-direct {v0}, Ld/j;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/j;)V

    goto :goto_5

    :cond_17
    :goto_6
    iget v0, p0, La/b;->nr:I

    iget v3, p0, La/b;->mo:I

    if-ne v0, v3, :cond_1c

    iget-object v0, p0, La/b;->nM:Ld/n;

    if-eqz v0, :cond_1a

    :goto_7
    iget-object v0, p0, La/b;->nM:Ld/n;

    invoke-virtual {v0}, Ld/n;->wU()V

    iget-object v0, p0, La/b;->africaCopa:Ld/africa;

    if-eqz v0, :cond_18

    invoke-virtual {v0}, Ld/africa;->wU()V

    :cond_18
    iget-object v0, p0, La/b;->asiaCopa:Ld/asia;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Ld/asia;->wU()V

    :cond_19
    goto :goto_8

    :cond_1a
    new-instance v0, Ld/n;

    invoke-direct {v0}, Ld/n;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/n;)V

    goto :goto_7

    :goto_8
    iget v0, p0, La/b;->mo:I

    if-ne v0, v1, :cond_1b

    iget v0, p0, La/b;->nr:I

    add-int/lit8 v0, v0, 0x3

    :goto_9
    iput v0, p0, La/b;->nr:I

    goto :goto_a

    :cond_1b
    iget v0, p0, La/b;->nr:I

    add-int/lit8 v0, v0, 0x4

    goto :goto_9

    :cond_1c
    iget-object v0, p0, La/b;->nM:Ld/n;

    if-eqz v0, :cond_1d

    iget-object v0, p0, La/b;->nM:Ld/n;

    invoke-virtual {v0, v2}, Ld/n;->l(Ld/q;)V

    :cond_1d
    :goto_a
    iget v0, p0, La/b;->ns:I

    iget v3, p0, La/b;->mo:I

    if-ne v0, v3, :cond_21

    iget-object v0, p0, La/b;->nL:Ld/c;

    if-eqz v0, :cond_20

    :goto_b
    iget-object v0, p0, La/b;->nL:Ld/c;

    invoke-virtual {v0}, Ld/c;->wU()V

    iget-object v0, p0, La/b;->ouroCopa:Ld/ouro;

    if-eqz v0, :cond_1e

    invoke-virtual {v0}, Ld/ouro;->wU()V

    :cond_1e
    iget-object v0, p0, La/b;->ofcCopa:Ld/ofc;

    if-eqz v0, :cond_1f

    invoke-virtual {v0}, Ld/ofc;->wU()V

    :cond_1f
    goto :goto_c

    :cond_20
    new-instance v0, Ld/c;

    invoke-direct {v0}, Ld/c;-><init>()V

    invoke-virtual {p0, v0}, La/b;->a(Ld/c;)V

    goto :goto_b

    :goto_c
    iget v0, p0, La/b;->ns:I

    add-int/lit8 v0, v0, 0x4

    iput v0, p0, La/b;->ns:I

    return-void

    :cond_21
    iget-object v0, p0, La/b;->nL:Ld/c;

    if-eqz v0, :cond_22

    iget-object v0, p0, La/b;->nL:Ld/c;

    invoke-virtual {v0, v2}, Ld/c;->l(Ld/q;)V

    :cond_22
    return-void
.end method

.method public dP()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->hE()La/ac;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, p0, La/b;->mw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    const/4 v2, 0x1

    invoke-virtual {p0, v1, v2}, La/b;->b(La/af;Z)Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public dQ()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ld/m;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mB:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dR()Ld/p;
    .locals 1

    iget-object v0, p0, La/b;->mN:Ld/p;

    return-object v0
.end method

.method public dS()Z
    .locals 1

    iget-boolean v0, p0, La/b;->na:Z

    return v0
.end method

.method public dT()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mA:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dU()Ld/ad;
    .locals 1

    iget-object v0, p0, La/b;->mW:Ld/ad;

    return-object v0
.end method

.method public dV()Ld/t;
    .locals 1

    iget-object v0, p0, La/b;->mM:Ld/t;

    return-object v0
.end method

.method public dW()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nb:Z

    return v0
.end method

.method public dX()Ld/v;
    .locals 1

    iget-object v0, p0, La/b;->mR:Ld/v;

    return-object v0
.end method

.method public dY()Ld/w;
    .locals 1

    iget-object v0, p0, La/b;->mV:Ld/w;

    return-object v0
.end method

.method public dZ()Ld/u;
    .locals 1

    iget-object v0, p0, La/b;->mU:Ld/u;

    return-object v0
.end method

.method public da()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->ny:Ljava/util/ArrayList;

    return-void
.end method

.method public db()I
    .locals 1

    iget v0, p0, La/b;->mo:I

    return v0
.end method

.method public dc()V
    .locals 1

    iget v0, p0, La/b;->mo:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->mo:I

    return-void
.end method

.method public dd()I
    .locals 1

    iget v0, p0, La/b;->mp:I

    return v0
.end method

.method public de()V
    .locals 1

    iget v0, p0, La/b;->mp:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->mp:I

    return-void
.end method

.method public df()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mv:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dg()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mw:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dh()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mz:Ljava/util/ArrayList;

    return-object v0
.end method

.method public di()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mr:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dj()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mt:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dk()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/l;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->my:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dl()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/a;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dm()Ljava/util/ArrayList;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    iget v1, p0, La/b;->mp:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method

.method public dn()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    iget v1, p0, La/b;->mp:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cK()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public dp()V
    .locals 4

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->ffpCheck()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->mg()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-boolean v1, p0, La/b;->jogaIntClubes:Z

    if-eqz v1, :cond_1

    invoke-direct {p0}, La/b;->dy()V

    :cond_1
    iget-boolean v1, p0, La/b;->nt:Z

    if-nez v1, :cond_2

    invoke-virtual {p0}, La/b;->dx()V

    :cond_2
    invoke-direct {p0}, La/b;->dw()V

    iget-boolean v1, p0, La/b;->jogaIntClubes:Z

    if-eqz v1, :cond_3

    invoke-virtual {p0}, La/b;->dq()V

    :cond_3
    iget v1, p0, La/b;->mn:I

    const/16 v2, 0x16

    if-ne v1, v2, :cond_4

    invoke-direct {p0}, La/b;->fl()V

    :cond_4
    invoke-direct {p0}, La/b;->dB()V

    invoke-direct {p0}, La/b;->dz()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eA()Z

    move-result v1

    if-eqz v1, :cond_5

    const/4 v1, 0x1

    invoke-static {v1}, La/a;->aa(I)I

    move-result v2

    if-lez v2, :cond_5

    const/4 v3, 0x4

    invoke-static {v2, v3, v1}, La/a;->h(III)V

    :cond_5
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->isJogaSelecoesAll()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-virtual {p0}, La/b;->dO()V

    :cond_6
    invoke-static {}, La/a;->cV()V

    invoke-virtual {p0}, La/b;->dr()V

    invoke-direct {p0}, La/b;->dv()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->db()I

    move-result v1

    const/4 v2, 0x5

    if-lt v1, v2, :cond_7

    invoke-direct {p0}, La/b;->do()V

    :cond_7
    invoke-static {}, La/ab;->lq()V

    invoke-static {}, La/ab;->ls()V

    iget-boolean v1, p0, La/b;->nt:Z

    if-eqz v1, :cond_8

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->isBot()Z

    :cond_8
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dJ()I

    sget-object v1, Lc/a;->TF:La/b;

    iget-boolean v1, v1, La/b;->nt:Z

    iput-boolean v0, p0, La/b;->nj:Z

    invoke-static {}, La/o;->hu()V

    return-void
.end method

.method public dq()V
    .locals 3

    invoke-virtual {p0}, La/b;->dR()Ld/p;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/b;->dR()Ld/p;

    move-result-object v0

    invoke-virtual {v0}, Ld/p;->xi()V

    :cond_0
    invoke-virtual {p0}, La/b;->dV()Ld/t;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, La/b;->dV()Ld/t;

    move-result-object v0

    invoke-virtual {v0}, Ld/t;->xi()V

    :cond_1
    invoke-virtual {p0}, La/b;->ea()Ld/r;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, La/b;->ea()Ld/r;

    move-result-object v0

    invoke-virtual {v0}, Ld/r;->xi()V

    :cond_2
    invoke-virtual {p0}, La/b;->eb()Ld/s;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, La/b;->eb()Ld/s;

    move-result-object v0

    invoke-virtual {v0}, Ld/s;->xi()V

    :cond_3
    invoke-virtual {p0}, La/b;->dZ()Ld/u;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {p0}, La/b;->dZ()Ld/u;

    move-result-object v0

    invoke-virtual {v0}, Ld/u;->xi()V

    :cond_4
    invoke-virtual {p0}, La/b;->dY()Ld/w;

    move-result-object v0

    if-eqz v0, :cond_5

    invoke-virtual {p0}, La/b;->dY()Ld/w;

    move-result-object v0

    invoke-virtual {v0}, Ld/w;->xi()V

    :cond_5
    invoke-virtual {p0}, La/b;->dU()Ld/ad;

    move-result-object v0

    if-eqz v0, :cond_6

    invoke-virtual {p0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->gk()V

    :cond_6
    invoke-virtual {p0}, La/b;->dX()Ld/v;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {p0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->xi()V

    :cond_7
    invoke-virtual {p0}, La/b;->d0()Ld/ag;

    move-result-object v0

    if-eqz v0, :cond_8

    invoke-virtual {p0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->xi()V

    :cond_8
    invoke-virtual {p0}, La/b;->dR()Ld/p;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-virtual {p0}, La/b;->dR()Ld/p;

    move-result-object v0

    invoke-virtual {v0}, Ld/p;->nZ()V

    :cond_9
    invoke-virtual {p0}, La/b;->dV()Ld/t;

    move-result-object v0

    if-eqz v0, :cond_a

    invoke-virtual {p0}, La/b;->dV()Ld/t;

    move-result-object v0

    invoke-virtual {v0}, Ld/t;->nZ()V

    :cond_a
    invoke-virtual {p0}, La/b;->ea()Ld/r;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-virtual {p0}, La/b;->ea()Ld/r;

    move-result-object v0

    invoke-virtual {v0}, Ld/r;->nZ()V

    :cond_b
    invoke-virtual {p0}, La/b;->eb()Ld/s;

    move-result-object v0

    if-eqz v0, :cond_c

    invoke-virtual {p0}, La/b;->eb()Ld/s;

    move-result-object v0

    invoke-virtual {v0}, Ld/s;->nZ()V

    :cond_c
    invoke-virtual {p0}, La/b;->dY()Ld/w;

    move-result-object v0

    if-eqz v0, :cond_d

    invoke-virtual {p0}, La/b;->dY()Ld/w;

    move-result-object v0

    invoke-virtual {v0}, Ld/w;->nZ()V

    :cond_d
    invoke-virtual {p0}, La/b;->dZ()Ld/u;

    move-result-object v0

    if-eqz v0, :cond_e

    invoke-virtual {p0}, La/b;->dZ()Ld/u;

    move-result-object v0

    invoke-virtual {v0}, Ld/u;->nZ()V

    :cond_e
    invoke-virtual {p0}, La/b;->dU()Ld/ad;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-virtual {p0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->nZ()V

    :cond_f
    invoke-virtual {p0}, La/b;->dX()Ld/v;

    move-result-object v0

    if-eqz v0, :cond_10

    invoke-virtual {p0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->nZ()V

    :cond_10
    invoke-virtual {p0}, La/b;->d0()Ld/ag;

    move-result-object v0

    if-eqz v0, :cond_11

    invoke-virtual {p0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->nZ()V

    :cond_11
    invoke-virtual {p0}, La/b;->ee()Ld/y;

    move-result-object v0

    if-eqz v0, :cond_12

    invoke-virtual {p0}, La/b;->ee()Ld/y;

    move-result-object v0

    invoke-virtual {v0}, Ld/y;->nZ()V

    :cond_12
    const/4 v0, 0x4

    invoke-static {v0}, La/a;->Z(I)I

    move-result v0

    if-lez v0, :cond_13

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, La/a;->h(III)V

    :cond_13
    return-void
.end method

.method public dr()V
    .locals 6

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->iH()I

    move-result v3

    if-lez v3, :cond_0

    new-instance v3, La/b$a;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->iH()I

    move-result v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->iI()I

    move-result v5

    invoke-direct {v3, p0, v4, v5}, La/b$a;-><init>(La/b;II)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    new-instance v2, La/b$a;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/ax;

    invoke-virtual {v3}, Lcomponents/ax;->tk()I

    move-result v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/ax;

    invoke-virtual {v4}, Lcomponents/ax;->fC()I

    move-result v4

    invoke-direct {v2, p0, v3, v4}, La/b$a;-><init>(La/b;II)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    sget-object v1, La/b;->oa:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v1, 0x1

    iput v1, p0, La/b;->nZ:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v2, 0xc8

    if-le v1, v2, :cond_3

    const/16 v1, 0xc7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/b$a;

    iget v0, v0, La/b$a;->g:I

    iput v0, p0, La/b;->nZ:I

    :cond_3
    return-void
.end method

.method public ds()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->ob:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->ob:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->ob:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dt()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->oc:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->oc:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->oc:Ljava/util/ArrayList;

    return-object v0
.end method

.method public du()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->od:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->od:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->od:Ljava/util/ArrayList;

    return-object v0
.end method

.method public dx()V
    .locals 3

    invoke-virtual {p0}, La/b;->dc()V

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget v0, p0, La/b;->mo:I

    add-int/lit8 v0, v0, -0x1

    add-int/lit16 v0, v0, 0x7ea

    iget v1, p0, La/b;->mo:I

    const-string v2, "DXDIAG mo="

    invoke-static {v2, v1}, Lcom/brasfoot/v2028/Recopa;->flogi(Ljava/lang/String;I)V

    const-string v2, "DXDIAG ano="

    invoke-static {v2, v0}, Lcom/brasfoot/v2028/Recopa;->flogi(Ljava/lang/String;I)V

    invoke-virtual {p0, v0}, La/b;->ak(I)V

    invoke-static {}, La/a;->cL()V

    return-void
.end method

.method public e(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mt:Ljava/util/ArrayList;

    return-void
.end method

.method public eA()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nc:Z

    return v0
.end method

.method public eB()La/t;
    .locals 1

    iget-object v0, p0, La/b;->nx:La/t;

    return-object v0
.end method

.method public eC()Z
    .locals 1

    iget-boolean v0, p0, La/b;->ne:Z

    return v0
.end method

.method public eD()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bf;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mE:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eE()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/aj;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mF:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eF()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/b;->ni:Ljava/lang/String;

    return-object v0
.end method

.method public eG()Lest/InfoArquivoSalvoType;
    .locals 1

    iget-object v0, p0, La/b;->mm:Lest/InfoArquivoSalvoType;

    if-nez v0, :cond_0

    new-instance v0, Lest/InfoArquivoSalvoType;

    invoke-direct {v0}, Lest/InfoArquivoSalvoType;-><init>()V

    iput-object v0, p0, La/b;->mm:Lest/InfoArquivoSalvoType;

    :cond_0
    iget-object v0, p0, La/b;->mm:Lest/InfoArquivoSalvoType;

    return-object v0
.end method

.method public eH()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bn;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mG:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eI()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mx:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->mx:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->mx:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eJ()Ld/a;
    .locals 1

    iget-object v0, p0, La/b;->mO:Ld/a;

    return-object v0
.end method

.method public eK()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bi;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mH:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->mH:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->mH:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eL()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/cr;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mJ:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eM()I
    .locals 1

    iget v0, p0, La/b;->nf:I

    return v0
.end method

.method public eN()I
    .locals 1

    iget v0, p0, La/b;->ng:I

    return v0
.end method

.method public eO()[La/al;
    .locals 4

    const/16 v0, 0xe

    new-array v0, v0, [La/al;

    const/4 v1, 0x0

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const/4 v2, 0x2

    aput-object v1, v0, v2

    iget-object v2, p0, La/b;->mL:Ld/y;

    const/4 v3, 0x3

    aput-object v2, v0, v3

    iget-object v2, p0, La/b;->mM:Ld/t;

    const/4 v3, 0x4

    aput-object v2, v0, v3

    iget-object v2, p0, La/b;->mN:Ld/p;

    const/4 v3, 0x5

    aput-object v2, v0, v3

    const/4 v2, 0x6

    aput-object v1, v0, v2

    const/4 v2, 0x7

    aput-object v1, v0, v2

    const/16 v3, 0x8

    iget-object v1, p0, La/b;->mQ:Ld/z;

    aput-object v1, v0, v3

    const/16 v2, 0x9

    aput-object v1, v0, v2

    const/16 v2, 0xa

    aput-object v1, v0, v2

    const/16 v2, 0xb

    aput-object v1, v0, v2

    const/16 v2, 0xc

    aput-object v1, v0, v2

    const/16 v2, 0xd

    aput-object v1, v0, v2

    return-object v0
.end method

.method public eP()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nF:Z

    return v0
.end method

.method public eQ()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nI:Z

    return v0
.end method

.method public eR()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nJ:Z

    return v0
.end method

.method public eS()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bv;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->nC:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eT()I
    .locals 1

    iget v0, p0, La/b;->nh:I

    return v0
.end method

.method public eU()V
    .locals 1

    iget v0, p0, La/b;->nh:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->nh:I

    return-void
.end method

.method public eV()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/ax;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mK:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eW()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->ms:Ljava/util/ArrayList;

    return-object v0
.end method

.method public eX()I
    .locals 1

    iget v0, p0, La/b;->mq:I

    return v0
.end method

.method public eY()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nE:Z

    return v0
.end method

.method public eZ()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nK:Z

    return v0
.end method

.method public ea()Ld/r;
    .locals 1

    iget-object v0, p0, La/b;->mT:Ld/r;

    return-object v0
.end method

.method public eb()Ld/s;
    .locals 1

    iget-object v0, p0, La/b;->mS:Ld/s;

    return-object v0
.end method

.method public ec()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, La/b;->mp:I

    if-gt v0, v1, :cond_0

    iget-object v1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, La/a;->f(Z)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public ed()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mu:Ljava/util/ArrayList;

    return-object v0
.end method

.method public ee()Ld/y;
    .locals 1

    iget-object v0, p0, La/b;->mL:Ld/y;

    if-nez v0, :cond_0

    new-instance v0, Ld/y;

    invoke-direct {v0}, Ld/y;-><init>()V

    iput-object v0, p0, La/b;->mL:Ld/y;

    :cond_0
    iget-object v0, p0, La/b;->mL:Ld/y;

    return-object v0
.end method

.method public eg()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/b;->mr:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/b;->mr:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->iq()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x0

    :goto_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/q;

    invoke-virtual {v3}, La/q;->iU()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public eh()V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    invoke-virtual {p0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->id()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_1
    iget-object v2, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x0

    :goto_2
    iget-object v3, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    iget-object v3, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/q;

    iget-object v4, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v3, v4}, La/q;->o(La/ac;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    :goto_3
    iget-object v1, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    iget-object v1, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->lO()V

    iget-object v1, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->mf()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_3
    return-void
.end method

.method public ei()Ld/aa;
    .locals 1

    iget-object v0, p0, La/b;->mP:Ld/aa;

    return-object v0
.end method

.method public ej()Ld/z;
    .locals 1

    iget-object v0, p0, La/b;->mQ:Ld/z;

    return-object v0
.end method

.method public ek()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->ny:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->ny:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->ny:Ljava/util/ArrayList;

    return-object v0
.end method

.method public el()I
    .locals 1

    iget v0, p0, La/b;->nl:I

    return v0
.end method

.method public em()V
    .locals 1

    iget v0, p0, La/b;->nl:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->nl:I

    return-void
.end method

.method public en()Ljava/util/Calendar;
    .locals 2

    iget v0, p0, La/b;->mp:I

    iget-object v1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    iget v1, p0, La/b;->mp:I

    :goto_0
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v0, p0, La/b;->mD:Ljava/util/ArrayList;

    iget-object v1, p0, La/b;->mD:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    goto :goto_0
.end method

.method public eo()I
    .locals 1

    iget v0, p0, La/b;->nm:I

    return v0
.end method

.method public ep()I
    .locals 1

    iget v0, p0, La/b;->nn:I

    return v0
.end method

.method public eq()I
    .locals 1

    iget v0, p0, La/b;->no:I

    return v0
.end method

.method public er()I
    .locals 1

    iget v0, p0, La/b;->np:I

    return v0
.end method

.method public es()V
    .locals 1

    iget v0, p0, La/b;->nm:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->nm:I

    return-void
.end method

.method public et()V
    .locals 1

    iget v0, p0, La/b;->nn:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->nn:I

    return-void
.end method

.method public eu()V
    .locals 1

    iget v0, p0, La/b;->no:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->no:I

    return-void
.end method

.method public ev()V
    .locals 1

    iget v0, p0, La/b;->nq:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->nq:I

    return-void
.end method

.method public ew()V
    .locals 1

    iget v0, p0, La/b;->np:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->np:I

    return-void
.end method

.method public ex()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/w;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mI:Ljava/util/ArrayList;

    return-object v0
.end method

.method public ey()La/af;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->hE()La/ac;

    move-result-object v1

    if-nez v1, :cond_0

    iget-object v1, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, La/b;->mv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    return-object v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public ez()Z
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bv;

    invoke-virtual {v2}, Lcomponents/bv;->uU()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public f(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/l;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->my:Ljava/util/ArrayList;

    return-void
.end method

.method public fa()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->nY:Ljava/util/ArrayList;

    return-object v0
.end method

.method public fb()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nj:Z

    return v0
.end method

.method public fc()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nt:Z

    return v0
.end method

.method public fd()I
    .locals 1

    iget v0, p0, La/b;->nv:I

    return v0
.end method

.method public fe()Ld/o;
    .locals 1

    iget-object v0, p0, La/b;->nR:Ld/o;

    return-object v0
.end method

.method public ff()Ld/c;
    .locals 1

    iget-object v0, p0, La/b;->nL:Ld/c;

    return-object v0
.end method

.method public ffin()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, La/b;->finalChamps:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->finalChamps:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->finalChamps:Ljava/util/ArrayList;

    return-object v0
.end method

.method public fg()Ld/n;
    .locals 1

    iget-object v0, p0, La/b;->nM:Ld/n;

    return-object v0
.end method

.method public fh()Ld/b;
    .locals 1

    iget-object v0, p0, La/b;->nN:Ld/b;

    return-object v0
.end method

.method public fi()Ld/d;
    .locals 1

    iget-object v0, p0, La/b;->nO:Ld/d;

    return-object v0
.end method

.method public fj()Ld/f;
    .locals 1

    iget-object v0, p0, La/b;->nP:Ld/f;

    return-object v0
.end method

.method public fk()I
    .locals 1

    iget v0, p0, La/b;->nu:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/b;->nu:I

    iget v0, p0, La/b;->nu:I

    return v0
.end method

.method public fm()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ld/ae;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/b;->mC:Ljava/util/ArrayList;

    return-object v0
.end method

.method public fn()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nd:Z

    return v0
.end method

.method public fo()Ld/l;
    .locals 1

    iget-object v0, p0, La/b;->nS:Ld/l;

    return-object v0
.end method

.method public fp()Ld/j;
    .locals 1

    iget-object v0, p0, La/b;->nT:Ld/j;

    return-object v0
.end method

.method public fq()[Ld/ab;
    .locals 1

    iget-object v0, p0, La/b;->mX:[Ld/ab;

    return-object v0
.end method

.method public fr()[Z
    .locals 1

    iget-object v0, p0, La/b;->mY:[Z

    return-object v0
.end method

.method public fs()Z
    .locals 1

    iget-boolean v0, p0, La/b;->mZ:Z

    return v0
.end method

.method public ft()I
    .locals 1

    iget v0, p0, La/b;->mn:I

    return v0
.end method

.method public g(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mu:Ljava/util/ArrayList;

    return-void
.end method

.method public gerarBolaDeOuro()V
    .locals 10

    invoke-virtual {p0}, La/b;->db()I

    move-result v0

    sget v1, La/ak;->yU:I

    add-int/lit8 v1, v1, -0x1

    add-int v0, v0, v1

    iget v1, p0, La/b;->bolaDeOuroAno:I

    if-ne v0, v1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_8

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_8

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->bolaScoreEuro(La/p;)D

    move-result-wide v3

    const/4 v5, 0x1

    :goto_0
    if-ge v5, v1, :cond_2

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-static {v6}, Lcom/brasfoot/v2028/Recopa;->bolaScoreEuro(La/p;)D

    move-result-wide v7

    cmpg-double v9, v3, v7

    if-gez v9, :cond_1

    move-wide v3, v7

    move-object v2, v6

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_2
    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->bolaScoreEuro(La/p;)D

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmpl-double v7, v3, v5

    if-lez v7, :cond_8

    invoke-virtual {p0}, La/b;->db()I

    move-result v0

    sget v1, La/ak;->yU:I

    add-int/lit8 v1, v1, -0x1

    add-int v0, v0, v1

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ":\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " ("

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3
    const-string v0, ")\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v3

    const/4 v4, 0x0

    if-eq v3, v4, :cond_4

    const/4 v4, 0x1

    if-eq v3, v4, :cond_5

    const/4 v4, 0x2

    if-eq v3, v4, :cond_6

    const/4 v4, 0x3

    if-eq v3, v4, :cond_7

    const-string v0, "ATA"

    goto :goto_1

    :cond_4
    const-string v0, "GOL"

    goto :goto_1

    :cond_5
    const-string v0, "LAT"

    goto :goto_1

    :cond_6
    const-string v0, "ZAG"

    goto :goto_1

    :cond_7
    const-string v0, "MEI"

    :goto_1
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " - "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->getIdade()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->seasonGoals(La/p;)I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " gols, "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->seasonAssists(La/p;)I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " assist. na temporada"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, La/b;->appendBolaDeOuroHistory(Ljava/lang/String;)V

    const v0, 0x2faf080

    invoke-virtual {v2, v0}, La/p;->addBolaBonus(I)V

    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->crownWorldBest(La/p;)V

    iget v0, v2, La/p;->awBola:I

    add-int/lit8 v0, v0, 0x1

    iput v0, v2, La/p;->awBola:I

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->recordIndividualAwards()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->extraAwards()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->boardGoals()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->acessoBonus()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->socioUpdate()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->loanDefaultCheck()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->updateIdols()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->contGoals()V

    invoke-virtual {p0}, La/b;->db()I

    move-result v1

    sget v0, La/ak;->yU:I

    add-int/lit8 v0, v0, -0x1

    add-int v1, v1, v0

    iput v1, p0, La/b;->bolaDeOuroAno:I

    :cond_8
    return-void
.end method

.method public getAutoSalvar()I
    .locals 1

    iget v0, p0, La/b;->autoSalvar:I

    return v0
.end method

.method public getAvisoTerminoContrato()I
    .locals 1

    iget v0, p0, La/b;->avisoTerminoContrato:I

    return v0
.end method

.method public getBolaDeOuroHistory()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, La/b;->bolaDeOuroHistory:Ljava/lang/String;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, ""

    return-object v0
.end method

.method public getCorPlacar()I
    .locals 1

    iget v0, p0, La/b;->corPlacar:I

    return v0
.end method

.method public getTransHist()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, La/b;->transHist:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->transHist:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/b;->transHist:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getVelocidade()I
    .locals 1

    iget v0, p0, La/b;->velocidade:I

    return v0
.end method

.method public getVelocidadeNH()I
    .locals 1

    iget v0, p0, La/b;->velocidadeNH:I

    return v0
.end method

.method public getVerDecisaoPenNaoHumano()I
    .locals 1

    iget v0, p0, La/b;->verDecisaoPenNaoHumano:I

    return v0
.end method

.method public getVerJanelaSubs()I
    .locals 1

    iget v0, p0, La/b;->verJanelaSubs:I

    return v0
.end method

.method public getVerJint()[Z
    .locals 1

    iget-object v0, p0, La/b;->verJint:[Z

    return-object v0
.end method

.method public getVerMudancaTecnicos()I
    .locals 1

    iget v0, p0, La/b;->verMudancaTecnicos:I

    return v0
.end method

.method public getWcCycle()I
    .locals 1

    iget v0, p0, La/b;->nk:I

    return v0
.end method

.method public h(Ljava/lang/String;)V
    .locals 6

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    const/4 v2, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    const/4 v4, 0x0

    :goto_2
    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public h(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bv;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->nC:Ljava/util/ArrayList;

    return-void
.end method

.method public h(Z)V
    .locals 1

    const/4 p1, 0x0

    :goto_0
    iget-object v0, p0, La/b;->mt:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_1

    invoke-virtual {p0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->my()V

    :cond_0
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public h2hMap()Ljava/util/HashMap;
    .locals 1

    iget-object v0, p0, La/b;->h2h:Ljava/util/HashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La/b;->h2h:Ljava/util/HashMap;

    :cond_0
    return-object v0
.end method

.method public i(Ljava/lang/String;)V
    .locals 4

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    const/4 v2, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-static {v3, v1}, Ljava/util/Collections;->frequency(Ljava/util/Collection;Ljava/lang/Object;)I

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public i(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mx:Ljava/util/ArrayList;

    return-void
.end method

.method public i(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->na:Z

    return-void
.end method

.method public isAutoRenovaContrato()Z
    .locals 1

    iget-boolean v0, p0, La/b;->autoRenovaContrato:Z

    return v0
.end method

.method public isBot()Z
    .locals 1

    iget-boolean v0, p0, La/b;->nH:Z

    return v0
.end method

.method public isGruposIntPadrao()Z
    .locals 1

    iget-boolean v0, p0, La/b;->gruposIntPadrao:Z

    return v0
.end method

.method public isIgnoraEstadual()Z
    .locals 1

    iget-boolean v0, p0, La/b;->ignoraEstadual:Z

    return v0
.end method

.method public isIgnoraLigas()Z
    .locals 1

    iget-boolean v0, p0, La/b;->ignoraLigas:Z

    return v0
.end method

.method public isJogaEstadual()Z
    .locals 1

    iget-boolean v0, p0, La/b;->jogaEstadual:Z

    return v0
.end method

.method public isJogaIntClubes()Z
    .locals 1

    iget-boolean v0, p0, La/b;->jogaIntClubes:Z

    return v0
.end method

.method public isJogaIntano1()Z
    .locals 1

    iget-boolean v0, p0, La/b;->jogaIntano1:Z

    return v0
.end method

.method public isJogaSelecoesAll()Z
    .locals 1

    iget-boolean v0, p0, La/b;->jogaSelecoesAll:Z

    return v0
.end method

.method public isNegritoCasa()Z
    .locals 1

    iget-boolean v0, p0, La/b;->negritoCasa:Z

    return v0
.end method

.method public isRecopa(Ld/q;)I
    .locals 3

    iget-object v0, p0, La/b;->recopaArr:[Ld/q;

    if-eqz v0, :cond_1

    if-eqz p1, :cond_1

    const/4 v1, 0x0

    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_1

    aget-object v2, v0, v1

    if-ne v2, p1, :cond_0

    return v1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, -0x1

    return v1
.end method

.method public isSalarioMensal()Z
    .locals 1

    iget-boolean v0, p0, La/b;->salarioMensal:Z

    return v0
.end method

.method public isUsaCorPlacar()Z
    .locals 1

    iget-boolean v0, p0, La/b;->usaCorPlacar:Z

    return v0
.end method

.method public isUsaCoresLista()Z
    .locals 1

    iget-boolean v0, p0, La/b;->usaCoresLista:Z

    return v0
.end method

.method public isUsaGrupoPadraoEstadual()Z
    .locals 1

    iget-boolean v0, p0, La/b;->usaGrupoPadraoEstadual:Z

    return v0
.end method

.method public isUsaSons()Z
    .locals 1

    iget-boolean v0, p0, La/b;->usaSons:Z

    return v0
.end method

.method public isVerEstaduaisAgrupados()Z
    .locals 1

    iget-boolean v0, p0, La/b;->verEstaduaisAgrupados:Z

    return v0
.end method

.method public j(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/b;->ni:Ljava/lang/String;

    return-void
.end method

.method public j(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mz:Ljava/util/ArrayList;

    return-void
.end method

.method public j(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nb:Z

    return-void
.end method

.method public k(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mA:Ljava/util/ArrayList;

    return-void
.end method

.method public k(Z)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    iget-object p1, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_1

    iget-object p1, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bv;

    invoke-virtual {p1, v1}, Lcomponents/bv;->at(Z)V

    return-void

    :cond_0
    :goto_0
    iget-object p1, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_1

    iget-object p1, p0, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bv;

    invoke-virtual {p1, v1}, Lcomponents/bv;->at(Z)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public l(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ld/m;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mB:Ljava/util/ArrayList;

    return-void
.end method

.method public l(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nc:Z

    return-void
.end method

.method public m(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bn;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mG:Ljava/util/ArrayList;

    return-void
.end method

.method public m(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->ne:Z

    return-void
.end method

.method public n(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/w;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mI:Ljava/util/ArrayList;

    return-void
.end method

.method public n(Z)V
    .locals 2

    if-eqz p1, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    iput-boolean p1, p0, La/b;->nF:Z

    :cond_1
    return-void
.end method

.method public o(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mD:Ljava/util/ArrayList;

    return-void
.end method

.method public o(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nH:Z

    return-void
.end method

.method public p(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bf;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mE:Ljava/util/ArrayList;

    return-void
.end method

.method public p(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nI:Z

    return-void
.end method

.method public prizeMap()Ljava/util/HashMap;
    .locals 1

    iget-object v0, p0, La/b;->prizeMap:Ljava/util/HashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La/b;->prizeMap:Ljava/util/HashMap;

    :cond_0
    return-object v0
.end method

.method public prizeMapCurrent()Ljava/util/HashMap;
    .locals 3

    invoke-virtual {p0}, La/b;->prizeMap()Ljava/util/HashMap;

    move-result-object v0

    iget v1, p0, La/b;->prizeSeason:I

    invoke-virtual {p0}, La/b;->db()I

    move-result v2

    if-eq v1, v2, :cond_0

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    :cond_0
    return-object v0
.end method

.method public q(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/aj;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mF:Ljava/util/ArrayList;

    return-void
.end method

.method public q(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nJ:Z

    return-void
.end method

.method public r(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bi;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mH:Ljava/util/ArrayList;

    return-void
.end method

.method public r(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nE:Z

    return-void
.end method

.method public recopaFor(I)Ld/q;
    .locals 5

    iget-object v0, p0, La/b;->recopaArr:[Ld/q;

    if-nez v0, :cond_0

    const/16 v0, 0x100

    new-array v0, v0, [Ld/q;

    iput-object v0, p0, La/b;->recopaArr:[Ld/q;

    :cond_0
    if-ltz p1, :cond_1

    array-length v1, v0

    if-lt p1, v1, :cond_2

    :cond_1
    const/4 v0, 0x0

    return-object v0

    :cond_2
    aget-object v1, v0, p1

    if-eqz v1, :cond_3

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Supercopa "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcomponents/bz;->dJ(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ld/q;->recopaNome(Ljava/lang/String;)V

    return-object v1

    :cond_3
    new-instance v1, Ld/q;

    invoke-direct {v1}, Ld/q;-><init>()V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Supercopa "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcomponents/bz;->dJ(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, La/al;->setNome(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ld/q;->recopaNome(Ljava/lang/String;)V

    const/16 v2, 0x14

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, La/al;->aa(II)V

    aput-object v1, v0, p1

    return-object v1
.end method

.method public recordPrize(Ljava/lang/String;I)V
    .locals 6

    invoke-virtual {p0}, La/b;->db()I

    move-result v0

    iget v1, p0, La/b;->prizeSeason:I

    invoke-virtual {p0}, La/b;->prizeMap()Ljava/util/HashMap;

    move-result-object v2

    if-eq v1, v0, :cond_0

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iput v0, p0, La/b;->prizeSeason:I

    :cond_0
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    const-wide/16 v4, 0x0

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    :cond_1
    int-to-long v0, p2

    add-long/2addr v4, v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v2, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public repQ()Ld/q;
    .locals 3

    iget-object v0, p0, La/b;->repCopa:Ld/q;

    if-nez v0, :cond_0

    new-instance v0, Ld/q;

    invoke-direct {v0}, Ld/q;-><init>()V

    const-string v1, "Repescagem Sul-Americana"

    invoke-virtual {v0, v1}, La/al;->setNome(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ld/q;->recopaNome(Ljava/lang/String;)V

    const/16 v1, 0x14

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, La/al;->aa(II)V

    iput-object v0, p0, La/b;->repCopa:Ld/q;

    :cond_0
    return-object v0
.end method

.method public repWin()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, La/b;->repWinners:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->repWinners:Ljava/util/ArrayList;

    :cond_0
    return-object v0
.end method

.method public s(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/cr;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mJ:Ljava/util/ArrayList;

    return-void
.end method

.method public s(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nK:Z

    return-void
.end method

.method public setAutoRenovaContrato(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->autoRenovaContrato:Z

    return-void
.end method

.method public setAutoSalvar(I)V
    .locals 0

    iput p1, p0, La/b;->autoSalvar:I

    return-void
.end method

.method public setAvisoTerminoContrato(I)V
    .locals 0

    iput p1, p0, La/b;->avisoTerminoContrato:I

    return-void
.end method

.method public setCorPlacar(I)V
    .locals 0

    iput p1, p0, La/b;->corPlacar:I

    return-void
.end method

.method public setCoresLista([Landroid/graphics/Color;)V
    .locals 0

    iput-object p1, p0, La/b;->coresLista:[Landroid/graphics/Color;

    return-void
.end method

.method public setGruposIntPadrao(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->gruposIntPadrao:Z

    return-void
.end method

.method public setIgnoraEstadual(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->ignoraEstadual:Z

    return-void
.end method

.method public setIgnoraLigas(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->ignoraLigas:Z

    return-void
.end method

.method public setJogaEstadual(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->jogaEstadual:Z

    return-void
.end method

.method public setJogaIntClubes(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->jogaIntClubes:Z

    return-void
.end method

.method public setJogaIntano1(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->jogaIntano1:Z

    return-void
.end method

.method public setJogaSelecoesAll(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->jogaSelecoesAll:Z

    return-void
.end method

.method public setNegritoCasa(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->negritoCasa:Z

    return-void
.end method

.method public setSalarioMensal(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->salarioMensal:Z

    return-void
.end method

.method public setUsaCorPlacar(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->usaCorPlacar:Z

    return-void
.end method

.method public setUsaCoresLista(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->usaCoresLista:Z

    return-void
.end method

.method public setUsaGrupoPadraoEstadual(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->usaGrupoPadraoEstadual:Z

    return-void
.end method

.method public setUsaSons(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->usaSons:Z

    return-void
.end method

.method public setVelocidade(I)V
    .locals 0

    iput p1, p0, La/b;->velocidade:I

    return-void
.end method

.method public setVelocidadeNH(I)V
    .locals 0

    iput p1, p0, La/b;->velocidadeNH:I

    return-void
.end method

.method public setVerDecisaoPenNaoHumano(I)V
    .locals 0

    iput p1, p0, La/b;->verDecisaoPenNaoHumano:I

    return-void
.end method

.method public setVerEstaduaisAgrupados(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->verEstaduaisAgrupados:Z

    return-void
.end method

.method public setVerJanelaSubs(I)V
    .locals 0

    iput p1, p0, La/b;->verJanelaSubs:I

    return-void
.end method

.method public setVerJint([Z)V
    .locals 0

    iput-object p1, p0, La/b;->verJint:[Z

    return-void
.end method

.method public setVerMudancaTecnicos(I)V
    .locals 0

    iput p1, p0, La/b;->verMudancaTecnicos:I

    return-void
.end method

.method public supQ()Ld/q;
    .locals 3

    iget-object v0, p0, La/b;->rcSupQ:Ld/q;

    if-nez v0, :cond_0

    new-instance v0, Ld/q;

    invoke-direct {v0}, Ld/q;-><init>()V

    const-string v1, "Supercopa das Copas"

    invoke-virtual {v0, v1}, La/al;->setNome(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ld/q;->recopaNome(Ljava/lang/String;)V

    const/16 v1, 0x14

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, La/al;->aa(II)V

    iput-object v0, p0, La/b;->rcSupQ:Ld/q;

    :cond_0
    return-object v0
.end method

.method public t(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/ax;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mK:Ljava/util/ArrayList;

    return-void
.end method

.method public t(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nj:Z

    return-void
.end method

.method public u(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->ms:Ljava/util/ArrayList;

    return-void
.end method

.method public u(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nt:Z

    return-void
.end method

.method public v(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ld/ae;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/b;->mC:Ljava/util/ArrayList;

    return-void
.end method

.method public v(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->nd:Z

    return-void
.end method

.method public w(Z)V
    .locals 0

    iput-boolean p1, p0, La/b;->mZ:Z

    return-void
.end method
