.class final La/ac$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/ac;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "La/p;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La/p;La/p;)I
    .locals 2

    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    invoke-virtual {p2}, La/p;->hG()I

    move-result v1

    invoke-virtual {p1}, La/p;->getIdade()I

    move-result p1

    invoke-virtual {p2}, La/p;->getIdade()I

    move-result p2

    if-ne v0, v1, :cond_0

    sub-int/2addr p2, p1

    return p2

    :cond_0
    sub-int/2addr v1, v0

    return v1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, La/p;

    check-cast p2, La/p;

    invoke-virtual {p0, p1, p2}, La/ac$1;->a(La/p;La/p;)I

    move-result p1

    return p1
.end method
