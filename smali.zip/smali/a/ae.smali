.class public La/ae;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private d:I

.field private of:I

.field private op:I

.field private xP:I

.field private xQ:I

.field private xR:I

.field private xU:Ld/q;

.field private xV:La/ac;


# direct methods
.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/ae;->xU:Ld/q;

    iput-object v0, p0, La/ae;->xV:La/ac;

    const/4 v0, 0x0

    iput v0, p0, La/ae;->xP:I

    iput v0, p0, La/ae;->of:I

    iput v0, p0, La/ae;->op:I

    iput v0, p0, La/ae;->d:I

    iput v0, p0, La/ae;->xQ:I

    iput v0, p0, La/ae;->xR:I

    return-void
.end method

.method public constructor <init>(La/ac;Ld/q;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/ae;->xU:Ld/q;

    iput-object v0, p0, La/ae;->xV:La/ac;

    const/4 v0, 0x0

    iput v0, p0, La/ae;->xP:I

    iput v0, p0, La/ae;->of:I

    iput v0, p0, La/ae;->op:I

    iput v0, p0, La/ae;->d:I

    iput v0, p0, La/ae;->xQ:I

    iput v0, p0, La/ae;->xR:I

    iput-object p1, p0, La/ae;->xV:La/ac;

    iput-object p2, p0, La/ae;->xU:Ld/q;

    return-void
.end method


# virtual methods
.method public ce(I)V
    .locals 1

    iget v0, p0, La/ae;->xP:I

    add-int/2addr v0, p1

    iput v0, p0, La/ae;->xP:I

    return-void
.end method

.method public cf(I)V
    .locals 1

    iget v0, p0, La/ae;->xQ:I

    add-int/2addr v0, p1

    iput v0, p0, La/ae;->xQ:I

    return-void
.end method

.method public cg(I)V
    .locals 1

    iget v0, p0, La/ae;->xR:I

    add-int/2addr v0, p1

    iput v0, p0, La/ae;->xR:I

    return-void
.end method

.method public f(Ld/q;)V
    .locals 0

    iput-object p1, p0, La/ae;->xU:Ld/q;

    return-void
.end method

.method public fC()I
    .locals 1

    iget v0, p0, La/ae;->of:I

    return v0
.end method

.method public fD()V
    .locals 1

    iget v0, p0, La/ae;->of:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ae;->of:I

    return-void
.end method

.method public fE()I
    .locals 1

    iget v0, p0, La/ae;->op:I

    return v0
.end method

.method public fF()V
    .locals 1

    iget v0, p0, La/ae;->op:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ae;->op:I

    return-void
.end method

.method public fG()I
    .locals 1

    iget v0, p0, La/ae;->d:I

    return v0
.end method

.method public fH()V
    .locals 1

    iget v0, p0, La/ae;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ae;->d:I

    return-void
.end method

.method public mJ()I
    .locals 1

    iget v0, p0, La/ae;->xP:I

    return v0
.end method

.method public mK()I
    .locals 1

    iget v0, p0, La/ae;->xQ:I

    return v0
.end method

.method public mL()I
    .locals 1

    iget v0, p0, La/ae;->xR:I

    return v0
.end method

.method public mP()V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, La/ae;->xP:I

    iput v0, p0, La/ae;->of:I

    iput v0, p0, La/ae;->op:I

    iput v0, p0, La/ae;->d:I

    iput v0, p0, La/ae;->xQ:I

    iput v0, p0, La/ae;->xR:I

    return-void
.end method

.method public mQ()[I
    .locals 4

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iget v1, p0, La/ae;->xP:I

    const/4 v2, 0x0

    aput v1, v0, v2

    iget v1, p0, La/ae;->of:I

    const/4 v2, 0x1

    aput v1, v0, v2

    iget v1, p0, La/ae;->op:I

    const/4 v2, 0x2

    aput v1, v0, v2

    iget v1, p0, La/ae;->of:I

    iget v2, p0, La/ae;->op:I

    iget v3, p0, La/ae;->d:I

    add-int/2addr v2, v3

    sub-int/2addr v1, v2

    const/4 v2, 0x3

    aput v1, v0, v2

    iget v1, p0, La/ae;->d:I

    const/4 v2, 0x4

    aput v1, v0, v2

    iget v1, p0, La/ae;->xQ:I

    const/4 v2, 0x5

    aput v1, v0, v2

    iget v1, p0, La/ae;->xR:I

    const/4 v2, 0x6

    aput v1, v0, v2

    iget v1, p0, La/ae;->xQ:I

    iget v2, p0, La/ae;->xR:I

    sub-int/2addr v1, v2

    const/4 v2, 0x7

    aput v1, v0, v2

    return-object v0

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public mR()Ld/q;
    .locals 1

    iget-object v0, p0, La/ae;->xU:Ld/q;

    return-object v0
.end method
