.class final La/b$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "La/b$a;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La/b$a;La/b$a;)I
    .locals 2

    iget v0, p1, La/b$a;->g:I

    iget v1, p2, La/b$a;->g:I

    iget p1, p1, La/b$a;->of:I

    iget p2, p2, La/b$a;->of:I

    if-eq v0, v1, :cond_0

    sub-int/2addr v1, v0

    return v1

    :cond_0
    if-eq p1, p2, :cond_1

    sub-int/2addr p1, p2

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, La/b$a;

    check-cast p2, La/b$a;

    invoke-virtual {p0, p1, p2}, La/b$1;->a(La/b$a;La/b$a;)I

    move-result p1

    return p1
.end method
