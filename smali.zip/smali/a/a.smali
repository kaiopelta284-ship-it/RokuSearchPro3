.class public La/a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field static final TER:I = 0x3

.field static final lV:I = 0x1

.field static final lW:I = 0x2

.field static final lX:I = 0x4

.field static final lY:I = 0x5

.field static final lZ:I = 0x6

.field static final ma:I = 0x7

.field static final mb:I = 0x1

.field static final mc:I = 0x2

.field static final md:I = 0x3

.field static final me:I = 0x4

.field static final mf:I = 0x5

.field static final mg:I = 0x6

.field static final mh:I = 0x7

.field static final mi:I = 0x8

.field static final mj:I = 0x9

.field static final mk:I = 0x64

.field static final ml:I = 0xc8

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private lN:Ljava/util/Calendar;

.field private lO:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private lP:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private lQ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation
.end field

.field private lR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private lS:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private lT:Z

.field private lU:I


# direct methods
.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, La/a;->lN:Ljava/util/Calendar;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a;->lO:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a;->lP:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a;->lQ:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a;->lR:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a;->lS:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, La/a;->lT:Z

    iput v0, p0, La/a;->lU:I

    return-void
.end method

.method public static G(II)I
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cG()I

    move-result v2

    if-ne v2, p0, :cond_0

    if-ne v0, p1, :cond_0

    return v1

    :cond_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cG()I

    move-result v2

    if-ne v2, p0, :cond_1

    add-int/lit8 v0, v0, 0x1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, -0x1

    return p0
.end method

.method private static H(II)V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v1, 0x0

    if-lez v0, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cG()I

    move-result v2

    if-lez v2, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dd()I

    move-result v2

    if-ge v0, v2, :cond_2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dd()I

    move-result v0

    :cond_2
    :goto_2
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cG()I

    move-result v2

    if-nez v2, :cond_3

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v2

    const/4 v3, 0x7

    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v2

    if-ne v2, p0, :cond_3

    goto :goto_3

    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_4
    const/4 v0, 0x0

    :goto_3
    if-lez v0, :cond_5

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/a;

    invoke-virtual {p0, p1}, La/a;->W(I)V

    :cond_5
    return-void
.end method

.method public static X(I)Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cG()I

    move-result v2

    if-ne v2, p0, :cond_0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static Y(I)Ljava/util/ArrayList;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v2

    const/4 v3, 0x7

    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v2

    if-ne v2, p0, :cond_0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static Z(I)I
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cG()I

    move-result v1

    if-ne v1, p0, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    const/4 p0, -0x1

    return p0
.end method

.method public static a(J)Ljava/lang/String;
    .locals 2

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "dd/MM/yyyy"

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/text/SimpleDateFormat;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a(Ljava/util/Calendar;)Ljava/lang/String;
    .locals 1

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    move-result-object v0

    invoke-virtual {p0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a(Ljava/util/Date;)Ljava/lang/String;
    .locals 3

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    move-result-object v0

    invoke-virtual {p0}, Ljava/util/Date;->getTime()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/text/DateFormat;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static aa(I)I
    .locals 2

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cG()I

    move-result v1

    if-ne v1, p0, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, -0x1

    return p0
.end method

.method public static b(IZ)Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 p1, 0x4

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cG()I

    move-result v2

    if-ne v2, p0, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cJ()Z

    move-result v2

    if-nez v2, :cond_2

    if-gtz p1, :cond_1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    if-lez p1, :cond_2

    add-int/lit8 p1, p1, -0x1

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return-object v0
.end method

.method public static cI()Ljava/util/ArrayList;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v2

    const/4 v3, 0x5

    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static cL()V
    .locals 0

    invoke-static {}, La/a;->cM()V

    return-void
.end method

.method public static cM()V
    .locals 11

    const/16 v0, 0x64

    const/4 v1, 0x1

    invoke-static {v1, v0}, La/a;->H(II)V

    const/4 v2, 0x3

    invoke-static {v2, v0}, La/a;->H(II)V

    const/4 v3, 0x6

    invoke-static {v3, v0}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    const/16 v4, 0xc8

    const/4 v5, 0x2

    invoke-static {v5, v4}, La/a;->H(II)V

    const/4 v6, 0x5

    invoke-static {v6, v2}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    invoke-static {v6, v2}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v5, v4}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    invoke-static {v6, v2}, La/a;->H(II)V

    const/4 v7, 0x7

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    invoke-static {v6, v2}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    invoke-static {v6, v2}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v5, v4}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    const/4 v8, 0x4

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v2}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    invoke-static {v6, v8}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v2}, La/a;->H(II)V

    invoke-static {v6, v8}, La/a;->H(II)V

    invoke-static {v1, v2}, La/a;->H(II)V

    invoke-static {v2, v0}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v4}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    const/16 v9, 0x9

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v8}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v5}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v2, v0}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v8, v5}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v7}, La/a;->H(II)V

    invoke-static {v8, v7}, La/a;->H(II)V

    invoke-static {v1, v7}, La/a;->H(II)V

    invoke-static {v8, v7}, La/a;->H(II)V

    invoke-static {v1, v7}, La/a;->H(II)V

    invoke-static {v8, v7}, La/a;->H(II)V

    invoke-static {v1, v7}, La/a;->H(II)V

    invoke-static {v8, v7}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v0}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v8}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v2, v0}, La/a;->H(II)V

    invoke-static {v6, v1}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v5}, La/a;->H(II)V

    invoke-static {v6, v3}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v8, v5}, La/a;->H(II)V

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v5}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v5}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v8, v5}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    const/16 v10, 0x8

    invoke-static {v2, v10}, La/a;->H(II)V

    invoke-static {v6, v1}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v2, v10}, La/a;->H(II)V

    invoke-static {v6, v1}, La/a;->H(II)V

    invoke-static {v7, v4}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v2, v0}, La/a;->H(II)V

    invoke-static {v6, v1}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v5, v4}, La/a;->H(II)V

    invoke-static {v5, v9}, La/a;->H(II)V

    invoke-static {v2, v0}, La/a;->H(II)V

    invoke-static {v6, v1}, La/a;->H(II)V

    invoke-static {v3, v9}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v1}, La/a;->H(II)V

    invoke-static {v8, v1}, La/a;->H(II)V

    invoke-static {v3, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v1}, La/a;->H(II)V

    invoke-static {v8, v1}, La/a;->H(II)V

    invoke-static {v3, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v2, v6}, La/a;->H(II)V

    invoke-static {v6, v6}, La/a;->H(II)V

    invoke-static {v7, v6}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    invoke-static {v1, v1}, La/a;->H(II)V

    return-void
.end method

.method private cQ()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaSelecoesAll()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->li()La/ac;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static cV()V
    .locals 5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaSelecoesAll()Z

    move-result v0

    if-eqz v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    const/16 v1, 0x8

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v4}, La/a;->G(II)I

    move-result v0

    if-lez v0, :cond_1

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    invoke-static {v2, v0}, La/a;->G(II)I

    move-result v0

    if-lez v0, :cond_1

    :goto_0
    invoke-static {v0, v1, v3}, La/a;->h(III)V

    :cond_1
    const/16 v0, 0xa

    invoke-static {v2, v0}, La/a;->G(II)I

    move-result v0

    if-lez v0, :cond_2

    invoke-static {v0, v1, v3}, La/a;->h(III)V

    :cond_2
    const/4 v0, 0x7

    invoke-static {v0}, La/a;->aa(I)I

    move-result v0

    const/4 v1, 0x6

    if-lez v0, :cond_3

    invoke-static {v0, v1, v3}, La/a;->h(III)V

    :cond_3
    const/16 v0, 0xc

    invoke-static {v2, v0}, La/a;->G(II)I

    move-result v0

    if-lez v0, :cond_4

    invoke-static {v0, v1, v3}, La/a;->h(III)V

    :cond_4
    const/16 v0, 0x12

    invoke-static {v2, v0}, La/a;->G(II)I

    move-result v0

    if-lez v0, :cond_5

    invoke-static {v0, v1, v3}, La/a;->h(III)V

    :cond_5
    return-void
.end method

.method private g(Z)V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaSelecoesAll()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    if-nez p1, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->li()La/ac;

    move-result-object v2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/af;

    invoke-virtual {v2, v3, v0}, La/b;->a(La/af;Z)Ljava/util/ArrayList;

    move-result-object v2

    sput-object v2, La/o;->pS:Ljava/util/ArrayList;

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static h(III)V
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    const-string p1, "cw"

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    const-string p1, "ds"

    goto :goto_0

    :cond_1
    const/4 v0, 0x3

    if-ne p1, v0, :cond_2

    const-string p1, "aj"

    goto :goto_0

    :cond_2
    const/4 v0, 0x4

    if-ne p1, v0, :cond_3

    const-string p1, "cD"

    goto :goto_0

    :cond_3
    const/4 v0, 0x5

    if-ne p1, v0, :cond_4

    const-string p1, "dJ"

    goto :goto_0

    :cond_4
    const/4 v0, 0x6

    if-ne p1, v0, :cond_5

    const-string p1, "cS"

    goto :goto_0

    :cond_5
    const/4 v0, 0x7

    if-ne p1, v0, :cond_6

    const-string p1, "cO"

    goto :goto_0

    :cond_6
    const/16 v0, 0x8

    if-ne p1, v0, :cond_7

    const-string p1, "cSempregado"

    goto :goto_0

    :cond_7
    const/4 p1, 0x0

    :goto_0
    if-nez p2, :cond_8

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/a;

    iget-object p0, p0, La/a;->lO:Ljava/util/ArrayList;

    :goto_1
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_8
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/a;

    iget-object p0, p0, La/a;->lP:Ljava/util/ArrayList;

    goto :goto_1

    return-void
.end method


# virtual methods
.method public W(I)V
    .locals 0

    iput p1, p0, La/a;->lU:I

    return-void
.end method

.method public a(La/al;)V
    .locals 1

    iget-object v0, p0, La/a;->lR:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, La/a;->lR:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public a(La/t;)V
    .locals 1

    iget-object v0, p0, La/a;->lQ:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(La/ac;)Z
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/a;->lQ:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    iget-object v2, p0, La/a;->lQ:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    if-eq v2, p1, :cond_1

    iget-object v2, p0, La/a;->lQ:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    if-ne v2, p1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 p1, 0x1

    return p1

    :cond_2
    return v0
.end method

.method public ab(I)V
    .locals 11

    const-string v0, "cw"

    const-string v1, "ds"

    const-string v2, "aj"

    const-string v3, "cD"

    const-string v4, "dJ"

    const-string v5, "cS"

    const-string v6, "cO"

    const-string v7, "cSempregado"

    if-nez p1, :cond_0

    iget-object p1, p0, La/a;->lO:Ljava/util/ArrayList;

    goto :goto_0

    :cond_0
    iget-object p1, p0, La/a;->lP:Ljava/util/ArrayList;

    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-lez v8, :cond_9

    const/4 v8, 0x0

    const/4 v9, 0x0

    :goto_1
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_9

    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1

    invoke-virtual {p0}, La/a;->cU()V

    goto/16 :goto_2

    :cond_1
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-virtual {p0}, La/a;->cS()V

    goto :goto_2

    :cond_2
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_3

    sget-object v10, Lc/a;->TF:La/b;

    invoke-virtual {v10}, La/b;->eg()V

    goto :goto_2

    :cond_3
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_4

    sget-object v10, Lc/a;->TF:La/b;

    invoke-virtual {v10}, La/b;->eA()Z

    move-result v10

    if-eqz v10, :cond_8

    invoke-virtual {p0}, La/a;->cR()V

    goto :goto_2

    :cond_4
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_5

    invoke-virtual {p0}, La/a;->cT()V

    goto :goto_2

    :cond_5
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_6

    invoke-direct {p0, v8}, La/a;->g(Z)V

    goto :goto_2

    :cond_6
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_7

    goto :goto_2

    :cond_7
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_8

    const/4 v10, 0x1

    invoke-direct {p0, v10}, La/a;->g(Z)V

    :cond_8
    :goto_2
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_1

    :cond_9
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public b(La/al;)V
    .locals 1

    iget-object v0, p0, La/a;->lS:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, La/a;->lS:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public cF()Ljava/util/Calendar;
    .locals 1

    iget-object v0, p0, La/a;->lN:Ljava/util/Calendar;

    return-object v0
.end method

.method public cG()I
    .locals 1

    iget v0, p0, La/a;->lU:I

    return v0
.end method

.method public cH()I
    .locals 2

    iget-object v0, p0, La/a;->lN:Ljava/util/Calendar;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    return v0
.end method

.method public cJ()Z
    .locals 1

    iget-boolean v0, p0, La/a;->lT:Z

    return v0
.end method

.method public cK()Ljava/lang/String;
    .locals 2

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "dd/MM/yyyy"

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public cN()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/a;->lQ:Ljava/util/ArrayList;

    return-object v0
.end method

.method public cO()I
    .locals 2

    iget-object v0, p0, La/a;->lQ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_0

    iget-object v0, p0, La/a;->lQ:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/t;

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    return v0

    :cond_0
    return v1
.end method

.method public cP()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/a;->lR:Ljava/util/ArrayList;

    return-object v0
.end method

.method public cR()V
    .locals 7

    sget-object v0, Lc/a;->TF:La/b;

    const/16 v1, 0x1d

    invoke-virtual {v0, v1}, La/b;->ah(I)La/y;

    move-result-object v0

    if-eqz v0, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eA()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x4

    if-ne v1, v2, :cond_3

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld/q;

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1, v3}, Ld/q;->aD(Z)V

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->getnTimes()I

    move-result v4

    invoke-static {v4}, Ld/m;->ep(I)Ljava/util/ArrayList;

    move-result-object v5

    if-eqz v5, :cond_0

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ne v4, v6, :cond_0

    invoke-virtual {v1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    invoke-virtual {v1, v3}, Ld/q;->aD(Z)V

    invoke-virtual {v1, v2}, Ld/q;->setDivisao(I)V

    invoke-virtual {v1}, Ld/q;->xw()V

    invoke-virtual {v1}, Ld/q;->xv()V

    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_0
    const/4 v5, 0x2

    if-gt v2, v5, :cond_2

    move v5, v4

    const/4 v4, 0x0

    :goto_1
    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_1

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    move v4, v5

    goto :goto_0

    :cond_2
    rsub-int v2, v4, 0x80

    invoke-static {v2}, Ld/m;->ep(I)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0, v1}, La/y;->J(Ljava/util/ArrayList;)Z

    :cond_3
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eL()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public cS()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {p0}, La/a;->cH()I

    move-result v2

    invoke-virtual {v1, v2}, La/ac;->cd(I)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->mh()V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public cT()V
    .locals 4

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->mj()La/n;

    move-result-object v1

    if-eqz v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->mj()La/n;

    move-result-object v1

    invoke-virtual {v1}, La/n;->hr()I

    move-result v1

    if-lez v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->mj()La/n;

    move-result-object v2

    invoke-virtual {v2}, La/n;->hr()I

    move-result v2

    const/4 v3, 0x4

    invoke-virtual {v1, v2, v3}, La/ac;->V(II)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public cU()V
    .locals 1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ee()Ld/y;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ld/y;->yA()V

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ej()Ld/z;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ld/z;->yD()V

    :cond_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ei()Ld/aa;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ld/aa;->yD()V

    :cond_2
    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->tickSuperMundial()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->tickCss()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->tickCne()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->tickCv()V

    return-void
.end method

.method public cW()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/a;->lO:Ljava/util/ArrayList;

    return-object v0
.end method

.method public cX()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/a;->lP:Ljava/util/ArrayList;

    return-object v0
.end method

.method public cY()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/a;->lS:Ljava/util/ArrayList;

    return-object v0
.end method

.method public f(Z)V
    .locals 0

    iput-boolean p1, p0, La/a;->lT:Z

    return-void
.end method

.method public g(III)V
    .locals 1

    iget-object v0, p0, La/a;->lN:Ljava/util/Calendar;

    invoke-virtual {v0, p1, p2, p3}, Ljava/util/Calendar;->set(III)V

    return-void
.end method
