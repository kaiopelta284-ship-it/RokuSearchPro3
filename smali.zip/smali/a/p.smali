.class public La/p;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public anoIn:I

.field private aposentado:Z

.field public awAssist:I

.field public awBola:I

.field public awChut:I

.field public awLuva:I

.field public awPrata:I

.field public awReveal:I

.field public awTeam:I

.field private bolaBonus:I

.field public energiaBase:I

.field private forca:I

.field public idolOf:I

.field public lastGameDay:I

.field private oo:I

.field private pV:I

.field private pW:I

.field private pX:Ljava/lang/Boolean;

.field private pY:Ljava/lang/Boolean;

.field private pZ:I

.field private pais:I

.field private pendIsLoan:Z

.field private pendSaleClub:La/ac;

.field private pendSaleValue:I

.field private posicao:I

.field private pq:Ljava/lang/String;

.field private qA:Ljava/lang/Boolean;

.field private qB:Ljava/lang/Boolean;

.field private qC:I

.field private qD:I

.field private qE:I

.field private qF:I

.field private transient qG:I

.field private qH:I

.field private qI:I

.field private transient qJ:I

.field private transient qK:Lcomponents/bm;

.field private transient qL:I

.field private transient qM:I

.field private transient qa:La/ac;

.field private qb:I

.field private qc:I

.field private qd:I

.field private qe:I

.field private qf:I

.field private qg:I

.field private qh:I

.field private qi:I

.field private qj:I

.field private transient qk:Z

.field private ql:J

.field private qm:J

.field private qn:I

.field private qo:Ljava/lang/Boolean;

.field private qp:D

.field private qq:D

.field private qr:Ljava/lang/Boolean;

.field private qs:Ljava/lang/Boolean;

.field private qt:Ljava/lang/Boolean;

.field private qu:I

.field private qv:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/s;",
            ">;"
        }
    .end annotation
.end field

.field private qw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/e;",
            ">;"
        }
    .end annotation
.end field

.field private qx:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/br;",
            ">;"
        }
    .end annotation
.end field

.field private qy:I

.field private qz:Ljava/lang/Boolean;

.field public rcConvYear:I

.field private salario:I

.field public selAssists:I

.field public selGoals:I

.field public selTitles:I

.field private status:I


# direct methods
.method public constructor <init>()V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/p;->pV:I

    iput v0, p0, La/p;->pW:I

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->pY:Ljava/lang/Boolean;

    const/4 v2, 0x0

    iput-object v2, p0, La/p;->qa:La/ac;

    iput v0, p0, La/p;->oo:I

    iput v0, p0, La/p;->qb:I

    iput v1, p0, La/p;->qc:I

    iput v1, p0, La/p;->status:I

    iput v1, p0, La/p;->qg:I

    iput v1, p0, La/p;->qi:I

    iput v1, p0, La/p;->qj:I

    iput-boolean v1, p0, La/p;->qk:Z

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/p;->ql:J

    iput-wide v3, p0, La/p;->qm:J

    const/16 v3, 0x64

    iput v3, p0, La/p;->qn:I

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qo:Ljava/lang/Boolean;

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/p;->qp:D

    iput-wide v3, p0, La/p;->qq:D

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qr:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qs:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qt:Ljava/lang/Boolean;

    iput v0, p0, La/p;->qu:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qw:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qx:Ljava/util/ArrayList;

    iput v1, p0, La/p;->qy:I

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qz:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qA:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qB:Ljava/lang/Boolean;

    iput v1, p0, La/p;->qC:I

    iput v1, p0, La/p;->qD:I

    iput v1, p0, La/p;->qE:I

    iput v1, p0, La/p;->qF:I

    iput v1, p0, La/p;->qG:I

    iput v1, p0, La/p;->qH:I

    iput v1, p0, La/p;->qI:I

    iput v1, p0, La/p;->qJ:I

    iput-object v2, p0, La/p;->qK:Lcomponents/bm;

    iput v1, p0, La/p;->qL:I

    iput v1, p0, La/p;->qM:I

    return-void
.end method

.method public constructor <init>(I)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/p;->pV:I

    iput v0, p0, La/p;->pW:I

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->pY:Ljava/lang/Boolean;

    const/4 v2, 0x0

    iput-object v2, p0, La/p;->qa:La/ac;

    iput v0, p0, La/p;->oo:I

    iput v0, p0, La/p;->qb:I

    iput v1, p0, La/p;->qc:I

    iput v1, p0, La/p;->status:I

    iput v1, p0, La/p;->qg:I

    iput v1, p0, La/p;->qi:I

    iput v1, p0, La/p;->qj:I

    iput-boolean v1, p0, La/p;->qk:Z

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/p;->ql:J

    iput-wide v3, p0, La/p;->qm:J

    const/16 v3, 0x64

    iput v3, p0, La/p;->qn:I

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qo:Ljava/lang/Boolean;

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/p;->qp:D

    iput-wide v3, p0, La/p;->qq:D

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qr:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qs:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qt:Ljava/lang/Boolean;

    iput v0, p0, La/p;->qu:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qw:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qx:Ljava/util/ArrayList;

    iput v1, p0, La/p;->qy:I

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qz:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qA:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qB:Ljava/lang/Boolean;

    iput v1, p0, La/p;->qC:I

    iput v1, p0, La/p;->qD:I

    iput v1, p0, La/p;->qE:I

    iput v1, p0, La/p;->qF:I

    iput v1, p0, La/p;->qG:I

    iput v1, p0, La/p;->qH:I

    iput v1, p0, La/p;->qI:I

    iput v1, p0, La/p;->qJ:I

    iput-object v2, p0, La/p;->qK:Lcomponents/bm;

    iput v1, p0, La/p;->qL:I

    iput v1, p0, La/p;->qM:I

    iput p1, p0, La/p;->pais:I

    invoke-static {p1}, La/p;->bf(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, La/p;->pq:Ljava/lang/String;

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->eW()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public constructor <init>(Lcomponents/bx;La/ac;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/p;->pV:I

    iput v0, p0, La/p;->pW:I

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->pY:Ljava/lang/Boolean;

    const/4 v2, 0x0

    iput-object v2, p0, La/p;->qa:La/ac;

    iput v0, p0, La/p;->oo:I

    iput v0, p0, La/p;->qb:I

    iput v1, p0, La/p;->qc:I

    iput v1, p0, La/p;->status:I

    iput v1, p0, La/p;->qg:I

    iput v1, p0, La/p;->qi:I

    iput v1, p0, La/p;->qj:I

    iput-boolean v1, p0, La/p;->qk:Z

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/p;->ql:J

    iput-wide v3, p0, La/p;->qm:J

    const/16 v3, 0x64

    iput v3, p0, La/p;->qn:I

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qo:Ljava/lang/Boolean;

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/p;->qp:D

    iput-wide v3, p0, La/p;->qq:D

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qr:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qs:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qt:Ljava/lang/Boolean;

    iput v0, p0, La/p;->qu:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qw:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/p;->qx:Ljava/util/ArrayList;

    iput v1, p0, La/p;->qy:I

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qz:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qA:Ljava/lang/Boolean;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qB:Ljava/lang/Boolean;

    iput v1, p0, La/p;->qC:I

    iput v1, p0, La/p;->qD:I

    iput v1, p0, La/p;->qE:I

    iput v1, p0, La/p;->qF:I

    iput v1, p0, La/p;->qG:I

    iput v1, p0, La/p;->qH:I

    iput v1, p0, La/p;->qI:I

    iput v1, p0, La/p;->qJ:I

    iput-object v2, p0, La/p;->qK:Lcomponents/bm;

    iput v1, p0, La/p;->qL:I

    iput v1, p0, La/p;->qM:I

    iget-object v0, p1, Lcomponents/bx;->pq:Ljava/lang/String;

    invoke-virtual {p0, v0}, La/p;->setNome(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, La/p;->i(La/ac;)V

    iget p2, p1, Lcomponents/bx;->pais:I

    invoke-virtual {p0, p2}, La/p;->setPais(I)V

    iget p2, p1, Lcomponents/bx;->posicao:I

    invoke-virtual {p0, p2}, La/p;->setPosicao(I)V

    iget p2, p1, Lcomponents/bx;->qc:I

    invoke-virtual {p0, p2}, La/p;->setLado(I)V

    iget p2, p1, Lcomponents/bx;->Qx:I

    const/4 v0, 0x1

    if-ne p2, v0, :cond_0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    iput-object p2, p0, La/p;->pY:Ljava/lang/Boolean;

    :cond_0
    iget p2, p1, Lcomponents/bx;->estrela:I

    if-ne p2, v0, :cond_1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    :goto_0
    invoke-virtual {p0, p2}, La/p;->a(Ljava/lang/Boolean;)V

    goto :goto_1

    :cond_1
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    goto :goto_0

    :goto_1
    iget p2, p1, Lcomponents/bx;->qd:I

    invoke-virtual {p0, p2}, La/p;->ba(I)V

    iget p2, p1, Lcomponents/bx;->Qw:I

    invoke-virtual {p0, p2}, La/p;->setStatus(I)V

    iget p2, p1, Lcomponents/bx;->Qy:I

    invoke-virtual {p0, p2}, La/p;->setCr1(I)V

    iget p2, p1, Lcomponents/bx;->Qz:I

    invoke-virtual {p0, p2}, La/p;->setCr2(I)V

    iget p1, p1, Lcomponents/bx;->pZ:I

    invoke-virtual {p0, p1}, La/p;->setIdade(I)V

    invoke-virtual {p0}, La/p;->ib()V

    return-void
.end method

.method public constructor <init>(Le/g;ZLa/ac;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p2, -0x1

    iput p2, p0, La/p;->pV:I

    iput p2, p0, La/p;->pW:I

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, p0, La/p;->pY:Ljava/lang/Boolean;

    const/4 v1, 0x0

    iput-object v1, p0, La/p;->qa:La/ac;

    iput p2, p0, La/p;->oo:I

    iput p2, p0, La/p;->qb:I

    iput v0, p0, La/p;->qc:I

    iput v0, p0, La/p;->status:I

    iput v0, p0, La/p;->qg:I

    iput v0, p0, La/p;->qi:I

    iput v0, p0, La/p;->qj:I

    iput-boolean v0, p0, La/p;->qk:Z

    const-wide/16 v2, 0x0

    iput-wide v2, p0, La/p;->ql:J

    iput-wide v2, p0, La/p;->qm:J

    const/16 v2, 0x64

    iput v2, p0, La/p;->qn:I

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->qo:Ljava/lang/Boolean;

    const-wide/16 v2, 0x0

    iput-wide v2, p0, La/p;->qp:D

    iput-wide v2, p0, La/p;->qq:D

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->qr:Ljava/lang/Boolean;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->qs:Ljava/lang/Boolean;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p0, La/p;->qt:Ljava/lang/Boolean;

    iput p2, p0, La/p;->qu:I

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, La/p;->qv:Ljava/util/ArrayList;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, La/p;->qw:Ljava/util/ArrayList;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, La/p;->qx:Ljava/util/ArrayList;

    iput v0, p0, La/p;->qy:I

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    iput-object p2, p0, La/p;->qz:Ljava/lang/Boolean;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    iput-object p2, p0, La/p;->qA:Ljava/lang/Boolean;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    iput-object p2, p0, La/p;->qB:Ljava/lang/Boolean;

    iput v0, p0, La/p;->qC:I

    iput v0, p0, La/p;->qD:I

    iput v0, p0, La/p;->qE:I

    iput v0, p0, La/p;->qF:I

    iput v0, p0, La/p;->qG:I

    iput v0, p0, La/p;->qH:I

    iput v0, p0, La/p;->qI:I

    iput v0, p0, La/p;->qJ:I

    iput-object v1, p0, La/p;->qK:Lcomponents/bm;

    iput v0, p0, La/p;->qL:I

    iput v0, p0, La/p;->qM:I

    invoke-virtual {p1}, Le/g;->getNome()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2}, La/p;->setNome(Ljava/lang/String;)V

    invoke-virtual {p0, p3}, La/p;->i(La/ac;)V

    invoke-virtual {p1}, Le/g;->getPais()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->setPais(I)V

    invoke-virtual {p1}, Le/g;->getPosicao()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->setPosicao(I)V

    invoke-virtual {p1}, Le/g;->getLado()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->setLado(I)V

    invoke-virtual {p1}, Le/g;->isTopMundial()Z

    move-result p2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    iput-object p2, p0, La/p;->pY:Ljava/lang/Boolean;

    invoke-virtual {p1}, Le/g;->isEstrela()Z

    move-result p2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p0, p2}, La/p;->a(Ljava/lang/Boolean;)V

    invoke-virtual {p1}, Le/g;->getHash()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->ba(I)V

    invoke-virtual {p1}, Le/g;->getStatus()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->setStatus(I)V

    invoke-virtual {p1}, Le/g;->getCr1()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->setCr1(I)V

    invoke-virtual {p1}, Le/g;->getCr2()I

    move-result p2

    invoke-virtual {p0, p2}, La/p;->setCr2(I)V

    invoke-virtual {p1}, Le/g;->getIdade()I

    move-result p1

    invoke-virtual {p0, p1}, La/p;->setIdade(I)V

    invoke-virtual {p0}, La/p;->ib()V

    return-void
.end method

.method private b(ILa/ac;)V
    .locals 1

    invoke-virtual {p0, p2}, La/p;->j(La/ac;)La/e;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance v0, La/e;

    invoke-direct {v0, p0, p2}, La/e;-><init>(La/p;La/ac;)V

    iget-object p2, p0, La/p;->qw:Ljava/util/ArrayList;

    if-eqz p2, :cond_0

    iget-object p2, p0, La/p;->qw:Ljava/util/ArrayList;

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 p2, 0x2

    if-ne p1, p2, :cond_1

    invoke-virtual {v0}, La/e;->fS()V

    return-void

    :cond_1
    const/4 p2, 0x4

    if-ne p1, p2, :cond_2

    invoke-virtual {v0}, La/e;->fT()V

    return-void

    :cond_2
    const/4 p2, 0x3

    if-ne p1, p2, :cond_3

    invoke-virtual {v0}, La/e;->fU()V

    return-void

    :cond_3
    const/4 p2, 0x1

    if-ne p1, p2, :cond_4

    invoke-virtual {v0}, La/e;->fR()V

    return-void

    :cond_4
    const/4 p2, 0x5

    if-ne p1, p2, :cond_5

    invoke-virtual {v0}, La/e;->fQ()V

    return-void

    :cond_5
    if-nez p1, :cond_6

    invoke-virtual {v0}, La/e;->fD()V

    return-void

    :cond_6
    const/16 p2, 0x8

    if-ne p1, p2, :cond_7

    invoke-virtual {v0}, La/e;->fM()V

    :cond_7
    return-void
.end method

.method public static be(I)[I
    .locals 11

    const/4 v0, 0x5

    new-array v1, v0, [[[I

    new-array v2, v0, [[I

    const/4 v3, 0x2

    new-array v4, v3, [I

    fill-array-data v4, :array_0

    const/4 v5, 0x0

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_1

    const/4 v6, 0x1

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_2

    aput-object v4, v2, v3

    new-array v4, v3, [I

    fill-array-data v4, :array_3

    const/4 v7, 0x3

    aput-object v4, v2, v7

    new-array v4, v3, [I

    fill-array-data v4, :array_4

    const/4 v8, 0x4

    aput-object v4, v2, v8

    aput-object v2, v1, v5

    new-array v2, v8, [[I

    new-array v4, v3, [I

    fill-array-data v4, :array_5

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_6

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_7

    aput-object v4, v2, v3

    new-array v4, v3, [I

    fill-array-data v4, :array_8

    aput-object v4, v2, v7

    aput-object v2, v1, v6

    new-array v2, v8, [[I

    new-array v4, v3, [I

    fill-array-data v4, :array_9

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_a

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_b

    aput-object v4, v2, v3

    new-array v4, v3, [I

    fill-array-data v4, :array_c

    aput-object v4, v2, v7

    aput-object v2, v1, v3

    const/16 v2, 0xc

    new-array v2, v2, [[I

    new-array v4, v3, [I

    fill-array-data v4, :array_d

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_e

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_f

    aput-object v4, v2, v3

    new-array v4, v3, [I

    fill-array-data v4, :array_10

    aput-object v4, v2, v7

    new-array v4, v3, [I

    fill-array-data v4, :array_11

    aput-object v4, v2, v8

    new-array v4, v3, [I

    fill-array-data v4, :array_12

    aput-object v4, v2, v0

    new-array v4, v3, [I

    fill-array-data v4, :array_13

    const/4 v9, 0x6

    aput-object v4, v2, v9

    new-array v4, v3, [I

    fill-array-data v4, :array_14

    const/4 v10, 0x7

    aput-object v4, v2, v10

    new-array v4, v3, [I

    fill-array-data v4, :array_15

    const/16 v10, 0x8

    aput-object v4, v2, v10

    new-array v4, v3, [I

    fill-array-data v4, :array_16

    const/16 v10, 0x9

    aput-object v4, v2, v10

    new-array v4, v3, [I

    fill-array-data v4, :array_17

    const/16 v10, 0xa

    aput-object v4, v2, v10

    new-array v4, v3, [I

    fill-array-data v4, :array_18

    const/16 v10, 0xb

    aput-object v4, v2, v10

    aput-object v2, v1, v7

    new-array v2, v9, [[I

    new-array v4, v3, [I

    fill-array-data v4, :array_19

    aput-object v4, v2, v5

    new-array v4, v3, [I

    fill-array-data v4, :array_1a

    aput-object v4, v2, v6

    new-array v4, v3, [I

    fill-array-data v4, :array_1b

    aput-object v4, v2, v3

    new-array v4, v3, [I

    fill-array-data v4, :array_1c

    aput-object v4, v2, v7

    new-array v4, v3, [I

    fill-array-data v4, :array_1d

    aput-object v4, v2, v8

    new-array v4, v3, [I

    fill-array-data v4, :array_1e

    aput-object v4, v2, v0

    aput-object v2, v1, v8

    aget-object p0, v1, p0

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    array-length v1, p0

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    new-array v1, v3, [I

    aget-object v2, p0, v0

    aget v2, v2, v5

    aput v2, v1, v5

    aget-object p0, p0, v0

    aget p0, p0, v6

    aput p0, v1, v6

    return-object v1

    :array_0
    .array-data 4
        0x0
        0x3
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x1
    .end array-data

    :array_2
    .array-data 4
        0x2
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x1
        0x2
    .end array-data

    :array_4
    .array-data 4
        0x3
        0x1
    .end array-data

    :array_5
    .array-data 4
        0x6
        0xa
    .end array-data

    :array_6
    .array-data 4
        0x6
        0xd
    .end array-data

    :array_7
    .array-data 4
        0xa
        0xb
    .end array-data

    :array_8
    .array-data 4
        0xa
        0xd
    .end array-data

    :array_9
    .array-data 4
        0x7
        0xa
    .end array-data

    :array_a
    .array-data 4
        0x7
        0xc
    .end array-data

    :array_b
    .array-data 4
        0x7
        0x5
    .end array-data

    :array_c
    .array-data 4
        0xa
        0xd
    .end array-data

    :array_d
    .array-data 4
        0x4
        0xb
    .end array-data

    :array_e
    .array-data 4
        0x4
        0x9
    .end array-data

    :array_f
    .array-data 4
        0x9
        0xb
    .end array-data

    :array_10
    .array-data 4
        0xb
        0x9
    .end array-data

    :array_11
    .array-data 4
        0x4
        0x8
    .end array-data

    :array_12
    .array-data 4
        0x4
        0xd
    .end array-data

    :array_13
    .array-data 4
        0x7
        0xa
    .end array-data

    :array_14
    .array-data 4
        0x7
        0xb
    .end array-data

    :array_15
    .array-data 4
        0x7
        0x5
    .end array-data

    :array_16
    .array-data 4
        0x7
        0xd
    .end array-data

    :array_17
    .array-data 4
        0xa
        0xd
    .end array-data

    :array_18
    .array-data 4
        0xa
        0xb
    .end array-data

    :array_19
    .array-data 4
        0x9
        0x5
    .end array-data

    :array_1a
    .array-data 4
        0xd
        0x9
    .end array-data

    :array_1b
    .array-data 4
        0x8
        0x9
    .end array-data

    :array_1c
    .array-data 4
        0x9
        0xd
    .end array-data

    :array_1d
    .array-data 4
        0x9
        0x8
    .end array-data

    :array_1e
    .array-data 4
        0x5
        0xd
    .end array-data
.end method

.method public static bf(I)Ljava/lang/String;
    .locals 2

    invoke-static {p0}, La/v;->bf(I)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    invoke-static {p0}, La/p;->bg(I)Ljava/lang/String;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public static bg(I)Ljava/lang/String;
    .locals 13

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ek()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    new-instance v1, Ljava/lang/String;

    invoke-direct {v1}, Ljava/lang/String;-><init>()V

    const/16 v2, 0x712a

    const/16 v3, 0x9fa

    const/16 v4, 0x79eb

    const/16 v5, 0x4e12

    const/16 v6, 0x359e

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/16 v9, 0xad3

    const/16 v10, 0x1733

    const/16 v11, 0x7bc

    const/16 v12, 0x2206

    if-nez v0, :cond_15

    const/16 v0, 0x61

    if-eq p0, v0, :cond_14

    const/16 v0, 0x3e

    if-eq p0, v0, :cond_14

    const/16 v0, 0x64

    if-eq p0, v0, :cond_14

    const/16 v0, 0x65

    if-eq p0, v0, :cond_14

    const/16 v0, 0x91

    if-ne p0, v0, :cond_1

    goto/16 :goto_8

    :cond_1
    if-eq p0, v7, :cond_13

    const/16 v0, 0xf

    if-ne p0, v0, :cond_2

    goto/16 :goto_7

    :cond_2
    const/16 v2, 0x68

    if-ne p0, v2, :cond_3

    const/16 v2, 0x2ef9

    const/16 v3, 0x6a4

    goto/16 :goto_d

    :cond_3
    const/16 v2, 0x48

    if-ne p0, v2, :cond_4

    const/16 v3, 0x385

    :goto_0
    const/16 v2, 0x359e

    goto/16 :goto_d

    :cond_4
    const/16 v2, 0x55

    if-ne p0, v2, :cond_5

    const/16 v2, 0x3923

    const/16 v3, 0x726

    goto/16 :goto_d

    :cond_5
    const/16 v2, 0x9a

    if-ne p0, v2, :cond_6

    const/16 v2, 0x404a

    const/16 v3, 0xdc8

    goto/16 :goto_d

    :cond_6
    const/16 v2, 0x8e

    if-eq p0, v2, :cond_12

    const/16 v2, 0x46

    if-eq p0, v2, :cond_12

    if-eq p0, v0, :cond_12

    const/16 v0, 0xb3

    if-eq p0, v0, :cond_12

    const/16 v0, 0x36

    if-ne p0, v0, :cond_7

    goto/16 :goto_5

    :cond_7
    const/16 v2, 0xa2

    if-eq p0, v2, :cond_11

    const/16 v2, 0xc1

    if-eq p0, v2, :cond_11

    const/16 v2, 0xc

    if-eq p0, v2, :cond_11

    const/16 v2, 0x19

    if-eq p0, v2, :cond_11

    if-ne p0, v0, :cond_8

    goto :goto_4

    :cond_8
    const/16 v0, 0x9f

    if-eq p0, v0, :cond_10

    const/16 v0, 0x98

    if-eq p0, v0, :cond_10

    const/16 v0, 0x58

    if-eq p0, v0, :cond_10

    const/16 v0, 0xa0

    if-eq p0, v0, :cond_10

    const/16 v0, 0x3f

    if-eq p0, v0, :cond_10

    const/16 v0, 0x40

    if-ne p0, v0, :cond_9

    goto :goto_3

    :cond_9
    const/16 v0, 0x34

    if-eq p0, v0, :cond_f

    const/16 v0, 0x1b

    if-ne p0, v0, :cond_a

    goto :goto_2

    :cond_a
    const/16 v0, 0x4e

    if-eq p0, v0, :cond_e

    const/16 v0, 0x2c

    if-ne p0, v0, :cond_b

    goto :goto_1

    :cond_b
    const/16 v0, 0x15

    if-ne p0, v0, :cond_c

    const/16 v3, 0xaac

    goto :goto_0

    :cond_c
    const/16 v0, 0x41

    if-ne p0, v0, :cond_d

    goto :goto_a

    :cond_d
    const/16 v3, 0x16a9

    goto :goto_6

    :cond_e
    :goto_1
    const/16 v2, 0x64bb

    const/16 v3, 0x310

    goto/16 :goto_d

    :cond_f
    :goto_2
    const/16 v2, 0x5dcd

    const/16 v3, 0x6ee

    goto/16 :goto_d

    :cond_10
    :goto_3
    const/16 v2, 0x58e4

    const/16 v3, 0x4e9

    goto/16 :goto_d

    :cond_11
    :goto_4
    const/16 v2, 0x534f

    const/16 v3, 0x595

    goto/16 :goto_d

    :cond_12
    :goto_5
    const/16 v3, 0x53c

    :goto_6
    const/16 v2, 0x4e12

    goto/16 :goto_d

    :cond_13
    :goto_7
    const/16 v2, 0x2a76

    const/16 v3, 0x483

    goto/16 :goto_d

    :cond_14
    :goto_8
    const/16 v2, 0x2206

    const/16 v3, 0x7bc

    goto/16 :goto_d

    :cond_15
    if-ne v0, v8, :cond_17

    const/16 v0, 0x1d

    if-ne p0, v0, :cond_16

    const/16 v3, 0x1732

    :goto_9
    const/4 v2, 0x1

    goto/16 :goto_d

    :cond_16
    :goto_a
    const/16 v2, 0x1733

    const/16 v3, 0xad3

    goto/16 :goto_d

    :cond_17
    const/4 v5, 0x2

    const/16 v6, 0xbe

    if-ne v0, v5, :cond_1a

    const/16 v0, 0x39

    if-eq p0, v0, :cond_19

    const/16 v0, 0xa

    if-eq p0, v0, :cond_19

    const/16 v0, 0x81

    if-eq p0, v0, :cond_19

    const/16 v0, 0x74

    if-eq p0, v0, :cond_19

    const/16 v0, 0xb2

    if-eq p0, v0, :cond_19

    if-ne p0, v6, :cond_18

    goto :goto_b

    :cond_18
    const/16 v2, 0x67cb

    const/16 v3, 0x95e

    goto/16 :goto_d

    :cond_19
    :goto_b
    const/16 v2, 0x79eb

    goto/16 :goto_d

    :cond_1a
    if-ne v0, v7, :cond_21

    const/16 v0, 0x30

    if-eq p0, v0, :cond_20

    const/16 v0, 0x31

    if-ne p0, v0, :cond_1b

    goto :goto_c

    :cond_1b
    const/16 v0, 0x6b

    if-ne p0, v0, :cond_1c

    const/16 v2, 0x75ba

    const/16 v3, 0x430

    goto/16 :goto_d

    :cond_1c
    const/16 v0, 0x2b

    if-ne p0, v0, :cond_1d

    const/16 v3, 0x25f

    goto/16 :goto_d

    :cond_1d
    const/16 v0, 0xe

    if-ne p0, v0, :cond_1e

    goto :goto_8

    :cond_1e
    const/16 v0, 0x9

    if-eq p0, v0, :cond_19

    const/16 v0, 0x12

    if-eq p0, v0, :cond_19

    const/16 v0, 0x3b

    if-eq p0, v0, :cond_19

    const/16 v0, 0x59

    if-eq p0, v0, :cond_19

    const/16 v0, 0x63

    if-eq p0, v0, :cond_19

    const/16 v0, 0x62

    if-eq p0, v0, :cond_19

    const/16 v0, 0x6c

    if-eq p0, v0, :cond_19

    const/16 v0, 0x6f

    if-eq p0, v0, :cond_19

    const/16 v0, 0x73

    if-eq p0, v0, :cond_19

    const/16 v0, 0x75

    if-eq p0, v0, :cond_19

    const/16 v0, 0x90

    if-eq p0, v0, :cond_19

    const/16 v0, 0x92

    if-eq p0, v0, :cond_19

    const/16 v0, 0x67

    if-eq p0, v0, :cond_19

    const/16 v0, 0x27

    if-eq p0, v0, :cond_19

    if-ne p0, v6, :cond_1f

    goto :goto_b

    :cond_1f
    const/16 v3, 0x12bb

    goto :goto_d

    :cond_20
    :goto_c
    const/16 v2, 0x738a

    const/16 v3, 0x230

    goto :goto_d

    :cond_21
    const/4 v2, 0x4

    if-ne v0, v2, :cond_22

    const/16 v0, 0x44

    if-eq p0, v0, :cond_14

    const/16 v0, 0x26

    if-eq p0, v0, :cond_14

    const/16 v0, 0x6a

    if-ne p0, v0, :cond_16

    goto/16 :goto_8

    :cond_22
    const/4 p0, 0x5

    if-ne v0, p0, :cond_23

    goto/16 :goto_8

    :cond_23
    const/16 v3, 0x4e20

    goto/16 :goto_9

    :goto_d
    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    invoke-virtual {p0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    add-int/2addr p0, v2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ek()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p0, v0, :cond_24

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ek()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    move-object v1, p0

    check-cast v1, Ljava/lang/String;

    :cond_24
    return-object v1
.end method

.method private static enReal()Z
    .locals 1

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lest/Options;->isEnergiaReal()Z

    move-result v0

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method private ir()V
    .locals 21

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    const/16 v2, 0x12

    const/16 v3, 0x14

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-wide/16 v6, 0x0

    if-eqz v1, :cond_2

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNivel()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-nez v8, :cond_3

    const-wide v6, 0x3f9eb851eb851eb8L    # 0.03

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    if-lt v1, v4, :cond_0

    const/16 v1, 0x14

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v5, :cond_1

    const/16 v1, 0x12

    goto :goto_0

    :cond_1
    const/16 v1, 0xc

    goto :goto_0

    :cond_2
    const/16 v1, 0xf

    :cond_3
    :goto_0
    const/16 v8, 0x13

    const-wide v9, 0x3fa47ae147ae147bL    # 0.04

    const/16 v11, 0x15

    const/16 v12, 0x1d

    const-wide v13, 0x3f947ae147ae147bL    # 0.02

    const-wide v15, 0x3faeb851eb851eb8L    # 0.06

    if-lt v1, v8, :cond_7

    iget v1, v0, La/p;->pZ:I

    if-ge v1, v3, :cond_4

    const-wide v1, 0x3fc47ae147ae147bL    # 0.16

    goto/16 :goto_7

    :cond_4
    iget v1, v0, La/p;->pZ:I

    const/16 v2, 0x17

    if-ge v1, v2, :cond_5

    :goto_1
    const-wide v1, 0x3fbeb851eb851eb8L    # 0.12

    goto :goto_7

    :cond_5
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v12, :cond_6

    :goto_2
    const-wide v1, 0x3fb999999999999aL    # 0.1

    goto :goto_7

    :cond_6
    :goto_3
    const-wide v1, 0x3fb47ae147ae147bL    # 0.08

    goto :goto_7

    :cond_7
    const/16 v8, 0xf

    if-lt v1, v8, :cond_b

    iget v1, v0, La/p;->pZ:I

    if-ge v1, v2, :cond_8

    goto :goto_1

    :cond_8
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v11, :cond_9

    :goto_4
    goto :goto_2

    :cond_9
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v12, :cond_a

    goto :goto_3

    :cond_a
    :goto_5
    move-wide v1, v15

    goto :goto_7

    :cond_b
    const/16 v8, 0xb

    if-lt v1, v8, :cond_f

    iget v1, v0, La/p;->pZ:I

    if-ge v1, v2, :cond_c

    goto :goto_4

    :cond_c
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v11, :cond_d

    goto :goto_3

    :cond_d
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v12, :cond_e

    goto :goto_5

    :cond_e
    :goto_6
    move-wide v1, v9

    goto :goto_7

    :cond_f
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v2, :cond_10

    goto :goto_3

    :cond_10
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v11, :cond_11

    goto :goto_5

    :cond_11
    iget v1, v0, La/p;->pZ:I

    if-ge v1, v12, :cond_12

    goto :goto_6

    :cond_12
    move-wide v1, v13

    :goto_7
    iget-object v8, v0, La/p;->qo:Ljava/lang/Boolean;

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-eqz v8, :cond_13

    add-double/2addr v1, v9

    :cond_13
    iget v8, v0, La/p;->forca:I

    const/16 v3, 0x1e

    const/16 v11, 0x46

    const/16 v12, 0x64

    if-lt v8, v3, :cond_14

    iget v8, v0, La/p;->forca:I

    const/16 v3, 0x28

    if-gt v8, v3, :cond_14

    sub-double/2addr v1, v13

    goto :goto_9

    :cond_14
    iget v3, v0, La/p;->forca:I

    const/16 v8, 0x29

    if-lt v3, v8, :cond_15

    iget v3, v0, La/p;->forca:I

    const/16 v8, 0x32

    if-gt v3, v8, :cond_15

    const-wide v18, 0x3f9eb851eb851eb8L    # 0.03

    :goto_8
    sub-double v1, v1, v18

    goto :goto_9

    :cond_15
    iget v3, v0, La/p;->forca:I

    const/16 v8, 0x33

    if-lt v3, v8, :cond_16

    iget v3, v0, La/p;->forca:I

    if-gt v3, v11, :cond_16

    sub-double/2addr v1, v9

    goto :goto_9

    :cond_16
    iget v3, v0, La/p;->forca:I

    const/16 v8, 0x47

    if-lt v3, v8, :cond_17

    iget v3, v0, La/p;->forca:I

    if-gt v3, v12, :cond_17

    const-wide v18, 0x3fa999999999999aL    # 0.05

    goto :goto_8

    :cond_17
    :goto_9
    iget v3, v0, La/p;->qF:I

    if-lez v3, :cond_1b

    iget v3, v0, La/p;->qF:I

    const/16 v8, 0x32

    if-ge v3, v8, :cond_18

    const-wide v18, 0x3fa999999999999aL    # 0.05

    sub-double v1, v1, v18

    goto :goto_a

    :cond_18
    iget v3, v0, La/p;->qF:I

    if-ge v3, v11, :cond_19

    sub-double/2addr v1, v13

    :cond_19
    :goto_a
    iget v3, v0, La/p;->qd:I

    const/16 v8, 0x9

    if-lt v3, v8, :cond_1a

    const-wide v18, 0x3fb1eb851eb851ecL    # 0.07

    :goto_b
    add-double v1, v1, v18

    goto :goto_c

    :cond_1a
    iget v3, v0, La/p;->qd:I

    const/4 v8, 0x7

    if-lt v3, v8, :cond_1b

    const-wide v18, 0x3fa999999999999aL    # 0.05

    goto :goto_b

    :cond_1b
    :goto_c
    invoke-virtual/range {p0 .. p0}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_1c

    add-double/2addr v1, v13

    goto :goto_d

    :cond_1c
    invoke-virtual/range {p0 .. p0}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_1d

    const-wide v18, 0x3f847ae147ae147bL    # 0.01

    add-double v1, v1, v18

    :cond_1d
    :goto_d
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    const/4 v8, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    if-eq v3, v8, :cond_27

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    if-ne v3, v5, :cond_1e

    goto/16 :goto_11

    :cond_1e
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    if-ne v3, v12, :cond_1f

    cmpl-double v3, v1, v15

    if-lez v3, :cond_28

    sub-double/2addr v1, v9

    goto/16 :goto_13

    :cond_1f
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    if-ne v3, v4, :cond_20

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x83

    if-eq v3, v8, :cond_28

    cmpl-double v3, v1, v15

    if-lez v3, :cond_28

    const-wide v8, 0x3f9eb851eb851eb8L    # 0.03

    :goto_e
    sub-double/2addr v1, v8

    goto/16 :goto_13

    :cond_20
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    if-ne v3, v11, :cond_22

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x1d

    if-ne v3, v8, :cond_21

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0xb

    if-ne v3, v8, :cond_21

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x2a

    if-ne v3, v8, :cond_21

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0xc3

    if-eq v3, v8, :cond_28

    :cond_21
    cmpl-double v3, v1, v15

    if-lez v3, :cond_28

    goto/16 :goto_12

    :cond_22
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    if-nez v3, :cond_28

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    if-eq v3, v5, :cond_26

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x48

    if-eq v3, v8, :cond_26

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x68

    if-eq v3, v8, :cond_26

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x41

    if-eq v3, v8, :cond_26

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x61

    if-ne v3, v8, :cond_23

    goto :goto_10

    :cond_23
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x9a

    if-eq v3, v8, :cond_25

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x55

    if-eq v3, v8, :cond_25

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v8, 0x15

    if-ne v3, v8, :cond_24

    goto :goto_f

    :cond_24
    cmpl-double v3, v1, v15

    if-lez v3, :cond_28

    goto :goto_12

    :cond_25
    :goto_f
    cmpl-double v3, v1, v15

    if-lez v3, :cond_28

    const-wide v8, 0x3f847ae147ae147bL    # 0.01

    goto/16 :goto_e

    :cond_26
    :goto_10
    const-wide v8, 0x3f847ae147ae147bL    # 0.01

    add-double/2addr v1, v8

    goto :goto_13

    :cond_27
    :goto_11
    cmpl-double v3, v1, v15

    if-lez v3, :cond_28

    :goto_12
    sub-double/2addr v1, v13

    :cond_28
    :goto_13
    const/4 v3, 0x0

    add-double/2addr v1, v6

    const-wide/16 v6, 0x0

    cmpg-double v3, v1, v6

    if-gez v3, :cond_29

    const-wide v1, 0x3f847ae147ae147bL    # 0.01

    :cond_29
    iget-wide v6, v0, La/p;->qp:D

    add-double/2addr v6, v1

    iput-wide v6, v0, La/p;->qp:D

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/16 v3, 0x3c

    if-eqz v1, :cond_2f

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getDivisao()I

    move-result v1

    if-nez v1, :cond_2a

    :goto_14
    const/16 v17, 0x1e

    goto :goto_15

    :cond_2a
    if-ne v1, v11, :cond_2b

    const/16 v17, 0x64

    goto :goto_15

    :cond_2b
    const/4 v2, 0x2

    if-ne v1, v2, :cond_2c

    const/16 v17, 0x3c

    goto :goto_15

    :cond_2c
    if-ne v1, v5, :cond_2d

    const/16 v1, 0x28

    const/16 v17, 0x28

    goto :goto_15

    :cond_2d
    if-ne v1, v4, :cond_2e

    goto :goto_14

    :cond_2e
    const/16 v17, 0x14

    :goto_15
    move/from16 v1, v17

    goto :goto_17

    :cond_2f
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v12, :cond_30

    :goto_16
    const/16 v1, 0x64

    goto :goto_17

    :cond_30
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v4, :cond_31

    goto :goto_16

    :cond_31
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v5, :cond_32

    const/16 v1, 0x4b

    goto :goto_17

    :cond_32
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_33

    const/16 v1, 0x28

    goto :goto_17

    :cond_33
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getReputacao()I

    move-result v1

    if-ne v1, v11, :cond_34

    const/16 v1, 0x1e

    goto :goto_17

    :cond_34
    const/16 v1, 0x14

    :goto_17
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-nez v2, :cond_39

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    if-eq v2, v5, :cond_37

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x48

    if-eq v2, v4, :cond_37

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x68

    if-eq v2, v4, :cond_37

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x41

    if-eq v2, v4, :cond_37

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x61

    if-ne v2, v4, :cond_35

    goto :goto_18

    :cond_35
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x9a

    if-eq v2, v4, :cond_3e

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x55

    if-ne v2, v4, :cond_36

    goto/16 :goto_1b

    :cond_36
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x15

    if-eq v2, v4, :cond_3d

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xa2

    if-ne v2, v4, :cond_41

    goto/16 :goto_1a

    :cond_37
    :goto_18
    const/16 v2, 0x64

    goto/16 :goto_1e

    :cond_38
    :goto_19
    const/16 v2, 0x5f

    goto/16 :goto_1e

    const/16 v2, 0x5f

    goto/16 :goto_1e

    :cond_39
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-ne v2, v11, :cond_3f

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x1d

    if-eq v2, v4, :cond_38

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xb

    if-ne v2, v4, :cond_3a

    goto :goto_19

    :cond_3a
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xc3

    if-eq v2, v4, :cond_3d

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x2e

    if-ne v2, v4, :cond_3b

    goto :goto_1a

    :cond_3b
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xc3

    if-eq v2, v4, :cond_3d

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x2e

    if-eq v2, v4, :cond_3d

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x2a

    if-ne v2, v4, :cond_3c

    goto :goto_1a

    :cond_3c
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x97

    if-eq v2, v4, :cond_41

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x96

    if-ne v2, v4, :cond_4a

    goto :goto_1c

    :cond_3d
    :goto_1a
    const/16 v2, 0x50

    goto/16 :goto_1e

    :cond_3e
    :goto_1b
    const/16 v2, 0x5a

    goto/16 :goto_1e

    :cond_3f
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    const/4 v6, 0x2

    if-ne v2, v6, :cond_43

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xa

    if-eq v2, v4, :cond_42

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x81

    if-eq v2, v4, :cond_42

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x39

    if-ne v2, v4, :cond_40

    goto :goto_1d

    :cond_40
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x8d

    if-eq v2, v4, :cond_41

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xa9

    if-eq v2, v4, :cond_41

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0xbe

    if-ne v2, v4, :cond_4a

    :cond_41
    :goto_1c
    const/16 v2, 0x46

    goto/16 :goto_1e

    :cond_42
    :goto_1d
    const/16 v2, 0x4b

    goto/16 :goto_1e

    :cond_43
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-ne v2, v5, :cond_45

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x6b

    if-eq v2, v4, :cond_42

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x31

    if-ne v2, v4, :cond_44

    goto :goto_1d

    :cond_44
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x62

    if-eq v2, v4, :cond_41

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x9

    if-eq v2, v4, :cond_41

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x3b

    if-eq v2, v4, :cond_41

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x2b

    if-ne v2, v4, :cond_4a

    goto :goto_1c

    :cond_45
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-ne v2, v4, :cond_49

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x83

    if-ne v2, v4, :cond_46

    goto/16 :goto_1a

    :cond_46
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x44

    if-ne v2, v4, :cond_47

    goto/16 :goto_1c

    :cond_47
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x33

    if-ne v2, v4, :cond_48

    const/16 v2, 0x41

    goto :goto_1e

    :cond_48
    const/16 v2, 0x37

    goto :goto_1e

    :cond_49
    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-ne v2, v12, :cond_4c

    invoke-virtual/range {p0 .. p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    const/16 v4, 0x8f

    if-ne v2, v4, :cond_4b

    :cond_4a
    const/16 v2, 0x3c

    goto :goto_1e

    :cond_4b
    const/16 v2, 0x2d

    goto :goto_1e

    :cond_4c
    const/16 v2, 0x64

    :goto_1e
    if-le v1, v2, :cond_4d

    move v1, v2

    :cond_4d
    iget v2, v0, La/p;->qF:I

    if-lt v2, v3, :cond_53

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    invoke-virtual {v2, v12}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    iget v3, v0, La/p;->qd:I

    const/4 v4, 0x7

    if-ne v3, v4, :cond_4f

    add-int/lit8 v1, v1, 0x5

    :goto_1f
    add-int/2addr v1, v2

    :cond_4e
    move v12, v1

    const/16 v2, 0x64

    goto :goto_20

    :cond_4f
    iget v3, v0, La/p;->qd:I

    const/16 v4, 0x8

    if-ne v3, v4, :cond_50

    add-int/lit8 v1, v1, 0xf

    goto :goto_1f

    :cond_50
    iget v3, v0, La/p;->qd:I

    const/16 v4, 0x9

    if-ne v3, v4, :cond_51

    add-int/lit8 v1, v1, 0x19

    goto :goto_1f

    :cond_51
    iget v3, v0, La/p;->qd:I

    const/16 v4, 0xa

    if-ne v3, v4, :cond_4e

    add-int/lit8 v1, v1, 0x1e

    goto :goto_1f

    :goto_20
    if-le v12, v2, :cond_52

    const/16 v1, 0x64

    goto :goto_21

    :cond_52
    move v1, v12

    goto :goto_21

    :cond_53
    const/16 v2, 0x64

    :goto_21
    iget-wide v3, v0, La/p;->qp:D

    const-wide/high16 v5, 0x3ff0000000000000L    # 1.0

    cmpl-double v7, v3, v5

    if-lez v7, :cond_55

    iget v3, v0, La/p;->forca:I

    if-ge v3, v2, :cond_55

    iget v2, v0, La/p;->forca:I

    if-ge v2, v1, :cond_54

    iget v1, v0, La/p;->forca:I

    add-int/2addr v1, v11

    iput v1, v0, La/p;->forca:I

    iget-wide v1, v0, La/p;->qp:D

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    sub-double/2addr v1, v3

    :goto_22
    iput-wide v1, v0, La/p;->qp:D

    goto :goto_23

    :cond_54
    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    goto :goto_22

    :cond_55
    :goto_23
    iget v1, v0, La/p;->forca:I

    const/16 v2, 0x64

    if-le v1, v2, :cond_56

    iput v2, v0, La/p;->forca:I

    :cond_56
    return-void
.end method

.method private is()V
    .locals 12

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getDivisao()I

    move-result v0

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNivel()I

    move-result v1

    iget v2, p0, La/p;->pZ:I

    add-int/lit8 v2, v2, -0x1f

    int-to-double v2, v2

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v4

    invoke-virtual {v4}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v4, :cond_2

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    const/4 v4, 0x4

    if-lt v0, v4, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-lt v0, v6, :cond_1

    const/4 v0, 0x2

    goto :goto_0

    :cond_1
    const/4 v0, 0x3

    :cond_2
    :goto_0
    const/16 v4, 0x14

    if-lt v1, v4, :cond_3

    const-wide/high16 v8, 0x4000000000000000L    # 2.0

    sub-double/2addr v2, v8

    :cond_3
    iget v1, p0, La/p;->forca:I

    const-wide/16 v8, 0x0

    if-lt v1, v7, :cond_4

    iget v1, p0, La/p;->forca:I

    const/16 v4, 0x32

    if-gt v1, v4, :cond_4

    const-wide v10, 0x3fe999999999999aL    # 0.8

    :goto_1
    mul-double v1, v2, v10

    goto :goto_2

    :cond_4
    iget v1, p0, La/p;->forca:I

    const/16 v4, 0x33

    if-lt v1, v4, :cond_5

    iget v1, p0, La/p;->forca:I

    const/16 v4, 0x46

    if-gt v1, v4, :cond_5

    const-wide v10, 0x3ff3333333333333L    # 1.2

    goto :goto_1

    :cond_5
    iget v1, p0, La/p;->forca:I

    const/16 v4, 0x47

    if-lt v1, v4, :cond_6

    iget v1, p0, La/p;->forca:I

    const/16 v4, 0x64

    if-gt v1, v4, :cond_6

    const-wide/high16 v10, 0x3ff8000000000000L    # 1.5

    goto :goto_1

    :cond_6
    move-wide v1, v8

    :goto_2
    cmpl-double v3, v1, v8

    if-lez v3, :cond_a

    const-wide/high16 v3, 0x4049000000000000L    # 50.0

    div-double/2addr v1, v3

    if-ne v0, v7, :cond_7

    const/16 v0, 0x23

    goto :goto_3

    :cond_7
    if-ne v0, v5, :cond_8

    const/16 v0, 0x19

    goto :goto_3

    :cond_8
    if-ne v0, v6, :cond_9

    const/16 v0, 0xa

    goto :goto_3

    :cond_9
    const/4 v0, 0x1

    :goto_3
    iget-wide v3, p0, La/p;->qp:D

    add-double/2addr v3, v1

    iput-wide v3, p0, La/p;->qp:D

    iget-wide v1, p0, La/p;->qp:D

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    cmpl-double v5, v1, v3

    if-lez v5, :cond_a

    iget v1, p0, La/p;->forca:I

    if-le v1, v0, :cond_a

    iget v0, p0, La/p;->forca:I

    sub-int/2addr v0, v7

    iput v0, p0, La/p;->forca:I

    iget-wide v0, p0, La/p;->qp:D

    sub-double/2addr v0, v3

    iput-wide v0, p0, La/p;->qp:D

    :cond_a
    iget v0, p0, La/p;->forca:I

    if-ge v0, v7, :cond_b

    iput v7, p0, La/p;->forca:I

    :cond_b
    return-void
.end method


# virtual methods
.method public A(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/s;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/p;->qv:Ljava/util/ArrayList;

    return-void
.end method

.method public B(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/e;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/p;->qw:Ljava/util/ArrayList;

    return-void
.end method

.method public C(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/br;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/p;->qx:Ljava/util/ArrayList;

    return-void
.end method

.method public H(Z)V
    .locals 0

    iput-boolean p1, p0, La/p;->qk:Z

    return-void
.end method

.method public a(JJ)I
    .locals 2

    cmp-long v0, p3, p1

    if-lez v0, :cond_0

    sub-long v0, p3, p1

    const-wide/32 p1, 0x5265c00

    div-long/2addr v0, p1

    long-to-int p1, v0

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public a(Ljava/util/Date;Ljava/util/Date;)I
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public a(D)V
    .locals 0

    iput-wide p1, p0, La/p;->qp:D

    return-void
.end method

.method public a(JZ)V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    if-nez p3, :cond_0

    iget-wide v2, p0, La/p;->qm:J

    cmp-long p3, v2, v0

    if-lez p3, :cond_0

    iget-wide v0, p0, La/p;->qm:J

    :cond_0
    const-wide/32 v2, 0x5265c00

    mul-long p1, p1, v2

    add-long v2, v0, p1

    iput-wide v2, p0, La/p;->qm:J

    return-void
.end method

.method public a(La/ac;IZZZ)V
    .locals 8

    iget-boolean v0, p0, La/p;->aposentado:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, La/p;->pendSaleClub:La/ac;

    if-eqz v0, :cond_1

    return-void

    :cond_1
    if-nez p4, :cond_2

    if-nez p5, :cond_2

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->isOnLoan(La/p;)Z

    move-result v0

    if-eqz v0, :cond_2

    return-void

    :cond_2
    invoke-static {p1, p2}, Lcom/brasfoot/v2028/Recopa;->tbBlocked(La/ac;I)Z

    move-result v0

    if-eqz v0, :cond_3

    return-void

    :cond_3
    if-nez p5, :cond_4

    if-nez p4, :cond_4

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->isOnLoan(La/p;)Z

    move-result v0

    if-nez v0, :cond_4

    invoke-static {p0, p1}, Lcom/brasfoot/v2028/Recopa;->intlBlocked(La/p;La/ac;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {p0, p1, p2}, Lcom/brasfoot/v2028/Recopa;->schedulePendingSale(La/p;La/ac;I)Z

    move-result v0

    return-void

    :cond_4
    invoke-static {p0, p1, p2, p4}, Lcom/brasfoot/v2028/Recopa;->newsTransfer(La/p;La/ac;IZ)V

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-static {p0, v0, p1, p2, p4}, Lcom/brasfoot/v2028/Recopa;->recordTransfer(La/p;La/ac;La/ac;II)V

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_5

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_5

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    :cond_5
    if-eqz p1, :cond_6

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_6

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    :cond_6
    invoke-static {p0, v0, p1, p2}, Lcom/brasfoot/v2028/Recopa;->baseSellOn(La/p;La/ac;La/ac;I)V

    invoke-static {p1}, Lcom/brasfoot/v2028/Recopa;->chemNewSigning(La/ac;)V

    invoke-virtual {p0, p1}, La/p;->i(La/ac;)V

    const/4 v2, 0x0

    iput v2, p0, La/p;->qg:I

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qz:Ljava/lang/Boolean;

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qB:Ljava/lang/Boolean;

    if-eqz p4, :cond_7

    if-nez p5, :cond_7

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qA:Ljava/lang/Boolean;

    :cond_7
    if-eqz p5, :cond_8

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/p;->qA:Ljava/lang/Boolean;

    :cond_8
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dd()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v3

    if-nez p4, :cond_11

    if-nez p5, :cond_11

    if-eqz p3, :cond_e

    iget-wide v4, p0, La/p;->qm:J

    const-wide/16 v6, 0x0

    cmp-long p3, v4, v6

    if-lez p3, :cond_e

    if-eqz v3, :cond_e

    const-wide/16 v3, 0x0

    :try_start_0
    invoke-virtual {p0}, La/p;->in()I

    move-result p3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 p3, 0x0

    :goto_0
    if-lez p3, :cond_d

    const/16 p5, 0x1e

    if-gt p3, p5, :cond_9

    const-wide v3, 0x3fbeb851eb851eb8L    # 0.12

    goto :goto_1

    :cond_9
    const/16 p5, 0x3c

    if-gt p3, p5, :cond_a

    const-wide v3, 0x3fc999999999999aL    # 0.2

    goto :goto_1

    :cond_a
    const/16 p5, 0x5a

    if-gt p3, p5, :cond_b

    const-wide v3, 0x3fcc28f5c28f5c29L    # 0.22

    goto :goto_1

    :cond_b
    const/16 p5, 0xb4

    if-gt p3, p5, :cond_c

    const-wide/high16 v3, 0x3fd0000000000000L    # 0.25

    goto :goto_1

    :cond_c
    const-wide v3, 0x3fd3333333333333L    # 0.3

    :cond_d
    :goto_1
    int-to-double v5, p2

    mul-double v5, v5, v3

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    long-to-int p3, v3

    goto :goto_2

    :cond_e
    const/4 p3, 0x0

    :goto_2
    if-lez p3, :cond_f

    invoke-virtual {v0}, La/ac;->mj()La/n;

    :cond_f
    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p5

    invoke-virtual {p5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p5

    if-eqz p5, :cond_10

    invoke-virtual {v0, p2, v1}, La/ac;->U(II)V

    if-lez p3, :cond_10

    const/16 p5, 0x8

    invoke-virtual {v0, p3, p5}, La/ac;->V(II)V

    :cond_10
    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    if-eqz p3, :cond_11

    invoke-virtual {p1, p2, v1}, La/ac;->V(II)V

    :cond_11
    if-nez p4, :cond_12

    const-wide/16 p2, 0xb4

    :goto_3
    :try_start_1
    invoke-virtual {p0, p2, p3, v1}, La/p;->a(JZ)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :cond_12
    const-wide/16 p2, 0x16d

    goto :goto_3

    :catch_1
    :goto_4
    invoke-virtual {p0}, La/p;->hK()V

    invoke-virtual {v0}, La/ac;->lD()La/p;

    move-result-object p2

    if-ne p2, p0, :cond_13

    invoke-virtual {v0}, La/ac;->lY()V

    :cond_13
    invoke-virtual {v0}, La/ac;->lC()La/p;

    move-result-object p2

    if-ne p2, p0, :cond_14

    invoke-virtual {v0}, La/ac;->lX()V

    :cond_14
    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_15

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_15

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p0, p2}, La/p;->e(Ljava/lang/Boolean;)V

    :cond_15
    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_16

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_16
    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_17

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_17

    invoke-virtual {v0, v2}, La/ac;->S(Z)V

    :cond_17
    return-void
.end method

.method public a(La/t;II)V
    .locals 28

    move-object/from16 v0, p0

    const/4 v3, 0x5

    new-array v3, v3, [I

    fill-array-data v3, :array_0

    const/16 v4, 0x5a

    const/4 v5, 0x0

    const/16 v6, 0x5a

    :goto_0
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/4 v8, 0x1

    if-ge v5, v7, :cond_4

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/m;

    invoke-virtual {v7}, La/m;->gW()La/p;

    move-result-object v7

    if-ne v7, v0, :cond_1

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->gV()I

    move-result v6

    if-ne v6, v8, :cond_0

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->gU()I

    move-result v6

    goto :goto_1

    :cond_0
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->gU()I

    move-result v6

    add-int/lit8 v6, v6, 0x30

    :cond_1
    :goto_1
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/m;

    invoke-virtual {v7}, La/m;->gX()La/p;

    move-result-object v7

    if-ne v7, v0, :cond_3

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->gV()I

    move-result v6

    if-ne v6, v8, :cond_2

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->gU()I

    move-result v6

    rsub-int/lit8 v6, v6, 0x32

    add-int/lit8 v6, v6, 0x30

    goto :goto_2

    :cond_2
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->gU()I

    move-result v6

    rsub-int/lit8 v6, v6, 0x32

    :cond_3
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v5, 0x2

    const/4 v7, 0x0

    if-nez p2, :cond_7

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v9

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v10

    if-le v9, v10, :cond_5

    const/4 v7, 0x1

    goto :goto_3

    :cond_5
    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v9

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v10

    if-ge v9, v10, :cond_6

    const/4 v7, 0x2

    :cond_6
    :goto_3
    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v9

    goto :goto_5

    :cond_7
    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v9

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v10

    if-le v9, v10, :cond_8

    const/4 v7, 0x1

    goto :goto_4

    :cond_8
    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v9

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v10

    if-ge v9, v10, :cond_9

    const/4 v7, 0x2

    :cond_9
    :goto_4
    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v9

    :goto_5
    iget v10, v0, La/p;->qu:I

    if-ge v10, v8, :cond_a

    iget v10, v0, La/p;->posicao:I

    aget v10, v3, v10

    iput v10, v0, La/p;->qu:I

    :cond_a
    const-wide/high16 v11, 0x4016000000000000L    # 5.5

    if-nez v7, :cond_e

    iget v3, v0, La/p;->forca:I

    const/16 v7, 0x1e

    if-gt v3, v7, :cond_b

    goto :goto_7

    :cond_b
    iget v3, v0, La/p;->forca:I

    const/16 v7, 0x3c

    if-gt v3, v7, :cond_c

    const-wide v11, 0x4017333333333333L    # 5.8

    goto :goto_7

    :cond_c
    iget v3, v0, La/p;->forca:I

    if-gt v3, v4, :cond_d

    const-wide v11, 0x4018cccccccccccdL    # 6.2

    goto :goto_7

    :cond_d
    const-wide v11, 0x401b333333333333L    # 6.8

    goto :goto_7

    :cond_e
    if-ne v7, v8, :cond_13

    iget v3, v0, La/p;->forca:I

    const/16 v7, 0x1e

    if-gt v3, v7, :cond_10

    :cond_f
    :goto_6
    const-wide/high16 v11, 0x4018000000000000L    # 6.0

    goto :goto_7

    :cond_10
    iget v3, v0, La/p;->forca:I

    const/16 v7, 0x3c

    if-gt v3, v7, :cond_11

    goto :goto_6

    :cond_11
    iget v3, v0, La/p;->forca:I

    if-gt v3, v4, :cond_12

    const-wide v11, 0x401acccccccccccdL    # 6.7

    goto :goto_7

    :cond_12
    const-wide v11, 0x401ccccccccccccdL    # 7.2

    goto :goto_7

    :cond_13
    if-ne v7, v5, :cond_16

    iget v3, v0, La/p;->forca:I

    const/16 v7, 0x1e

    if-gt v3, v7, :cond_14

    const-wide/high16 v11, 0x4014000000000000L    # 5.0

    goto :goto_7

    :cond_14
    iget v3, v0, La/p;->forca:I

    const/16 v7, 0x3c

    if-gt v3, v7, :cond_15

    const-wide v11, 0x4014cccccccccccdL    # 5.2

    goto :goto_7

    :cond_15
    iget v3, v0, La/p;->forca:I

    if-gt v3, v4, :cond_f

    :cond_16
    :goto_7
    invoke-virtual/range {p0 .. p0}, La/p;->iO()Z

    move-result v3

    const-wide/high16 v13, 0x3ff8000000000000L    # 1.5

    if-eqz v3, :cond_17

    sub-double/2addr v11, v13

    invoke-virtual/range {p0 .. p0}, La/p;->io()I

    move-result v3

    if-ne v3, v8, :cond_17

    sub-double/2addr v11, v13

    :cond_17
    new-instance v3, Ljava/util/Random;

    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    const/16 v4, 0xa

    const/4 v7, 0x4

    const/16 v15, 0xb

    const-wide v16, 0x3fe999999999999aL    # 0.8

    const-wide v18, 0x3fd3333333333333L    # 0.3

    const-wide/high16 v20, 0x3fe0000000000000L    # 0.5

    const/4 v5, 0x3

    if-lt v10, v4, :cond_1d

    const/16 v4, 0x11

    if-gt v10, v4, :cond_1d

    invoke-virtual/range {p1 .. p1}, La/t;->jI()[I

    move-result-object v4

    aget v13, v4, p2

    aget v14, v4, p3

    if-le v13, v14, :cond_1b

    invoke-virtual {v3, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    if-ne v4, v8, :cond_18

    add-double v11, v11, v18

    goto :goto_8

    :cond_18
    const/4 v4, 0x0

    add-double v11, v11, v16

    :goto_8
    iget v4, v0, La/p;->qh:I

    if-nez v4, :cond_19

    add-double v11, v11, v18

    :cond_19
    invoke-virtual/range {p0 .. p0}, La/p;->getCr1()I

    move-result v4

    if-eq v4, v15, :cond_1a

    invoke-virtual/range {p0 .. p0}, La/p;->getCr1()I

    move-result v4

    if-ne v4, v7, :cond_1d

    :cond_1a
    const/4 v4, 0x0

    add-double v11, v11, v20

    goto :goto_a

    :cond_1b
    aget v13, v4, p2

    aget v4, v4, p3

    if-ge v13, v4, :cond_1d

    invoke-virtual {v3, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    if-ne v4, v8, :cond_1c

    sub-double v11, v11, v18

    goto :goto_9

    :cond_1c
    const/4 v4, 0x0

    sub-double v11, v11, v16

    :goto_9
    iget v4, v0, La/p;->qh:I

    if-nez v4, :cond_1d

    sub-double v11, v11, v20

    :cond_1d
    :goto_a
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->fy()I

    move-result v4

    if-lez v4, :cond_1e

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->fy()I

    move-result v4

    int-to-double v13, v4

    const-wide v24, 0x3feccccccccccccdL    # 0.9

    mul-double v13, v13, v24

    add-double/2addr v11, v13

    :cond_1e
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->un()I

    move-result v4

    if-lez v4, :cond_1f

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->un()I

    move-result v4

    int-to-double v13, v4

    const-wide/high16 v22, 0x3ff8000000000000L    # 1.5

    mul-double v13, v13, v22

    sub-double/2addr v11, v13

    :cond_1f
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->uo()I

    move-result v4

    if-lez v4, :cond_20

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->un()I

    move-result v4

    int-to-double v13, v4

    const-wide v24, 0x3ff3333333333333L    # 1.2

    mul-double v13, v13, v24

    sub-double/2addr v11, v13

    :cond_20
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->up()I

    move-result v4

    const-wide v13, 0x3fc999999999999aL    # 0.2

    if-lez v4, :cond_21

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->up()I

    move-result v4

    move/from16 v26, v6

    int-to-double v5, v4

    mul-double v5, v5, v13

    sub-double/2addr v11, v5

    goto :goto_b

    :cond_21
    move/from16 v26, v6

    :goto_b
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->uq()I

    move-result v4

    if-lez v4, :cond_22

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->uq()I

    move-result v4

    int-to-double v4, v4

    mul-double v4, v4, v16

    sub-double/2addr v11, v4

    :cond_22
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->fW()I

    move-result v4

    if-lez v4, :cond_23

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/bm;->fW()I

    move-result v4

    int-to-double v4, v4

    const-wide v24, 0x3fd999999999999aL    # 0.4

    mul-double v4, v4, v24

    add-double/2addr v11, v4

    :cond_23
    const-wide v4, 0x3fe3333333333333L    # 0.6

    const/16 v6, 0xd

    if-lt v10, v8, :cond_29

    if-gt v10, v6, :cond_29

    invoke-virtual/range {p1 .. p1}, La/t;->jK()[I

    move-result-object v24

    aget v13, v24, p2

    aget v14, v24, p3

    if-le v13, v14, :cond_27

    const/4 v13, 0x3

    invoke-virtual {v3, v13}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v8, :cond_24

    const-wide v13, 0x3feccccccccccccdL    # 0.9

    add-double/2addr v11, v13

    :goto_c
    const/4 v1, 0x2

    goto :goto_d

    :cond_24
    const/4 v1, 0x0

    add-double/2addr v11, v4

    goto :goto_c

    :goto_d
    if-lt v10, v1, :cond_25

    const/16 v1, 0x9

    if-gt v10, v1, :cond_25

    const/4 v1, 0x3

    invoke-virtual {v3, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v13

    if-ne v13, v8, :cond_26

    add-double/2addr v11, v4

    goto :goto_e

    :cond_25
    const/4 v1, 0x3

    :cond_26
    :goto_e
    if-lt v10, v15, :cond_29

    if-gt v10, v6, :cond_29

    invoke-virtual {v3, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v13

    if-ne v13, v8, :cond_29

    add-double/2addr v11, v4

    goto :goto_f

    :cond_27
    aget v1, v24, p2

    aget v13, v24, p3

    if-ge v1, v13, :cond_29

    sub-double v11, v11, v20

    const/4 v1, 0x3

    if-lt v10, v1, :cond_28

    const/16 v1, 0x8

    if-gt v10, v1, :cond_28

    invoke-virtual {v3, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v8, :cond_28

    sub-double/2addr v11, v4

    :cond_28
    if-lt v10, v15, :cond_29

    if-gt v10, v6, :cond_29

    invoke-virtual {v3, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v8, :cond_29

    sub-double/2addr v11, v4

    :cond_29
    :goto_f
    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v1

    invoke-virtual {v1}, Lcomponents/bm;->uA()I

    move-result v1

    if-lez v1, :cond_2a

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v1

    invoke-virtual {v1}, Lcomponents/bm;->uA()I

    move-result v1

    int-to-double v13, v1

    mul-double v13, v13, v18

    add-double/2addr v11, v13

    :cond_2a
    const-wide/high16 v13, 0x4000000000000000L    # 2.0

    if-ne v10, v8, :cond_34

    sub-double v11, v11, v16

    invoke-virtual/range {p1 .. p1}, La/t;->jJ()[I

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, La/t;->kl()[I

    move-result-object v16

    aget v4, v16, p3

    int-to-double v6, v4

    const-wide v16, 0x3fc999999999999aL    # 0.2

    mul-double v6, v6, v16

    add-double/2addr v11, v6

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v5

    invoke-virtual {v5}, Lcomponents/bm;->uy()I

    move-result v5

    if-lez v5, :cond_2b

    invoke-virtual/range {p0 .. p0}, La/p;->iK()Lcomponents/bm;

    move-result-object v5

    invoke-virtual {v5}, Lcomponents/bm;->uy()I

    move-result v5

    int-to-double v5, v5

    const-wide v16, 0x3ff3333333333333L    # 1.2

    mul-double v5, v5, v16

    add-double/2addr v11, v5

    :cond_2b
    aget v5, v1, p3

    const/16 v6, 0xa

    if-le v5, v6, :cond_2c

    const-wide v5, 0x3fc999999999999aL    # 0.2

    :goto_10
    add-double/2addr v11, v5

    goto :goto_11

    :cond_2c
    const-wide v5, 0x3fc999999999999aL    # 0.2

    aget v7, v1, p3

    const/16 v15, 0xf

    if-le v7, v15, :cond_2d

    goto :goto_10

    :cond_2d
    aget v1, v1, p3

    const/16 v2, 0x14

    if-le v1, v2, :cond_2e

    add-double v11, v11, v18

    :cond_2e
    :goto_11
    const/4 v1, 0x5

    if-lt v9, v1, :cond_2f

    sub-double/2addr v11, v13

    goto :goto_13

    :cond_2f
    const/4 v1, 0x4

    if-lt v9, v1, :cond_30

    const-wide/high16 v1, 0x3ff8000000000000L    # 1.5

    :goto_12
    sub-double/2addr v11, v1

    goto :goto_13

    :cond_30
    const/4 v1, 0x2

    if-lt v9, v1, :cond_31

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    goto :goto_12

    :cond_31
    if-lt v9, v8, :cond_32

    sub-double v11, v11, v20

    goto :goto_13

    :cond_32
    if-nez v9, :cond_33

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    add-double/2addr v11, v1

    :cond_33
    :goto_13
    if-nez v4, :cond_34

    const-wide/high16 v1, 0x3ff8000000000000L    # 1.5

    sub-double/2addr v11, v1

    :cond_34
    if-lt v10, v8, :cond_38

    const/16 v1, 0xd

    if-gt v10, v1, :cond_38

    if-nez v9, :cond_36

    add-double v11, v11, v20

    const/4 v1, 0x2

    if-lt v10, v1, :cond_35

    const/16 v1, 0x9

    if-gt v10, v1, :cond_35

    add-double v11, v11, v20

    :cond_35
    const/16 v1, 0xb

    if-lt v10, v1, :cond_37

    const/16 v1, 0xd

    if-gt v10, v1, :cond_37

    const/4 v1, 0x3

    invoke-virtual {v3, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    if-ne v2, v8, :cond_37

    add-double v11, v11, v20

    goto :goto_14

    :cond_36
    if-le v9, v8, :cond_37

    const-wide v1, 0x3fb999999999999aL    # 0.1

    int-to-double v4, v9

    mul-double v4, v4, v1

    sub-double/2addr v11, v4

    :cond_37
    :goto_14
    const/4 v1, 0x2

    if-lt v10, v1, :cond_38

    const/16 v1, 0xd

    if-gt v10, v1, :cond_38

    const/4 v1, 0x3

    invoke-virtual {v3, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v8, :cond_38

    const-wide v1, 0x3fd999999999999aL    # 0.4

    sub-double/2addr v11, v1

    :cond_38
    iget-object v1, v0, La/p;->pX:Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_39

    const-wide v1, 0x3fd999999999999aL    # 0.4

    add-double/2addr v11, v1

    :cond_39
    iget-object v1, v0, La/p;->pY:Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_3a

    const-wide v1, 0x3fe3333333333333L    # 0.6

    add-double/2addr v11, v1

    :cond_3a
    const-wide/high16 v1, 0x4024000000000000L    # 10.0

    cmpl-double v3, v11, v1

    if-lez v3, :cond_3b

    const-wide/high16 v11, 0x4024000000000000L    # 10.0

    :cond_3b
    const-wide/16 v1, 0x0

    cmpg-double v3, v11, v1

    if-gez v3, :cond_3c

    const-wide/high16 v11, 0x3ff0000000000000L    # 1.0

    :cond_3c
    const/16 v1, 0xf

    move/from16 v4, v26

    if-ge v4, v1, :cond_3d

    const-wide/high16 v1, 0x4004000000000000L    # 2.5

    :goto_15
    sub-double/2addr v11, v1

    goto :goto_16

    :cond_3d
    const/16 v1, 0x2d

    if-ge v4, v1, :cond_3e

    const-wide/high16 v1, 0x3ff8000000000000L    # 1.5

    goto :goto_15

    :cond_3e
    :goto_16
    cmpg-double v1, v11, v13

    if-gez v1, :cond_3f

    move-wide v11, v13

    :cond_3f
    const/16 v1, 0x14

    if-ge v4, v1, :cond_40

    cmpg-double v1, v11, v13

    if-gtz v1, :cond_40

    const-wide/16 v11, 0x0

    :cond_40
    iput-wide v11, v0, La/p;->qq:D

    iget-object v1, v0, La/p;->qx:Ljava/util/ArrayList;

    new-instance v2, Lcomponents/br;

    iget-wide v3, v0, La/p;->qq:D

    move-object/from16 v5, p1

    invoke-direct {v2, v5, v3, v4}, Lcomponents/br;-><init>(La/t;D)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-wide/16 v1, 0x0

    cmpl-double v3, v11, v1

    if-lez v3, :cond_41

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v1

    if-eqz v1, :cond_41

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v1

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    if-ne v1, v8, :cond_41

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v1

    invoke-virtual {v1, v0}, La/al;->p(La/p;)V

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v1

    instance-of v1, v1, Ld/q;

    if-eqz v1, :cond_41

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v1

    check-cast v1, Ld/q;

    invoke-virtual {v1, v0}, Ld/q;->x(La/p;)V

    :cond_41
    return-void

    :array_0
    .array-data 4
        0x1
        0x2
        0x7
        0xf
        0x17
    .end array-data
.end method

.method public a(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->pX:Ljava/lang/Boolean;

    iget-object p1, p0, La/p;->pY:Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, p0, La/p;->pX:Ljava/lang/Boolean;

    :cond_0
    return-void
.end method

.method public a(ILa/al;La/ac;)Z
    .locals 10

    invoke-virtual {p0}, La/p;->iy()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x1

    if-eqz p2, :cond_7

    invoke-virtual {p0, p2}, La/p;->j(La/al;)La/s;

    move-result-object p2

    const/4 v2, 0x2

    if-ne p1, v2, :cond_1

    invoke-virtual {p2}, La/s;->fS()V

    goto/16 :goto_1

    :cond_1
    const/4 v3, 0x3

    if-ne p1, v3, :cond_2

    invoke-virtual {p2}, La/s;->fU()V

    goto/16 :goto_1

    :cond_2
    const/4 v4, 0x4

    if-ne p1, v4, :cond_7

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/16 v5, 0x3e8

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/16 v5, 0x320

    if-le v4, v5, :cond_3

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v3

    if-eqz v3, :cond_6

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lz()La/af;

    move-result-object v3

    if-eqz v3, :cond_6

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lz()La/af;

    move-result-object v3

    invoke-virtual {v3}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_6

    new-instance v4, Lcomponents/co;

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lz()La/af;

    move-result-object v5

    const/4 v6, 0x1

    new-instance v3, Ljava/util/Random;

    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    const/4 v7, 0x6

    invoke-virtual {v3, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    add-int/lit8 v7, v3, 0xa

    invoke-virtual {p0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v8

    const-string v9, ""

    invoke-direct/range {v4 .. v9}, Lcomponents/co;-><init>(La/af;IILjava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :cond_3
    const/16 v2, 0x3b6

    if-le v4, v2, :cond_5

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    if-eqz v2, :cond_4

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v2}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_4

    new-instance v4, Lcomponents/co;

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v5

    const/4 v6, 0x1

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/4 v7, 0x5

    invoke-virtual {v2, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v7, v2

    invoke-virtual {p0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v8

    const-string v9, ""

    invoke-direct/range {v4 .. v9}, Lcomponents/co;-><init>(La/af;IILjava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v2, 0x3

    goto :goto_0

    :cond_5
    const/4 v2, 0x1

    :cond_6
    :goto_0
    if-ge v1, v2, :cond_7

    invoke-virtual {p2}, La/s;->fT()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_7
    :goto_1
    invoke-direct {p0, p1, p3}, La/p;->b(ILa/ac;)V

    return v0
.end method

.method public a(La/al;La/ac;)Z
    .locals 1

    invoke-virtual {p0}, La/p;->iy()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    if-eqz p1, :cond_1

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object v0

    invoke-virtual {v0}, La/s;->fR()V

    invoke-virtual {p1, p0}, La/al;->l(La/p;)Lcomponents/ay;

    move-result-object p1

    invoke-virtual {p1}, Lcomponents/ay;->fR()V

    :cond_1
    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, La/p;->b(ILa/ac;)V

    iget p2, p0, La/p;->qH:I

    add-int/2addr p2, p1

    iput p2, p0, La/p;->qH:I

    return p1
.end method

.method public a(La/t;Z)Z
    .locals 5

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    invoke-virtual {p1}, La/al;->cG()I

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    :goto_1
    invoke-virtual {p0}, La/p;->il()Z

    move-result v3

    if-eqz v3, :cond_2

    return v1

    :cond_2
    if-eqz v2, :cond_3

    invoke-virtual {p0, p1}, La/p;->e(La/al;)Z

    move-result p1

    if-eqz p1, :cond_3

    const/4 v0, 0x0

    :cond_3
    if-nez p2, :cond_4

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object p1

    if-eqz p1, :cond_4

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_4

    iget-wide p1, p0, La/p;->qm:J

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->en()Ljava/util/Calendar;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    cmp-long v4, p1, v2

    if-gez v4, :cond_4

    return v1

    :cond_4
    return v0
.end method

.method public a(Ljava/lang/String;IZ)Z
    .locals 12

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v6

    const/4 v0, 0x0

    if-nez v6, :cond_0

    return v0

    :cond_0
    invoke-virtual {v6}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v7, 0x1

    if-eqz v1, :cond_8

    invoke-virtual {v6}, La/ac;->getDivisao()I

    move-result v1

    if-nez v1, :cond_1

    const/16 v1, 0x78

    goto :goto_0

    :cond_1
    if-ne v1, v7, :cond_2

    const/16 v1, 0x19

    goto :goto_0

    :cond_2
    if-ne v1, v4, :cond_3

    const/16 v1, 0x32

    goto :goto_0

    :cond_3
    if-ne v1, v2, :cond_4

    const/16 v1, 0x3c

    goto :goto_0

    :cond_4
    const/4 v5, 0x4

    if-ne v1, v5, :cond_5

    const/16 v1, 0x64

    goto :goto_0

    :cond_5
    const/16 v1, 0x7d

    :goto_0
    iget-object v5, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v1, 0x5

    :cond_6
    invoke-virtual {p0}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_7

    const/4 v1, 0x2

    :cond_7
    new-instance v5, Ljava/util/Random;

    invoke-direct {v5}, Ljava/util/Random;-><init>()V

    invoke-virtual {v5, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v7, :cond_8

    const/4 v8, 0x1

    goto :goto_1

    :cond_8
    const/4 v8, 0x0

    :goto_1
    new-array v1, v3, [I

    fill-array-data v1, :array_0

    iget v5, p0, La/p;->posicao:I

    invoke-virtual {v6, v5}, La/ac;->bZ(I)I

    move-result v5

    sub-int/2addr v5, v7

    invoke-virtual {v6}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    const/16 v10, 0xa

    if-nez v9, :cond_c

    iget p2, p0, La/p;->posicao:I

    iget v9, p0, La/p;->posicao:I

    aget v1, v1, v9

    if-ge v5, v1, :cond_9

    iget p2, p0, La/p;->posicao:I

    move v1, p2

    const/4 p2, 0x1

    goto :goto_2

    :cond_9
    move v1, p2

    const/4 p2, 0x0

    :goto_2
    invoke-virtual {v6}, La/ac;->lU()I

    move-result v5

    const/16 v9, 0x11

    if-ge v5, v9, :cond_a

    move v5, v1

    const/4 p2, 0x1

    goto :goto_3

    :cond_a
    invoke-virtual {v6}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lt v5, v10, :cond_b

    move v5, v1

    const/4 v1, 0x1

    goto :goto_4

    :cond_b
    move v5, v1

    goto :goto_3

    :cond_c
    move v5, p2

    const/4 p2, 0x0

    :goto_3
    const/4 v1, 0x0

    :goto_4
    invoke-virtual {v6}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-eqz v9, :cond_d

    invoke-virtual {v6}, La/ac;->lV()I

    move-result v9

    const/16 v11, 0x12

    if-lt v9, v11, :cond_d

    const/4 p2, 0x1

    :cond_d
    invoke-virtual {v6}, La/ac;->getDivisao()I

    move-result v9

    if-le v9, v4, :cond_e

    const/4 v4, 0x5

    :cond_e
    invoke-virtual {v6}, La/ac;->getReputacao()I

    move-result v9

    if-ge v9, v2, :cond_f

    goto :goto_5

    :cond_f
    move v3, v4

    :goto_5
    invoke-virtual {v6}, La/ac;->lV()I

    move-result v2

    sub-int/2addr v10, v3

    if-lt v2, v10, :cond_10

    if-nez p2, :cond_10

    invoke-virtual {v6}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_10

    const/4 v1, 0x1

    :cond_10
    invoke-virtual {v6}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0}, La/p;->iQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    if-nez p3, :cond_11

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dr()V

    :cond_11
    iget v2, p0, La/p;->qH:I

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->cZ()I

    move-result v3

    if-lt v2, v3, :cond_12

    new-instance v2, Lcomponents/ax;

    invoke-virtual {p0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, La/p;->iH()I

    move-result v4

    invoke-virtual {p0}, La/p;->iI()I

    move-result v9

    invoke-direct {v2, v3, v4, v9}, Lcomponents/ax;-><init>(Ljava/lang/String;II)V

    :cond_12
    iput v0, p0, La/p;->qI:I

    iput v0, p0, La/p;->qH:I

    invoke-virtual {p0}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_13

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qA:Ljava/lang/Boolean;

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, p0}, La/b;->b(La/p;)V

    :cond_13
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La/p;->i(La/ac;)V

    if-nez p3, :cond_14

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_14
    if-nez v1, :cond_16

    invoke-virtual {v6}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/16 v9, 0x1e

    if-eqz v0, :cond_15

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v10

    move-object v0, v6

    move v1, v5

    move-object v4, p1

    move-object v5, v10

    invoke-static/range {v0 .. v5}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    move-result-object p1

    if-eqz p2, :cond_16

    if-eqz p1, :cond_16

    invoke-virtual {v6}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge p2, v9, :cond_16

    invoke-static {p3, p1, v6}, La/u;->a(ZLa/q;La/ac;)V

    goto :goto_6

    :cond_15
    invoke-virtual {v6}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge p1, v9, :cond_16

    invoke-static {p3, p0, v6}, La/u;->a(ZLa/p;La/ac;)V

    :cond_16
    :goto_6
    if-eqz v8, :cond_17

    new-instance p1, La/af;

    iget-object p2, p0, La/p;->pq:Ljava/lang/String;

    invoke-direct {p1, p2}, La/af;-><init>(Ljava/lang/String;)V

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2, p1}, La/b;->a(La/af;)V

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object p2

    invoke-virtual {p1, p2, p0}, La/af;->b(La/ac;La/p;)V

    :cond_17
    return v7

    :array_0
    .array-data 4
        0x2
        0x3
        0x3
        0x6
        0x4
    .end array-data
.end method

.method public aP(I)V
    .locals 0

    iput p1, p0, La/p;->forca:I

    return-void
.end method

.method public aQ(I)V
    .locals 0

    iput p1, p0, La/p;->salario:I

    return-void
.end method

.method public aR(I)V
    .locals 0

    iput p1, p0, La/p;->qe:I

    return-void
.end method

.method public aS(I)V
    .locals 0

    iput p1, p0, La/p;->qf:I

    return-void
.end method

.method public aT(I)V
    .locals 0

    iput p1, p0, La/p;->qg:I

    return-void
.end method

.method public aU(I)V
    .locals 0

    iput p1, p0, La/p;->qn:I

    return-void
.end method

.method public aV(I)V
    .locals 1

    iget v0, p0, La/p;->qn:I

    sub-int/2addr v0, p1

    iput v0, p0, La/p;->qn:I

    iget p1, p0, La/p;->qn:I

    if-gez p1, :cond_0

    const/4 p1, 0x1

    iput p1, p0, La/p;->qn:I

    :cond_0
    return-void
.end method

.method public aW(I)V
    .locals 1

    iget v0, p0, La/p;->qn:I

    add-int/2addr v0, p1

    iput v0, p0, La/p;->qn:I

    iget p1, p0, La/p;->qn:I

    const/16 v0, 0x64

    if-le p1, v0, :cond_0

    iput v0, p0, La/p;->qn:I

    :cond_0
    return-void
.end method

.method public aX(I)V
    .locals 0

    iput p1, p0, La/p;->qy:I

    return-void
.end method

.method public aY(I)V
    .locals 0

    iput p1, p0, La/p;->qC:I

    return-void
.end method

.method public aZ(I)V
    .locals 0

    iput p1, p0, La/p;->qD:I

    return-void
.end method

.method public addBolaBonus(I)V
    .locals 2

    iget v0, p0, La/p;->bolaBonus:I

    add-int/2addr v0, p1

    iput v0, p0, La/p;->bolaBonus:I

    iget v1, p0, La/p;->qe:I

    add-int/2addr v1, p1

    iput v1, p0, La/p;->qe:I

    return-void
.end method

.method public b(D)V
    .locals 0

    iput-wide p1, p0, La/p;->qq:D

    return-void
.end method

.method public b(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qo:Ljava/lang/Boolean;

    return-void
.end method

.method public b(La/al;La/ac;)Z
    .locals 1

    invoke-virtual {p0}, La/p;->iy()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    if-eqz p1, :cond_1

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object p1

    invoke-virtual {p1}, La/s;->fM()V

    :cond_1
    const/16 p1, 0x8

    invoke-direct {p0, p1, p2}, La/p;->b(ILa/ac;)V

    const/4 p1, 0x1

    return p1
.end method

.method public ba(I)V
    .locals 1

    iput p1, p0, La/p;->qd:I

    iget-object p1, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    iget p1, p0, La/p;->qd:I

    const/16 v0, 0x8

    if-le p1, v0, :cond_0

    const/16 p1, 0xa

    iput p1, p0, La/p;->qd:I

    :cond_0
    return-void
.end method

.method public bb(I)V
    .locals 0

    iput p1, p0, La/p;->qE:I

    return-void
.end method

.method public bc(I)V
    .locals 0

    iput p1, p0, La/p;->qF:I

    return-void
.end method

.method public bd(I)V
    .locals 0

    iput p1, p0, La/p;->qu:I

    return-void
.end method

.method public bh(I)V
    .locals 0

    iput p1, p0, La/p;->qG:I

    return-void
.end method

.method public bi(I)V
    .locals 0

    iput p1, p0, La/p;->qJ:I

    return-void
.end method

.method public bj(I)V
    .locals 0

    iput p1, p0, La/p;->qL:I

    return-void
.end method

.method public bk(I)V
    .locals 0

    iput p1, p0, La/p;->pV:I

    return-void
.end method

.method public bl(I)V
    .locals 0

    iput p1, p0, La/p;->qb:I

    return-void
.end method

.method public bm(I)Z
    .locals 4

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ltz p1, :cond_2

    const/16 v2, 0x19

    if-gt p1, v2, :cond_2

    sget-object v2, La/ak;->AS:[[I

    aget-object v2, v2, p1

    aget v2, v2, v1

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v3

    if-eq v2, v3, :cond_2

    const/16 v2, 0xa

    if-eq p1, v2, :cond_1

    const/16 v2, 0x11

    if-ne p1, v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    return v1

    :cond_1
    :goto_0
    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result p1

    if-eq p1, v0, :cond_2

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result p1

    const/4 v0, 0x3

    :cond_2
    return v1
.end method

.method public bn(I)V
    .locals 0

    iput p1, p0, La/p;->qM:I

    return-void
.end method

.method public bo(I)V
    .locals 0

    iput p1, p0, La/p;->pW:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, La/p;->ql:J

    return-void
.end method

.method public c(La/ac;I)V
    .locals 0

    return-void
.end method

.method public c(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qB:Ljava/lang/Boolean;

    return-void
.end method

.method public c(La/al;La/ac;)Z
    .locals 2

    invoke-virtual {p0}, La/p;->iy()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    if-eqz p1, :cond_1

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object p1

    invoke-virtual {p1}, La/s;->fD()V

    :cond_1
    invoke-direct {p0, v1, p2}, La/p;->b(ILa/ac;)V

    iget p1, p0, La/p;->qI:I

    const/4 p2, 0x1

    add-int/2addr p1, p2

    iput p1, p0, La/p;->qI:I

    return p2
.end method

.method public clearPendSale()V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, La/p;->pendSaleClub:La/ac;

    const/4 v0, 0x0

    iput v0, p0, La/p;->pendSaleValue:I

    const/4 v0, 0x0

    iput-boolean v0, p0, La/p;->pendIsLoan:Z

    return-void
.end method

.method public d(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qr:Ljava/lang/Boolean;

    return-void
.end method

.method public d(La/t;)Z
    .locals 4

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    invoke-virtual {p1}, La/al;->cG()I

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    :goto_1
    invoke-virtual {p0}, La/p;->il()Z

    move-result v3

    if-eqz v3, :cond_2

    return v1

    :cond_2
    if-eqz v2, :cond_3

    invoke-virtual {p0, p1}, La/p;->e(La/al;)Z

    move-result p1

    if-eqz p1, :cond_3

    return v1

    :cond_3
    invoke-virtual {p0}, La/p;->in()I

    move-result p1

    if-gez p1, :cond_4

    return v1

    :cond_4
    return v0
.end method

.method public e(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qs:Ljava/lang/Boolean;

    return-void
.end method

.method public e(La/al;)Z
    .locals 0

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/s;->jc()Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public f(La/al;)I
    .locals 0

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/s;->fy()I

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public f(Landroid/content/Context;)I
    .locals 3

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "flag_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, La/p;->pais:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v1, v2, p1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public f(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qt:Ljava/lang/Boolean;

    return-void
.end method

.method public g(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qz:Ljava/lang/Boolean;

    return-void
.end method

.method public g(La/al;)[I
    .locals 0

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/s;->je()[I

    move-result-object p1

    return-object p1

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method

.method public getCr1()I
    .locals 1

    iget v0, p0, La/p;->qi:I

    return v0
.end method

.method public getCr2()I
    .locals 1

    iget v0, p0, La/p;->qj:I

    return v0
.end method

.method public getEnergia()I
    .locals 1

    iget v0, p0, La/p;->qn:I

    return v0
.end method

.method public getIdade()I
    .locals 1

    iget v0, p0, La/p;->pZ:I

    return v0
.end method

.method public getLado()I
    .locals 1

    iget v0, p0, La/p;->qc:I

    return v0
.end method

.method public getNome()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/p;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public getPais()I
    .locals 1

    iget v0, p0, La/p;->pais:I

    return v0
.end method

.method public getPendSaleClub()La/ac;
    .locals 1

    iget-object v0, p0, La/p;->pendSaleClub:La/ac;

    return-object v0
.end method

.method public getPendSaleValue()I
    .locals 1

    iget v0, p0, La/p;->pendSaleValue:I

    return v0
.end method

.method public getPosicao()I
    .locals 1

    iget v0, p0, La/p;->posicao:I

    return v0
.end method

.method public getStatus()I
    .locals 1

    iget v0, p0, La/p;->status:I

    return v0
.end method

.method public h(La/al;)V
    .locals 0

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/s;->jd()V

    :cond_0
    return-void
.end method

.method public h(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->qA:Ljava/lang/Boolean;

    return-void
.end method

.method public hB()V
    .locals 3

    iget v0, p0, La/p;->qL:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, La/p;->qL:I

    invoke-virtual {p0}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_4

    iget v0, p0, La/p;->qL:I

    const/4 v2, 0x2

    if-lt v0, v2, :cond_4

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_4

    iget v0, p0, La/p;->pZ:I

    const/16 v2, 0x23

    if-ge v0, v2, :cond_4

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-nez v0, :cond_3

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    if-eq v0, v1, :cond_2

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    const/16 v2, 0x41

    if-eq v0, v2, :cond_2

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    const/16 v2, 0x61

    if-ne v0, v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    const/16 v2, 0x68

    if-eq v0, v2, :cond_1

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    const/16 v2, 0x48

    if-eq v0, v2, :cond_1

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    const/16 v2, 0x9a

    if-ne v0, v2, :cond_4

    :cond_1
    iget v0, p0, La/p;->qL:I

    const/4 v2, 0x3

    if-lt v0, v2, :cond_4

    :cond_2
    :goto_0
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p0, v0}, La/p;->i(Ljava/lang/Boolean;)V

    return-void

    :cond_3
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    const/16 v2, 0x1d

    if-ne v0, v2, :cond_4

    iget v0, p0, La/p;->qL:I

    const/4 v2, 0x4

    if-lt v0, v2, :cond_4

    goto :goto_0

    :cond_4
    return-void
.end method

.method public hC()V
    .locals 1

    new-instance v0, Lcomponents/bm;

    invoke-direct {v0}, Lcomponents/bm;-><init>()V

    iput-object v0, p0, La/p;->qK:Lcomponents/bm;

    return-void
.end method

.method public hD()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->pX:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hE()La/ac;
    .locals 3

    iget-object v0, p0, La/p;->qa:La/ac;

    if-nez v0, :cond_0

    iget v1, p0, La/p;->oo:I

    if-ltz v1, :cond_0

    iget v0, p0, La/p;->oo:I

    invoke-static {v0}, La/b;->aq(I)La/ac;

    move-result-object v0

    iput-object v0, p0, La/p;->qa:La/ac;

    return-object v0

    :cond_0
    iget v1, p0, La/p;->oo:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    const/4 v0, 0x0

    :cond_1
    return-object v0
.end method

.method public hF()V
    .locals 1

    iget-object v0, p0, La/p;->qa:La/ac;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/p;->qa:La/ac;

    invoke-virtual {v0}, La/ac;->mE()I

    move-result v0

    iput v0, p0, La/p;->oo:I

    :cond_0
    return-void
.end method

.method public hG()I
    .locals 1

    iget v0, p0, La/p;->forca:I

    return v0
.end method

.method public hH()I
    .locals 1

    iget v0, p0, La/p;->salario:I

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/Recopa;->salaryFloor(La/p;I)I

    move-result v0

    return v0
.end method

.method public hI()I
    .locals 1

    iget v0, p0, La/p;->qe:I

    return v0
.end method

.method public hJ()I
    .locals 1

    iget v0, p0, La/p;->qf:I

    return v0
.end method

.method public hK()V
    .locals 1

    iget v0, p0, La/p;->qe:I

    iput v0, p0, La/p;->qf:I

    return-void
.end method

.method public hL()I
    .locals 1

    iget v0, p0, La/p;->qg:I

    return v0
.end method

.method public hM()J
    .locals 2

    iget-wide v0, p0, La/p;->ql:J

    return-wide v0
.end method

.method public hN()I
    .locals 1

    iget v0, p0, La/p;->qn:I

    return v0
.end method

.method public hO()V
    .locals 2

    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x19

    if-gt v0, v1, :cond_0

    const/4 v0, 0x1

    :goto_0
    invoke-virtual {p0, v0}, La/p;->aV(I)V

    return-void

    :cond_0
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x20

    if-gt v0, v1, :cond_1

    const/4 v0, 0x2

    goto :goto_0

    :cond_1
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x29

    if-gt v0, v1, :cond_2

    const/4 v0, 0x3

    goto :goto_0

    :cond_2
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x2a

    if-gt v0, v1, :cond_3

    const/4 v0, 0x4

    goto :goto_0

    :cond_3
    const/4 v0, 0x5

    goto :goto_0

    return-void
.end method

.method public hP()V
    .locals 4

    iget-object v0, p0, La/p;->qo:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/16 v1, 0x14

    const/16 v2, 0x1e

    if-eqz v0, :cond_3

    iget v0, p0, La/p;->pZ:I

    if-gt v0, v1, :cond_0

    const/16 v0, 0xd

    :goto_0
    invoke-virtual {p0, v0}, La/p;->aW(I)V

    return-void

    :cond_0
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x19

    if-gt v0, v1, :cond_1

    const/16 v0, 0x18

    goto :goto_0

    :cond_1
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x29

    if-gt v0, v1, :cond_2

    const/16 v0, 0x2b

    goto :goto_0

    :cond_2
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x2a

    if-gt v0, v1, :cond_4

    const/16 v0, 0x2a

    goto :goto_0

    :cond_3
    iget v0, p0, La/p;->pZ:I

    if-ge v0, v1, :cond_5

    :cond_4
    :goto_1
    invoke-virtual {p0, v2}, La/p;->aW(I)V

    return-void

    :cond_5
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x1a

    if-ge v0, v1, :cond_6

    goto :goto_1

    :cond_6
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x21

    const/16 v3, 0x23

    if-ge v0, v1, :cond_7

    :goto_2
    invoke-virtual {p0, v3}, La/p;->aW(I)V

    return-void

    :cond_7
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x2d

    if-ge v0, v1, :cond_4

    goto :goto_2

    return-void
.end method

.method public hQ()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qo:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hR()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qB:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hS()D
    .locals 2

    iget-wide v0, p0, La/p;->qp:D

    return-wide v0
.end method

.method public hT()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qr:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hU()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qs:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hV()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qt:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hW()I
    .locals 1

    iget v0, p0, La/p;->qy:I

    return v0
.end method

.method public hX()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qz:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hY()I
    .locals 1

    iget v0, p0, La/p;->qC:I

    return v0
.end method

.method public hZ()I
    .locals 1

    iget v0, p0, La/p;->qD:I

    return v0
.end method

.method public i(La/al;)La/s;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/s;

    invoke-virtual {v1}, La/s;->jb()La/al;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/s;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public i(La/ac;)V
    .locals 3

    iput-object p1, p0, La/p;->qa:La/ac;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/ac;->mE()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, -0x1

    :goto_0
    iget v1, p0, La/p;->oo:I

    if-eq v0, v1, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    if-eqz v2, :cond_1

    invoke-virtual {v2}, La/b;->db()I

    move-result v1

    iput v1, p0, La/p;->anoIn:I

    :cond_1
    iput v0, p0, La/p;->oo:I

    return-void
.end method

.method public i(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/p;->pY:Ljava/lang/Boolean;

    return-void
.end method

.method public iA()V
    .locals 1

    iget v0, p0, La/p;->qG:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/p;->qG:I

    return-void
.end method

.method public iB()D
    .locals 6

    iget-wide v0, p0, La/p;->qq:D

    invoke-static {}, La/p;->enReal()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, La/p;->getEnergia()I

    move-result v2

    const/16 v3, 0x3c

    if-ge v2, v3, :cond_1

    rsub-int/lit8 v2, v2, 0x3c

    const/16 v3, 0x14

    if-le v2, v3, :cond_0

    move v2, v3

    :cond_0
    int-to-double v4, v2

    const-wide v2, 0x3f947ae147ae147bL    # 0.02

    mul-double/2addr v4, v2

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    sub-double/2addr v2, v4

    mul-double/2addr v0, v2

    :cond_1
    return-wide v0
.end method

.method public iC()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->qA:Ljava/lang/Boolean;

    return-object v0
.end method

.method public iD()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/p;->pY:Ljava/lang/Boolean;

    return-object v0
.end method

.method public iE()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/e;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/p;->qw:Ljava/util/ArrayList;

    return-object v0
.end method

.method public iF()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/br;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/p;->qx:Ljava/util/ArrayList;

    return-object v0
.end method

.method public iG()[I
    .locals 6

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    :goto_0
    if-ltz v1, :cond_0

    const/4 v3, 0x0

    aget v4, v0, v3

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/e;

    invoke-virtual {v5}, La/e;->fC()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    aget v3, v0, v2

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/e;

    invoke-virtual {v4}, La/e;->fy()I

    move-result v4

    add-int/2addr v3, v4

    aput v3, v0, v2

    const/4 v3, 0x2

    aget v4, v0, v3

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/e;

    invoke-virtual {v5}, La/e;->fN()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    const/4 v3, 0x3

    aget v4, v0, v3

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/e;

    invoke-virtual {v5}, La/e;->fO()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    const/4 v3, 0x4

    aget v4, v0, v3

    invoke-virtual {p0}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/e;

    invoke-virtual {v5}, La/e;->fP()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_0
    return-object v0

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public iH()I
    .locals 1

    iget v0, p0, La/p;->qH:I

    return v0
.end method

.method public iI()I
    .locals 1

    iget v0, p0, La/p;->qI:I

    return v0
.end method

.method public iJ()I
    .locals 1

    iget v0, p0, La/p;->qJ:I

    return v0
.end method

.method public iK()Lcomponents/bm;
    .locals 1

    iget-object v0, p0, La/p;->qK:Lcomponents/bm;

    if-nez v0, :cond_0

    new-instance v0, Lcomponents/bm;

    invoke-direct {v0}, Lcomponents/bm;-><init>()V

    iput-object v0, p0, La/p;->qK:Lcomponents/bm;

    :cond_0
    iget-object v0, p0, La/p;->qK:Lcomponents/bm;

    return-object v0
.end method

.method public iL()I
    .locals 1

    iget v0, p0, La/p;->qL:I

    return v0
.end method

.method public iM()I
    .locals 1

    iget v0, p0, La/p;->pV:I

    return v0
.end method

.method public iN()I
    .locals 1

    iget v0, p0, La/p;->qb:I

    return v0
.end method

.method public iO()Z
    .locals 4

    invoke-virtual {p0}, La/p;->io()I

    move-result v0

    const/4 v1, 0x1

    if-gtz v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, La/p;->io()I

    move-result v0

    const/16 v2, 0x19

    const/4 v3, 0x0

    if-gt v0, v2, :cond_3

    sget-object v0, La/ak;->AS:[[I

    invoke-virtual {p0}, La/p;->io()I

    move-result v2

    aget-object v0, v0, v2

    aget v0, v0, v3

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v2

    if-eq v0, v2, :cond_3

    invoke-virtual {p0}, La/p;->io()I

    move-result v0

    const/16 v2, 0xa

    if-eq v0, v2, :cond_2

    invoke-virtual {p0}, La/p;->io()I

    move-result v0

    const/16 v2, 0x11

    if-ne v0, v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    return v3

    :cond_2
    :goto_0
    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v0

    if-eq v0, v1, :cond_3

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v0

    const/4 v1, 0x3

    :cond_3
    return v3
.end method

.method public iP()I
    .locals 1

    iget v0, p0, La/p;->qM:I

    return v0
.end method

.method public iQ()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/s;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    return-object v0
.end method

.method public iR()I
    .locals 1

    iget v0, p0, La/p;->pW:I

    return v0
.end method

.method public iS()Z
    .locals 5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dd()I

    move-result v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    goto :goto_0

    :cond_0
    const-wide/16 v0, 0x0

    :goto_0
    iget-wide v2, p0, La/p;->qm:J

    cmp-long v4, v2, v0

    if-gtz v4, :cond_1

    const/4 v0, 0x1

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public iT()V
    .locals 7

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dd()I

    move-result v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_0

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    const-wide v2, 0x757b12c00L

    add-long/2addr v2, v0

    iget-wide v4, p0, La/p;->qm:J

    cmp-long v6, v4, v2

    if-gtz v6, :cond_0

    const-wide/16 v0, 0x2da

    const/4 v2, 0x1

    invoke-virtual {p0, v0, v1, v2}, La/p;->a(JZ)V

    :cond_0
    return-void
.end method

.method public ia()I
    .locals 1

    iget v0, p0, La/p;->qh:I

    return v0
.end method

.method public ib()V
    .locals 15

    iget v0, p0, La/p;->qi:I

    iget v1, p0, La/p;->qj:I

    iget v2, p0, La/p;->posicao:I

    const/4 v3, 0x0

    if-eqz v2, :cond_d

    iget v2, p0, La/p;->posicao:I

    const/4 v4, 0x2

    if-ne v2, v4, :cond_0

    goto/16 :goto_1

    :cond_0
    iget v2, p0, La/p;->posicao:I

    const/16 v5, 0xb

    const/16 v6, 0x9

    const/4 v7, 0x6

    const/16 v8, 0xd

    const/4 v9, 0x4

    const/16 v10, 0x8

    const/16 v11, 0xa

    const/4 v12, 0x7

    const/4 v13, 0x1

    if-ne v2, v13, :cond_6

    if-eq v0, v8, :cond_5

    if-ne v0, v7, :cond_1

    goto :goto_0

    :cond_1
    if-eq v0, v12, :cond_d

    if-ne v0, v11, :cond_2

    goto :goto_1

    :cond_2
    if-eq v1, v8, :cond_5

    if-ne v0, v7, :cond_3

    goto :goto_0

    :cond_3
    if-eq v1, v12, :cond_d

    if-ne v1, v11, :cond_4

    goto :goto_1

    :cond_4
    if-eq v0, v10, :cond_5

    if-eq v0, v6, :cond_5

    if-eq v0, v5, :cond_5

    if-ne v0, v9, :cond_d

    :cond_5
    :goto_0
    iput v13, p0, La/p;->qh:I

    return-void

    :cond_6
    iget v2, p0, La/p;->posicao:I

    const/4 v14, 0x3

    if-ne v2, v14, :cond_a

    if-eq v0, v5, :cond_5

    if-eq v0, v6, :cond_5

    if-eq v0, v10, :cond_5

    if-ne v0, v9, :cond_7

    goto :goto_0

    :cond_7
    if-eq v0, v12, :cond_d

    if-ne v0, v11, :cond_8

    goto :goto_1

    :cond_8
    if-eq v1, v5, :cond_5

    if-eq v1, v6, :cond_5

    if-eq v1, v10, :cond_5

    if-ne v1, v9, :cond_9

    goto :goto_0

    :cond_9
    if-eq v1, v12, :cond_d

    if-ne v1, v11, :cond_5

    goto :goto_1

    :cond_a
    iget v1, p0, La/p;->posicao:I

    if-ne v1, v9, :cond_e

    if-eq v0, v12, :cond_d

    if-ne v0, v11, :cond_b

    goto :goto_1

    :cond_b
    if-eq v0, v10, :cond_c

    if-eq v0, v8, :cond_c

    if-ne v0, v7, :cond_5

    :cond_c
    iput v4, p0, La/p;->qh:I

    return-void

    :cond_d
    :goto_1
    iput v3, p0, La/p;->qh:I

    :cond_e
    return-void
.end method

.method public ic()I
    .locals 1

    iget v0, p0, La/p;->qd:I

    return v0
.end method

.method public id()V
    .locals 6

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_6

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getDivisao()I

    move-result v0

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNivel()I

    move-result v1

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/16 v3, 0xf

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x1

    goto :goto_0

    :pswitch_0
    const/4 v0, 0x5

    goto :goto_0

    :pswitch_1
    const/16 v0, 0xf

    goto :goto_0

    :pswitch_2
    const/16 v0, 0x14

    :goto_0
    move v5, v0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    packed-switch v0, :pswitch_data_1

    const/4 v5, 0x1

    goto :goto_1

    :pswitch_3
    const/16 v0, 0x16

    const/16 v5, 0x16

    goto :goto_1

    :pswitch_4
    const/16 v5, 0xf

    :goto_1
    :pswitch_5
    const/16 v0, 0x1e

    if-gt v1, v3, :cond_1

    goto :goto_2

    :cond_1
    packed-switch v1, :pswitch_data_2

    const/4 v1, 0x0

    goto :goto_2

    :pswitch_6
    const/16 v1, 0x1e

    goto :goto_2

    :pswitch_7
    const/16 v1, 0x1d

    goto :goto_2

    :pswitch_8
    const/16 v1, 0x1c

    goto :goto_2

    :pswitch_9
    const/16 v1, 0x1b

    goto :goto_2

    :pswitch_a
    const/16 v1, 0x1a

    goto :goto_2

    :pswitch_b
    const/16 v1, 0x19

    goto :goto_2

    :pswitch_c
    const/16 v1, 0x15

    goto :goto_2

    :pswitch_d
    const/16 v1, 0x13

    goto :goto_2

    :pswitch_e
    const/16 v1, 0x12

    goto :goto_2

    :pswitch_f
    const/16 v1, 0x11

    :goto_2
    add-int/2addr v1, v5

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/4 v3, 0x3

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v1, v2

    iget v2, p0, La/p;->status:I

    if-ne v2, v4, :cond_2

    add-int/lit8 v1, v1, 0x8

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/4 v5, 0x2

    invoke-virtual {v2, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v1, v2

    :cond_2
    iget-object v2, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_3

    iget-object v2, p0, La/p;->pY:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_4

    :cond_3
    add-int/lit8 v1, v1, 0x9

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v1, v2

    :cond_4
    const/16 v2, 0x64

    if-le v1, v2, :cond_5

    const/16 v1, 0x64

    :cond_5
    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    invoke-virtual {v2, v0}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/lit16 v0, v0, 0xd2

    int-to-long v2, v0

    invoke-virtual {p0, v2, v3, v4}, La/p;->a(JZ)V

    invoke-virtual {p0, v1}, La/p;->aP(I)V

    invoke-virtual {p0}, La/p;->if()V

    invoke-virtual {p0}, La/p;->ie()V

    :cond_6
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
    .end packed-switch
.end method

.method public ie()V
    .locals 9

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->lH()Z

    move-result v0

    const/16 v1, 0x1c2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 v5, 0x1f4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/16 v8, 0x15e

    if-eqz v0, :cond_3

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getDivisao()I

    move-result v0

    if-ne v0, v7, :cond_0

    const/16 v1, 0x2ee

    goto :goto_2

    :cond_0
    if-ne v0, v6, :cond_1

    const/16 v1, 0x226

    goto :goto_2

    :cond_1
    if-ne v0, v3, :cond_2

    goto :goto_0

    :cond_2
    if-eq v0, v4, :cond_9

    if-ne v0, v2, :cond_7

    goto :goto_2

    :cond_3
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getDivisao()I

    move-result v0

    if-ne v0, v7, :cond_4

    const/16 v1, 0x258

    goto :goto_2

    :cond_4
    if-ne v0, v6, :cond_5

    :goto_0
    const/16 v1, 0x1f4

    goto :goto_2

    :cond_5
    if-ne v0, v3, :cond_6

    goto :goto_2

    :cond_6
    if-eq v0, v4, :cond_8

    if-ne v0, v2, :cond_7

    goto :goto_1

    :cond_7
    const/16 v1, 0x15e

    goto :goto_2

    :cond_8
    :goto_1
    const/16 v1, 0x190

    :cond_9
    :goto_2
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getNivel()I

    move-result v0

    const/16 v2, 0x14

    if-le v0, v2, :cond_a

    add-int/lit8 v1, v1, 0x32

    :cond_a
    iget v0, p0, La/p;->posicao:I

    if-nez v0, :cond_b

    add-int/lit8 v1, v1, -0x46

    goto :goto_3

    :cond_b
    if-ne v0, v7, :cond_c

    add-int/lit8 v1, v1, -0x1e

    goto :goto_3

    :cond_c
    if-ne v0, v6, :cond_d

    add-int/lit8 v1, v1, -0x28

    goto :goto_3

    :cond_d
    if-ne v0, v4, :cond_e

    add-int/lit8 v1, v1, -0x32

    :cond_e
    :goto_3
    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    int-to-double v0, v1

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    iget v1, p0, La/p;->forca:I

    mul-int/lit8 v1, v1, 0x2

    mul-int v1, v1, v0

    iget v0, p0, La/p;->pZ:I

    const/16 v2, 0x20

    sub-int/2addr v0, v2

    mul-int/lit16 v0, v0, 0x12c

    const/4 v3, 0x0

    iget-object v6, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-nez v6, :cond_f

    iget-object v6, p0, La/p;->pY:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-eqz v6, :cond_10

    :cond_f
    iget v3, p0, La/p;->forca:I

    mul-int/lit16 v3, v3, 0xfa

    :cond_10
    iget v6, p0, La/p;->pZ:I

    if-ge v6, v2, :cond_11

    :goto_4
    add-int/2addr v1, v3

    goto :goto_5

    :cond_11
    sub-int/2addr v1, v0

    goto :goto_4

    :goto_5
    if-ge v1, v5, :cond_12

    const/16 v1, 0x1f4

    :cond_12
    iget-object v0, p0, La/p;->pY:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_13

    int-to-double v0, v1

    const-wide v2, 0x3ff6666666666666L    # 1.4

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v1, v0

    :cond_13
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isSalarioMensal()Z

    move-result v0

    if-ne v0, v7, :cond_14

    mul-int/lit8 v1, v1, 0x4

    :cond_14
    iput v1, p0, La/p;->salario:I

    :cond_15
    return-void
.end method

.method public if()V
    .locals 11

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/p;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget v1, p0, La/p;->pais:I

    if-ltz v1, :cond_0

    const/16 v2, 0xdc

    if-le v1, v2, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    :goto_0
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNivel()I

    move-result v1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_1
    iget v3, p0, La/p;->forca:I

    mul-int/lit8 v3, v3, 0x2

    mul-int v3, v3, v3

    const/16 v4, 0x14

    const/16 v5, 0x15

    if-lt v1, v5, :cond_2

    const/16 v6, 0x2ee

    goto :goto_2

    :cond_2
    if-lt v1, v4, :cond_3

    const/16 v6, 0x258

    goto :goto_2

    :cond_3
    const/16 v6, 0x12

    if-lt v1, v6, :cond_4

    const/16 v6, 0x1f4

    goto :goto_2

    :cond_4
    const/16 v6, 0xc

    if-lt v1, v6, :cond_5

    const/16 v6, 0x190

    goto :goto_2

    :cond_5
    const/16 v6, 0x16e

    :goto_2
    iget-object v7, p0, La/p;->pX:Ljava/lang/Boolean;

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    const/16 v8, 0x16

    if-eqz v7, :cond_8

    if-lt v1, v8, :cond_6

    if-nez v0, :cond_6

    mul-int/lit8 v6, v6, 0x3

    goto :goto_3

    :cond_6
    if-lt v1, v5, :cond_7

    if-nez v0, :cond_7

    mul-int/lit8 v6, v6, 0x2

    goto :goto_3

    :cond_7
    const-wide v9, 0x3ffb333333333333L    # 1.7

    int-to-double v5, v6

    mul-double v5, v5, v9

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v5

    long-to-int v6, v5

    :cond_8
    :goto_3
    invoke-virtual {p0}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_9

    const-wide v9, 0x3ff999999999999aL    # 1.6

    int-to-double v5, v6

    mul-double v5, v5, v9

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v5

    long-to-int v6, v5

    :cond_9
    iget v1, p0, La/p;->posicao:I

    const/4 v5, 0x4

    if-ne v1, v5, :cond_a

    const-wide v9, 0x3ff4cccccccccccdL    # 1.3

    int-to-double v5, v6

    mul-double v5, v5, v9

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v5

    long-to-int v6, v5

    :cond_a
    iget v1, p0, La/p;->status:I

    const/4 v5, 0x1

    if-ne v1, v5, :cond_b

    int-to-double v5, v6

    const-wide v9, 0x3fc999999999999aL    # 0.2

    mul-double v9, v9, v5

    add-double/2addr v5, v9

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v5

    long-to-int v6, v5

    :cond_b
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x10

    if-ge v0, v1, :cond_c

    iput v1, p0, La/p;->pZ:I

    :cond_c
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x20

    if-ge v0, v4, :cond_d

    iget v0, p0, La/p;->pZ:I

    sub-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1b

    goto :goto_4

    :cond_d
    iget v0, p0, La/p;->pZ:I

    const/16 v4, 0x19

    if-gt v0, v4, :cond_e

    iget v0, p0, La/p;->pZ:I

    sub-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x16

    goto :goto_4

    :cond_e
    iget v0, p0, La/p;->pZ:I

    if-ge v0, v1, :cond_f

    iget v0, p0, La/p;->pZ:I

    sub-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0xf

    goto :goto_4

    :cond_f
    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x22

    if-ge v0, v1, :cond_10

    iget v0, p0, La/p;->pZ:I

    sub-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0xa

    goto :goto_4

    :cond_10
    iget v0, p0, La/p;->pZ:I

    sub-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x32

    rsub-int/lit8 v1, v0, 0x0

    :goto_4
    add-int/2addr v6, v1

    if-gtz v6, :cond_11

    const/16 v6, 0x3c

    :cond_11
    mul-int v3, v3, v6

    iget v0, p0, La/p;->qE:I

    if-lez v0, :cond_12

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    iget v1, p0, La/p;->qE:I

    if-ne v0, v1, :cond_12

    int-to-double v0, v3

    const-wide v2, 0x3f9eb851eb851eb8L    # 0.03

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    iget v1, p0, La/p;->qd:I

    mul-int v3, v0, v1

    :cond_12
    iget v0, p0, La/p;->bolaBonus:I

    add-int/2addr v3, v0

    iput v3, p0, La/p;->qe:I

    return-void
.end method

.method public ig()I
    .locals 1

    iget v0, p0, La/p;->qE:I

    return v0
.end method

.method public ih()I
    .locals 1

    iget v0, p0, La/p;->qF:I

    return v0
.end method

.method public ii()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/p;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ij()I
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/p;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    return v0
.end method

.method public ik()Z
    .locals 6

    sget-object v0, La/ak;->Ao:[I

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_1

    aget v4, v0, v3

    iget v5, p0, La/p;->pais:I

    if-ne v4, v5, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return v2
.end method

.method public il()Z
    .locals 5

    iget-wide v0, p0, La/p;->ql:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-lez v4, :cond_0

    iget-wide v0, p0, La/p;->ql:J

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->en()Ljava/util/Calendar;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v2

    cmp-long v4, v0, v2

    if-lez v4, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public im()Ljava/lang/String;
    .locals 6

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b009f

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-wide v1, p0, La/p;->qm:J

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->en()Ljava/util/Calendar;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/Date;->getTime()J

    move-result-wide v3

    cmp-long v5, v1, v3

    if-lez v5, :cond_0

    iget-wide v0, p0, La/p;->qm:J

    invoke-static {v0, v1}, La/a;->a(J)Ljava/lang/String;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public in()I
    .locals 4

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->en()Ljava/util/Calendar;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    iget-wide v2, p0, La/p;->qm:J

    invoke-virtual {p0, v0, v1, v2, v3}, La/p;->a(JJ)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    const/4 v0, 0x0

    return v0
.end method

.method public io()I
    .locals 1

    iget v0, p0, La/p;->qu:I

    return v0
.end method

.method public ip()I
    .locals 2

    iget v0, p0, La/p;->qn:I

    div-int/lit8 v0, v0, 0x64

    iget v1, p0, La/p;->forca:I

    mul-int v0, v0, v1

    int-to-float v0, v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method public iq()V
    .locals 2

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_1

    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x2a

    if-ge v0, v1, :cond_0

    invoke-direct {p0}, La/p;->ir()V

    goto :goto_0

    :cond_0
    invoke-direct {p0}, La/p;->is()V

    :goto_0
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qo:Ljava/lang/Boolean;

    :cond_1
    return-void
.end method

.method public isAposentado()Z
    .locals 1

    iget-boolean v0, p0, La/p;->aposentado:Z

    return v0
.end method

.method public isPendLoan()Z
    .locals 1

    iget-boolean v0, p0, La/p;->pendIsLoan:Z

    return v0
.end method

.method public it()V
    .locals 1

    iget v0, p0, La/p;->pZ:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/p;->pZ:I

    return-void
.end method

.method public iu()V
    .locals 4

    iget-boolean v0, p0, La/p;->aposentado:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget v0, p0, La/p;->pZ:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/p;->pZ:I

    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x23

    if-le v0, v1, :cond_3

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->ageDecline(La/p;)I

    move-result v1

    iget v2, p0, La/p;->forca:I

    sub-int/2addr v2, v1

    invoke-static {p0, v2}, Lcom/brasfoot/v2028/Recopa;->retireDecision(La/p;I)Z

    move-result v1

    if-nez v1, :cond_2

    const/4 v1, 0x1

    if-ge v2, v1, :cond_1

    const/4 v2, 0x1

    :cond_1
    iput v2, p0, La/p;->forca:I

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    iput-boolean v0, p0, La/p;->aposentado:Z

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_3
    :goto_0
    iget-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/p;->qx:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public iv()V
    .locals 6

    invoke-virtual {p0}, La/p;->it()V

    iget-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/p;->qx:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-boolean v0, p0, La/p;->aposentado:Z

    if-nez v0, :cond_2

    iget v0, p0, La/p;->pZ:I

    const/16 v1, 0x23

    if-le v0, v1, :cond_3

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->ageDecline(La/p;)I

    move-result v1

    iget v2, p0, La/p;->forca:I

    sub-int/2addr v2, v1

    invoke-static {p0, v2}, Lcom/brasfoot/v2028/Recopa;->retireDecision(La/p;I)Z

    move-result v1

    if-nez v1, :cond_1

    const/4 v1, 0x1

    if-ge v2, v1, :cond_0

    const/4 v2, 0x1

    :cond_0
    iput v2, p0, La/p;->forca:I

    return-void

    :cond_1
    const/4 v0, 0x1

    iput-boolean v0, p0, La/p;->aposentado:Z

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_2
    return-void

    :cond_3
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_13

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->qB:Ljava/lang/Boolean;

    :cond_4
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v3, 0x64

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/2addr v0, v2

    iget v3, p0, La/p;->pZ:I

    const/16 v4, 0x20

    if-le v3, v4, :cond_13

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_13

    iget v3, p0, La/p;->pZ:I

    invoke-virtual {p0}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_5

    add-int/lit8 v3, v3, -0x1

    :cond_5
    invoke-virtual {p0}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_6

    add-int/lit8 v3, v3, -0x3

    :cond_6
    iget v5, p0, La/p;->posicao:I

    if-nez v5, :cond_7

    add-int/lit8 v3, v3, -0x3

    :cond_7
    if-ge v3, v4, :cond_8

    goto :goto_1

    :cond_8
    if-ne v3, v4, :cond_a

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    :cond_9
    :goto_0
    const/4 v1, 0x1

    goto :goto_1

    :cond_a
    const/16 v4, 0x22

    if-gt v3, v4, :cond_b

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_b
    const/16 v4, 0x23

    if-gt v3, v4, :cond_c

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_c
    const/16 v4, 0x24

    if-gt v3, v4, :cond_d

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_d
    const/16 v4, 0x26

    if-gt v3, v4, :cond_e

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_e
    const/16 v4, 0x27

    if-gt v3, v4, :cond_f

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_f
    const/16 v4, 0x28

    if-gt v3, v4, :cond_10

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_10
    const/16 v4, 0x2a

    if-gt v3, v4, :cond_11

    const/16 v3, 0x63

    if-le v0, v3, :cond_12

    goto :goto_0

    :cond_11
    const/16 v4, 0x30

    if-gt v3, v4, :cond_9

    if-le v0, v2, :cond_12

    goto :goto_0

    :cond_12
    :goto_1
    if-eqz v1, :cond_13

    const/4 v0, 0x0

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1, v2}, La/p;->a(Ljava/lang/String;IZ)Z

    :cond_13
    return-void
.end method

.method public iw()I
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/p;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    return v0
.end method

.method public ix()I
    .locals 1

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    return v0

    :cond_0
    const/4 v0, -0x1

    return v0
.end method

.method public iy()Z
    .locals 1

    iget-boolean v0, p0, La/p;->qk:Z

    return v0
.end method

.method public iz()I
    .locals 1

    iget v0, p0, La/p;->qG:I

    return v0
.end method

.method public j(La/ac;)La/e;
    .locals 3

    iget-object v0, p0, La/p;->qw:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/p;->qw:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/p;->qw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/e;

    invoke-virtual {v1}, La/e;->fL()I

    move-result v1

    invoke-virtual {p1}, La/ac;->mE()I

    move-result v2

    if-ne v1, v2, :cond_0

    iget-object v1, p0, La/p;->qw:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/e;

    invoke-virtual {v1}, La/e;->db()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    if-ne v1, v2, :cond_0

    iget-object p1, p0, La/p;->qw:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/e;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public j(La/al;)La/s;
    .locals 2

    iget-object v0, p0, La/p;->qv:Ljava/util/ArrayList;

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/s;

    invoke-virtual {v1}, La/s;->jb()La/al;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/s;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, La/s;

    invoke-direct {v0, p0, p1}, La/s;-><init>(La/p;La/al;)V

    iget-object p1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0

    :cond_2
    const/4 p1, 0x0

    return-object p1
.end method

.method public k(La/ac;)V
    .locals 9

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0xe

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x14

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    const/4 v3, 0x5

    add-int/2addr v1, v3

    iget v4, p0, La/p;->qn:I

    const/16 v5, 0xa

    const/4 v6, 0x1

    if-ge v4, v5, :cond_0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    iget v4, p0, La/p;->qn:I

    const/16 v7, 0x32

    if-ge v4, v7, :cond_1

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    :goto_0
    iget v7, p0, La/p;->pZ:I

    const/16 v8, 0x23

    if-gt v7, v2, :cond_2

    goto :goto_3

    :cond_2
    iget v2, p0, La/p;->pZ:I

    const/16 v7, 0x19

    if-gt v2, v7, :cond_3

    add-int/2addr v4, v0

    add-int/lit8 v0, v4, 0x1

    goto :goto_3

    :cond_3
    iget v2, p0, La/p;->pZ:I

    const/16 v7, 0x1e

    if-gt v2, v7, :cond_4

    add-int/2addr v4, v0

    add-int/lit8 v0, v4, 0x2

    goto :goto_3

    :cond_4
    iget v2, p0, La/p;->pZ:I

    if-gt v2, v8, :cond_5

    add-int/2addr v4, v0

    add-int/lit8 v0, v4, 0x3

    goto :goto_3

    :cond_5
    iget v2, p0, La/p;->pZ:I

    const/16 v7, 0x28

    if-gt v2, v7, :cond_6

    :goto_1
    add-int/2addr v4, v0

    :goto_2
    add-int v0, v4, v1

    goto :goto_3

    :cond_6
    iget v2, p0, La/p;->pZ:I

    const/16 v7, 0x2d

    if-gt v2, v7, :cond_7

    goto :goto_1

    :cond_7
    add-int/2addr v4, v0

    add-int/2addr v4, v5

    goto :goto_2

    :goto_3
    iget v1, p0, La/p;->pZ:I

    if-lt v1, v8, :cond_8

    iget v1, p0, La/p;->forca:I

    sub-int/2addr v1, v3

    iput v1, p0, La/p;->forca:I

    iget v1, p0, La/p;->forca:I

    if-gez v1, :cond_8

    iput v6, p0, La/p;->forca:I

    :cond_8
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x64

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    if-ne v1, v6, :cond_9

    add-int/lit8 v0, v0, 0x46

    goto :goto_4

    :cond_9
    const/4 v2, 0x4

    if-ge v1, v2, :cond_a

    add-int/lit8 v0, v0, 0x28

    goto :goto_4

    :cond_a
    if-ge v1, v5, :cond_b

    add-int/lit8 v0, v0, 0x14

    :cond_b
    :goto_4
    if-lez v0, :cond_c

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dd()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Date;->getTime()J

    move-result-wide v1

    int-to-long v4, v0

    const-wide/32 v6, 0x5265c00

    mul-long v4, v4, v6

    add-long v6, v1, v4

    iput-wide v6, p0, La/p;->ql:J

    :cond_c
    invoke-direct {p0, v3, p1}, La/p;->b(ILa/ac;)V

    return-void
.end method

.method public k(La/al;)V
    .locals 1

    invoke-virtual {p0, p1}, La/p;->j(La/al;)La/s;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance v0, La/s;

    invoke-direct {v0, p0, p1}, La/s;-><init>(La/p;La/al;)V

    iget-object p1, p0, La/p;->qv:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public l(La/ac;)V
    .locals 8

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->isOnLoan(La/p;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, La/p;->pendSaleClub:La/ac;

    if-eqz v0, :cond_1

    return-void

    :cond_1
    invoke-static {p0, p1}, Lcom/brasfoot/v2028/Recopa;->intlBlocked(La/p;La/ac;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {p0, p1}, Lcom/brasfoot/v2028/Recopa;->schedulePendingLoan(La/p;La/ac;)Z

    move-result v0

    return-void

    :cond_2
    new-instance v0, Lcomponents/bn;

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcomponents/bn;-><init>(La/p;La/ac;)V

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    move-object v2, p0

    move-object v3, p1

    invoke-virtual/range {v2 .. v7}, La/p;->a(La/ac;IZZZ)V

    return-void
.end method

.method public m(La/ac;)V
    .locals 6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object v0, p0

    move-object v1, p1

    :try_start_0
    invoke-virtual/range {v0 .. v5}, La/p;->a(La/ac;IZZZ)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public onPlayEnergia(I)V
    .locals 2

    invoke-static {}, La/p;->enReal()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-virtual {p0}, La/p;->getIdade()I

    move-result v0

    const/16 v1, 0x19

    if-gt v0, v1, :cond_0

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    const/16 v1, 0x1e

    if-gt v0, v1, :cond_1

    const/16 v0, 0x8

    goto :goto_0

    :cond_1
    const/16 v1, 0x23

    if-gt v0, v1, :cond_2

    const/16 v0, 0xc

    goto :goto_0

    :cond_2
    const/16 v0, 0x14

    :goto_0
    invoke-virtual {p0}, La/p;->getEnergia()I

    move-result v1

    sub-int/2addr v1, v0

    const/16 v0, 0xa

    if-ge v1, v0, :cond_3

    move v1, v0

    :cond_3
    const/16 v0, 0x64

    if-le v1, v0, :cond_4

    move v1, v0

    :cond_4
    iput v1, p0, La/p;->energiaBase:I

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, La/b;->dd()I

    move-result v0

    iput v0, p0, La/p;->lastGameDay:I

    :cond_5
    return-void
.end method

.method public setCr1(I)V
    .locals 0

    iput p1, p0, La/p;->qi:I

    return-void
.end method

.method public setCr2(I)V
    .locals 0

    iput p1, p0, La/p;->qj:I

    return-void
.end method

.method public setForca(I)V
    .locals 0

    iput p1, p0, La/p;->forca:I

    return-void
.end method

.method public setIdade(I)V
    .locals 1

    const/16 v0, 0x10

    if-lt p1, v0, :cond_0

    const/16 v0, 0x30

    if-le p1, v0, :cond_1

    :cond_0
    const/16 p1, 0x23

    :cond_1
    iput p1, p0, La/p;->pZ:I

    return-void
.end method

.method public setLado(I)V
    .locals 0

    if-nez p1, :cond_0

    const/4 p1, 0x0

    :goto_0
    iput p1, p0, La/p;->qc:I

    return-void

    :cond_0
    const/4 p1, 0x1

    goto :goto_0

    return-void
.end method

.method public setNome(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/p;->pq:Ljava/lang/String;

    return-void
.end method

.method public setPais(I)V
    .locals 0

    iput p1, p0, La/p;->pais:I

    return-void
.end method

.method public setPendLoan(La/ac;)V
    .locals 1

    iput-object p1, p0, La/p;->pendSaleClub:La/ac;

    const/4 v0, 0x0

    iput v0, p0, La/p;->pendSaleValue:I

    const/4 v0, 0x1

    iput-boolean v0, p0, La/p;->pendIsLoan:Z

    return-void
.end method

.method public setPendSale(La/ac;I)V
    .locals 0

    iput-object p1, p0, La/p;->pendSaleClub:La/ac;

    iput p2, p0, La/p;->pendSaleValue:I

    return-void
.end method

.method public setPosicao(I)V
    .locals 0

    iput p1, p0, La/p;->posicao:I

    return-void
.end method

.method public setStar(Z)V
    .locals 1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->pX:Ljava/lang/Boolean;

    return-void
.end method

.method public setStatus(I)V
    .locals 0

    iput p1, p0, La/p;->status:I

    return-void
.end method

.method public setTop(Z)V
    .locals 1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, p0, La/p;->pY:Ljava/lang/Boolean;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    const-string v0, ""

    invoke-virtual {p0}, La/p;->hL()I

    move-result v1

    if-lez v1, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, La/p;->hL()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
