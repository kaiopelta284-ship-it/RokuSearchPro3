.class public La/ai;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private lU:I

.field private mo:I

.field private oo:I

.field private pv:I

.field private qQ:La/al;

.field private yE:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, La/ai;->mo:I

    iput v0, p0, La/ai;->lU:I

    iput v0, p0, La/ai;->pv:I

    const/4 v0, -0x1

    iput v0, p0, La/ai;->oo:I

    iput v0, p0, La/ai;->yE:I

    const/4 v0, 0x0

    iput-object v0, p0, La/ai;->qQ:La/al;

    return-void
.end method


# virtual methods
.method public W(I)V
    .locals 0

    iput p1, p0, La/ai;->lU:I

    return-void
.end method

.method public aJ(I)V
    .locals 0

    iput p1, p0, La/ai;->pv:I

    return-void
.end method

.method public ad(I)V
    .locals 0

    iput p1, p0, La/ai;->mo:I

    return-void
.end method

.method public aw(I)V
    .locals 0

    iput p1, p0, La/ai;->oo:I

    return-void
.end method

.method public cG()I
    .locals 1

    iget v0, p0, La/ai;->lU:I

    return v0
.end method

.method public cu(I)V
    .locals 0

    iput p1, p0, La/ai;->yE:I

    return-void
.end method

.method public db()I
    .locals 1

    iget v0, p0, La/ai;->mo:I

    return v0
.end method

.method public fL()I
    .locals 1

    iget v0, p0, La/ai;->oo:I

    return v0
.end method

.method public gT()I
    .locals 1

    iget v0, p0, La/ai;->pv:I

    return v0
.end method

.method public jb()La/al;
    .locals 1

    iget-object v0, p0, La/ai;->qQ:La/al;

    return-object v0
.end method

.method public l(La/al;)V
    .locals 0

    iput-object p1, p0, La/ai;->qQ:La/al;

    return-void
.end method

.method public nC()I
    .locals 1

    iget v0, p0, La/ai;->yE:I

    return v0
.end method
