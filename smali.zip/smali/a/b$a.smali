.class public La/b$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field g:I

.field of:I

.field final synthetic og:La/b;


# direct methods
.method constructor <init>(La/b;II)V
    .locals 0

    iput-object p1, p0, La/b$a;->og:La/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput p1, p0, La/b$a;->g:I

    iput p1, p0, La/b$a;->of:I

    iput p2, p0, La/b$a;->g:I

    iput p3, p0, La/b$a;->of:I

    return-void
.end method
