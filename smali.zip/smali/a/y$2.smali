.class final La/y$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "La/y;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La/y;La/y;)I
    .locals 2

    invoke-static {p1}, La/y;->b(La/y;)I

    move-result v0

    invoke-static {p2}, La/y;->b(La/y;)I

    move-result v1

    invoke-static {p1}, La/y;->c(La/y;)I

    move-result p1

    invoke-static {p2}, La/y;->c(La/y;)I

    move-result p2

    if-eq v0, v1, :cond_0

    sub-int/2addr v1, v0

    return v1

    :cond_0
    if-eq p1, p2, :cond_1

    sub-int/2addr p2, p1

    return p2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, La/y;

    check-cast p2, La/y;

    invoke-virtual {p0, p1, p2}, La/y$2;->a(La/y;La/y;)I

    move-result p1

    return p1
.end method
