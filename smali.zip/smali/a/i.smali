.class public abstract La/i;
.super Ljava/lang/Object;


# static fields
.field private static oW:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private static oX:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private static oY:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bt;",
            ">;"
        }
    .end annotation
.end field

.field private static oZ:Ld/m; = null

.field private static pa:I = -0x1

.field private static pb:I = -0x1

.field private static pc:La/al;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/i;->oW:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/i;->oX:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/i;->oY:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static aE(I)Z
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_1

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getEstado()I

    move-result v3

    if-ne v3, p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public static aF(I)V
    .locals 0

    sput p0, La/i;->pa:I

    return-void
.end method

.method public static aG(I)V
    .locals 0

    sput p0, La/i;->pb:I

    return-void
.end method

.method public static addExtraDiv4Team()V
    .locals 10

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v6, 0x0

    :goto_1
    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_0

    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bt;

    invoke-virtual {v3}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_0
    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v4, 0x60

    if-lt v3, v4, :cond_3

    const/4 v1, 0x0

    const/4 v2, -0x1

    const/4 v6, 0x0

    :goto_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v4

    const/16 v5, 0x1d

    if-eq v4, v5, :cond_1

    iget v4, v3, La/ac;->divisao:I

    const/4 v5, 0x1

    if-ne v4, v5, :cond_1

    const/4 v5, 0x2

    if-ne v4, v5, :cond_1

    const/4 v5, 0x3

    if-ne v4, v5, :cond_1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v3}, La/ac;->mi()I

    move-result v4

    if-gt v4, v2, :cond_1

    move v2, v4

    move-object v1, v3

    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    if-eqz v1, :cond_4

    :cond_3
    return-void

    :cond_4
    new-instance v3, Lcomponents/bt;

    invoke-direct {v3}, Lcomponents/bt;-><init>()V

    invoke-virtual {v3}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Lcomponents/bt;->as(Z)V

    sget-object v4, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0
.end method

.method public static c(La/al;)Z
    .locals 7

    invoke-virtual {p0}, La/al;->cG()I

    move-result v0

    invoke-virtual {p0}, La/al;->iw()I

    move-result v1

    const/16 v2, 0xa

    new-array v2, v2, [Z

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/4 v6, 0x1

    if-ge v4, v5, :cond_2

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jH()La/al;

    move-result-object v5

    if-ne v5, p0, :cond_1

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->ji()La/ac;

    move-result-object v5

    invoke-virtual {v5}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-nez v5, :cond_0

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jj()La/ac;

    move-result-object v5

    invoke-virtual {v5}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_1

    :cond_0
    return v6

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-virtual {v4}, Lest/Options;->isSoMinhasCompeticoes()Z

    move-result v4

    if-eqz v4, :cond_3

    return v3

    :cond_3
    const/4 p0, 0x2

    if-ne v0, p0, :cond_4

    const/16 p0, 0x8

    aget-boolean p0, v2, p0

    return p0

    :cond_4
    const/4 p0, 0x4

    if-ne v0, p0, :cond_5

    aget-boolean p0, v2, v1

    return p0

    :cond_5
    const/4 p0, 0x7

    const/4 v4, 0x6

    if-ne v0, v4, :cond_7

    if-nez v1, :cond_6

    aget-boolean p0, v2, v4

    return p0

    :cond_6
    if-ne v1, v6, :cond_8

    aget-boolean p0, v2, p0

    return p0

    :cond_7
    if-eq v0, p0, :cond_9

    const/16 p0, 0x9

    if-ne v0, p0, :cond_8

    return v3

    :cond_8
    return v6

    :cond_9
    return v3

    :array_0
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method

.method public static gA()V
    .locals 8

    sget-object v0, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v3, 0x12

    const/4 v4, 0x1

    if-ge v1, v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->le()Z

    move-result v2

    if-eqz v2, :cond_3

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->lg()Z

    move-result v2

    if-eqz v2, :cond_3

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->getEstado()I

    move-result v2

    sput v2, La/i;->pa:I

    const/4 v2, 0x0

    :goto_1
    sget-object v5, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v2, v5, :cond_1

    sget-object v5, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/al;

    invoke-virtual {v5}, La/al;->nQ()Ld/m;

    move-result-object v5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-ne v5, v6, :cond_0

    sget-object v5, La/i;->oX:Ljava/util/ArrayList;

    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_3

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-le v2, v4, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->getEstado()I

    move-result v2

    if-ne v2, v3, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->xS()I

    move-result v2

    const/16 v3, 0xc

    if-ne v2, v3, :cond_2

    invoke-static {}, La/i;->gB()V

    :cond_2
    new-instance v2, Lcomponents/bt;

    invoke-direct {v2}, Lcomponents/bt;-><init>()V

    invoke-virtual {v2}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v3

    sget-object v5, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v2, v4}, Lcomponents/bt;->as(Z)V

    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_4
    sget-object v1, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_b

    const/4 v1, 0x6

    new-array v1, v1, [I

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eM()I

    move-result v2

    aput v2, v1, v0

    const/16 v2, 0x19

    aput v2, v1, v4

    const/4 v2, 0x2

    aput v3, v1, v2

    const/4 v2, 0x3

    const/16 v3, 0x16

    aput v3, v1, v2

    const/4 v2, 0x4

    const/16 v3, 0x11

    aput v3, v1, v2

    const/4 v2, 0x5

    const/16 v3, 0xa

    aput v3, v1, v2

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_2
    array-length v5, v1

    if-ge v2, v5, :cond_b

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    sub-int/2addr v5, v4

    :goto_3
    if-ltz v5, :cond_9

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/m;

    invoke-virtual {v6}, Ld/m;->getEstado()I

    move-result v6

    aget v7, v1, v2

    if-ne v6, v7, :cond_8

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/m;

    invoke-virtual {v6}, Ld/m;->lg()Z

    move-result v6

    if-eqz v6, :cond_8

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/m;

    invoke-virtual {v3}, Ld/m;->getEstado()I

    move-result v3

    sput v3, La/i;->pa:I

    sget-object v3, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    const/4 v3, 0x0

    :goto_4
    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v3, v6, :cond_6

    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/al;

    invoke-virtual {v6}, La/al;->nQ()Ld/m;

    move-result-object v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    if-ne v6, v7, :cond_5

    sget-object v6, La/i;->oX:Ljava/util/ArrayList;

    sget-object v7, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    :cond_6
    sget-object v3, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_7

    new-instance v3, Lcomponents/bt;

    invoke-direct {v3}, Lcomponents/bt;-><init>()V

    invoke-virtual {v3}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v6

    sget-object v7, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v3, v4}, Lcomponents/bt;->as(Z)V

    sget-object v6, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    const/4 v3, 0x1

    :cond_8
    add-int/lit8 v5, v5, -0x1

    goto/16 :goto_3

    :cond_9
    if-eqz v3, :cond_a

    goto :goto_5

    :cond_a
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_2

    :cond_b
    :goto_5
    invoke-static {}, La/i;->addExtraDiv4Team()V

    invoke-static {}, La/i;->gG()V

    return-void
.end method

.method public static gB()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Ld/q;

    if-eqz v2, :cond_0

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    sget-object v1, Lcomponents/ce;->RJ:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_2
    sget-object v1, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    return-void
.end method

.method public static gC()V
    .locals 8

    sget-object v0, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ge v1, v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->ld()Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->lf()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    :goto_1
    if-eqz v2, :cond_3

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    :goto_2
    sget-object v4, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_2

    sget-object v4, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/al;

    sput-object v4, La/i;->pc:La/al;

    sget-object v4, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_1

    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    sget-object v5, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_2
    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_3

    new-instance v2, Lcomponents/bt;

    invoke-direct {v2}, Lcomponents/bt;-><init>()V

    invoke-virtual {v2}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v4

    sget-object v5, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v2, v3}, Lcomponents/bt;->as(Z)V

    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_4
    sget-object v1, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_b

    new-array v1, v3, [I

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eN()I

    move-result v2

    aput v2, v1, v0

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_3
    array-length v5, v1

    if-ge v2, v5, :cond_b

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    sub-int/2addr v5, v3

    :goto_4
    if-ltz v5, :cond_9

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->kK()I

    move-result v6

    aget v7, v1, v2

    if-ne v6, v7, :cond_8

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->lf()Z

    move-result v6

    if-eqz v6, :cond_8

    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    const/4 v4, 0x0

    :goto_5
    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_6

    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/al;

    sput-object v6, La/i;->pc:La/al;

    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    if-ne v6, v7, :cond_5

    sget-object v6, La/i;->oX:Ljava/util/ArrayList;

    sget-object v7, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    :cond_6
    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_7

    new-instance v4, Lcomponents/bt;

    invoke-direct {v4}, Lcomponents/bt;-><init>()V

    invoke-virtual {v4}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v6

    sget-object v7, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v4, v3}, Lcomponents/bt;->as(Z)V

    sget-object v6, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    const/4 v4, 0x1

    :cond_8
    add-int/lit8 v5, v5, -0x1

    goto/16 :goto_4

    :cond_9
    if-eqz v4, :cond_a

    goto :goto_6

    :cond_a
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_3

    :cond_b
    :goto_6
    invoke-static {}, La/i;->gG()V

    return-void
.end method

.method public static gD()Z
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dd()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    const/4 v2, 0x0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dd()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    instance-of v3, v3, Ld/q;

    if-eqz v3, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dd()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    :goto_1
    check-cast v2, Ld/q;

    goto :goto_2

    :cond_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dd()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    instance-of v3, v3, Ld/x;

    if-eqz v3, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dd()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/x;

    invoke-virtual {v2}, Ld/x;->yx()La/al;

    move-result-object v2

    goto :goto_1

    :cond_1
    :goto_2
    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ld/q;->le()Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v0, 0x1

    return v0

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_3
    return v0
.end method

.method public static gE()Z
    .locals 8

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    :goto_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_5

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/af;

    invoke-virtual {v4}, La/af;->hE()La/ac;

    move-result-object v4

    const/16 v5, 0x1d

    if-eqz v4, :cond_3

    invoke-virtual {v4}, La/ac;->getPais()I

    move-result v6

    if-ne v6, v5, :cond_3

    const/4 v3, 0x0

    const/4 v5, 0x0

    :goto_1
    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v3, v6, :cond_1

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/m;

    invoke-virtual {v6}, Ld/m;->getEstado()I

    move-result v6

    invoke-virtual {v4}, La/ac;->getEstado()I

    move-result v7

    if-ne v6, v7, :cond_0

    const/4 v5, 0x1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    if-eqz v5, :cond_2

    invoke-virtual {v4}, La/ac;->getEstado()I

    move-result v3

    invoke-static {v3}, La/i;->aE(I)Z

    move-result v3

    goto :goto_2

    :cond_2
    move v3, v5

    goto :goto_2

    :cond_3
    if-eqz v4, :cond_4

    invoke-virtual {v4}, La/ac;->getPais()I

    move-result v4

    if-eq v4, v5, :cond_4

    const/4 v3, 0x0

    :cond_4
    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_5
    return v3
.end method

.method public static gF()V
    .locals 8

    sget-object v0, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ge v1, v2, :cond_5

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->le()Z

    move-result v2

    if-nez v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->la()Z

    move-result v2

    if-eqz v2, :cond_1

    :cond_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->lg()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    :goto_1
    if-eqz v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kK()I

    move-result v2

    sput v2, La/i;->pa:I

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    :goto_2
    sget-object v4, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_3

    sget-object v4, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/al;

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_2

    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    sget-object v5, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_4

    new-instance v2, Lcomponents/bt;

    invoke-direct {v2}, Lcomponents/bt;-><init>()V

    invoke-virtual {v2}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v4

    sget-object v5, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v2, v3}, Lcomponents/bt;->as(Z)V

    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_5
    sget-object v1, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_c

    new-array v1, v3, [I

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eN()I

    move-result v2

    aput v2, v1, v0

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_3
    array-length v5, v1

    if-ge v2, v5, :cond_c

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    sub-int/2addr v5, v3

    :goto_4
    if-ltz v5, :cond_a

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->kK()I

    move-result v6

    aget v7, v1, v2

    if-ne v6, v7, :cond_9

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->lg()Z

    move-result v6

    if-eqz v6, :cond_9

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kK()I

    move-result v4

    sput v4, La/i;->pa:I

    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    const/4 v4, 0x0

    :goto_5
    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_7

    sget-object v6, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/al;

    invoke-virtual {v6}, La/al;->nR()La/y;

    move-result-object v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    if-ne v6, v7, :cond_6

    sget-object v6, La/i;->oX:Ljava/util/ArrayList;

    sget-object v7, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    :cond_7
    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_8

    new-instance v4, Lcomponents/bt;

    invoke-direct {v4}, Lcomponents/bt;-><init>()V

    invoke-virtual {v4}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v6

    sget-object v7, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v4, v3}, Lcomponents/bt;->as(Z)V

    sget-object v6, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    const/4 v4, 0x1

    :cond_9
    add-int/lit8 v5, v5, -0x1

    goto/16 :goto_4

    :cond_a
    if-eqz v4, :cond_b

    goto :goto_6

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_3

    :cond_c
    :goto_6
    invoke-static {}, La/i;->gG()V

    return-void
.end method

.method public static gG()V
    .locals 0

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->finGroupHook()V

    return-void
.end method

.method public static gH()I
    .locals 2

    sget-object v0, La/i;->oY:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    sget-object v1, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bt;

    invoke-virtual {v1}, Lcomponents/bt;->uP()Z

    move-result v1

    if-eqz v1, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    return v0
.end method

.method public static gI()I
    .locals 1

    sget v0, La/i;->pa:I

    return v0
.end method

.method public static gJ()I
    .locals 1

    sget v0, La/i;->pb:I

    return v0
.end method

.method public static gK()La/al;
    .locals 1

    sget-object v0, La/i;->pc:La/al;

    return-object v0
.end method

.method public static gw()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bt;",
            ">;"
        }
    .end annotation

    sget-object v0, La/i;->oY:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static gx()Z
    .locals 6

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->getVerJint()[Z

    const/4 v0, -0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, -0x1

    :goto_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v5, 0x1

    if-ge v2, v4, :cond_3

    if-ne v3, v0, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jH()La/al;

    move-result-object v3

    invoke-virtual {v3}, La/al;->cG()I

    move-result v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->jH()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->iw()I

    :cond_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->ji()La/ac;

    move-result-object v4

    invoke-virtual {v4}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->jj()La/ac;

    move-result-object v4

    invoke-virtual {v4}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v0, 0x1

    goto :goto_2

    :cond_3
    const/4 v0, 0x0

    :goto_2
    if-nez v0, :cond_4

    return v1

    :cond_4
    return v5
.end method

.method public static gy()V
    .locals 3

    sget-object v0, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, -0x1

    sput v0, La/i;->pa:I

    sput v0, La/i;->pb:I

    const/4 v0, 0x0

    sput-object v0, La/i;->pc:La/al;

    sget-object v0, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    sget-object v0, La/i;->oW:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dd()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    sget-object v0, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_3

    sget-object v0, Lc/a;->TF:La/b;

    iget-boolean v0, v0, La/b;->nt:Z

    sget-object v0, La/i;->oW:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    invoke-static {}, La/i;->gF()V

    return-void

    :cond_0
    sget-object v0, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v2, 0x2

    if-ne v0, v2, :cond_1

    invoke-static {}, La/i;->gC()V

    return-void

    :cond_1
    sget-object v0, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    invoke-static {}, La/i;->gA()V

    return-void

    :cond_2
    invoke-static {}, La/i;->gz()V

    :cond_3
    return-void
.end method

.method public static gz()V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    sget-object v2, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/al;

    invoke-static {v2}, La/i;->c(La/al;)Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    sget-object v3, La/i;->oW:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v2, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_0

    new-instance v2, Lcomponents/bt;

    invoke-direct {v2}, Lcomponents/bt;-><init>()V

    invoke-virtual {v2}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object v3

    sget-object v4, La/i;->oX:Ljava/util/ArrayList;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Lcomponents/bt;->as(Z)V

    sget-object v3, La/i;->oY:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sput v1, La/i;->pa:I

    add-int/lit8 v1, v1, 0x1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-static {}, La/i;->gG()V

    return-void
.end method
