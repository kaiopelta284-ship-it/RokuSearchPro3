.class public La/ad;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private d:I

.field private mo:I

.field private of:I

.field private op:I

.field private qQ:La/al;

.field private xP:I

.field private xQ:I

.field private xR:I

.field private xS:I

.field private xT:I


# direct methods
.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/ad;->qQ:La/al;

    const/4 v0, 0x0

    iput v0, p0, La/ad;->xP:I

    iput v0, p0, La/ad;->of:I

    iput v0, p0, La/ad;->op:I

    iput v0, p0, La/ad;->d:I

    iput v0, p0, La/ad;->xQ:I

    iput v0, p0, La/ad;->xR:I

    iput v0, p0, La/ad;->xS:I

    const/4 v0, -0x1

    iput v0, p0, La/ad;->xT:I

    return-void
.end method

.method public constructor <init>(La/al;La/ac;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p2, 0x0

    iput-object p2, p0, La/ad;->qQ:La/al;

    const/4 p2, 0x0

    iput p2, p0, La/ad;->xP:I

    iput p2, p0, La/ad;->of:I

    iput p2, p0, La/ad;->op:I

    iput p2, p0, La/ad;->d:I

    iput p2, p0, La/ad;->xQ:I

    iput p2, p0, La/ad;->xR:I

    iput p2, p0, La/ad;->xS:I

    const/4 p2, -0x1

    iput p2, p0, La/ad;->xT:I

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->db()I

    move-result p2

    iput p2, p0, La/ad;->mo:I

    iput-object p1, p0, La/ad;->qQ:La/al;

    return-void
.end method


# virtual methods
.method public ce(I)V
    .locals 1

    iget v0, p0, La/ad;->xP:I

    add-int/2addr v0, p1

    iput v0, p0, La/ad;->xP:I

    return-void
.end method

.method public cf(I)V
    .locals 1

    iget v0, p0, La/ad;->xQ:I

    add-int/2addr v0, p1

    iput v0, p0, La/ad;->xQ:I

    return-void
.end method

.method public cg(I)V
    .locals 1

    iget v0, p0, La/ad;->xR:I

    add-int/2addr v0, p1

    iput v0, p0, La/ad;->xR:I

    return-void
.end method

.method public ch(I)V
    .locals 0

    iput p1, p0, La/ad;->xS:I

    return-void
.end method

.method public ci(I)V
    .locals 0

    iput p1, p0, La/ad;->xT:I

    return-void
.end method

.method public db()I
    .locals 1

    iget v0, p0, La/ad;->mo:I

    return v0
.end method

.method public fC()I
    .locals 1

    iget v0, p0, La/ad;->of:I

    return v0
.end method

.method public fD()V
    .locals 1

    iget v0, p0, La/ad;->of:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ad;->of:I

    return-void
.end method

.method public fE()I
    .locals 1

    iget v0, p0, La/ad;->op:I

    return v0
.end method

.method public fF()V
    .locals 1

    iget v0, p0, La/ad;->op:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ad;->op:I

    return-void
.end method

.method public fG()I
    .locals 1

    iget v0, p0, La/ad;->d:I

    return v0
.end method

.method public fH()V
    .locals 1

    iget v0, p0, La/ad;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ad;->d:I

    return-void
.end method

.method public jb()La/al;
    .locals 1

    iget-object v0, p0, La/ad;->qQ:La/al;

    return-object v0
.end method

.method public l(La/al;)V
    .locals 0

    iput-object p1, p0, La/ad;->qQ:La/al;

    return-void
.end method

.method public mJ()I
    .locals 1

    iget v0, p0, La/ad;->xP:I

    return v0
.end method

.method public mK()I
    .locals 1

    iget v0, p0, La/ad;->xQ:I

    return v0
.end method

.method public mL()I
    .locals 1

    iget v0, p0, La/ad;->xR:I

    return v0
.end method

.method public mM()I
    .locals 1

    iget v0, p0, La/ad;->xS:I

    return v0
.end method

.method public mN()I
    .locals 1

    iget v0, p0, La/ad;->xT:I

    return v0
.end method

.method public mO()Ljava/lang/String;
    .locals 10

    const-string v0, ""

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0053

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v2

    const v3, 0x7f0b01ab

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v3

    const v4, 0x7f0b0147

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x7

    new-array v4, v4, [Ljava/lang/String;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v6, 0x7f0b01f7

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    aput-object v5, v4, v6

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v6, 0x7f0b020b

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    aput-object v5, v4, v6

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v7, 0x7f0b0207

    invoke-virtual {v5, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x2

    aput-object v5, v4, v7

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v8, 0x7f0b0209

    invoke-virtual {v5, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x3

    aput-object v5, v4, v8

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v8, 0x7f0b0205

    invoke-virtual {v5, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    aput-object v5, v4, v8

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v8, 0x7f0b0203

    invoke-virtual {v5, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    aput-object v5, v4, v9

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    aput-object v5, v4, v8

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v8, 0x7f010002

    invoke-virtual {v5, v8}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v5

    iget v8, p0, La/ad;->xT:I

    if-ltz v8, :cond_2

    iget v5, p0, La/ad;->xT:I

    if-nez v5, :cond_1

    iget v3, p0, La/ad;->xS:I

    if-ne v3, v6, :cond_0

    return-object v1

    :cond_0
    iget v1, p0, La/ad;->xS:I

    if-ne v1, v7, :cond_6

    return-object v2

    :cond_1
    iget v1, p0, La/ad;->xT:I

    if-lt v1, v6, :cond_6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/ad;->xT:I

    aget-object v1, v4, v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_2
    invoke-virtual {p0}, La/ad;->mM()I

    move-result v3

    if-lez v3, :cond_6

    iget v0, p0, La/ad;->xS:I

    if-ne v0, v6, :cond_3

    return-object v1

    :cond_3
    iget v0, p0, La/ad;->xS:I

    if-ne v0, v7, :cond_4

    return-object v2

    :cond_4
    invoke-virtual {p0}, La/ad;->mM()I

    move-result v0

    array-length v1, v5

    if-ge v0, v1, :cond_5

    invoke-virtual {p0}, La/ad;->mM()I

    move-result v0

    aget-object v0, v5, v0

    return-object v0

    :cond_5
    const-string v0, ""

    :cond_6
    return-object v0
.end method
