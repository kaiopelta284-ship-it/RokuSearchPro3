.class final La/al$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/al;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcomponents/ba;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcomponents/ba;Lcomponents/ba;)I
    .locals 7

    invoke-virtual {p1}, Lcomponents/ba;->to()D

    move-result-wide v0

    invoke-virtual {p2}, Lcomponents/ba;->to()D

    move-result-wide v2

    invoke-virtual {p1}, Lcomponents/ba;->tm()D

    move-result-wide v4

    invoke-virtual {p2}, Lcomponents/ba;->tm()D

    move-result-wide p1

    cmpl-double v6, v0, v2

    if-eqz v6, :cond_0

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Double;->compare(DD)I

    move-result p1

    return p1

    :cond_0
    cmpl-double v0, v4, p1

    if-eqz v0, :cond_1

    invoke-static {p1, p2, v4, v5}, Ljava/lang/Double;->compare(DD)I

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcomponents/ba;

    check-cast p2, Lcomponents/ba;

    invoke-virtual {p0, p1, p2}, La/al$2;->a(Lcomponents/ba;Lcomponents/ba;)I

    move-result p1

    return p1
.end method
