.class public La/w;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private of:I

.field private rQ:I

.field private rR:I

.field private rS:I

.field private rT:I

.field private rU:I

.field private rV:I

.field private rW:I

.field private rX:I

.field private rY:I

.field private rZ:I

.field private sa:I

.field private sb:I

.field private sc:I

.field private sd:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, La/w;->rS:I

    iput v0, p0, La/w;->rT:I

    iput v0, p0, La/w;->rU:I

    iput v0, p0, La/w;->rV:I

    iput v0, p0, La/w;->of:I

    const/4 v0, -0x1

    iput v0, p0, La/w;->rW:I

    iput v0, p0, La/w;->sa:I

    return-void
.end method

.method public constructor <init>(IIIII)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, La/w;->rS:I

    iput v0, p0, La/w;->rT:I

    iput v0, p0, La/w;->rU:I

    iput v0, p0, La/w;->rV:I

    iput v0, p0, La/w;->of:I

    const/4 v0, -0x1

    iput v0, p0, La/w;->rW:I

    iput v0, p0, La/w;->sa:I

    iput p1, p0, La/w;->rQ:I

    iput p2, p0, La/w;->rR:I

    iput p3, p0, La/w;->rS:I

    iput p4, p0, La/w;->rT:I

    iget p1, p0, La/w;->of:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, La/w;->of:I

    if-eq p3, p4, :cond_1

    if-le p3, p4, :cond_0

    iget p1, p0, La/w;->rU:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, La/w;->rU:I

    iput p5, p0, La/w;->rW:I

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    iput p1, p0, La/w;->rX:I

    iput p3, p0, La/w;->rY:I

    iput p4, p0, La/w;->rZ:I

    goto :goto_0

    :cond_0
    iget p1, p0, La/w;->rV:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, La/w;->rV:I

    iput p5, p0, La/w;->sa:I

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    iput p1, p0, La/w;->sb:I

    iput p3, p0, La/w;->sc:I

    iput p4, p0, La/w;->sd:I

    :cond_1
    :goto_0
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->ex()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public a(La/ac;La/ac;III)V
    .locals 1

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    invoke-virtual {p0}, La/w;->ku()I

    move-result p2

    const/4 v0, 0x1

    if-ne p1, p2, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iget p2, p0, La/w;->of:I

    add-int/2addr p2, v0

    iput p2, p0, La/w;->of:I

    const/4 p2, 0x2

    if-eqz p1, :cond_2

    iget p1, p0, La/w;->rS:I

    add-int/2addr p1, p3

    iput p1, p0, La/w;->rS:I

    iget p1, p0, La/w;->rT:I

    add-int/2addr p1, p4

    iput p1, p0, La/w;->rT:I

    if-le p3, p4, :cond_1

    iget p1, p0, La/w;->rU:I

    add-int/2addr p1, v0

    iput p1, p0, La/w;->rU:I

    invoke-virtual {p0, v0, p3, p4, p5}, La/w;->d(IIII)V

    return-void

    :cond_1
    if-le p4, p3, :cond_4

    iget p1, p0, La/w;->rV:I

    add-int/2addr p1, v0

    iput p1, p0, La/w;->rV:I

    invoke-virtual {p0, p2, p4, p3, p5}, La/w;->d(IIII)V

    return-void

    :cond_2
    iget p1, p0, La/w;->rS:I

    add-int/2addr p1, p4

    iput p1, p0, La/w;->rS:I

    iget p1, p0, La/w;->rT:I

    add-int/2addr p1, p3

    iput p1, p0, La/w;->rT:I

    if-le p3, p4, :cond_3

    iget p1, p0, La/w;->rV:I

    add-int/2addr p1, v0

    iput p1, p0, La/w;->rV:I

    invoke-virtual {p0, p2, p3, p4, p5}, La/w;->d(IIII)V

    return-void

    :cond_3
    if-le p4, p3, :cond_4

    iget p1, p0, La/w;->rU:I

    add-int/2addr p1, v0

    iput p1, p0, La/w;->rU:I

    invoke-virtual {p0, v0, p4, p3, p5}, La/w;->d(IIII)V

    :cond_4
    return-void
.end method

.method public a(La/ac;La/ac;)Z
    .locals 3

    iget v0, p0, La/w;->rQ:I

    invoke-virtual {p1}, La/ac;->mE()I

    move-result v1

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    iget v0, p0, La/w;->rR:I

    invoke-virtual {p2}, La/ac;->mE()I

    move-result v1

    if-ne v0, v1, :cond_0

    return v2

    :cond_0
    iget v0, p0, La/w;->rR:I

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    if-ne v0, p1, :cond_1

    iget p1, p0, La/w;->rQ:I

    invoke-virtual {p2}, La/ac;->mE()I

    move-result p2

    if-ne p1, p2, :cond_1

    return v2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public ad(I)V
    .locals 0

    return-void
.end method

.method public bC(I)V
    .locals 0

    return-void
.end method

.method public bD(I)V
    .locals 0

    return-void
.end method

.method public bE(I)V
    .locals 0

    return-void
.end method

.method public bF(I)V
    .locals 0

    return-void
.end method

.method public bG(I)Ljava/lang/String;
    .locals 2

    iget v0, p0, La/w;->rU:I

    iget v1, p0, La/w;->rR:I

    if-ne p1, v1, :cond_0

    iget v0, p0, La/w;->rV:I

    :cond_0
    const-string p1, "vit?rias"

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    const-string p1, "vit?ria"

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bH(I)Ljava/lang/String;
    .locals 2

    iget v0, p0, La/w;->rS:I

    iget v1, p0, La/w;->rR:I

    if-ne p1, v1, :cond_0

    iget v0, p0, La/w;->rT:I

    :cond_0
    const-string p1, "gols"

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    const-string p1, "gol"

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bI(I)[Ljava/lang/String;
    .locals 1

    iget v0, p0, La/w;->rR:I

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, La/w;->kB()[Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    invoke-virtual {p0}, La/w;->kA()[Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bJ(I)Ljava/lang/String;
    .locals 4

    sget-object v0, La/ak;->BO:[Ljava/lang/String;

    iget v1, p0, La/w;->rW:I

    aget-object v0, v0, v1

    iget v1, p0, La/w;->rQ:I

    invoke-static {v1}, La/b;->aq(I)La/ac;

    move-result-object v1

    iget v2, p0, La/w;->rW:I

    const/4 v3, 0x2

    if-ne p1, v3, :cond_0

    iget p1, p0, La/w;->rR:I

    invoke-static {p1}, La/b;->aq(I)La/ac;

    move-result-object v1

    sget-object p1, La/ak;->BO:[Ljava/lang/String;

    iget v0, p0, La/w;->sa:I

    aget-object v0, p1, v0

    iget v2, p0, La/w;->sa:I

    :cond_0
    const/4 p1, 0x1

    if-ne v2, p1, :cond_1

    const-string v0, "Camp. Nacional"

    return-object v0

    :cond_1
    const/4 p1, 0x3

    if-ne v2, p1, :cond_2

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Camp. "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, La/ak;->Ar:[Ljava/lang/String;

    invoke-virtual {v1}, La/ac;->getEstado()I

    move-result v1

    aget-object v0, v0, v1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_2
    const/4 p1, 0x4

    if-eq v2, p1, :cond_3

    const/4 p1, 0x6

    if-eq v2, p1, :cond_3

    const/4 p1, 0x7

    if-eq v2, p1, :cond_3

    const/16 p1, 0x8

    if-ne v2, p1, :cond_4

    :cond_3
    invoke-virtual {v1}, La/ac;->iw()I

    move-result p1

    invoke-static {v2, p1}, La/ak;->X(II)Ljava/lang/String;

    move-result-object v0

    :cond_4
    return-object v0
.end method

.method public d(IIII)V
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ne p1, v0, :cond_2

    iget p1, p0, La/w;->rY:I

    iget v2, p0, La/w;->rZ:I

    sub-int/2addr p1, v2

    sub-int v2, p2, p3

    if-le v2, p1, :cond_0

    goto :goto_0

    :cond_0
    if-ne v2, p1, :cond_1

    iget p1, p0, La/w;->rY:I

    if-lt p2, p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_5

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    iput p1, p0, La/w;->rX:I

    iput p4, p0, La/w;->rW:I

    iput p2, p0, La/w;->rY:I

    iput p3, p0, La/w;->rZ:I

    return-void

    :cond_2
    const/4 v2, 0x2

    if-ne p1, v2, :cond_5

    iget p1, p0, La/w;->sc:I

    iget v2, p0, La/w;->rZ:I

    sub-int/2addr p1, v2

    sub-int v2, p2, p3

    if-le v2, p1, :cond_3

    goto :goto_1

    :cond_3
    if-ne v2, p1, :cond_4

    iget p1, p0, La/w;->sc:I

    if-lt p2, p1, :cond_4

    goto :goto_1

    :cond_4
    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_5

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    iput p1, p0, La/w;->sb:I

    iput p4, p0, La/w;->sa:I

    iput p2, p0, La/w;->sc:I

    iput p3, p0, La/w;->sd:I

    :cond_5
    return-void
.end method

.method public kA()[Ljava/lang/String;
    .locals 5

    const-string v0, ""

    const-string v1, ""

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    iget v1, p0, La/w;->rW:I

    if-ltz v1, :cond_0

    const/4 v1, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, La/w;->rX:I

    add-int/lit16 v3, v3, 0x7e0

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-virtual {p0, v3}, La/w;->bJ(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ": "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, p0, La/w;->rY:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "x"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, p0, La/w;->rZ:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, La/ak;->BO:[Ljava/lang/String;

    iget v4, p0, La/w;->rW:I

    aget-object v2, v2, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    :cond_0
    return-object v0
.end method

.method public kB()[Ljava/lang/String;
    .locals 5

    const-string v0, ""

    const-string v1, ""

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    iget v1, p0, La/w;->sa:I

    if-ltz v1, :cond_0

    const/4 v1, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, La/w;->sb:I

    add-int/lit16 v3, v3, 0x7e0

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    invoke-virtual {p0, v3}, La/w;->bJ(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, p0, La/w;->sc:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "x"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, p0, La/w;->sd:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, La/ak;->BO:[Ljava/lang/String;

    iget v4, p0, La/w;->sa:I

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    :cond_0
    return-object v0
.end method

.method public ks()Ljava/lang/String;
    .locals 1

    iget v0, p0, La/w;->rQ:I

    invoke-static {v0}, La/b;->ar(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public kt()Ljava/lang/String;
    .locals 1

    iget v0, p0, La/w;->rR:I

    invoke-static {v0}, La/b;->ar(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ku()I
    .locals 1

    iget v0, p0, La/w;->rQ:I

    return v0
.end method

.method public kv()I
    .locals 1

    iget v0, p0, La/w;->rR:I

    return v0
.end method

.method public kw()I
    .locals 1

    iget v0, p0, La/w;->rS:I

    return v0
.end method

.method public kx()I
    .locals 1

    iget v0, p0, La/w;->rT:I

    return v0
.end method

.method public ky()Ljava/lang/String;
    .locals 3

    const-string v0, "jogos"

    iget v1, p0, La/w;->of:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    const-string v0, "jogo"

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, La/w;->of:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public kz()Ljava/lang/String;
    .locals 3

    iget v0, p0, La/w;->of:I

    iget v1, p0, La/w;->rU:I

    iget v2, p0, La/w;->rV:I

    add-int/2addr v1, v2

    sub-int/2addr v0, v1

    const-string v1, "empates"

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    const-string v1, "empate"

    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public u(La/ac;)La/ac;
    .locals 2

    iget v0, p0, La/w;->rQ:I

    invoke-virtual {p1}, La/ac;->mE()I

    move-result v1

    if-ne v0, v1, :cond_0

    sget-object p1, Lc/a;->TF:La/b;

    iget p1, p0, La/w;->rR:I

    :goto_0
    invoke-static {p1}, La/b;->aq(I)La/ac;

    move-result-object p1

    return-object p1

    :cond_0
    iget v0, p0, La/w;->rR:I

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    if-ne v0, p1, :cond_1

    sget-object p1, Lc/a;->TF:La/b;

    iget p1, p0, La/w;->rQ:I

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method
