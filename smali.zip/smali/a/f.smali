.class public La/f;
.super Ljava/lang/Object;


# static fields
.field private static oJ:La/ac;

.field private static oK:I

.field private static oL:I

.field private static oM:Z


# instance fields
.field private oA:La/ac;

.field private oB:La/ac;

.field private oC:I

.field private oD:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field

.field private oE:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field

.field private oF:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field

.field private oG:I

.field private oH:Z

.field private oI:I

.field private ox:La/p;

.field private oy:I

.field private oz:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(La/p;IZZI)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p4, 0x0

    iput-object p4, p0, La/f;->ox:La/p;

    const/4 v0, 0x0

    iput v0, p0, La/f;->oy:I

    iput-boolean v0, p0, La/f;->oz:Z

    iput-object p4, p0, La/f;->oA:La/ac;

    iput-object p4, p0, La/f;->oB:La/ac;

    iput v0, p0, La/f;->oC:I

    new-instance p4, Ljava/util/ArrayList;

    invoke-direct {p4}, Ljava/util/ArrayList;-><init>()V

    iput-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    new-instance p4, Ljava/util/ArrayList;

    invoke-direct {p4}, Ljava/util/ArrayList;-><init>()V

    iput-object p4, p0, La/f;->oE:Ljava/util/ArrayList;

    new-instance p4, Ljava/util/ArrayList;

    invoke-direct {p4}, Ljava/util/ArrayList;-><init>()V

    iput-object p4, p0, La/f;->oF:Ljava/util/ArrayList;

    const/4 p4, -0x1

    iput p4, p0, La/f;->oG:I

    iput-boolean v0, p0, La/f;->oH:Z

    iput v0, p0, La/f;->oI:I

    iput p5, p0, La/f;->oI:I

    iput-object p1, p0, La/f;->ox:La/p;

    iput p2, p0, La/f;->oy:I

    iput-boolean p3, p0, La/f;->oz:Z

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object p2

    iput-object p2, p0, La/f;->oA:La/ac;

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result p1

    iget-object p2, p0, La/f;->oA:La/ac;

    if-eqz p2, :cond_0

    iget-object p2, p0, La/f;->oA:La/ac;

    invoke-virtual {p2}, La/ac;->iw()I

    move-result p2

    iput p2, p0, La/f;->oG:I

    :cond_0
    const/16 p2, 0xa

    const/16 p3, 0x64

    const/16 p4, 0x32

    const/16 v1, 0x1d

    const/4 v2, 0x1

    if-nez p5, :cond_b

    iget-object p5, p0, La/f;->oA:La/ac;

    if-eqz p5, :cond_1

    iget-object p5, p0, La/f;->oA:La/ac;

    invoke-virtual {p5}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object p5

    invoke-virtual {p5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p5

    if-eqz p5, :cond_1

    iget-object p5, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3, p1}, La/b;->ah(I)La/y;

    move-result-object p1

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    iget-object p1, p0, La/f;->oA:La/ac;

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result p1

    if-ne p1, v1, :cond_2

    iget-object p1, p0, La/f;->ox:La/p;

    invoke-virtual {p1}, La/p;->hG()I

    move-result p1

    if-le p1, p4, :cond_2

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    invoke-virtual {p1, p3}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    if-le p1, p2, :cond_2

    const/4 p1, 0x1

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    :goto_0
    iget-object p2, p0, La/f;->ox:La/p;

    invoke-virtual {p2}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-nez p2, :cond_3

    iget-object p2, p0, La/f;->ox:La/p;

    invoke-virtual {p2}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_4

    :cond_3
    const/4 p1, 0x1

    :cond_4
    iget p2, p0, La/f;->oG:I

    if-eqz p2, :cond_5

    if-eqz p1, :cond_7

    :cond_5
    const/4 p1, 0x0

    :goto_1
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge p1, p2, :cond_7

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/y;

    invoke-virtual {p2}, La/y;->iw()I

    move-result p2

    if-nez p2, :cond_6

    iget-object p2, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_6

    iget-object p2, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_7
    const/4 p1, 0x0

    :goto_2
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge p1, p2, :cond_9

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/y;

    invoke-virtual {p2}, La/y;->iw()I

    move-result p2

    if-nez p2, :cond_8

    iget-object p2, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_8

    iget-object p2, p0, La/f;->oE:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    :cond_9
    :goto_3
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_28

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    invoke-virtual {p1}, La/y;->iw()I

    move-result p1

    if-nez p1, :cond_a

    iget-object p1, p0, La/f;->oF:Ljava/util/ArrayList;

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_b
    const/4 v3, 0x2

    if-ne p5, v2, :cond_26

    iget-object p5, p0, La/f;->oA:La/ac;

    if-eqz p5, :cond_c

    iget-object p5, p0, La/f;->oA:La/ac;

    invoke-virtual {p5}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object p5

    invoke-virtual {p5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p5

    if-eqz p5, :cond_c

    iget-object p5, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4, p1}, La/b;->ah(I)La/y;

    move-result-object p1

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_c
    iget-object p1, p0, La/f;->oA:La/ac;

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result p1

    if-ne p1, v1, :cond_d

    iget-object p1, p0, La/f;->ox:La/p;

    invoke-virtual {p1}, La/p;->hG()I

    move-result p1

    if-le p1, p4, :cond_d

    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    invoke-virtual {p1, p3}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    if-le p1, p2, :cond_d

    const/4 p1, 0x1

    goto :goto_4

    :cond_d
    const/4 p1, 0x0

    :goto_4
    iget-object p2, p0, La/f;->ox:La/p;

    invoke-virtual {p2}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-nez p2, :cond_e

    iget-object p2, p0, La/f;->ox:La/p;

    invoke-virtual {p2}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_f

    :cond_e
    const/4 p1, 0x1

    :cond_f
    iget p2, p0, La/f;->oG:I

    if-eqz p2, :cond_10

    if-eqz p1, :cond_12

    :cond_10
    const/4 p1, 0x0

    :goto_5
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge p1, p2, :cond_12

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/y;

    invoke-virtual {p2}, La/y;->iw()I

    move-result p2

    if-nez p2, :cond_11

    iget-object p2, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_11

    iget-object p2, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_11
    add-int/lit8 p1, p1, 0x1

    goto :goto_5

    :cond_12
    iget p1, p0, La/f;->oG:I

    const/4 p2, 0x5

    if-ne p1, v2, :cond_14

    const/4 p1, 0x0

    :goto_6
    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-ge p1, p3, :cond_14

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/y;

    invoke-virtual {p3}, La/y;->iw()I

    move-result p3

    if-eq p3, p2, :cond_13

    iget-object p3, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_13

    iget-object p3, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_13
    add-int/lit8 p1, p1, 0x1

    goto :goto_6

    :cond_14
    iget p1, p0, La/f;->oG:I

    const/4 p3, 0x3

    if-ne p1, v3, :cond_17

    const/4 p1, 0x0

    :goto_7
    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result p4

    if-ge p1, p4, :cond_17

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-eqz p4, :cond_15

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-ne p4, p3, :cond_16

    :cond_15
    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p4

    if-nez p4, :cond_16

    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_16
    add-int/lit8 p1, p1, 0x1

    goto :goto_7

    :cond_17
    iget p1, p0, La/f;->oG:I

    if-ne p1, p3, :cond_1a

    const/4 p1, 0x0

    :goto_8
    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result p4

    if-ge p1, p4, :cond_1a

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-eq p4, p3, :cond_18

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-nez p4, :cond_19

    :cond_18
    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p4

    if-nez p4, :cond_19

    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_19
    add-int/lit8 p1, p1, 0x1

    goto :goto_8

    :cond_1a
    iget-object p1, p0, La/f;->oA:La/ac;

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result p1

    const/16 p4, 0x83

    if-eq p1, p4, :cond_1d

    iget-object p1, p0, La/f;->oA:La/ac;

    invoke-virtual {p1}, La/ac;->getPais()I

    move-result p1

    const/16 p4, 0x44

    if-ne p1, p4, :cond_1b

    goto :goto_a

    :cond_1b
    iget p1, p0, La/f;->oG:I

    const/4 p4, 0x4

    if-ne p1, p4, :cond_1f

    const/4 p1, 0x0

    :goto_9
    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result p5

    if-ge p1, p5, :cond_1f

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    check-cast p5, La/y;

    invoke-virtual {p5}, La/y;->iw()I

    move-result p5

    if-ne p5, p4, :cond_1c

    iget-object p5, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p5, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p5

    if-nez p5, :cond_1c

    iget-object p5, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1c
    add-int/lit8 p1, p1, 0x1

    goto :goto_9

    :cond_1d
    :goto_a
    const/4 p1, 0x0

    :goto_b
    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result p4

    if-ge p1, p4, :cond_1f

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-nez p4, :cond_1e

    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p4

    if-nez p4, :cond_1e

    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1e
    add-int/lit8 p1, p1, 0x1

    goto :goto_b

    :cond_1f
    iget p1, p0, La/f;->oG:I

    if-ne p1, p2, :cond_22

    const/4 p1, 0x0

    :goto_c
    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result p4

    if-ge p1, p4, :cond_22

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-eq p4, p2, :cond_20

    sget-object p4, Lc/a;->TF:La/b;

    invoke-virtual {p4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p4

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/y;

    invoke-virtual {p4}, La/y;->iw()I

    move-result p4

    if-ne p4, p3, :cond_21

    :cond_20
    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p4

    if-nez p4, :cond_21

    iget-object p4, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p5, Lc/a;->TF:La/b;

    invoke-virtual {p5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p5

    invoke-virtual {p5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_21
    add-int/lit8 p1, p1, 0x1

    goto :goto_c

    :cond_22
    const/4 p1, 0x0

    :goto_d
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-ge p1, p2, :cond_24

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/y;

    invoke-virtual {p2}, La/y;->iw()I

    move-result p2

    if-nez p2, :cond_23

    iget-object p2, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_23

    iget-object p2, p0, La/f;->oE:Ljava/util/ArrayList;

    sget-object p3, Lc/a;->TF:La/b;

    invoke-virtual {p3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_23
    add-int/lit8 p1, p1, 0x1

    goto :goto_d

    :cond_24
    :goto_e
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_28

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    invoke-virtual {p1}, La/y;->iw()I

    move-result p1

    if-nez p1, :cond_25

    iget-object p1, p0, La/f;->oF:Ljava/util/ArrayList;

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_25
    add-int/lit8 v0, v0, 0x1

    goto :goto_e

    :cond_26
    if-ne p5, v3, :cond_28

    :goto_f
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_28

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    invoke-virtual {p1}, La/y;->iw()I

    move-result p1

    if-nez p1, :cond_27

    iget-object p1, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_27

    iget-object p1, p0, La/f;->oD:Ljava/util/ArrayList;

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_27
    add-int/lit8 v0, v0, 0x1

    goto :goto_f

    :cond_28
    invoke-direct {p0}, La/f;->brMkt()V

    return-void
.end method

.method public static a(La/p;La/ac;)I
    .locals 3

    const/4 v0, 0x0

    if-eqz p0, :cond_a

    if-nez p1, :cond_0

    return v0

    :cond_0
    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->isOnLoan(La/p;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 p0, 0x5

    return p0

    :cond_1
    invoke-virtual {p0}, La/p;->getPendSaleClub()La/ac;

    move-result-object v1

    if-eqz v1, :cond_2

    const/4 p0, 0x5

    return p0

    :cond_2
    invoke-virtual {p0}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_3

    const/4 p0, 0x5

    return p0

    :cond_3
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    if-ne p1, v1, :cond_4

    const/4 p0, 0x2

    return p0

    :cond_4
    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_5

    const/4 p0, 0x6

    return p0

    :cond_5
    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_7

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-eqz v2, :cond_6

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-ne v2, p1, :cond_6

    add-int/lit8 v1, v1, 0x1

    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_7
    const/4 v0, 0x3

    if-lt v1, v0, :cond_8

    return v0

    :cond_8
    invoke-static {p0, p1}, La/f;->d(La/p;La/ac;)Z

    move-result v0

    if-nez v0, :cond_9

    const/4 p0, 0x4

    return p0

    :cond_9
    invoke-virtual {p0, p1}, La/p;->l(La/ac;)V

    const/4 p0, 0x1

    return p0

    :cond_a
    return v0
.end method

.method public static a(La/p;La/ac;I)I
    .locals 10

    const/4 v0, 0x0

    sput-boolean v0, La/f;->oM:Z

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v1

    sput-object v1, La/f;->oJ:La/ac;

    sput v0, La/f;->oK:I

    sget-object v1, La/f;->oJ:La/ac;

    invoke-virtual {v1, v0}, La/ac;->T(Z)[I

    move-result-object v1

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x6

    new-array v4, v3, [D

    fill-array-data v4, :array_1

    new-array v5, v3, [D

    fill-array-data v5, :array_2

    new-array v6, v3, [D

    fill-array-data v6, :array_3

    new-array v7, v3, [I

    fill-array-data v7, :array_4

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v8

    aget v8, v1, v8

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v9

    aget v2, v2, v9

    const/4 v9, 0x1

    if-lt v8, v2, :cond_2

    invoke-virtual {p0}, La/p;->hG()I

    move-result v1

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_1

    invoke-virtual {p0}, La/p;->getIdade()I

    move-result v1

    const/16 v2, 0x23

    if-le v1, v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/p;->hI()I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v4

    aget-wide v4, v6, v4

    goto :goto_2

    :cond_1
    :goto_0
    invoke-virtual {p0}, La/p;->hI()I

    move-result v1

    invoke-virtual {p0}, La/p;->hI()I

    move-result v2

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v4

    aget v4, v7, v4

    mul-int v2, v2, v4

    div-int/lit8 v2, v2, 0x64

    int-to-float v2, v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    sub-int v2, v1, v2

    goto :goto_3

    :cond_2
    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v2

    aget v1, v1, v2

    if-ne v1, v9, :cond_3

    invoke-virtual {p0}, La/p;->hI()I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v5

    aget-wide v5, v4, v5

    mul-double v1, v1, v5

    :goto_1
    invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J

    move-result-wide v1

    long-to-int v1, v1

    invoke-virtual {p0}, La/p;->hI()I

    move-result v2

    add-int/2addr v2, v1

    goto :goto_3

    :cond_3
    invoke-virtual {p0}, La/p;->hI()I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v4

    aget-wide v4, v5, v4

    :goto_2
    mul-double v1, v1, v4

    goto :goto_1

    :goto_3
    const/4 v1, 0x2

    if-lt p2, v2, :cond_6

    invoke-static {p0, p1}, La/f;->c(La/p;La/ac;)I

    move-result p0

    if-ne p0, v9, :cond_4

    const/4 p0, 0x4

    return p0

    :cond_4
    if-ne p0, v1, :cond_5

    return v3

    :cond_5
    return v9

    :cond_6
    invoke-virtual {p1}, La/ac;->lA()J

    move-result-wide v3

    int-to-long v5, v2

    cmp-long p2, v3, v5

    if-ltz p2, :cond_8

    invoke-static {p0, p1}, La/f;->c(La/p;La/ac;)I

    move-result p0

    if-eqz p0, :cond_7

    if-ne p0, v1, :cond_8

    :cond_7
    sput v2, La/f;->oL:I

    const/4 p0, 0x7

    return p0

    :cond_8
    return v0

    nop

    :array_0
    .array-data 4
        0x3
        0x4
        0x4
        0x5
        0x4
    .end array-data

    :array_1
    .array-data 8
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x4000000000000000L    # 2.0
        0x3ff0000000000000L    # 1.0
    .end array-data

    :array_2
    .array-data 8
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff8000000000000L    # 1.5
        0x4000000000000000L    # 2.0
    .end array-data

    :array_3
    .array-data 8
        0x3fe0000000000000L    # 0.5
        0x3fc999999999999aL    # 0.2
        0x3fc999999999999aL    # 0.2
        0x3fc999999999999aL    # 0.2
        0x3fe0000000000000L    # 0.5
        0x3ff0000000000000L    # 1.0
    .end array-data

    :array_4
    .array-data 4
        0xf
        0x14
        0x14
        0xa
        0xa
        0x2
    .end array-data
.end method

.method private a(Ljava/util/ArrayList;Z)La/ac;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;Z)",
            "La/ac;"
        }
    .end annotation

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->getDivisao()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    iget-object v2, p0, La/f;->oA:La/ac;

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v2

    add-int/2addr v2, v1

    const/4 v3, 0x6

    new-array v3, v3, [I

    fill-array-data v3, :array_0

    iget-object v3, p0, La/f;->oA:La/ac;

    invoke-virtual {v3}, La/ac;->getDivisao()I

    move-result v3

    if-ne v3, v1, :cond_0

    const/4 v0, 0x1

    :cond_0
    iget v3, p0, La/f;->oI:I

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-ne v3, v1, :cond_2

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->iw()I

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-lt v0, v4, :cond_1

    iget-object v0, p0, La/f;->ox:La/p;

    invoke-virtual {v0}, La/p;->hG()I

    move-result v0

    const/16 v2, 0x28

    if-lt v0, v2, :cond_1

    const/4 v0, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x1

    const/4 v2, 0x2

    :cond_2
    :goto_0
    const/4 v3, 0x0

    move v6, v2

    move v2, v0

    const/4 v0, 0x0

    :goto_1
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v0, v7, :cond_a

    iget-object v7, p0, La/f;->ox:La/p;

    invoke-virtual {v7}, La/p;->hG()I

    move-result v7

    const/4 v8, 0x5

    const/16 v9, 0x14

    if-gt v7, v8, :cond_3

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->lb()I

    move-result v2

    move v6, v2

    const/4 v2, 0x0

    goto :goto_2

    :cond_3
    iget-object v7, p0, La/f;->ox:La/p;

    invoke-virtual {v7}, La/p;->hG()I

    move-result v7

    if-gt v7, v9, :cond_4

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->lb()I

    move-result v6

    :cond_4
    :goto_2
    iget-object v7, p0, La/f;->ox:La/p;

    invoke-virtual {v7}, La/p;->hG()I

    move-result v7

    if-gt v7, v9, :cond_5

    const/4 v2, 0x0

    :cond_5
    iget v7, p0, La/f;->oI:I

    const/16 v8, 0x1e

    if-nez v7, :cond_7

    const/4 v7, 0x0

    :goto_3
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v7, v9, :cond_9

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->getDivisao()I

    move-result v9

    if-gt v9, v6, :cond_6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->getDivisao()I

    move-result v9

    if-lt v9, v2, :cond_6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    iget-object v10, p0, La/f;->oA:La/ac;

    if-eq v9, v10, :cond_6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-nez v9, :cond_6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v9, v8, :cond_6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9, v1}, La/ac;->T(Z)[I

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {p2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_3

    :cond_7
    const/4 v7, 0x0

    :goto_4
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v7, v9, :cond_9

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->getDivisao()I

    move-result v9

    if-gt v9, v6, :cond_8

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->getDivisao()I

    move-result v9

    if-lt v9, v2, :cond_8

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    iget-object v10, p0, La/f;->oA:La/ac;

    if-eq v9, v10, :cond_8

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-nez v9, :cond_8

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v9, v8, :cond_8

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    invoke-virtual {v9, v1}, La/ac;->T(Z)[I

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/y;

    invoke-virtual {v9}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {p2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_4

    :cond_9
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_1

    :cond_a
    invoke-static {p2}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 p1, 0x0

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    xor-int/2addr v0, v1

    iget v2, p0, La/f;->oI:I

    if-ne v2, v1, :cond_c

    :goto_5
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v3, v1, :cond_10

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    iget-object v2, p0, La/f;->ox:La/p;

    invoke-virtual {v1, v2, v0}, La/ac;->b(La/p;Z)Z

    move-result v1

    if-eqz v1, :cond_b

    goto :goto_8

    :cond_b
    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    :cond_c
    iget v1, p0, La/f;->oI:I

    if-ne v1, v5, :cond_e

    :goto_6
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_10

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->mC()Z

    move-result v0

    if-nez v0, :cond_d

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-lt v0, v4, :cond_d

    goto :goto_8

    :cond_d
    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_e
    :goto_7
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v3, v1, :cond_10

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    iget-object v2, p0, La/f;->ox:La/p;

    invoke-virtual {v1, v2, v0}, La/ac;->a(La/p;Z)Z

    move-result v1

    if-eqz v1, :cond_f

    :goto_8
    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/ac;

    goto :goto_9

    :cond_f
    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_10
    :goto_9
    iget p2, p0, La/f;->oy:I

    invoke-direct {p0, p1, p2}, La/f;->b(La/ac;I)V

    return-object p1

    :array_0
    .array-data 4
        0x4
        0x5
        0x5
        0xa
        0x6
        0x5
    .end array-data
.end method

.method public static a(Ljava/util/ArrayList;[I)La/p;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;[I)",
            "La/p;"
        }
    .end annotation

    const/4 v0, 0x1

    aget v1, p1, v0

    const/4 v2, 0x5

    sub-int/2addr v1, v2

    aget v0, p1, v0

    add-int/2addr v0, v2

    const/4 v3, 0x0

    aget p1, p1, v3

    const/4 v4, 0x6

    new-array v4, v4, [I

    fill-array-data v4, :array_0

    if-ge v1, v2, :cond_0

    const/4 v1, 0x5

    :cond_0
    const/16 v2, 0x64

    if-le v0, v2, :cond_1

    const/16 v0, 0x64

    :cond_1
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    :goto_0
    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v5, v7, :cond_6

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-static {v2}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    move-object v7, v6

    const/4 v6, 0x0

    const/4 v8, 0x0

    :goto_1
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v6, v9, :cond_4

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->getPosicao()I

    move-result v9

    if-ne v9, p1, :cond_2

    add-int/lit8 v8, v8, 0x1

    :cond_2
    if-nez v7, :cond_3

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->getPosicao()I

    move-result v9

    if-ne v9, p1, :cond_3

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->hG()I

    move-result v9

    if-lt v9, v1, :cond_3

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->hG()I

    move-result v9

    if-gt v9, v0, :cond_3

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-nez v9, :cond_3

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-nez v9, :cond_3

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    :cond_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_4
    if-eqz v7, :cond_5

    aget v6, v4, p1

    if-lt v8, v6, :cond_5

    move-object v6, v7

    return-object v6

    :cond_5
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_0

    :cond_6
    return-object v6

    nop

    :array_0
    .array-data 4
        0x3
        0x4
        0x4
        0x6
        0x4
        0x3
    .end array-data
.end method

.method public static a(La/ac;La/p;)V
    .locals 7

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La/ac;->T(Z)[I

    move-result-object v1

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x4

    if-gt v3, v4, :cond_1

    aget v4, v1, v3

    aget v5, v2, v3

    if-ge v4, v5, :cond_0

    const/4 v4, 0x2

    new-array v4, v4, [I

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v5

    aput v5, v4, v0

    invoke-virtual {p1}, La/p;->hG()I

    move-result v5

    const/4 v6, 0x1

    aput v5, v4, v6

    invoke-static {p0, v4}, La/f;->a(La/ac;[I)V

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return-void

    :array_0
    .array-data 4
        0x2
        0x3
        0x3
        0x5
        0x3
        0x2
    .end array-data
.end method

.method public static a(La/ac;[I)V
    .locals 8

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result v1

    add-int/lit8 v2, v1, -0x2

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x0

    if-gez v2, :cond_0

    const/4 v2, 0x0

    :cond_0
    const/4 v4, 0x0

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_4

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/ac;->getPais()I

    move-result v7

    invoke-virtual {v1, v7}, La/b;->ah(I)La/y;

    move-result-object v1

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    :goto_0
    invoke-virtual {v1}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_2

    invoke-virtual {v1}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-nez v7, :cond_1

    invoke-virtual {v1}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    if-eq v7, p0, :cond_1

    invoke-virtual {v1}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->getReputacao()I

    move-result v7

    if-gt v2, v7, :cond_1

    invoke-virtual {v1}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ac;

    invoke-virtual {v7}, La/ac;->getReputacao()I

    move-result v7

    if-lt v3, v7, :cond_1

    invoke-virtual {v1}, La/y;->kP()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    invoke-static {v5}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    invoke-static {v5, p1}, La/f;->a(Ljava/util/ArrayList;[I)La/p;

    move-result-object v1

    goto/16 :goto_2

    :cond_3
    move-object v1, v4

    goto/16 :goto_2

    :cond_4
    add-int/lit8 v1, v1, -0x1

    if-gez v1, :cond_5

    const/4 v1, 0x0

    :cond_5
    const/4 v2, 0x0

    :goto_1
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_6

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-eq v4, p0, :cond_6

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->iw()I

    move-result v4

    invoke-virtual {p0}, La/ac;->iw()I

    move-result v7

    if-ne v4, v7, :cond_6

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->getReputacao()I

    move-result v4

    if-gt v1, v4, :cond_6

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->getReputacao()I

    move-result v4

    if-lt v3, v4, :cond_6

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :goto_2
    if-eqz v1, :cond_7

    invoke-virtual {v1}, La/p;->hI()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, v1

    move-object v1, p0

    invoke-virtual/range {v0 .. v5}, La/p;->a(La/ac;IZZZ)V

    return-void

    :cond_7
    aget v1, p1, v6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    move-object v0, p0

    invoke-static/range {v0 .. v5}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    move-result-object v0

    if-eqz v0, :cond_8

    invoke-static {v6, v0, p0}, La/u;->a(ZLa/q;La/ac;)V

    :cond_8
    return-void
.end method

.method public static b(La/p;La/ac;)I
    .locals 6

    const/4 v0, 0x0

    sput-boolean v0, La/f;->oM:Z

    if-eqz p0, :cond_5

    if-eqz p1, :cond_5

    invoke-virtual {p0}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    if-ne p1, v0, :cond_1

    const/4 p0, 0x2

    return p0

    :cond_1
    invoke-virtual {p1}, La/ac;->lA()J

    move-result-wide v0

    invoke-virtual {p0}, La/p;->hJ()I

    move-result v2

    int-to-long v2, v2

    cmp-long v4, v0, v2

    if-gez v4, :cond_2

    const/4 p0, 0x5

    return p0

    :cond_2
    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_3

    const/4 p0, 0x3

    return p0

    :cond_3
    invoke-static {p0, p1}, La/f;->d(La/p;La/ac;)Z

    move-result v0

    if-nez v0, :cond_4

    const/4 p0, 0x4

    return p0

    :cond_4
    invoke-virtual {p0}, La/p;->hJ()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, La/p;->a(La/ac;IZZZ)V

    const/4 p0, 0x1

    sput-boolean p0, La/f;->oM:Z

    return p0

    :cond_5
    return v0
.end method

.method private b(La/ac;I)V
    .locals 0

    iput-object p1, p0, La/f;->oB:La/ac;

    iput p2, p0, La/f;->oC:I

    return-void
.end method

.method private brMkt()V
    .locals 10

    iget-object v0, p0, La/f;->ox:La/p;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, La/p;->getPais()I

    move-result v0

    invoke-static {v0}, La/f;->isSA(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v1, 0x3c

    goto :goto_0

    :cond_0
    const/16 v1, 0xc

    :goto_0
    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    sget-object v3, Lc/a;->TF:La/b;

    if-eqz v3, :cond_2

    iget-object v4, p0, La/f;->oD:Ljava/util/ArrayList;

    if-eqz v4, :cond_2

    new-instance v5, Ljava/util/Random;

    invoke-direct {v5}, Ljava/util/Random;-><init>()V

    const/4 v6, 0x0

    :goto_1
    array-length v7, v2

    if-ge v6, v7, :cond_2

    aget v7, v2, v6

    if-eq v0, v7, :cond_1

    const/16 v8, 0x64

    invoke-virtual {v5, v8}, Ljava/util/Random;->nextInt(I)I

    move-result v8

    if-ge v8, v1, :cond_1

    invoke-virtual {v3, v7}, La/b;->ah(I)La/y;

    move-result-object v9

    if-eqz v9, :cond_1

    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_1

    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_2
    return-void

    nop

    :array_0
    .array-data 4
        0x1d
        0xb
        0x2e
        0x3c
        0x96
        0xc3
    .end array-data
.end method

.method public static c(La/p;La/ac;)I
    .locals 6

    invoke-virtual {p1}, La/ac;->iw()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, La/p;->ix()I

    move-result v0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez v0, :cond_4

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    const/4 v5, 0x4

    if-lt v0, v5, :cond_4

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    if-ge v0, v5, :cond_3

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v0

    if-ne v0, v3, :cond_1

    return v1

    :cond_1
    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    if-ge v0, v4, :cond_2

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result p1

    if-ne p1, v3, :cond_8

    :cond_2
    invoke-virtual {p0}, La/p;->hH()I

    move-result p0

    mul-int/lit8 p0, p0, 0x2

    sput p0, La/f;->oK:I

    return v2

    :cond_3
    return v1

    :cond_4
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-lt v0, v4, :cond_5

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    if-lt v0, v4, :cond_5

    return v1

    :cond_5
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-ne v0, v4, :cond_6

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    if-ne v0, v2, :cond_6

    return v1

    :cond_6
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-ne v0, v4, :cond_7

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result p1

    if-ne p1, v3, :cond_7

    return v1

    :cond_7
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object p0

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result p0

    if-gt p0, v2, :cond_8

    return v1

    :cond_8
    return v3
.end method

.method public static d(La/p;La/ac;)Z
    .locals 4

    invoke-virtual {p1}, La/ac;->iw()I

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, La/p;->ix()I

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    const/4 v2, 0x4

    if-lt v0, v2, :cond_2

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result p0

    if-ge p0, v2, :cond_1

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result p0

    if-ne p0, v1, :cond_6

    :cond_1
    return v1

    :cond_2
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    const/4 v2, 0x3

    if-lt v0, v2, :cond_3

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    if-lt v0, v2, :cond_3

    return v1

    :cond_3
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    const/4 v3, 0x2

    if-ne v0, v2, :cond_4

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    if-ne v0, v3, :cond_4

    return v1

    :cond_4
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-ne v0, v2, :cond_5

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result p1

    if-ne p1, v1, :cond_5

    return v1

    :cond_5
    invoke-virtual {p0}, La/p;->hE()La/ac;

    move-result-object p0

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result p0

    if-gt p0, v3, :cond_6

    return v1

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method private fX()La/ac;
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v4, 0x1e

    if-ge v3, v4, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    iget-object v2, p0, La/f;->oA:La/ac;

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    xor-int/lit8 v2, v2, 0x1

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    iget-object v4, p0, La/f;->ox:La/p;

    invoke-virtual {v3, v4, v2}, La/ac;->a(La/p;Z)Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    iget v1, p0, La/f;->oy:I

    invoke-direct {p0, v0, v1}, La/f;->b(La/ac;I)V

    return-object v2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    const/4 v2, 0x0

    return-object v2
.end method

.method public static ga()I
    .locals 1

    sget v0, La/f;->oK:I

    return v0
.end method

.method public static gb()I
    .locals 1

    sget v0, La/f;->oL:I

    return v0
.end method

.method public static gc()Z
    .locals 1

    sget-boolean v0, La/f;->oM:Z

    return v0
.end method

.method private static isSA(I)Z
    .locals 1

    const/16 v0, 0xb

    if-eq p0, v0, :cond_0

    const/16 v0, 0x1a

    if-eq p0, v0, :cond_0

    const/16 v0, 0x2a

    if-eq p0, v0, :cond_0

    const/16 v0, 0x2e

    if-eq p0, v0, :cond_0

    const/16 v0, 0x3c

    if-eq p0, v0, :cond_0

    const/16 v0, 0x96

    if-eq p0, v0, :cond_0

    const/16 v0, 0x97

    if-eq p0, v0, :cond_0

    const/16 v0, 0xc3

    if-eq p0, v0, :cond_0

    const/16 v0, 0xc6

    if-eq p0, v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    const/4 v0, 0x1

    return v0
.end method

.method private w(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;)V"
        }
    .end annotation

    return-void
.end method

.method public static z(Z)V
    .locals 0

    sput-boolean p0, La/f;->oM:Z

    return-void
.end method


# virtual methods
.method public A(Z)V
    .locals 0

    iput-boolean p1, p0, La/f;->oH:Z

    return-void
.end method

.method public az(I)V
    .locals 0

    iput p1, p0, La/f;->oC:I

    return-void
.end method

.method public e(La/ac;)V
    .locals 0

    iput-object p1, p0, La/f;->oB:La/ac;

    return-void
.end method

.method public fY()La/ac;
    .locals 1

    iget-object v0, p0, La/f;->oB:La/ac;

    return-object v0
.end method

.method public fZ()I
    .locals 1

    iget v0, p0, La/f;->oC:I

    return v0
.end method

.method public gd()Z
    .locals 1

    iget-boolean v0, p0, La/f;->oH:Z

    return v0
.end method

.method public x(Z)La/ac;
    .locals 3

    iget-object v0, p0, La/f;->ox:La/p;

    invoke-virtual {v0}, La/p;->hG()I

    move-result v0

    const/4 v1, 0x0

    const/16 v2, 0x1e

    if-le v0, v2, :cond_0

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v2, 0x64

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/16 v2, 0x3c

    if-le v0, v2, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    iget-object v2, p0, La/f;->ox:La/p;

    invoke-virtual {v2}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v2, p0, La/f;->oA:La/ac;

    invoke-virtual {v2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v0, 0x0

    :cond_1
    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_3

    iget-object v0, p0, La/f;->oD:Ljava/util/ArrayList;

    if-eqz v0, :cond_2

    iget-object v0, p0, La/f;->oD:Ljava/util/ArrayList;

    invoke-direct {p0, v0, p1}, La/f;->a(Ljava/util/ArrayList;Z)La/ac;

    move-result-object v2

    :cond_2
    iget-object v0, p0, La/f;->oB:La/ac;

    if-nez v0, :cond_6

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-le v0, v1, :cond_6

    iget-object v0, p0, La/f;->oE:Ljava/util/ArrayList;

    :goto_1
    invoke-direct {p0, v0, p1}, La/f;->a(Ljava/util/ArrayList;Z)La/ac;

    move-result-object v2

    goto :goto_2

    :cond_3
    iget-object v0, p0, La/f;->oB:La/ac;

    if-nez v0, :cond_4

    iget-object v0, p0, La/f;->ox:La/p;

    invoke-virtual {v0}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, La/f;->oF:Ljava/util/ArrayList;

    invoke-direct {p0, v0, p1}, La/f;->a(Ljava/util/ArrayList;Z)La/ac;

    move-result-object v2

    :cond_4
    iget-object v0, p0, La/f;->oB:La/ac;

    if-nez v0, :cond_5

    iget-object v0, p0, La/f;->oA:La/ac;

    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v0

    if-le v0, v1, :cond_5

    iget-object v0, p0, La/f;->oE:Ljava/util/ArrayList;

    invoke-direct {p0, v0, p1}, La/f;->a(Ljava/util/ArrayList;Z)La/ac;

    move-result-object v0

    move-object v2, v0

    :cond_5
    iget-object v0, p0, La/f;->oB:La/ac;

    if-nez v0, :cond_6

    iget-object v0, p0, La/f;->oD:Ljava/util/ArrayList;

    if-eqz v0, :cond_6

    iget-object v0, p0, La/f;->oD:Ljava/util/ArrayList;

    goto :goto_1

    :cond_6
    :goto_2
    iget-object p1, p0, La/f;->oB:La/ac;

    if-nez p1, :cond_7

    invoke-direct {p0}, La/f;->fX()La/ac;

    move-result-object v2

    :cond_7
    return-object v2
.end method

.method public y(Z)La/ac;
    .locals 0

    invoke-direct {p0}, La/f;->fX()La/ac;

    move-result-object p1

    return-object p1
.end method
