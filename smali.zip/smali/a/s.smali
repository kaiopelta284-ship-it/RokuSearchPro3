.class public La/s;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private of:I

.field private ol:I

.field private os:I

.field private ot:I

.field private ou:I

.field private transient qQ:La/al;

.field private qR:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/s;->qQ:La/al;

    const/4 v0, -0x1

    iput v0, p0, La/s;->qR:I

    return-void
.end method

.method public constructor <init>(La/p;La/al;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-object p1, p0, La/s;->qQ:La/al;

    const/4 p1, -0x1

    iput p1, p0, La/s;->qR:I

    iput-object p2, p0, La/s;->qQ:La/al;

    return-void
.end method


# virtual methods
.method public fC()I
    .locals 1

    iget v0, p0, La/s;->of:I

    return v0
.end method

.method public fD()V
    .locals 1

    iget v0, p0, La/s;->of:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->of:I

    return-void
.end method

.method public fM()V
    .locals 1

    iget v0, p0, La/s;->ou:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->ou:I

    return-void
.end method

.method public fR()V
    .locals 1

    iget v0, p0, La/s;->ol:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->ol:I

    return-void
.end method

.method public fS()V
    .locals 1

    iget v0, p0, La/s;->os:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->os:I

    return-void
.end method

.method public fT()V
    .locals 1

    iget v0, p0, La/s;->ot:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->ot:I

    return-void
.end method

.method public fU()V
    .locals 1

    iget v0, p0, La/s;->os:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->os:I

    iget v0, p0, La/s;->ot:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/s;->ot:I

    return-void
.end method

.method public fW()I
    .locals 1

    iget v0, p0, La/s;->ou:I

    return v0
.end method

.method public fy()I
    .locals 1

    iget v0, p0, La/s;->ol:I

    return v0
.end method

.method public jb()La/al;
    .locals 1

    iget-object v0, p0, La/s;->qQ:La/al;

    return-object v0
.end method

.method public jc()Z
    .locals 3

    iget v0, p0, La/s;->os:I

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-ge v0, v2, :cond_1

    iget v0, p0, La/s;->ot:I

    if-lt v0, v1, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    return v0

    :cond_1
    return v1
.end method

.method public jd()V
    .locals 2

    iget v0, p0, La/s;->os:I

    const/4 v1, 0x3

    if-lt v0, v1, :cond_0

    const/4 v0, 0x0

    iput v0, p0, La/s;->os:I

    return-void

    :cond_0
    iget v0, p0, La/s;->ot:I

    const/4 v1, 0x1

    if-lt v0, v1, :cond_1

    iget v0, p0, La/s;->ot:I

    sub-int/2addr v0, v1

    iput v0, p0, La/s;->ot:I

    :cond_1
    return-void
.end method

.method public je()[I
    .locals 3

    const/4 v0, 0x2

    new-array v0, v0, [I

    iget v1, p0, La/s;->os:I

    const/4 v2, 0x0

    aput v1, v0, v2

    iget v1, p0, La/s;->ot:I

    const/4 v2, 0x1

    aput v1, v0, v2

    return-object v0
.end method

.method public jf()I
    .locals 1

    iget v0, p0, La/s;->qR:I

    return v0
.end method

.method public jg()V
    .locals 1

    iget-object v0, p0, La/s;->qQ:La/al;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/s;->qQ:La/al;

    invoke-virtual {v0}, La/al;->iM()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, La/s;->qQ:La/al;

    invoke-virtual {v0}, La/al;->iM()I

    move-result v0

    iput v0, p0, La/s;->qR:I

    :cond_0
    iget v0, p0, La/s;->qR:I

    iput v0, p0, La/s;->qR:I

    return-void
.end method

.method public l(La/al;)V
    .locals 0

    iput-object p1, p0, La/s;->qQ:La/al;

    return-void
.end method
