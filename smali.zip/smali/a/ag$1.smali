.class La/ag$1;
.super Ljava/util/TimerTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La/ag;->nj()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic yA:La/ag;


# direct methods
.method constructor <init>(La/ag;)V
    .locals 0

    iput-object p1, p0, La/ag$1;->yA:La/ag;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    invoke-static {}, La/ag;->ny()Ljava/util/Timer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Timer;->cancel()V

    iget-object v0, p0, La/ag$1;->yA:La/ag;

    invoke-virtual {v0}, La/ag;->nk()V

    return-void
.end method
