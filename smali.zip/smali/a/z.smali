.class public final enum La/z;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "La/z;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum sA:La/z;

.field public static final enum sB:La/z;

.field public static final enum sC:La/z;

.field public static final enum sD:La/z;

.field public static final enum sE:La/z;

.field public static final enum sF:La/z;

.field public static final enum sG:La/z;

.field public static final enum sH:La/z;

.field public static final enum sI:La/z;

.field public static final enum sJ:La/z;

.field public static final enum sK:La/z;

.field public static final enum sL:La/z;

.field public static final enum sM:La/z;

.field public static final enum sN:La/z;

.field public static final enum sO:La/z;

.field public static final enum sP:La/z;

.field public static final enum sQ:La/z;

.field public static final enum sR:La/z;

.field public static final enum sS:La/z;

.field public static final enum sT:La/z;

.field public static final enum sU:La/z;

.field public static final enum sV:La/z;

.field public static final enum sW:La/z;

.field public static final enum sX:La/z;

.field public static final enum sY:La/z;

.field public static final enum sZ:La/z;

.field public static final enum su:La/z;

.field public static final enum sv:La/z;

.field public static final enum sw:La/z;

.field public static final enum sx:La/z;

.field public static final enum sy:La/z;

.field public static final enum sz:La/z;

.field public static final enum tA:La/z;

.field public static final enum tB:La/z;

.field public static final enum tC:La/z;

.field public static final enum tD:La/z;

.field public static final enum tE:La/z;

.field public static final enum tF:La/z;

.field public static final enum tG:La/z;

.field public static final enum tH:La/z;

.field public static final enum tI:La/z;

.field public static final enum tJ:La/z;

.field public static final enum tK:La/z;

.field public static final enum tL:La/z;

.field public static final enum tM:La/z;

.field public static final enum tN:La/z;

.field public static final enum tO:La/z;

.field public static final enum tP:La/z;

.field public static final enum tQ:La/z;

.field public static final enum tR:La/z;

.field public static final enum tS:La/z;

.field public static final enum tT:La/z;

.field public static final enum tU:La/z;

.field public static final enum tV:La/z;

.field public static final enum tW:La/z;

.field public static final enum tX:La/z;

.field public static final enum tY:La/z;

.field public static final enum tZ:La/z;

.field public static final enum ta:La/z;

.field public static final enum tb:La/z;

.field public static final enum td:La/z;

.field public static final enum te:La/z;

.field public static final enum tf:La/z;

.field public static final enum tg:La/z;

.field public static final enum th:La/z;

.field public static final enum ti:La/z;

.field public static final enum tj:La/z;

.field public static final enum tk:La/z;

.field public static final enum tl:La/z;

.field public static final enum tm:La/z;

.field public static final enum tn:La/z;

.field public static final enum to:La/z;

.field public static final enum tp:La/z;

.field public static final enum tq:La/z;

.field public static final enum tr:La/z;

.field public static final enum ts:La/z;

.field public static final enum tt:La/z;

.field public static final enum tu:La/z;

.field public static final enum tv:La/z;

.field public static final enum tw:La/z;

.field public static final enum tx:La/z;

.field public static final enum ty:La/z;

.field public static final enum tz:La/z;

.field public static final enum uA:La/z;

.field public static final enum uB:La/z;

.field public static final enum uC:La/z;

.field public static final enum uD:La/z;

.field public static final enum uE:La/z;

.field public static final enum uF:La/z;

.field public static final enum uG:La/z;

.field public static final enum uH:La/z;

.field public static final enum uI:La/z;

.field public static final enum uJ:La/z;

.field public static final enum uK:La/z;

.field public static final enum uL:La/z;

.field public static final enum uM:La/z;

.field public static final enum uN:La/z;

.field public static final enum uO:La/z;

.field public static final enum uP:La/z;

.field public static final enum uQ:La/z;

.field public static final enum uR:La/z;

.field public static final enum uS:La/z;

.field public static final enum uT:La/z;

.field public static final enum uU:La/z;

.field public static final enum uV:La/z;

.field public static final enum uW:La/z;

.field public static final enum uX:La/z;

.field public static final enum uY:La/z;

.field public static final enum uZ:La/z;

.field public static final enum ua:La/z;

.field public static final enum ub:La/z;

.field public static final enum uc:La/z;

.field public static final enum ud:La/z;

.field public static final enum ue:La/z;

.field public static final enum uf:La/z;

.field public static final enum ug:La/z;

.field public static final enum uh:La/z;

.field public static final enum ui:La/z;

.field public static final enum uj:La/z;

.field public static final enum uk:La/z;

.field public static final enum ul:La/z;

.field public static final enum um:La/z;

.field public static final enum un:La/z;

.field public static final enum uo:La/z;

.field public static final enum up:La/z;

.field public static final enum uq:La/z;

.field public static final enum ur:La/z;

.field public static final enum us:La/z;

.field public static final enum ut:La/z;

.field public static final enum uu:La/z;

.field public static final enum uv:La/z;

.field public static final enum uw:La/z;

.field public static final enum ux:La/z;

.field public static final enum uy:La/z;

.field public static final enum uz:La/z;

.field public static final enum vA:La/z;

.field public static final enum vB:La/z;

.field public static final enum vC:La/z;

.field public static final enum vD:La/z;

.field public static final enum vE:La/z;

.field public static final enum vF:La/z;

.field public static final enum vG:La/z;

.field public static final enum vH:La/z;

.field public static final enum vI:La/z;

.field public static final enum vJ:La/z;

.field public static final enum vK:La/z;

.field public static final enum vL:La/z;

.field public static final enum vM:La/z;

.field public static final enum vN:La/z;

.field public static final enum vO:La/z;

.field public static final enum vP:La/z;

.field public static final enum vQ:La/z;

.field public static final enum vR:La/z;

.field public static final enum vS:La/z;

.field public static final enum vT:La/z;

.field public static final enum vU:La/z;

.field public static final enum vV:La/z;

.field public static final enum vW:La/z;

.field public static final enum vX:La/z;

.field public static final enum vY:La/z;

.field public static final enum vZ:La/z;

.field public static final enum va:La/z;

.field public static final enum vb:La/z;

.field public static final enum vc:La/z;

.field public static final enum vd:La/z;

.field public static final enum ve:La/z;

.field public static final enum vf:La/z;

.field public static final enum vg:La/z;

.field public static final enum vh:La/z;

.field public static final enum vi:La/z;

.field public static final enum vj:La/z;

.field public static final enum vk:La/z;

.field public static final enum vl:La/z;

.field public static final enum vm:La/z;

.field public static final enum vn:La/z;

.field public static final enum vo:La/z;

.field public static final enum vp:La/z;

.field public static final enum vq:La/z;

.field public static final enum vr:La/z;

.field public static final enum vs:La/z;

.field public static final enum vt:La/z;

.field public static final enum vu:La/z;

.field public static final enum vv:La/z;

.field public static final enum vw:La/z;

.field public static final enum vx:La/z;

.field public static final enum vy:La/z;

.field public static final enum vz:La/z;

.field public static final enum wA:La/z;

.field public static final enum wB:La/z;

.field public static final enum wC:La/z;

.field public static final enum wD:La/z;

.field public static final enum wE:La/z;

.field public static final enum wF:La/z;

.field public static final enum wG:La/z;

.field public static final enum wH:La/z;

.field private static final synthetic wM:[La/z;

.field public static final enum wa:La/z;

.field public static final enum wb:La/z;

.field public static final enum wc:La/z;

.field public static final enum wd:La/z;

.field public static final enum we:La/z;

.field public static final enum wf:La/z;

.field public static final enum wg:La/z;

.field public static final enum wh:La/z;

.field public static final enum wi:La/z;

.field public static final enum wj:La/z;

.field public static final enum wk:La/z;

.field public static final enum wl:La/z;

.field public static final enum wm:La/z;

.field public static final enum wn:La/z;

.field public static final enum wo:La/z;

.field public static final enum wp:La/z;

.field public static final enum wq:La/z;

.field public static final enum wr:La/z;

.field public static final enum ws:La/z;

.field public static final enum wt:La/z;

.field public static final enum wu:La/z;

.field public static final enum wv:La/z;

.field public static final enum ww:La/z;

.field public static final enum wx:La/z;

.field public static final enum wy:La/z;

.field public static final enum wz:La/z;


# instance fields
.field private final id:I

.field private final pq:Ljava/lang/String;

.field private final so:I

.field private final wI:Ljava/lang/String;

.field private final wJ:I

.field private final wK:[I

.field private final wL:[I


# direct methods
.method static constructor <clinit>()V
    .locals 21

    new-instance v10, La/z;

    const-string v1, "P0"

    const-string v3, "Afeganist\u00e3o"

    const-string v4, "AFG"

    sget-object v8, La/ak;->zA:[I

    sget-object v9, La/ak;->zn:[I

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/16 v7, 0xd

    move-object v0, v10

    invoke-direct/range {v0 .. v9}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v10, La/z;->su:La/z;

    new-instance v0, La/z;

    const-string v12, "P1"

    const-string v14, "Africa do Sul"

    const-string v15, "AFS"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zn:[I

    const/4 v13, 0x1

    const/16 v16, 0x1

    const/16 v17, 0x2

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sv:La/z;

    new-instance v0, La/z;

    const-string v2, "P2"

    const-string v4, "Alb\u00e2nia"

    const-string v5, "ALB"

    sget-object v9, La/ak;->zo:[I

    sget-object v10, La/ak;->zn:[I

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sw:La/z;

    new-instance v0, La/z;

    const-string v12, "P3"

    const-string v14, "Alemanha"

    const-string v15, "ALE"

    sget-object v19, La/ak;->zn:[I

    sget-object v20, La/ak;->zm:[I

    const/4 v13, 0x3

    const/16 v16, 0x3

    const/16 v17, 0x0

    const/16 v18, 0x15

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sx:La/z;

    new-instance v0, La/z;

    const-string v2, "P4"

    const-string v4, "Andorra"

    const-string v5, "AND"

    sget-object v9, La/ak;->zC:[I

    sget-object v10, La/ak;->zo:[I

    const/4 v3, 0x4

    const/4 v6, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sy:La/z;

    new-instance v0, La/z;

    const-string v12, "P5"

    const-string v14, "Angola"

    const-string v15, "AGO"

    sget-object v19, La/ak;->zn:[I

    sget-object v20, La/ak;->zo:[I

    const/4 v13, 0x5

    const/16 v16, 0x5

    const/16 v17, 0x2

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sz:La/z;

    new-instance v0, La/z;

    const-string v2, "P6"

    const-string v4, "Anguilla"

    const-string v5, "AIA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/4 v3, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sA:La/z;

    new-instance v0, La/z;

    const-string v12, "P7"

    const-string v14, "Antigua"

    const-string v15, "ATG"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/4 v13, 0x7

    const/16 v16, 0x7

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sB:La/z;

    new-instance v0, La/z;

    const-string v2, "P8"

    const-string v4, "Cura\u00e7ao"

    const-string v5, "CUR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0x8

    const/16 v6, 0x8

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sC:La/z;

    new-instance v0, La/z;

    const-string v12, "P9"

    const-string v14, "Ar\u00e1bia Saudita"

    const-string v15, "ARS"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x9

    const/16 v16, 0x9

    const/16 v17, 0x3

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sD:La/z;

    new-instance v0, La/z;

    const-string v2, "P10"

    const-string v4, "Arg\u00e9lia"

    const-string v5, "ALG"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0xa

    const/16 v6, 0xa

    const/4 v7, 0x2

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sE:La/z;

    new-instance v0, La/z;

    const-string v12, "P11"

    const-string v14, "Argentina"

    const-string v15, "ARG"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xb

    const/16 v16, 0xb

    const/16 v17, 0x1

    const/16 v18, 0x14

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sF:La/z;

    new-instance v0, La/z;

    const-string v2, "P12"

    const-string v4, "Armenia"

    const-string v5, "ARM"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zt:[I

    const/16 v3, 0xc

    const/16 v6, 0xc

    const/4 v7, 0x0

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sG:La/z;

    new-instance v0, La/z;

    const-string v12, "P13"

    const-string v14, "Aruba"

    const-string v15, "ARU"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zy:[I

    const/16 v13, 0xd

    const/16 v16, 0xd

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sH:La/z;

    new-instance v0, La/z;

    const-string v2, "P14"

    const-string v4, "Austr\u00e1lia"

    const-string v5, "AUS"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zu:[I

    const/16 v3, 0xe

    const/16 v6, 0xe

    const/4 v7, 0x3

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sI:La/z;

    new-instance v0, La/z;

    const-string v12, "P15"

    const-string v14, "\u00c1ustria"

    const-string v15, "AUT"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0xf

    const/16 v16, 0xf

    const/16 v17, 0x0

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sJ:La/z;

    new-instance v0, La/z;

    const-string v2, "P16"

    const-string v4, "Azerbaij\u00e3o"

    const-string v5, "AZE"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x10

    const/16 v6, 0x10

    const/4 v7, 0x0

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sK:La/z;

    new-instance v0, La/z;

    const-string v12, "P17"

    const-string v14, "Bahamas"

    const-string v15, "BAH"

    sget-object v19, La/ak;->zn:[I

    sget-object v20, La/ak;->zx:[I

    const/16 v13, 0x11

    const/16 v16, 0x11

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sL:La/z;

    new-instance v0, La/z;

    const-string v2, "P18"

    const-string v4, "Bahrain"

    const-string v5, "BHR"

    sget-object v9, La/ak;->zp:[I

    sget-object v10, La/ak;->zm:[I

    const/16 v3, 0x12

    const/16 v6, 0x12

    const/4 v7, 0x3

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sM:La/z;

    new-instance v0, La/z;

    const-string v12, "P19"

    const-string v14, "Bangladesh"

    const-string v15, "BAN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x13

    const/16 v16, 0x13

    const/16 v17, 0x3

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sN:La/z;

    new-instance v0, La/z;

    const-string v2, "P20"

    const-string v4, "Barbados"

    const-string v5, "BAR"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x14

    const/16 v6, 0x14

    const/4 v7, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sO:La/z;

    new-instance v0, La/z;

    const-string v12, "P21"

    const-string v14, "B\u00e9lgica"

    const-string v15, "BEL"

    sget-object v19, La/ak;->zC:[I

    sget-object v20, La/ak;->zn:[I

    const/16 v13, 0x15

    const/16 v16, 0x15

    const/16 v17, 0x0

    const/16 v18, 0x13

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sP:La/z;

    new-instance v0, La/z;

    const-string v2, "P22"

    const-string v4, "Belize"

    const-string v5, "BLZ"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x16

    const/16 v6, 0x16

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sQ:La/z;

    new-instance v0, La/z;

    const-string v12, "P23"

    const-string v14, "Benin"

    const-string v15, "BEN"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x17

    const/16 v16, 0x17

    const/16 v17, 0x2

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sR:La/z;

    new-instance v0, La/z;

    const-string v2, "P24"

    const-string v4, "Bermudas"

    const-string v5, "BER"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x18

    const/16 v6, 0x18

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sS:La/z;

    new-instance v0, La/z;

    const-string v12, "P25"

    const-string v14, "Bielo Russia"

    const-string v15, "BIE"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x19

    const/16 v16, 0x19

    const/16 v17, 0x0

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sT:La/z;

    new-instance v0, La/z;

    const-string v2, "P26"

    const-string v4, "Bolivia"

    const-string v5, "BOL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x1a

    const/16 v6, 0x1a

    const/4 v7, 0x1

    const/16 v8, 0x10

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sU:La/z;

    new-instance v0, La/z;

    const-string v12, "P27"

    const-string v14, "B\u00f3snia"

    const-string v15, "BOS"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0x1b

    const/16 v16, 0x1b

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sV:La/z;

    new-instance v0, La/z;

    const-string v2, "P28"

    const-string v4, "Botsuana"

    const-string v5, "BOT"

    sget-object v9, La/ak;->zn:[I

    sget-object v10, La/ak;->zy:[I

    const/16 v3, 0x1c

    const/16 v6, 0x1c

    const/4 v7, 0x2

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sW:La/z;

    new-instance v0, La/z;

    const-string v12, "P29"

    const-string v14, "Brasil"

    const-string v15, "BRA"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x1d

    const/16 v16, 0x1d

    const/16 v17, 0x1

    const/16 v18, 0x14

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sX:La/z;

    new-instance v0, La/z;

    const-string v2, "P30"

    const-string v4, "Brunei"

    const-string v5, "BRU"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zn:[I

    const/16 v3, 0x1e

    const/16 v6, 0x1e

    const/4 v7, 0x3

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sY:La/z;

    new-instance v0, La/z;

    const-string v12, "P31"

    const-string v14, "Bulg\u00e1ria"

    const-string v15, "BUL"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x1f

    const/16 v16, 0x1f

    const/16 v17, 0x0

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->sZ:La/z;

    new-instance v0, La/z;

    const-string v2, "P32"

    const-string v4, "Burkina Faso"

    const-string v5, "BKF"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x20

    const/16 v6, 0x20

    const/4 v7, 0x2

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ta:La/z;

    new-instance v0, La/z;

    const-string v12, "P33"

    const-string v14, "Burundi"

    const-string v15, "BUR"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x21

    const/16 v16, 0x21

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tb:La/z;

    new-instance v0, La/z;

    const-string v2, "P34"

    const-string v4, "But\u00e3o"

    const-string v5, "BUT"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x22

    const/16 v6, 0x22

    const/4 v7, 0x3

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->td:La/z;

    new-instance v0, La/z;

    const-string v12, "P35"

    const-string v14, "Cabo Verde"

    const-string v15, "CAV"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0x23

    const/16 v16, 0x23

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->te:La/z;

    new-instance v0, La/z;

    const-string v2, "P36"

    const-string v4, "Camar\u00f5es"

    const-string v5, "CAM"

    sget-object v9, La/ak;->zC:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x24

    const/16 v6, 0x24

    const/4 v7, 0x2

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tf:La/z;

    new-instance v0, La/z;

    const-string v12, "P37"

    const-string v14, "Camboja"

    const-string v15, "CMJ"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x25

    const/16 v16, 0x25

    const/16 v17, 0x3

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tg:La/z;

    new-instance v0, La/z;

    const-string v2, "P38"

    const-string v4, "Canad\u00e1"

    const-string v5, "CAN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x26

    const/16 v6, 0x26

    const/4 v7, 0x4

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->th:La/z;

    new-instance v0, La/z;

    const-string v12, "P39"

    const-string v14, "Catar"

    const-string v15, "CAT"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x27

    const/16 v16, 0x27

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ti:La/z;

    new-instance v0, La/z;

    const-string v2, "P40"

    const-string v4, "Cazaquist\u00e3o"

    const-string v5, "CAZ"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zy:[I

    const/16 v3, 0x28

    const/16 v6, 0x28

    const/4 v7, 0x0

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tj:La/z;

    new-instance v0, La/z;

    const-string v12, "P41"

    const-string v14, "Chade"

    const-string v15, "CHA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x29

    const/16 v16, 0x29

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tk:La/z;

    new-instance v0, La/z;

    const-string v2, "P42"

    const-string v4, "Chile"

    const-string v5, "CHI"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x2a

    const/16 v6, 0x2a

    const/4 v7, 0x1

    const/16 v8, 0x13

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tl:La/z;

    new-instance v0, La/z;

    const-string v12, "P43"

    const-string v14, "China"

    const-string v15, "CHN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x2b

    const/16 v16, 0x2b

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tm:La/z;

    new-instance v0, La/z;

    const-string v2, "P44"

    const-string v4, "Chipre"

    const-string v5, "CPR"

    sget-object v9, La/ak;->zn:[I

    sget-object v10, La/ak;->zm:[I

    const/16 v3, 0x2c

    const/16 v6, 0x2c

    const/4 v7, 0x0

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tn:La/z;

    new-instance v0, La/z;

    const-string v12, "P45"

    const-string v14, "Timor-Leste"

    const-string v15, "TML"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x2d

    const/16 v16, 0x2d

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->to:La/z;

    new-instance v0, La/z;

    const-string v2, "P46"

    const-string v4, "Col\u00f4mbia"

    const-string v5, "COL"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x2e

    const/16 v6, 0x2e

    const/4 v7, 0x1

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tp:La/z;

    new-instance v0, La/z;

    const-string v12, "P47"

    const-string v14, "Congo"

    const-string v15, "CNG"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x2f

    const/16 v16, 0x2f

    const/16 v17, 0x2

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tq:La/z;

    new-instance v0, La/z;

    const-string v2, "P48"

    const-string v4, "Coreia do Norte"

    const-string v5, "CRN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x30

    const/16 v6, 0x30

    const/4 v7, 0x3

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tr:La/z;

    new-instance v0, La/z;

    const-string v12, "P49"

    const-string v14, "Coreia do Sul"

    const-string v15, "CRS"

    sget-object v19, La/ak;->zw:[I

    sget-object v20, La/ak;->zm:[I

    const/16 v13, 0x31

    const/16 v16, 0x31

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ts:La/z;

    new-instance v0, La/z;

    const-string v2, "P50"

    const-string v4, "Costa do Marfim"

    const-string v5, "COM"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0x32

    const/16 v6, 0x32

    const/4 v7, 0x2

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tt:La/z;

    new-instance v0, La/z;

    const-string v12, "P51"

    const-string v14, "Costa Rica"

    const-string v15, "CSR"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x33

    const/16 v16, 0x33

    const/16 v17, 0x4

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tu:La/z;

    new-instance v0, La/z;

    const-string v2, "P52"

    const-string v4, "Cro\u00e1cia"

    const-string v5, "CRO"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x34

    const/16 v6, 0x34

    const/4 v7, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tv:La/z;

    new-instance v0, La/z;

    const-string v12, "P53"

    const-string v14, "Cuba"

    const-string v15, "CUB"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x35

    const/16 v16, 0x35

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tw:La/z;

    new-instance v0, La/z;

    const-string v2, "P54"

    const-string v4, "Dinamarca"

    const-string v5, "DIN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zq:[I

    const/16 v3, 0x36

    const/16 v6, 0x36

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tx:La/z;

    new-instance v0, La/z;

    const-string v12, "P55"

    const-string v14, "Djibuti"

    const-string v15, "DJI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x37

    const/16 v16, 0x37

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ty:La/z;

    new-instance v0, La/z;

    const-string v2, "P56"

    const-string v4, "Dominica"

    const-string v5, "DOM"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zq:[I

    const/16 v3, 0x38

    const/16 v6, 0x38

    const/4 v7, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tz:La/z;

    new-instance v0, La/z;

    const-string v12, "P57"

    const-string v14, "Egito"

    const-string v15, "EGI"

    sget-object v19, La/ak;->zn:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x39

    const/16 v16, 0x39

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tA:La/z;

    new-instance v0, La/z;

    const-string v2, "P58"

    const-string v4, "El Salvador"

    const-string v5, "ELS"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x3a

    const/16 v6, 0x3a

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tB:La/z;

    new-instance v0, La/z;

    const-string v12, "P59"

    const-string v14, "Emirados \u00c1rabes"

    const-string v15, "EMI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x3b

    const/16 v16, 0x3b

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tC:La/z;

    new-instance v0, La/z;

    const-string v2, "P60"

    const-string v4, "Equador"

    const-string v5, "EQU"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zt:[I

    const/16 v3, 0x3c

    const/16 v6, 0x3c

    const/4 v7, 0x1

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tD:La/z;

    new-instance v0, La/z;

    const-string v12, "P61"

    const-string v14, "Eritr\u00e9ia"

    const-string v15, "ERI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x3d

    const/16 v16, 0x3d

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tE:La/z;

    new-instance v0, La/z;

    const-string v2, "P62"

    const-string v4, "Esc\u00f3cia"

    const-string v5, "ESC"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0x3e

    const/16 v6, 0x3e

    const/4 v7, 0x0

    const/16 v8, 0x10

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tF:La/z;

    new-instance v0, La/z;

    const-string v12, "P63"

    const-string v14, "Eslov\u00e1quia"

    const-string v15, "ELQ"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zw:[I

    const/16 v13, 0x3f

    const/16 v16, 0x3f

    const/16 v17, 0x0

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tG:La/z;

    new-instance v0, La/z;

    const-string v2, "P64"

    const-string v4, "Eslov\u00eania"

    const-string v5, "ESV"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x40

    const/16 v6, 0x40

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tH:La/z;

    new-instance v0, La/z;

    const-string v12, "P65"

    const-string v14, "Espanha"

    const-string v15, "ESP"

    sget-object v19, La/ak;->zp:[I

    sget-object v20, La/ak;->zE:[I

    const/16 v13, 0x41

    const/16 v16, 0x41

    const/16 v18, 0x14

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tI:La/z;

    new-instance v0, La/z;

    const-string v2, "P66"

    const-string v4, "Estonia"

    const-string v5, "EST"

    sget-object v9, La/ak;->zn:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x42

    const/16 v6, 0x42

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tJ:La/z;

    new-instance v0, La/z;

    const-string v12, "P67"

    const-string v14, "Eti\u00f3pia"

    const-string v15, "ETI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x43

    const/16 v16, 0x43

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tK:La/z;

    new-instance v0, La/z;

    const-string v2, "P68"

    const-string v4, "EUA"

    const-string v5, "EUA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0x44

    const/16 v6, 0x44

    const/4 v7, 0x4

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tL:La/z;

    new-instance v0, La/z;

    const-string v12, "P69"

    const-string v14, "Fiji"

    const-string v15, "FIJ"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0x45

    const/16 v16, 0x45

    const/16 v17, 0x5

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tM:La/z;

    new-instance v0, La/z;

    const-string v2, "P70"

    const-string v4, "Finl\u00e2ndia"

    const-string v5, "FIN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x46

    const/16 v6, 0x46

    const/4 v7, 0x0

    const/16 v8, 0x10

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tN:La/z;

    new-instance v0, La/z;

    const-string v12, "P71"

    const-string v14, "Filipinas"

    const-string v15, "FIL"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x47

    const/16 v16, 0x47

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tO:La/z;

    new-instance v0, La/z;

    const-string v2, "P72"

    const-string v4, "Fran\u00e7a"

    const-string v5, "FRA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x48

    const/16 v6, 0x48

    const/16 v8, 0x14

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tP:La/z;

    new-instance v0, La/z;

    const-string v12, "P73"

    const-string v14, "Gab\u00e3o"

    const-string v15, "GAB"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x49

    const/16 v16, 0x49

    const/16 v17, 0x2

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tQ:La/z;

    new-instance v0, La/z;

    const-string v2, "P74"

    const-string v4, "G\u00e2mbia"

    const-string v5, "GAM"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x4a

    const/16 v6, 0x4a

    const/4 v7, 0x2

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tR:La/z;

    new-instance v0, La/z;

    const-string v12, "P75"

    const-string v14, "Gana"

    const-string v15, "GAN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x4b

    const/16 v16, 0x4b

    const/16 v18, 0x12

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tS:La/z;

    new-instance v0, La/z;

    const-string v2, "P76"

    const-string v4, "Georgia"

    const-string v5, "GEO"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x4c

    const/16 v6, 0x4c

    const/4 v7, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tT:La/z;

    new-instance v0, La/z;

    const-string v12, "P77"

    const-string v14, "Granada"

    const-string v15, "GRA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x4d

    const/16 v16, 0x4d

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tU:La/z;

    new-instance v0, La/z;

    const-string v2, "P78"

    const-string v4, "Gr\u00e9cia"

    const-string v5, "GRE"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x4e

    const/16 v6, 0x4e

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tV:La/z;

    new-instance v0, La/z;

    const-string v12, "P79"

    const-string v14, "Guatemala"

    const-string v15, "GUA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zy:[I

    const/16 v13, 0x4f

    const/16 v16, 0x4f

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tW:La/z;

    new-instance v0, La/z;

    const-string v2, "P80"

    const-string v4, "Guiana"

    const-string v5, "GUN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0x50

    const/16 v6, 0x50

    const/4 v7, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tX:La/z;

    new-instance v0, La/z;

    const-string v12, "P81"

    const-string v14, "Guin\u00e9"

    const-string v15, "GUI"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x51

    const/16 v16, 0x51

    const/16 v17, 0x2

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tY:La/z;

    new-instance v0, La/z;

    const-string v2, "P82"

    const-string v4, "Guin\u00e9-Bissau"

    const-string v5, "GNB"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0x52

    const/16 v6, 0x52

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->tZ:La/z;

    new-instance v0, La/z;

    const-string v12, "P83"

    const-string v14, "Guin\u00e9 Equatorial"

    const-string v15, "GNE"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0x53

    const/16 v16, 0x53

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ua:La/z;

    new-instance v0, La/z;

    const-string v2, "P84"

    const-string v4, "Haiti"

    const-string v5, "HAI"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0x54

    const/16 v6, 0x54

    const/4 v7, 0x4

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ub:La/z;

    new-instance v0, La/z;

    const-string v12, "P85"

    const-string v14, "Holanda"

    const-string v15, "HOL"

    sget-object v19, La/ak;->zn:[I

    sget-object v20, La/ak;->zD:[I

    const/16 v13, 0x55

    const/16 v16, 0x55

    const/16 v17, 0x0

    const/16 v18, 0x14

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uc:La/z;

    new-instance v0, La/z;

    const-string v2, "P86"

    const-string v4, "Honduras"

    const-string v5, "HON"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zy:[I

    const/16 v3, 0x56

    const/16 v6, 0x56

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ud:La/z;

    new-instance v0, La/z;

    const-string v12, "P87"

    const-string v14, "Hong Kong"

    const-string v15, "HKG"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x57

    const/16 v16, 0x57

    const/16 v17, 0x3

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ue:La/z;

    new-instance v0, La/z;

    const-string v2, "P88"

    const-string v4, "Hungria"

    const-string v5, "HUN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x58

    const/16 v6, 0x58

    const/4 v7, 0x0

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uf:La/z;

    new-instance v0, La/z;

    const-string v12, "P89"

    const-string v14, "I\u00eamen"

    const-string v15, "IEM"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zn:[I

    const/16 v13, 0x59

    const/16 v16, 0x59

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ug:La/z;

    new-instance v0, La/z;

    const-string v2, "P90"

    const-string v4, "Ilhas Cayman"

    const-string v5, "ICA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x5a

    const/16 v6, 0x5a

    const/4 v7, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uh:La/z;

    new-instance v0, La/z;

    const-string v12, "P91"

    const-string v14, "Ilhas Cook"

    const-string v15, "ICO"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0x5b

    const/16 v16, 0x5b

    const/16 v17, 0x4

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ui:La/z;

    new-instance v0, La/z;

    const-string v2, "P92"

    const-string v4, "Ilhas Faroe"

    const-string v5, "IFA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x5c

    const/16 v6, 0x5c

    const/4 v7, 0x0

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uj:La/z;

    new-instance v0, La/z;

    const-string v12, "P93"

    const-string v14, "Ilhas Salom\u00e3o"

    const-string v15, "ISA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0x5d

    const/16 v16, 0x5d

    const/16 v17, 0x5

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uk:La/z;

    new-instance v0, La/z;

    const-string v2, "P94"

    const-string v4, "Ilhas Virgens Brit\u00e2nicas"

    const-string v5, "IVB"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0x5e

    const/16 v6, 0x5e

    const/4 v7, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ul:La/z;

    new-instance v0, La/z;

    const-string v12, "P95"

    const-string v14, "\u00cdndia"

    const-string v15, "IND"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x5f

    const/16 v16, 0x5f

    const/16 v17, 0x3

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->um:La/z;

    new-instance v0, La/z;

    const-string v2, "P96"

    const-string v4, "Indon\u00e9sia"

    const-string v5, "IDO"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x60

    const/16 v6, 0x60

    const/4 v7, 0x3

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->un:La/z;

    new-instance v0, La/z;

    const-string v12, "P97"

    const-string v14, "Inglaterra"

    const-string v15, "ING"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zu:[I

    const/16 v13, 0x61

    const/16 v16, 0x61

    const/16 v17, 0x0

    const/16 v18, 0x14

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uo:La/z;

    new-instance v0, La/z;

    const-string v2, "P98"

    const-string v4, "Ir\u00e3"

    const-string v5, "IRA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x62

    const/16 v6, 0x62

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->up:La/z;

    new-instance v0, La/z;

    const-string v12, "P99"

    const-string v14, "Iraque"

    const-string v15, "IRQ"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zn:[I

    const/16 v13, 0x63

    const/16 v16, 0x63

    const/16 v17, 0x3

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uq:La/z;

    new-instance v0, La/z;

    const-string v2, "P100"

    const-string v4, "Irlanda"

    const-string v5, "IRL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x64

    const/16 v6, 0x64

    const/4 v7, 0x0

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ur:La/z;

    new-instance v0, La/z;

    const-string v12, "P101"

    const-string v14, "Irlanda do Norte"

    const-string v15, "IRN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x65

    const/16 v16, 0x65

    const/16 v17, 0x0

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->us:La/z;

    new-instance v0, La/z;

    const-string v2, "P102"

    const-string v4, "Isl\u00e2ndia"

    const-string v5, "ISL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x66

    const/16 v6, 0x66

    const/16 v8, 0x10

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ut:La/z;

    new-instance v0, La/z;

    const-string v12, "P103"

    const-string v14, "Israel"

    const-string v15, "ISR"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zw:[I

    const/16 v13, 0x67

    const/16 v16, 0x67

    const/16 v18, 0xc

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uu:La/z;

    new-instance v0, La/z;

    const-string v2, "P104"

    const-string v4, "It\u00e1lia"

    const-string v5, "ITA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x68

    const/16 v6, 0x68

    const/16 v8, 0x14

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uv:La/z;

    new-instance v0, La/z;

    const-string v12, "P105"

    const-string v14, "Montenegro"

    const-string v15, "MON"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x69

    const/16 v16, 0x69

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uw:La/z;

    new-instance v0, La/z;

    const-string v2, "P106"

    const-string v4, "Jamaica"

    const-string v5, "JAM"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x6a

    const/16 v6, 0x6a

    const/4 v7, 0x4

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ux:La/z;

    new-instance v0, La/z;

    const-string v12, "P107"

    const-string v14, "Jap\u00e3o"

    const-string v15, "JAP"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zt:[I

    const/16 v13, 0x6b

    const/16 v16, 0x6b

    const/16 v17, 0x3

    const/16 v18, 0x12

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uy:La/z;

    new-instance v0, La/z;

    const-string v2, "P108"

    const-string v4, "Jord\u00e2nia"

    const-string v5, "JOR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x6c

    const/16 v6, 0x6c

    const/4 v7, 0x3

    const/16 v8, 0x10

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uz:La/z;

    new-instance v0, La/z;

    const-string v12, "P109"

    const-string v14, "Qu\u00eania"

    const-string v15, "QUE"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x6d

    const/16 v16, 0x6d

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uA:La/z;

    new-instance v0, La/z;

    const-string v2, "P110"

    const-string v4, "Kosovo"

    const-string v5, "KOS"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0x6e

    const/16 v6, 0x6e

    const/4 v7, 0x0

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uB:La/z;

    new-instance v0, La/z;

    const-string v12, "P111"

    const-string v14, "Kuwait"

    const-string v15, "KUW"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x6f

    const/16 v16, 0x6f

    const/16 v17, 0x3

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uC:La/z;

    new-instance v0, La/z;

    const-string v2, "P112"

    const-string v4, "Laos"

    const-string v5, "LAO"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x70

    const/16 v6, 0x70

    const/4 v7, 0x3

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uD:La/z;

    new-instance v0, La/z;

    const-string v12, "P113"

    const-string v14, "Lesoto"

    const-string v15, "LES"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x71

    const/16 v16, 0x71

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uE:La/z;

    new-instance v0, La/z;

    const-string v2, "P114"

    const-string v4, "Let\u00f4nia"

    const-string v5, "LET"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x72

    const/16 v6, 0x72

    const/4 v7, 0x0

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uF:La/z;

    new-instance v0, La/z;

    const-string v12, "P115"

    const-string v14, "Libano"

    const-string v15, "LBN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x73

    const/16 v16, 0x73

    const/16 v17, 0x3

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uG:La/z;

    new-instance v0, La/z;

    const-string v2, "P116"

    const-string v4, "L\u00edbia"

    const-string v5, "LIB"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x74

    const/16 v6, 0x74

    const/4 v7, 0x2

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uH:La/z;

    new-instance v0, La/z;

    const-string v12, "P117"

    const-string v14, "Lib\u00e9ria"

    const-string v15, "LRI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x75

    const/16 v16, 0x75

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uI:La/z;

    new-instance v0, La/z;

    const-string v2, "P118"

    const-string v4, "Liechenstein"

    const-string v5, "LIE"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0x76

    const/16 v6, 0x76

    const/4 v7, 0x0

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uJ:La/z;

    new-instance v0, La/z;

    const-string v12, "P119"

    const-string v14, "Litu\u00e2nia"

    const-string v15, "LIT"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x77

    const/16 v16, 0x77

    const/16 v17, 0x0

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uK:La/z;

    new-instance v0, La/z;

    const-string v2, "P120"

    const-string v4, "Luxemburgo"

    const-string v5, "LUX"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x78

    const/16 v6, 0x78

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uL:La/z;

    new-instance v0, La/z;

    const-string v12, "P121"

    const-string v14, "Macau"

    const-string v15, "MAC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x79

    const/16 v16, 0x79

    const/16 v17, 0x3

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uM:La/z;

    new-instance v0, La/z;

    const-string v2, "P122"

    const-string v4, "Maced\u00f4nia"

    const-string v5, "MCD"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x7a

    const/16 v6, 0x7a

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uN:La/z;

    new-instance v0, La/z;

    const-string v12, "P123"

    const-string v14, "Madagascar"

    const-string v15, "MAD"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x7b

    const/16 v16, 0x7b

    const/16 v17, 0x2

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uO:La/z;

    new-instance v0, La/z;

    const-string v2, "P124"

    const-string v4, "Mal\u00e1sia"

    const-string v5, "MAL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x7c

    const/16 v6, 0x7c

    const/4 v7, 0x3

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uP:La/z;

    new-instance v0, La/z;

    const-string v12, "P125"

    const-string v14, "Malawi"

    const-string v15, "MWI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x7d

    const/16 v16, 0x7d

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uQ:La/z;

    new-instance v0, La/z;

    const-string v2, "P126"

    const-string v4, "Maldivas"

    const-string v5, "MLD"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x7e

    const/16 v6, 0x7e

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uR:La/z;

    new-instance v0, La/z;

    const-string v12, "P127"

    const-string v14, "Mali"

    const-string v15, "MLI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x7f

    const/16 v16, 0x7f

    const/16 v17, 0x2

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uS:La/z;

    new-instance v0, La/z;

    const-string v2, "P128"

    const-string v4, "Malta"

    const-string v5, "MTA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x80

    const/16 v6, 0x80

    const/4 v7, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uT:La/z;

    new-instance v0, La/z;

    const-string v12, "P129"

    const-string v14, "Marrocos"

    const-string v15, "MAR"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0x81

    const/16 v16, 0x81

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uU:La/z;

    new-instance v0, La/z;

    const-string v2, "P130"

    const-string v4, "Maurit\u00e2nia"

    const-string v5, "MAU"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zn:[I

    const/16 v3, 0x82

    const/16 v6, 0x82

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uV:La/z;

    new-instance v0, La/z;

    const-string v12, "P131"

    const-string v14, "M\u00e9xico"

    const-string v15, "MEX"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x83

    const/16 v16, 0x83

    const/16 v17, 0x4

    const/16 v18, 0x13

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uW:La/z;

    new-instance v0, La/z;

    const-string v2, "P132"

    const-string v4, "Mianmar"

    const-string v5, "MIA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x84

    const/16 v6, 0x84

    const/4 v7, 0x3

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uX:La/z;

    new-instance v0, La/z;

    const-string v12, "P133"

    const-string v14, "Mo\u00e7ambique"

    const-string v15, "MOC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x85

    const/16 v16, 0x85

    const/16 v17, 0x2

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uY:La/z;

    new-instance v0, La/z;

    const-string v2, "P134"

    const-string v4, "Mold\u00e1via"

    const-string v5, "MOL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zt:[I

    const/16 v3, 0x86

    const/16 v6, 0x86

    const/4 v7, 0x0

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->uZ:La/z;

    new-instance v0, La/z;

    const-string v12, "P135"

    const-string v14, "M\u00f4naco"

    const-string v15, "MNC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x87

    const/16 v16, 0x87

    const/16 v17, 0x0

    const/16 v18, 0xc

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->va:La/z;

    new-instance v0, La/z;

    const-string v2, "P136"

    const-string v4, "Mongolia"

    const-string v5, "MGL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x88

    const/16 v6, 0x88

    const/4 v7, 0x3

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vb:La/z;

    new-instance v0, La/z;

    const-string v12, "P137"

    const-string v14, "Nam\u00edbia"

    const-string v15, "NAM"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x89

    const/16 v16, 0x89

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vc:La/z;

    new-instance v0, La/z;

    const-string v2, "P138"

    const-string v4, "Nepal"

    const-string v5, "NEP"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x8a

    const/16 v6, 0x8a

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vd:La/z;

    new-instance v0, La/z;

    const-string v12, "P139"

    const-string v14, "Nicaragua"

    const-string v15, "NIC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zw:[I

    const/16 v13, 0x8b

    const/16 v16, 0x8b

    const/16 v17, 0x4

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ve:La/z;

    new-instance v0, La/z;

    const-string v2, "P140"

    const-string v4, "N\u00edger"

    const-string v5, "NIR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0x8c

    const/16 v6, 0x8c

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vf:La/z;

    new-instance v0, La/z;

    const-string v12, "P141"

    const-string v14, "Nig\u00e9ria"

    const-string v15, "NIG"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x8d

    const/16 v16, 0x8d

    const/16 v17, 0x2

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vg:La/z;

    new-instance v0, La/z;

    const-string v2, "P142"

    const-string v4, "Noruega"

    const-string v5, "NOR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x8e

    const/16 v6, 0x8e

    const/4 v7, 0x0

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vh:La/z;

    new-instance v0, La/z;

    const-string v12, "P143"

    const-string v14, "Nova Zel\u00e2ndia"

    const-string v15, "NOZ"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x8f

    const/16 v16, 0x8f

    const/16 v17, 0x5

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vi:La/z;

    new-instance v0, La/z;

    const-string v2, "P144"

    const-string v4, "Om\u00e3"

    const-string v5, "OMA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x90

    const/16 v6, 0x90

    const/4 v7, 0x3

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vj:La/z;

    new-instance v0, La/z;

    const-string v12, "P145"

    const-string v14, "Pa\u00eds de Gales"

    const-string v15, "PGA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0x91

    const/16 v16, 0x91

    const/16 v17, 0x0

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vk:La/z;

    new-instance v0, La/z;

    const-string v2, "P146"

    const-string v4, "Palestina"

    const-string v5, "PAL"

    sget-object v9, La/ak;->zn:[I

    sget-object v10, La/ak;->zA:[I

    const/16 v3, 0x92

    const/16 v6, 0x92

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vl:La/z;

    new-instance v0, La/z;

    const-string v12, "P147"

    const-string v14, "Panam\u00e1"

    const-string v15, "PAN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zt:[I

    const/16 v13, 0x93

    const/16 v16, 0x93

    const/16 v17, 0x4

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vm:La/z;

    new-instance v0, La/z;

    const-string v2, "P148"

    const-string v4, "Papua Nova Guin\u00e9"

    const-string v5, "PNG"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zn:[I

    const/16 v3, 0x94

    const/16 v6, 0x94

    const/4 v7, 0x5

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vn:La/z;

    new-instance v0, La/z;

    const-string v12, "P149"

    const-string v14, "Paquist\u00e3o"

    const-string v15, "PAQ"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0x95

    const/16 v16, 0x95

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vo:La/z;

    new-instance v0, La/z;

    const-string v2, "P150"

    const-string v4, "Paraguai"

    const-string v5, "PAR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x96

    const/16 v6, 0x96

    const/4 v7, 0x1

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vp:La/z;

    new-instance v0, La/z;

    const-string v12, "P151"

    const-string v14, "Peru"

    const-string v15, "PER"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0x97

    const/16 v16, 0x97

    const/16 v17, 0x1

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vq:La/z;

    new-instance v0, La/z;

    const-string v2, "P152"

    const-string v4, "Pol\u00f4nia"

    const-string v5, "POL"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x98

    const/16 v6, 0x98

    const/4 v7, 0x0

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vr:La/z;

    new-instance v0, La/z;

    const-string v12, "P153"

    const-string v14, "Porto Rico"

    const-string v15, "PRI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x99

    const/16 v16, 0x99

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vs:La/z;

    new-instance v0, La/z;

    const-string v2, "P154"

    const-string v4, "Portugal"

    const-string v5, "POR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0x9a

    const/16 v6, 0x9a

    const/16 v8, 0x13

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vt:La/z;

    new-instance v0, La/z;

    const-string v12, "P155"

    const-string v14, "Quirguist\u00e3o"

    const-string v15, "QUI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0x9b

    const/16 v16, 0x9b

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vu:La/z;

    new-instance v0, La/z;

    const-string v2, "P156"

    const-string v4, "Rep. Centro-Africana"

    const-string v5, "RCA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0x9c

    const/16 v6, 0x9c

    const/4 v7, 0x2

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vv:La/z;

    new-instance v0, La/z;

    const-string v12, "P157"

    const-string v14, "Rep. Dem. Congo"

    const-string v15, "RDG"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0x9d

    const/16 v16, 0x9d

    const/16 v17, 0x2

    const/16 v18, 0x10

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vw:La/z;

    new-instance v0, La/z;

    const-string v2, "P158"

    const-string v4, "Rep. Dominicana"

    const-string v5, "RDO"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0x9e

    const/16 v6, 0x9e

    const/4 v7, 0x4

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vx:La/z;

    new-instance v0, La/z;

    const-string v12, "P159"

    const-string v14, "Rep. Tcheca"

    const-string v15, "RTC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0x9f

    const/16 v16, 0x9f

    const/16 v17, 0x0

    const/16 v18, 0x12

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vy:La/z;

    new-instance v0, La/z;

    const-string v2, "P160"

    const-string v4, "Rom\u00eania"

    const-string v5, "ROM"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0xa0

    const/16 v6, 0xa0

    const/4 v7, 0x0

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vz:La/z;

    new-instance v0, La/z;

    const-string v12, "P161"

    const-string v14, "Ruanda"

    const-string v15, "RUA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0xa1

    const/16 v16, 0xa1

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vA:La/z;

    new-instance v0, La/z;

    const-string v2, "P162"

    const-string v4, "R\u00fassia"

    const-string v5, "RUS"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0xa2

    const/16 v6, 0xa2

    const/16 v8, 0x13

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vB:La/z;

    new-instance v0, La/z;

    const-string v12, "P163"

    const-string v14, "Samoa"

    const-string v15, "SAM"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0xa3

    const/16 v16, 0xa3

    const/16 v17, 0x5

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vC:La/z;

    new-instance v0, La/z;

    const-string v2, "P164"

    const-string v4, "San Marino"

    const-string v5, "SAN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zy:[I

    const/16 v3, 0xa4

    const/16 v6, 0xa4

    const/16 v8, 0xc

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vD:La/z;

    new-instance v0, La/z;

    const-string v12, "P165"

    const-string v14, "Santa L\u00facia"

    const-string v15, "STL"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0xa5

    const/16 v16, 0xa5

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vE:La/z;

    new-instance v0, La/z;

    const-string v2, "P166"

    const-string v4, "S\u00e3o Cristov\u00e3o e Neves"

    const-string v5, "SCN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xa6

    const/16 v6, 0xa6

    const/4 v7, 0x4

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vF:La/z;

    new-instance v0, La/z;

    const-string v12, "P167"

    const-string v14, "S\u00e3o Tom\u00e9 e Pr\u00edncipe"

    const-string v15, "STP"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0xa7

    const/16 v16, 0xa7

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vG:La/z;

    new-instance v0, La/z;

    const-string v2, "P168"

    const-string v4, "S\u00e3o Vicente e Granadinas"

    const-string v5, "SVG"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0xa8

    const/16 v6, 0xa8

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vH:La/z;

    new-instance v0, La/z;

    const-string v12, "P169"

    const-string v14, "Senegal"

    const-string v15, "SEN"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zq:[I

    const/16 v13, 0xa9

    const/16 v16, 0xa9

    const/16 v17, 0x2

    const/16 v18, 0x11

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vI:La/z;

    new-instance v0, La/z;

    const-string v2, "P170"

    const-string v4, "Serra Leoa"

    const-string v5, "SLE"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0xaa

    const/16 v6, 0xaa

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vJ:La/z;

    new-instance v0, La/z;

    const-string v12, "P171"

    const-string v14, "S\u00e9rvia"

    const-string v15, "SER"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0xab

    const/16 v16, 0xab

    const/16 v17, 0x0

    const/16 v18, 0x12

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vK:La/z;

    new-instance v0, La/z;

    const-string v2, "P172"

    const-string v4, "Seychelles"

    const-string v5, "SEY"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zs:[I

    const/16 v3, 0xac

    const/16 v6, 0xac

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vL:La/z;

    new-instance v0, La/z;

    const-string v12, "P173"

    const-string v14, "Singapura"

    const-string v15, "SIN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0xad

    const/16 v16, 0xad

    const/16 v17, 0x3

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vM:La/z;

    new-instance v0, La/z;

    const-string v2, "P174"

    const-string v4, "S\u00edria"

    const-string v5, "SIR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0xae

    const/16 v6, 0xae

    const/4 v7, 0x3

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vN:La/z;

    new-instance v0, La/z;

    const-string v12, "P175"

    const-string v14, "Som\u00e1lia"

    const-string v15, "SOM"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0xaf

    const/16 v16, 0xaf

    const/16 v17, 0x2

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vO:La/z;

    new-instance v0, La/z;

    const-string v2, "P176"

    const-string v4, "Sri Lanka"

    const-string v5, "SRI"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0xb0

    const/16 v6, 0xb0

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vP:La/z;

    new-instance v0, La/z;

    const-string v12, "P177"

    const-string v14, "Suazil\u00e2ndia"

    const-string v15, "SUA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zs:[I

    const/16 v13, 0xb1

    const/16 v16, 0xb1

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vQ:La/z;

    new-instance v0, La/z;

    const-string v2, "P178"

    const-string v4, "Sud\u00e3o"

    const-string v5, "SUD"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zn:[I

    const/16 v3, 0xb2

    const/16 v6, 0xb2

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vR:La/z;

    new-instance v0, La/z;

    const-string v12, "P179"

    const-string v14, "Su\u00e9cia"

    const-string v15, "SUE"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zu:[I

    const/16 v13, 0xb3

    const/16 v16, 0xb3

    const/16 v17, 0x0

    const/16 v18, 0x13

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vS:La/z;

    new-instance v0, La/z;

    const-string v2, "P180"

    const-string v4, "Sui\u00e7a"

    const-string v5, "SUI"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xb4

    const/16 v6, 0xb4

    const/4 v7, 0x0

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vT:La/z;

    new-instance v0, La/z;

    const-string v12, "P181"

    const-string v14, "Suriname"

    const-string v15, "SUR"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0xb5

    const/16 v16, 0xb5

    const/16 v17, 0x4

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vU:La/z;

    new-instance v0, La/z;

    const-string v2, "P182"

    const-string v4, "Tadjquist\u00e3o"

    const-string v5, "TAD"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xb6

    const/16 v6, 0xb6

    const/4 v7, 0x3

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vV:La/z;

    new-instance v0, La/z;

    const-string v12, "P183"

    const-string v14, "Tail\u00e2ndia"

    const-string v15, "TAI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0xb7

    const/16 v16, 0xb7

    const/16 v17, 0x3

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vW:La/z;

    new-instance v0, La/z;

    const-string v2, "P184"

    const-string v4, "Taiti"

    const-string v5, "TTI"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xb8

    const/16 v6, 0xb8

    const/4 v7, 0x5

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vX:La/z;

    new-instance v0, La/z;

    const-string v12, "P185"

    const-string v14, "Taiwan"

    const-string v15, "TAW"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0xb9

    const/16 v16, 0xb9

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vY:La/z;

    new-instance v0, La/z;

    const-string v2, "P186"

    const-string v4, "T\u00e2nzania"

    const-string v5, "TAN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zn:[I

    const/16 v3, 0xba

    const/16 v6, 0xba

    const/4 v7, 0x2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->vZ:La/z;

    new-instance v0, La/z;

    const-string v12, "P187"

    const-string v14, "Togo"

    const-string v15, "TGO"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0xbb

    const/16 v16, 0xbb

    const/16 v17, 0x2

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wa:La/z;

    new-instance v0, La/z;

    const-string v2, "P188"

    const-string v4, "Tonga"

    const-string v5, "TON"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xbc

    const/16 v6, 0xbc

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wb:La/z;

    new-instance v0, La/z;

    const-string v12, "P189"

    const-string v14, "Trinidad e Tobago"

    const-string v15, "TRT"

    sget-object v19, La/ak;->zn:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0xbd

    const/16 v16, 0xbd

    const/16 v17, 0x4

    const/16 v18, 0xf

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wc:La/z;

    new-instance v0, La/z;

    const-string v2, "P190"

    const-string v4, "Tun\u00edsia"

    const-string v5, "TUN"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xbe

    const/16 v6, 0xbe

    const/16 v8, 0x10

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wd:La/z;

    new-instance v0, La/z;

    const-string v12, "P191"

    const-string v14, "Turcomenist\u00e3o"

    const-string v15, "TCM"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0xbf

    const/16 v16, 0xbf

    const/16 v17, 0x3

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->we:La/z;

    new-instance v0, La/z;

    const-string v2, "P192"

    const-string v4, "Turquia"

    const-string v5, "TUR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xc0

    const/16 v6, 0xc0

    const/4 v7, 0x0

    const/16 v8, 0x12

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wf:La/z;

    new-instance v0, La/z;

    const-string v12, "P193"

    const-string v14, "Ucr\u00e2nia"

    const-string v15, "UCR"

    sget-object v19, La/ak;->zE:[I

    sget-object v20, La/ak;->zw:[I

    const/16 v13, 0xc1

    const/16 v16, 0xc1

    const/16 v17, 0x0

    const/16 v18, 0x12

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wg:La/z;

    new-instance v0, La/z;

    const-string v2, "P194"

    const-string v4, "Uganda"

    const-string v5, "UGA"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zn:[I

    const/16 v3, 0xc2

    const/16 v6, 0xc2

    const/4 v7, 0x2

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wh:La/z;

    new-instance v0, La/z;

    const-string v12, "P195"

    const-string v14, "Uruguai"

    const-string v15, "URU"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xc3

    const/16 v16, 0xc3

    const/16 v17, 0x1

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wi:La/z;

    new-instance v0, La/z;

    const-string v2, "P196"

    const-string v4, "Uzbequist\u00e3o"

    const-string v5, "UZB"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0xc4

    const/16 v6, 0xc4

    const/4 v7, 0x3

    const/16 v8, 0x11

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wj:La/z;

    new-instance v0, La/z;

    const-string v12, "P197"

    const-string v14, "Vanuatu"

    const-string v15, "VAN"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0xc5

    const/16 v16, 0xc5

    const/16 v17, 0x5

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wk:La/z;

    new-instance v0, La/z;

    const-string v2, "P198"

    const-string v4, "Venezuela"

    const-string v5, "VEN"

    sget-object v9, La/ak;->zE:[I

    sget-object v10, La/ak;->zp:[I

    const/16 v3, 0xc6

    const/16 v6, 0xc6

    const/4 v7, 0x1

    const/16 v8, 0xf

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wl:La/z;

    new-instance v0, La/z;

    const-string v12, "P199"

    const-string v14, "Vietn\u00e3"

    const-string v15, "VIE"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zp:[I

    const/16 v13, 0xc7

    const/16 v16, 0xc7

    const/16 v17, 0x3

    const/16 v18, 0xe

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wm:La/z;

    new-instance v0, La/z;

    const-string v2, "P200"

    const-string v4, "Z\u00e2mbia"

    const-string v5, "ZAM"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0xc8

    const/16 v6, 0xc8

    const/4 v7, 0x2

    const/16 v8, 0xe

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wn:La/z;

    new-instance v0, La/z;

    const-string v12, "P201"

    const-string v14, "Zimbabwe"

    const-string v15, "ZIM"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zB:[I

    const/16 v13, 0xc9

    const/16 v16, 0xc9

    const/16 v17, 0x2

    const/16 v18, 0xd

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wo:La/z;

    new-instance v0, La/z;

    const-string v2, "P202"

    const-string v4, "Ilhas Comores"

    const-string v5, "ICM"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0xca

    const/16 v6, 0xca

    const/16 v8, 0xd

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wp:La/z;

    new-instance v0, La/z;

    const-string v12, "P203"

    const-string v14, "Micron\u00e9sia"

    const-string v15, "MIC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xcb

    const/16 v16, 0xcb

    const/16 v17, 0x5

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wq:La/z;

    new-instance v0, La/z;

    const-string v2, "P204"

    const-string v4, "Ilhas Marshall"

    const-string v5, "IMA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0xcc

    const/16 v6, 0xcc

    const/4 v7, 0x5

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wr:La/z;

    new-instance v0, La/z;

    const-string v12, "P205"

    const-string v14, "Ilhas Maur\u00edcio"

    const-string v15, "IMR"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xcd

    const/16 v16, 0xcd

    const/16 v17, 0x2

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ws:La/z;

    new-instance v0, La/z;

    const-string v2, "P206"

    const-string v4, "Nauru"

    const-string v5, "NAU"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0xce

    const/16 v6, 0xce

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wt:La/z;

    new-instance v0, La/z;

    const-string v12, "P207"

    const-string v14, "Palau"

    const-string v15, "PLU"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xcf

    const/16 v16, 0xcf

    const/16 v17, 0x5

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wu:La/z;

    new-instance v0, La/z;

    const-string v2, "P208"

    const-string v4, "Kiribati"

    const-string v5, "KIR"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0xd0

    const/16 v6, 0xd0

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wv:La/z;

    new-instance v0, La/z;

    const-string v12, "P209"

    const-string v14, "Sud\u00e3o do Sul"

    const-string v15, "SUS"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zn:[I

    const/16 v13, 0xd1

    const/16 v16, 0xd1

    const/16 v17, 0x2

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->ww:La/z;

    new-instance v0, La/z;

    const-string v2, "P210"

    const-string v4, "Tuvalu"

    const-string v5, "TUV"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0xd2

    const/16 v6, 0xd2

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wx:La/z;

    new-instance v0, La/z;

    const-string v12, "P211"

    const-string v14, "Ilhas Virgens Americanas"

    const-string v15, "IVA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xd3

    const/16 v16, 0xd3

    const/16 v17, 0x4

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wy:La/z;

    new-instance v0, La/z;

    const-string v2, "P212"

    const-string v4, "Montserrat"

    const-string v5, "MST"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zw:[I

    const/16 v3, 0xd4

    const/16 v6, 0xd4

    const/4 v7, 0x4

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wz:La/z;

    new-instance v0, La/z;

    const-string v12, "P213"

    const-string v14, "Ilhas Turks e Caicos"

    const-string v15, "ITC"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zw:[I

    const/16 v13, 0xd5

    const/16 v16, 0xd5

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wA:La/z;

    new-instance v0, La/z;

    const-string v2, "P214"

    const-string v4, "Samoa Americana"

    const-string v5, "SME"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zt:[I

    const/16 v3, 0xd6

    const/16 v6, 0xd6

    const/4 v7, 0x5

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wB:La/z;

    new-instance v0, La/z;

    const-string v12, "P215"

    const-string v14, "Nova Caled\u00f4nia"

    const-string v15, "NCA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zo:[I

    const/16 v13, 0xd7

    const/16 v16, 0xd7

    const/16 v17, 0x5

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wC:La/z;

    new-instance v0, La/z;

    const-string v2, "P216"

    const-string v4, "Gibraltar"

    const-string v5, "GIB"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zo:[I

    const/16 v3, 0xd8

    const/16 v6, 0xd8

    const/4 v7, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wD:La/z;

    new-instance v0, La/z;

    const-string v12, "P217"

    const-string v14, "Guadalupe"

    const-string v15, "GDA"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zA:[I

    const/16 v13, 0xd9

    const/16 v16, 0xd9

    const/16 v17, 0x4

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wE:La/z;

    new-instance v0, La/z;

    const-string v2, "P218"

    const-string v4, "Guam"

    const-string v5, "GMA"

    sget-object v9, La/ak;->zm:[I

    sget-object v10, La/ak;->zv:[I

    const/16 v3, 0xda

    const/16 v6, 0xda

    const/4 v7, 0x5

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wF:La/z;

    new-instance v0, La/z;

    const-string v12, "P219"

    const-string v14, "Martinica"

    const-string v15, "MTI"

    sget-object v19, La/ak;->zm:[I

    sget-object v20, La/ak;->zv:[I

    const/16 v13, 0xdb

    const/16 v16, 0xdb

    move-object v11, v0

    invoke-direct/range {v11 .. v20}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wG:La/z;

    new-instance v0, La/z;

    const-string v2, "P220"

    const-string v4, "Guiana Francesa"

    const-string v5, "GFR"

    sget-object v9, La/ak;->zC:[I

    sget-object v10, La/ak;->zB:[I

    const/16 v3, 0xdc

    const/16 v6, 0xdc

    const/4 v7, 0x4

    move-object v1, v0

    invoke-direct/range {v1 .. v10}, La/z;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V

    sput-object v0, La/z;->wH:La/z;

    const/16 v0, 0xdd

    new-array v0, v0, [La/z;

    sget-object v1, La/z;->su:La/z;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, La/z;->sv:La/z;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    sget-object v1, La/z;->sw:La/z;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    sget-object v1, La/z;->sx:La/z;

    const/4 v2, 0x3

    aput-object v1, v0, v2

    sget-object v1, La/z;->sy:La/z;

    const/4 v2, 0x4

    aput-object v1, v0, v2

    sget-object v1, La/z;->sz:La/z;

    const/4 v2, 0x5

    aput-object v1, v0, v2

    sget-object v1, La/z;->sA:La/z;

    const/4 v2, 0x6

    aput-object v1, v0, v2

    sget-object v1, La/z;->sB:La/z;

    const/4 v2, 0x7

    aput-object v1, v0, v2

    sget-object v1, La/z;->sC:La/z;

    const/16 v2, 0x8

    aput-object v1, v0, v2

    sget-object v1, La/z;->sD:La/z;

    const/16 v2, 0x9

    aput-object v1, v0, v2

    sget-object v1, La/z;->sE:La/z;

    const/16 v2, 0xa

    aput-object v1, v0, v2

    sget-object v1, La/z;->sF:La/z;

    const/16 v2, 0xb

    aput-object v1, v0, v2

    sget-object v1, La/z;->sG:La/z;

    const/16 v2, 0xc

    aput-object v1, v0, v2

    sget-object v1, La/z;->sH:La/z;

    const/16 v2, 0xd

    aput-object v1, v0, v2

    sget-object v1, La/z;->sI:La/z;

    const/16 v2, 0xe

    aput-object v1, v0, v2

    sget-object v1, La/z;->sJ:La/z;

    const/16 v2, 0xf

    aput-object v1, v0, v2

    sget-object v1, La/z;->sK:La/z;

    const/16 v2, 0x10

    aput-object v1, v0, v2

    sget-object v1, La/z;->sL:La/z;

    const/16 v2, 0x11

    aput-object v1, v0, v2

    sget-object v1, La/z;->sM:La/z;

    const/16 v2, 0x12

    aput-object v1, v0, v2

    sget-object v1, La/z;->sN:La/z;

    const/16 v2, 0x13

    aput-object v1, v0, v2

    sget-object v1, La/z;->sO:La/z;

    const/16 v2, 0x14

    aput-object v1, v0, v2

    sget-object v1, La/z;->sP:La/z;

    const/16 v2, 0x15

    aput-object v1, v0, v2

    sget-object v1, La/z;->sQ:La/z;

    const/16 v2, 0x16

    aput-object v1, v0, v2

    sget-object v1, La/z;->sR:La/z;

    const/16 v2, 0x17

    aput-object v1, v0, v2

    sget-object v1, La/z;->sS:La/z;

    const/16 v2, 0x18

    aput-object v1, v0, v2

    sget-object v1, La/z;->sT:La/z;

    const/16 v2, 0x19

    aput-object v1, v0, v2

    sget-object v1, La/z;->sU:La/z;

    const/16 v2, 0x1a

    aput-object v1, v0, v2

    sget-object v1, La/z;->sV:La/z;

    const/16 v2, 0x1b

    aput-object v1, v0, v2

    sget-object v1, La/z;->sW:La/z;

    const/16 v2, 0x1c

    aput-object v1, v0, v2

    sget-object v1, La/z;->sX:La/z;

    const/16 v2, 0x1d

    aput-object v1, v0, v2

    sget-object v1, La/z;->sY:La/z;

    const/16 v2, 0x1e

    aput-object v1, v0, v2

    sget-object v1, La/z;->sZ:La/z;

    const/16 v2, 0x1f

    aput-object v1, v0, v2

    sget-object v1, La/z;->ta:La/z;

    const/16 v2, 0x20

    aput-object v1, v0, v2

    sget-object v1, La/z;->tb:La/z;

    const/16 v2, 0x21

    aput-object v1, v0, v2

    sget-object v1, La/z;->td:La/z;

    const/16 v2, 0x22

    aput-object v1, v0, v2

    sget-object v1, La/z;->te:La/z;

    const/16 v2, 0x23

    aput-object v1, v0, v2

    sget-object v1, La/z;->tf:La/z;

    const/16 v2, 0x24

    aput-object v1, v0, v2

    sget-object v1, La/z;->tg:La/z;

    const/16 v2, 0x25

    aput-object v1, v0, v2

    sget-object v1, La/z;->th:La/z;

    const/16 v2, 0x26

    aput-object v1, v0, v2

    sget-object v1, La/z;->ti:La/z;

    const/16 v2, 0x27

    aput-object v1, v0, v2

    sget-object v1, La/z;->tj:La/z;

    const/16 v2, 0x28

    aput-object v1, v0, v2

    sget-object v1, La/z;->tk:La/z;

    const/16 v2, 0x29

    aput-object v1, v0, v2

    sget-object v1, La/z;->tl:La/z;

    const/16 v2, 0x2a

    aput-object v1, v0, v2

    sget-object v1, La/z;->tm:La/z;

    const/16 v2, 0x2b

    aput-object v1, v0, v2

    sget-object v1, La/z;->tn:La/z;

    const/16 v2, 0x2c

    aput-object v1, v0, v2

    sget-object v1, La/z;->to:La/z;

    const/16 v2, 0x2d

    aput-object v1, v0, v2

    sget-object v1, La/z;->tp:La/z;

    const/16 v2, 0x2e

    aput-object v1, v0, v2

    sget-object v1, La/z;->tq:La/z;

    const/16 v2, 0x2f

    aput-object v1, v0, v2

    sget-object v1, La/z;->tr:La/z;

    const/16 v2, 0x30

    aput-object v1, v0, v2

    sget-object v1, La/z;->ts:La/z;

    const/16 v2, 0x31

    aput-object v1, v0, v2

    sget-object v1, La/z;->tt:La/z;

    const/16 v2, 0x32

    aput-object v1, v0, v2

    sget-object v1, La/z;->tu:La/z;

    const/16 v2, 0x33

    aput-object v1, v0, v2

    sget-object v1, La/z;->tv:La/z;

    const/16 v2, 0x34

    aput-object v1, v0, v2

    sget-object v1, La/z;->tw:La/z;

    const/16 v2, 0x35

    aput-object v1, v0, v2

    sget-object v1, La/z;->tx:La/z;

    const/16 v2, 0x36

    aput-object v1, v0, v2

    sget-object v1, La/z;->ty:La/z;

    const/16 v2, 0x37

    aput-object v1, v0, v2

    sget-object v1, La/z;->tz:La/z;

    const/16 v2, 0x38

    aput-object v1, v0, v2

    sget-object v1, La/z;->tA:La/z;

    const/16 v2, 0x39

    aput-object v1, v0, v2

    sget-object v1, La/z;->tB:La/z;

    const/16 v2, 0x3a

    aput-object v1, v0, v2

    sget-object v1, La/z;->tC:La/z;

    const/16 v2, 0x3b

    aput-object v1, v0, v2

    sget-object v1, La/z;->tD:La/z;

    const/16 v2, 0x3c

    aput-object v1, v0, v2

    sget-object v1, La/z;->tE:La/z;

    const/16 v2, 0x3d

    aput-object v1, v0, v2

    sget-object v1, La/z;->tF:La/z;

    const/16 v2, 0x3e

    aput-object v1, v0, v2

    sget-object v1, La/z;->tG:La/z;

    const/16 v2, 0x3f

    aput-object v1, v0, v2

    sget-object v1, La/z;->tH:La/z;

    const/16 v2, 0x40

    aput-object v1, v0, v2

    sget-object v1, La/z;->tI:La/z;

    const/16 v2, 0x41

    aput-object v1, v0, v2

    sget-object v1, La/z;->tJ:La/z;

    const/16 v2, 0x42

    aput-object v1, v0, v2

    sget-object v1, La/z;->tK:La/z;

    const/16 v2, 0x43

    aput-object v1, v0, v2

    sget-object v1, La/z;->tL:La/z;

    const/16 v2, 0x44

    aput-object v1, v0, v2

    sget-object v1, La/z;->tM:La/z;

    const/16 v2, 0x45

    aput-object v1, v0, v2

    sget-object v1, La/z;->tN:La/z;

    const/16 v2, 0x46

    aput-object v1, v0, v2

    sget-object v1, La/z;->tO:La/z;

    const/16 v2, 0x47

    aput-object v1, v0, v2

    sget-object v1, La/z;->tP:La/z;

    const/16 v2, 0x48

    aput-object v1, v0, v2

    sget-object v1, La/z;->tQ:La/z;

    const/16 v2, 0x49

    aput-object v1, v0, v2

    sget-object v1, La/z;->tR:La/z;

    const/16 v2, 0x4a

    aput-object v1, v0, v2

    sget-object v1, La/z;->tS:La/z;

    const/16 v2, 0x4b

    aput-object v1, v0, v2

    sget-object v1, La/z;->tT:La/z;

    const/16 v2, 0x4c

    aput-object v1, v0, v2

    sget-object v1, La/z;->tU:La/z;

    const/16 v2, 0x4d

    aput-object v1, v0, v2

    sget-object v1, La/z;->tV:La/z;

    const/16 v2, 0x4e

    aput-object v1, v0, v2

    sget-object v1, La/z;->tW:La/z;

    const/16 v2, 0x4f

    aput-object v1, v0, v2

    sget-object v1, La/z;->tX:La/z;

    const/16 v2, 0x50

    aput-object v1, v0, v2

    sget-object v1, La/z;->tY:La/z;

    const/16 v2, 0x51

    aput-object v1, v0, v2

    sget-object v1, La/z;->tZ:La/z;

    const/16 v2, 0x52

    aput-object v1, v0, v2

    sget-object v1, La/z;->ua:La/z;

    const/16 v2, 0x53

    aput-object v1, v0, v2

    sget-object v1, La/z;->ub:La/z;

    const/16 v2, 0x54

    aput-object v1, v0, v2

    sget-object v1, La/z;->uc:La/z;

    const/16 v2, 0x55

    aput-object v1, v0, v2

    sget-object v1, La/z;->ud:La/z;

    const/16 v2, 0x56

    aput-object v1, v0, v2

    sget-object v1, La/z;->ue:La/z;

    const/16 v2, 0x57

    aput-object v1, v0, v2

    sget-object v1, La/z;->uf:La/z;

    const/16 v2, 0x58

    aput-object v1, v0, v2

    sget-object v1, La/z;->ug:La/z;

    const/16 v2, 0x59

    aput-object v1, v0, v2

    sget-object v1, La/z;->uh:La/z;

    const/16 v2, 0x5a

    aput-object v1, v0, v2

    sget-object v1, La/z;->ui:La/z;

    const/16 v2, 0x5b

    aput-object v1, v0, v2

    sget-object v1, La/z;->uj:La/z;

    const/16 v2, 0x5c

    aput-object v1, v0, v2

    sget-object v1, La/z;->uk:La/z;

    const/16 v2, 0x5d

    aput-object v1, v0, v2

    sget-object v1, La/z;->ul:La/z;

    const/16 v2, 0x5e

    aput-object v1, v0, v2

    sget-object v1, La/z;->um:La/z;

    const/16 v2, 0x5f

    aput-object v1, v0, v2

    sget-object v1, La/z;->un:La/z;

    const/16 v2, 0x60

    aput-object v1, v0, v2

    sget-object v1, La/z;->uo:La/z;

    const/16 v2, 0x61

    aput-object v1, v0, v2

    sget-object v1, La/z;->up:La/z;

    const/16 v2, 0x62

    aput-object v1, v0, v2

    sget-object v1, La/z;->uq:La/z;

    const/16 v2, 0x63

    aput-object v1, v0, v2

    sget-object v1, La/z;->ur:La/z;

    const/16 v2, 0x64

    aput-object v1, v0, v2

    sget-object v1, La/z;->us:La/z;

    const/16 v2, 0x65

    aput-object v1, v0, v2

    sget-object v1, La/z;->ut:La/z;

    const/16 v2, 0x66

    aput-object v1, v0, v2

    sget-object v1, La/z;->uu:La/z;

    const/16 v2, 0x67

    aput-object v1, v0, v2

    sget-object v1, La/z;->uv:La/z;

    const/16 v2, 0x68

    aput-object v1, v0, v2

    sget-object v1, La/z;->uw:La/z;

    const/16 v2, 0x69

    aput-object v1, v0, v2

    sget-object v1, La/z;->ux:La/z;

    const/16 v2, 0x6a

    aput-object v1, v0, v2

    sget-object v1, La/z;->uy:La/z;

    const/16 v2, 0x6b

    aput-object v1, v0, v2

    sget-object v1, La/z;->uz:La/z;

    const/16 v2, 0x6c

    aput-object v1, v0, v2

    sget-object v1, La/z;->uA:La/z;

    const/16 v2, 0x6d

    aput-object v1, v0, v2

    sget-object v1, La/z;->uB:La/z;

    const/16 v2, 0x6e

    aput-object v1, v0, v2

    sget-object v1, La/z;->uC:La/z;

    const/16 v2, 0x6f

    aput-object v1, v0, v2

    sget-object v1, La/z;->uD:La/z;

    const/16 v2, 0x70

    aput-object v1, v0, v2

    sget-object v1, La/z;->uE:La/z;

    const/16 v2, 0x71

    aput-object v1, v0, v2

    sget-object v1, La/z;->uF:La/z;

    const/16 v2, 0x72

    aput-object v1, v0, v2

    sget-object v1, La/z;->uG:La/z;

    const/16 v2, 0x73

    aput-object v1, v0, v2

    sget-object v1, La/z;->uH:La/z;

    const/16 v2, 0x74

    aput-object v1, v0, v2

    sget-object v1, La/z;->uI:La/z;

    const/16 v2, 0x75

    aput-object v1, v0, v2

    sget-object v1, La/z;->uJ:La/z;

    const/16 v2, 0x76

    aput-object v1, v0, v2

    sget-object v1, La/z;->uK:La/z;

    const/16 v2, 0x77

    aput-object v1, v0, v2

    sget-object v1, La/z;->uL:La/z;

    const/16 v2, 0x78

    aput-object v1, v0, v2

    sget-object v1, La/z;->uM:La/z;

    const/16 v2, 0x79

    aput-object v1, v0, v2

    sget-object v1, La/z;->uN:La/z;

    const/16 v2, 0x7a

    aput-object v1, v0, v2

    sget-object v1, La/z;->uO:La/z;

    const/16 v2, 0x7b

    aput-object v1, v0, v2

    sget-object v1, La/z;->uP:La/z;

    const/16 v2, 0x7c

    aput-object v1, v0, v2

    sget-object v1, La/z;->uQ:La/z;

    const/16 v2, 0x7d

    aput-object v1, v0, v2

    sget-object v1, La/z;->uR:La/z;

    const/16 v2, 0x7e

    aput-object v1, v0, v2

    sget-object v1, La/z;->uS:La/z;

    const/16 v2, 0x7f

    aput-object v1, v0, v2

    sget-object v1, La/z;->uT:La/z;

    const/16 v2, 0x80

    aput-object v1, v0, v2

    sget-object v1, La/z;->uU:La/z;

    const/16 v2, 0x81

    aput-object v1, v0, v2

    sget-object v1, La/z;->uV:La/z;

    const/16 v2, 0x82

    aput-object v1, v0, v2

    sget-object v1, La/z;->uW:La/z;

    const/16 v2, 0x83

    aput-object v1, v0, v2

    sget-object v1, La/z;->uX:La/z;

    const/16 v2, 0x84

    aput-object v1, v0, v2

    sget-object v1, La/z;->uY:La/z;

    const/16 v2, 0x85

    aput-object v1, v0, v2

    sget-object v1, La/z;->uZ:La/z;

    const/16 v2, 0x86

    aput-object v1, v0, v2

    sget-object v1, La/z;->va:La/z;

    const/16 v2, 0x87

    aput-object v1, v0, v2

    sget-object v1, La/z;->vb:La/z;

    const/16 v2, 0x88

    aput-object v1, v0, v2

    sget-object v1, La/z;->vc:La/z;

    const/16 v2, 0x89

    aput-object v1, v0, v2

    sget-object v1, La/z;->vd:La/z;

    const/16 v2, 0x8a

    aput-object v1, v0, v2

    sget-object v1, La/z;->ve:La/z;

    const/16 v2, 0x8b

    aput-object v1, v0, v2

    sget-object v1, La/z;->vf:La/z;

    const/16 v2, 0x8c

    aput-object v1, v0, v2

    sget-object v1, La/z;->vg:La/z;

    const/16 v2, 0x8d

    aput-object v1, v0, v2

    sget-object v1, La/z;->vh:La/z;

    const/16 v2, 0x8e

    aput-object v1, v0, v2

    sget-object v1, La/z;->vi:La/z;

    const/16 v2, 0x8f

    aput-object v1, v0, v2

    sget-object v1, La/z;->vj:La/z;

    const/16 v2, 0x90

    aput-object v1, v0, v2

    sget-object v1, La/z;->vk:La/z;

    const/16 v2, 0x91

    aput-object v1, v0, v2

    sget-object v1, La/z;->vl:La/z;

    const/16 v2, 0x92

    aput-object v1, v0, v2

    sget-object v1, La/z;->vm:La/z;

    const/16 v2, 0x93

    aput-object v1, v0, v2

    sget-object v1, La/z;->vn:La/z;

    const/16 v2, 0x94

    aput-object v1, v0, v2

    sget-object v1, La/z;->vo:La/z;

    const/16 v2, 0x95

    aput-object v1, v0, v2

    sget-object v1, La/z;->vp:La/z;

    const/16 v2, 0x96

    aput-object v1, v0, v2

    sget-object v1, La/z;->vq:La/z;

    const/16 v2, 0x97

    aput-object v1, v0, v2

    sget-object v1, La/z;->vr:La/z;

    const/16 v2, 0x98

    aput-object v1, v0, v2

    sget-object v1, La/z;->vs:La/z;

    const/16 v2, 0x99

    aput-object v1, v0, v2

    sget-object v1, La/z;->vt:La/z;

    const/16 v2, 0x9a

    aput-object v1, v0, v2

    sget-object v1, La/z;->vu:La/z;

    const/16 v2, 0x9b

    aput-object v1, v0, v2

    sget-object v1, La/z;->vv:La/z;

    const/16 v2, 0x9c

    aput-object v1, v0, v2

    sget-object v1, La/z;->vw:La/z;

    const/16 v2, 0x9d

    aput-object v1, v0, v2

    sget-object v1, La/z;->vx:La/z;

    const/16 v2, 0x9e

    aput-object v1, v0, v2

    sget-object v1, La/z;->vy:La/z;

    const/16 v2, 0x9f

    aput-object v1, v0, v2

    sget-object v1, La/z;->vz:La/z;

    const/16 v2, 0xa0

    aput-object v1, v0, v2

    sget-object v1, La/z;->vA:La/z;

    const/16 v2, 0xa1

    aput-object v1, v0, v2

    sget-object v1, La/z;->vB:La/z;

    const/16 v2, 0xa2

    aput-object v1, v0, v2

    sget-object v1, La/z;->vC:La/z;

    const/16 v2, 0xa3

    aput-object v1, v0, v2

    sget-object v1, La/z;->vD:La/z;

    const/16 v2, 0xa4

    aput-object v1, v0, v2

    sget-object v1, La/z;->vE:La/z;

    const/16 v2, 0xa5

    aput-object v1, v0, v2

    sget-object v1, La/z;->vF:La/z;

    const/16 v2, 0xa6

    aput-object v1, v0, v2

    sget-object v1, La/z;->vG:La/z;

    const/16 v2, 0xa7

    aput-object v1, v0, v2

    sget-object v1, La/z;->vH:La/z;

    const/16 v2, 0xa8

    aput-object v1, v0, v2

    sget-object v1, La/z;->vI:La/z;

    const/16 v2, 0xa9

    aput-object v1, v0, v2

    sget-object v1, La/z;->vJ:La/z;

    const/16 v2, 0xaa

    aput-object v1, v0, v2

    sget-object v1, La/z;->vK:La/z;

    const/16 v2, 0xab

    aput-object v1, v0, v2

    sget-object v1, La/z;->vL:La/z;

    const/16 v2, 0xac

    aput-object v1, v0, v2

    sget-object v1, La/z;->vM:La/z;

    const/16 v2, 0xad

    aput-object v1, v0, v2

    sget-object v1, La/z;->vN:La/z;

    const/16 v2, 0xae

    aput-object v1, v0, v2

    sget-object v1, La/z;->vO:La/z;

    const/16 v2, 0xaf

    aput-object v1, v0, v2

    sget-object v1, La/z;->vP:La/z;

    const/16 v2, 0xb0

    aput-object v1, v0, v2

    sget-object v1, La/z;->vQ:La/z;

    const/16 v2, 0xb1

    aput-object v1, v0, v2

    sget-object v1, La/z;->vR:La/z;

    const/16 v2, 0xb2

    aput-object v1, v0, v2

    sget-object v1, La/z;->vS:La/z;

    const/16 v2, 0xb3

    aput-object v1, v0, v2

    sget-object v1, La/z;->vT:La/z;

    const/16 v2, 0xb4

    aput-object v1, v0, v2

    sget-object v1, La/z;->vU:La/z;

    const/16 v2, 0xb5

    aput-object v1, v0, v2

    sget-object v1, La/z;->vV:La/z;

    const/16 v2, 0xb6

    aput-object v1, v0, v2

    sget-object v1, La/z;->vW:La/z;

    const/16 v2, 0xb7

    aput-object v1, v0, v2

    sget-object v1, La/z;->vX:La/z;

    const/16 v2, 0xb8

    aput-object v1, v0, v2

    sget-object v1, La/z;->vY:La/z;

    const/16 v2, 0xb9

    aput-object v1, v0, v2

    sget-object v1, La/z;->vZ:La/z;

    const/16 v2, 0xba

    aput-object v1, v0, v2

    sget-object v1, La/z;->wa:La/z;

    const/16 v2, 0xbb

    aput-object v1, v0, v2

    sget-object v1, La/z;->wb:La/z;

    const/16 v2, 0xbc

    aput-object v1, v0, v2

    sget-object v1, La/z;->wc:La/z;

    const/16 v2, 0xbd

    aput-object v1, v0, v2

    sget-object v1, La/z;->wd:La/z;

    const/16 v2, 0xbe

    aput-object v1, v0, v2

    sget-object v1, La/z;->we:La/z;

    const/16 v2, 0xbf

    aput-object v1, v0, v2

    sget-object v1, La/z;->wf:La/z;

    const/16 v2, 0xc0

    aput-object v1, v0, v2

    sget-object v1, La/z;->wg:La/z;

    const/16 v2, 0xc1

    aput-object v1, v0, v2

    sget-object v1, La/z;->wh:La/z;

    const/16 v2, 0xc2

    aput-object v1, v0, v2

    sget-object v1, La/z;->wi:La/z;

    const/16 v2, 0xc3

    aput-object v1, v0, v2

    sget-object v1, La/z;->wj:La/z;

    const/16 v2, 0xc4

    aput-object v1, v0, v2

    sget-object v1, La/z;->wk:La/z;

    const/16 v2, 0xc5

    aput-object v1, v0, v2

    sget-object v1, La/z;->wl:La/z;

    const/16 v2, 0xc6

    aput-object v1, v0, v2

    sget-object v1, La/z;->wm:La/z;

    const/16 v2, 0xc7

    aput-object v1, v0, v2

    sget-object v1, La/z;->wn:La/z;

    const/16 v2, 0xc8

    aput-object v1, v0, v2

    sget-object v1, La/z;->wo:La/z;

    const/16 v2, 0xc9

    aput-object v1, v0, v2

    sget-object v1, La/z;->wp:La/z;

    const/16 v2, 0xca

    aput-object v1, v0, v2

    sget-object v1, La/z;->wq:La/z;

    const/16 v2, 0xcb

    aput-object v1, v0, v2

    sget-object v1, La/z;->wr:La/z;

    const/16 v2, 0xcc

    aput-object v1, v0, v2

    sget-object v1, La/z;->ws:La/z;

    const/16 v2, 0xcd

    aput-object v1, v0, v2

    sget-object v1, La/z;->wt:La/z;

    const/16 v2, 0xce

    aput-object v1, v0, v2

    sget-object v1, La/z;->wu:La/z;

    const/16 v2, 0xcf

    aput-object v1, v0, v2

    sget-object v1, La/z;->wv:La/z;

    const/16 v2, 0xd0

    aput-object v1, v0, v2

    sget-object v1, La/z;->ww:La/z;

    const/16 v2, 0xd1

    aput-object v1, v0, v2

    sget-object v1, La/z;->wx:La/z;

    const/16 v2, 0xd2

    aput-object v1, v0, v2

    sget-object v1, La/z;->wy:La/z;

    const/16 v2, 0xd3

    aput-object v1, v0, v2

    sget-object v1, La/z;->wz:La/z;

    const/16 v2, 0xd4

    aput-object v1, v0, v2

    sget-object v1, La/z;->wA:La/z;

    const/16 v2, 0xd5

    aput-object v1, v0, v2

    sget-object v1, La/z;->wB:La/z;

    const/16 v2, 0xd6

    aput-object v1, v0, v2

    sget-object v1, La/z;->wC:La/z;

    const/16 v2, 0xd7

    aput-object v1, v0, v2

    sget-object v1, La/z;->wD:La/z;

    const/16 v2, 0xd8

    aput-object v1, v0, v2

    sget-object v1, La/z;->wE:La/z;

    const/16 v2, 0xd9

    aput-object v1, v0, v2

    sget-object v1, La/z;->wF:La/z;

    const/16 v2, 0xda

    aput-object v1, v0, v2

    sget-object v1, La/z;->wG:La/z;

    const/16 v2, 0xdb

    aput-object v1, v0, v2

    sget-object v1, La/z;->wH:La/z;

    const/16 v2, 0xdc

    aput-object v1, v0, v2

    sput-object v0, La/z;->wM:[La/z;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;III[I[I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "III[I[I)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, La/z;->pq:Ljava/lang/String;

    iput-object p4, p0, La/z;->wI:Ljava/lang/String;

    iput p5, p0, La/z;->id:I

    iput p6, p0, La/z;->wJ:I

    iput p7, p0, La/z;->so:I

    iput-object p8, p0, La/z;->wK:[I

    iput-object p9, p0, La/z;->wL:[I

    return-void
.end method

.method public static bM(I)V
    .locals 0

    return-void
.end method

.method public static lj()I
    .locals 1

    const/16 v0, 0xdd

    return v0
.end method

.method public static valueOf(Ljava/lang/String;)La/z;
    .locals 1

    const-class v0, La/z;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La/z;

    return-object p0
.end method

.method public static values()[La/z;
    .locals 1

    sget-object v0, La/z;->wM:[La/z;

    invoke-virtual {v0}, [La/z;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La/z;

    return-object v0
.end method


# virtual methods
.method public getId()I
    .locals 1

    iget v0, p0, La/z;->id:I

    return v0
.end method

.method public getNivel()I
    .locals 1

    iget v0, p0, La/z;->so:I

    return v0
.end method

.method public getNome()Ljava/lang/String;
    .locals 2

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iget v1, p0, La/z;->id:I

    aget-object v0, v0, v1

    return-object v0
.end method

.method public iw()I
    .locals 1

    iget v0, p0, La/z;->wJ:I

    return v0
.end method

.method public lk()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/z;->wI:Ljava/lang/String;

    return-object v0
.end method

.method public ll()[I
    .locals 1

    iget-object v0, p0, La/z;->wK:[I

    return-object v0
.end method

.method public lm()[I
    .locals 1

    iget-object v0, p0, La/z;->wL:[I

    return-object v0
.end method
