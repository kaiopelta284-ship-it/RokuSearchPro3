.class public final La/ak;
.super Ljava/lang/Object;


# static fields
.field public static final AA:I = 0x1d4c0

.field public static final AB:[Z

.field public static final AC:I = 0xa

.field public static final AD:I = 0x12

.field public static final AE:I = 0x1e

.field public static final AF:I = 0xf

.field public static final AG:I = 0x1c

.field public static final AH:[I

.field public static final AI:[[I

.field public static final AJ:[I

.field public static final AK:[I

.field public static final AL:[[I

.field public static final AM:[I

.field public static final AN:[[I

.field public static final AO:[I

.field public static final AP:[[I

.field public static final AQ:[[J

.field public static final AR:[[I

.field public static final AS:[[I

.field public static final AT:[[I

.field public static final AU:[I

.field public static final AV:[[I

.field public static final AW:[I

.field public static final AX:[[I

.field public static final AY:[Ljava/lang/String;

.field public static final AZ:[[I

.field public static final Aa:I = 0x4

.field public static final Ab:[Ljava/lang/String;

.field public static final Ac:I = 0x0

.field public static final Ad:I = 0x1

.field public static final Ae:I = 0x5

.field public static final Af:I = 0xa

.field public static final Ag:I = 0xb

.field public static final Ah:I = 0x0

.field public static final Ai:I = 0x1

.field public static final Aj:I = 0x2

.field public static final Ak:I = 0x3

.field public static final Al:I = 0x4

.field public static final Am:I = 0x5

.field public static final An:I = 0x7

.field public static final Ao:[I

.field public static final Ap:[Ljava/lang/String;

.field public static final Aq:[Ljava/lang/String;

.field public static final Ar:[Ljava/lang/String;

.field public static final As:[Ljava/lang/String;

.field public static final At:[I

.field public static final Au:[I

.field public static final Av:[I

.field public static final Aw:[I

.field public static final Ax:[I

.field public static final Ay:[Ljava/lang/String;

.field public static final Az:[Ljava/lang/String;

.field public static final BA:I = 0x6

.field public static final BB:I = 0x1e

.field public static final BC:I = 0x1

.field public static final BD:I = 0x2

.field public static final BE:I = 0x3

.field public static final BF:I = 0x4

.field public static final BG:I = 0x5

.field public static final BH:I = 0x6

.field public static final BI:I = 0x7

.field public static final BJ:I = 0x8

.field public static final BK:Ljava/lang/String; = "/teams/escudos/"

.field public static final BL:[Ljava/lang/String;

.field public static final BM:Ljava/lang/String; = "/selecoes/escudos/"

.field public static final BN:[Ljava/lang/String;

.field public static final BO:[Ljava/lang/String;

.field public static final BP:[Ljava/lang/String;

.field public static final BQ:[Ljava/lang/String;

.field public static final BR:[Ljava/lang/String;

.field public static final BS:[Ljava/lang/String;

.field public static BT:[Z = null

.field public static BU:[Z = null

.field public static final BV:[I

.field public static final BX:[Ljava/lang/String;

.field public static final Ba:I = 0xc

.field public static final Bb:I = 0xb

.field public static final Bc:[Ljava/lang/String;

.field public static final Bd:[I

.field public static final Be:[I

.field public static final Bf:[I

.field public static final Bg:[I

.field public static final Bh:[I

.field public static final Bi:[I

.field public static final Bj:[[I

.field public static final Bk:[[I

.field public static final Bl:[Ljava/lang/String;

.field public static final Bm:[Ljava/lang/String;

.field public static final Bn:I = 0x1

.field public static final Bo:I = 0x2

.field public static final Bp:I = 0x3

.field public static final Bq:I = 0x4

.field public static final Br:I = 0x5

.field public static final Bs:I = 0x6

.field public static final Bt:I = 0x7

.field public static final Bu:I = 0x8

.field public static final Bv:I = 0x1

.field public static final Bw:I = 0x2

.field public static final Bx:I = 0x3

.field public static final By:I = 0x4

.field public static final Bz:I = 0x5

.field public static final mb:I = 0x1

.field public static final mc:I = 0x2

.field public static final md:I = 0x3

.field public static final me:I = 0x4

.field public static final mg:I = 0x6

.field public static final mh:I = 0x7

.field public static final mi:I = 0x8

.field public static final mj:I = 0x9

.field public static final yI:I = 0x0

.field public static final yJ:I = 0x1

.field public static final yK:I = 0x2

.field public static final yL:I = 0x3

.field public static final yM:I = 0x4

.field public static final yN:I = 0x4

.field public static final yO:I = -0x1

.field public static final yP:I = 0x2

.field public static final yQ:Ljava/lang/String; = "indCorLista"

.field public static final yR:I = 0x0

.field public static final yS:I = 0x1

.field public static final yT:I = 0x7e9

.field public static final yU:I = 0x7ea

.field public static final yV:[[I

.field public static final yW:[[I

.field public static final yX:[[I

.field public static final yY:[[I

.field public static final yZ:[Ljava/lang/String;

.field public static final zA:[I

.field public static final zB:[I

.field public static final zC:[I

.field public static final zD:[I

.field public static final zE:[I

.field public static final zF:[[[I

.field public static final zG:I = 0x14

.field public static final zH:I = 0x0

.field public static final zI:I = 0x1

.field public static final zJ:I = 0x2

.field public static final zK:I = 0x3

.field public static final zL:I = 0x4

.field public static final zM:I = 0x5

.field public static final zN:I = 0x6

.field public static final zO:I = 0x7

.field public static final zP:I = 0x8

.field public static final zQ:I = 0x9

.field public static final zR:I = 0xa

.field public static final zS:I = 0xb

.field public static final zT:I = 0xc

.field public static final zU:I = 0xd

.field public static final zV:[I

.field public static final zW:[I

.field public static final zX:[Ljava/lang/String;

.field public static final zY:I = 0x8

.field public static final zZ:[Ljava/lang/String;

.field public static final za:[Ljava/lang/String;

.field public static final zb:Ljava/lang/String; = "Qualquer"

.field public static final zc:Ljava/lang/String; = "Internacional"

.field public static final zd:I = 0x0

.field public static final ze:I = 0x1

.field public static final zf:I = 0x2

.field public static final zg:I = 0x3

.field public static final zh:I = 0x4

.field public static final zi:I = 0x5

.field public static final zj:[I

.field public static final zk:[I

.field public static final zl:[I

.field public static final zm:[I

.field public static final zn:[I

.field public static final zo:[I

.field public static final zp:[I

.field public static final zq:[I

.field public static final zr:[I

.field public static final zs:[I

.field public static final zt:[I

.field public static final zu:[I

.field public static final zv:[I

.field public static final zw:[I

.field public static final zx:[I

.field public static final zy:[I

.field public static final zz:[I


# direct methods
.method static constructor <clinit>()V
    .locals 64

    const/4 v0, 0x3

    new-array v1, v0, [[I

    new-array v2, v0, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    aput-object v2, v1, v3

    new-array v2, v0, [I

    fill-array-data v2, :array_1

    const/4 v4, 0x1

    aput-object v2, v1, v4

    new-array v2, v0, [I

    fill-array-data v2, :array_2

    const/4 v5, 0x2

    aput-object v2, v1, v5

    sput-object v1, La/ak;->yV:[[I

    const/4 v1, 0x5

    new-array v2, v1, [[I

    new-array v6, v0, [I

    fill-array-data v6, :array_3

    aput-object v6, v2, v3

    new-array v6, v0, [I

    fill-array-data v6, :array_4

    aput-object v6, v2, v4

    new-array v6, v0, [I

    fill-array-data v6, :array_5

    aput-object v6, v2, v5

    new-array v6, v0, [I

    fill-array-data v6, :array_6

    aput-object v6, v2, v0

    new-array v6, v0, [I

    fill-array-data v6, :array_7

    const/4 v7, 0x4

    aput-object v6, v2, v7

    sput-object v2, La/ak;->yW:[[I

    new-array v2, v7, [[I

    new-array v6, v7, [I

    fill-array-data v6, :array_8

    aput-object v6, v2, v3

    new-array v6, v7, [I

    fill-array-data v6, :array_9

    aput-object v6, v2, v4

    new-array v6, v7, [I

    fill-array-data v6, :array_a

    aput-object v6, v2, v5

    new-array v6, v7, [I

    fill-array-data v6, :array_b

    aput-object v6, v2, v0

    sput-object v2, La/ak;->yX:[[I

    const/16 v2, 0x2d

    new-array v2, v2, [[I

    new-array v6, v5, [I

    fill-array-data v6, :array_c

    aput-object v6, v2, v3

    new-array v6, v5, [I

    fill-array-data v6, :array_d

    aput-object v6, v2, v4

    new-array v6, v5, [I

    fill-array-data v6, :array_e

    aput-object v6, v2, v5

    new-array v6, v5, [I

    fill-array-data v6, :array_f

    aput-object v6, v2, v0

    new-array v6, v5, [I

    fill-array-data v6, :array_10

    aput-object v6, v2, v7

    new-array v6, v5, [I

    fill-array-data v6, :array_11

    aput-object v6, v2, v1

    new-array v6, v5, [I

    fill-array-data v6, :array_12

    const/4 v8, 0x6

    aput-object v6, v2, v8

    new-array v6, v5, [I

    fill-array-data v6, :array_13

    const/4 v9, 0x7

    aput-object v6, v2, v9

    new-array v6, v5, [I

    fill-array-data v6, :array_14

    const/16 v10, 0x8

    aput-object v6, v2, v10

    new-array v6, v5, [I

    fill-array-data v6, :array_15

    const/16 v11, 0x9

    aput-object v6, v2, v11

    new-array v6, v5, [I

    fill-array-data v6, :array_16

    const/16 v12, 0xa

    aput-object v6, v2, v12

    new-array v6, v5, [I

    fill-array-data v6, :array_17

    const/16 v13, 0xb

    aput-object v6, v2, v13

    new-array v6, v5, [I

    fill-array-data v6, :array_18

    const/16 v14, 0xc

    aput-object v6, v2, v14

    new-array v6, v5, [I

    fill-array-data v6, :array_19

    const/16 v15, 0xd

    aput-object v6, v2, v15

    new-array v6, v5, [I

    fill-array-data v6, :array_1a

    const/16 v16, 0xe

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_1b

    const/16 v16, 0xf

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_1c

    const/16 v16, 0x10

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_1d

    const/16 v16, 0x11

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_1e

    const/16 v16, 0x12

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_1f

    const/16 v16, 0x13

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_20

    const/16 v15, 0x14

    aput-object v6, v2, v15

    new-array v6, v5, [I

    fill-array-data v6, :array_21

    const/16 v16, 0x15

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_22

    const/16 v16, 0x16

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_23

    const/16 v16, 0x17

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_24

    const/16 v16, 0x18

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_25

    const/16 v16, 0x19

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_26

    const/16 v16, 0x1a

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_27

    const/16 v16, 0x1b

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_28

    const/16 v16, 0x1c

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_29

    const/16 v16, 0x1d

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_2a

    const/16 v16, 0x1e

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_2b

    const/16 v16, 0x1f

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_2c

    const/16 v16, 0x20

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_2d

    const/16 v16, 0x21

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_2e

    const/16 v16, 0x22

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_2f

    const/16 v16, 0x23

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_30

    const/16 v16, 0x24

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_31

    const/16 v16, 0x25

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_32

    const/16 v16, 0x26

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_33

    const/16 v16, 0x27

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_34

    const/16 v16, 0x28

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_35

    const/16 v16, 0x29

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_36

    const/16 v16, 0x2a

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_37

    const/16 v16, 0x2b

    aput-object v6, v2, v16

    new-array v6, v5, [I

    fill-array-data v6, :array_38

    const/16 v16, 0x2c

    aput-object v6, v2, v16

    sput-object v2, La/ak;->yY:[[I

    const-string v18, "branco"

    const-string v19, "verde"

    const-string v20, "amarelo"

    const-string v21, "verm"

    const-string v22, "azul"

    const-string v23, "azul2"

    filled-new-array/range {v18 .. v23}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->yZ:[Ljava/lang/String;

    const-string v18, ""

    const-string v19, ""

    const-string v20, ""

    const-string v21, ""

    const-string v22, ""

    const-string v23, ""

    const-string v24, ""

    filled-new-array/range {v18 .. v24}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->za:[Ljava/lang/String;

    new-array v2, v1, [I

    fill-array-data v2, :array_39

    sput-object v2, La/ak;->zj:[I

    new-array v2, v8, [I

    fill-array-data v2, :array_3a

    sput-object v2, La/ak;->zk:[I

    new-array v2, v8, [I

    fill-array-data v2, :array_3b

    sput-object v2, La/ak;->zl:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_3c

    sput-object v2, La/ak;->zm:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_3d

    sput-object v2, La/ak;->zn:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_3e

    sput-object v2, La/ak;->zo:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_3f

    sput-object v2, La/ak;->zp:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_40

    sput-object v2, La/ak;->zq:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_41

    sput-object v2, La/ak;->zr:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_42

    sput-object v2, La/ak;->zs:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_43

    sput-object v2, La/ak;->zt:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_44

    sput-object v2, La/ak;->zu:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_45

    sput-object v2, La/ak;->zv:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_46

    sput-object v2, La/ak;->zw:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_47

    sput-object v2, La/ak;->zx:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_48

    sput-object v2, La/ak;->zy:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_49

    sput-object v2, La/ak;->zz:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_4a

    sput-object v2, La/ak;->zA:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_4b

    sput-object v2, La/ak;->zB:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_4c

    sput-object v2, La/ak;->zC:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_4d

    sput-object v2, La/ak;->zD:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_4e

    sput-object v2, La/ak;->zE:[I

    new-array v2, v11, [[[I

    new-array v6, v8, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_4f

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_50

    aput-object v15, v6, v4

    new-array v15, v7, [I

    fill-array-data v15, :array_51

    aput-object v15, v6, v5

    new-array v15, v7, [I

    fill-array-data v15, :array_52

    aput-object v15, v6, v0

    new-array v15, v7, [I

    fill-array-data v15, :array_53

    aput-object v15, v6, v7

    new-array v15, v7, [I

    fill-array-data v15, :array_54

    aput-object v15, v6, v1

    aput-object v6, v2, v3

    new-array v6, v8, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_55

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_56

    aput-object v15, v6, v4

    new-array v15, v7, [I

    fill-array-data v15, :array_57

    aput-object v15, v6, v5

    new-array v15, v7, [I

    fill-array-data v15, :array_58

    aput-object v15, v6, v0

    new-array v15, v7, [I

    fill-array-data v15, :array_59

    aput-object v15, v6, v7

    new-array v15, v7, [I

    fill-array-data v15, :array_5a

    aput-object v15, v6, v1

    aput-object v6, v2, v4

    new-array v6, v9, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_5b

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_5c

    aput-object v15, v6, v4

    new-array v15, v7, [I

    fill-array-data v15, :array_5d

    aput-object v15, v6, v5

    new-array v15, v7, [I

    fill-array-data v15, :array_5e

    aput-object v15, v6, v0

    new-array v15, v7, [I

    fill-array-data v15, :array_5f

    aput-object v15, v6, v7

    new-array v15, v7, [I

    fill-array-data v15, :array_60

    aput-object v15, v6, v1

    new-array v15, v7, [I

    fill-array-data v15, :array_61

    aput-object v15, v6, v8

    aput-object v6, v2, v5

    new-array v6, v8, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_62

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_63

    aput-object v15, v6, v4

    new-array v15, v7, [I

    fill-array-data v15, :array_64

    aput-object v15, v6, v5

    new-array v15, v7, [I

    fill-array-data v15, :array_65

    aput-object v15, v6, v0

    new-array v15, v7, [I

    fill-array-data v15, :array_66

    aput-object v15, v6, v7

    new-array v15, v7, [I

    fill-array-data v15, :array_67

    aput-object v15, v6, v1

    aput-object v6, v2, v0

    new-array v6, v5, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_68

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_69

    aput-object v15, v6, v4

    aput-object v6, v2, v7

    new-array v6, v4, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_6a

    aput-object v15, v6, v3

    aput-object v6, v2, v1

    new-array v6, v5, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_6b

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_6c

    aput-object v15, v6, v4

    aput-object v6, v2, v8

    new-array v6, v4, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_6d

    aput-object v15, v6, v3

    aput-object v6, v2, v9

    new-array v6, v5, [[I

    new-array v15, v7, [I

    fill-array-data v15, :array_6e

    aput-object v15, v6, v3

    new-array v15, v7, [I

    fill-array-data v15, :array_6f

    aput-object v15, v6, v4

    aput-object v6, v2, v10

    sput-object v2, La/ak;->zF:[[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_70

    sput-object v2, La/ak;->zV:[I

    new-array v2, v8, [I

    fill-array-data v2, :array_71

    sput-object v2, La/ak;->zW:[I

    const-string v25, "Selecione op??o"

    const-string v26, "Resetar tudo"

    const-string v27, "5-4-1"

    const-string v28, "5-3-2"

    const-string v29, "4-5-1"

    const-string v30, "4-4-2"

    const-string v31, "4-4-2 def"

    const-string v32, "4-4-2 Ofen."

    const-string v33, "4-3-3"

    const-string v34, "4-3-3 def"

    const-string v35, "3-5-2"

    const-string v36, "3-4-3"

    filled-new-array/range {v25 .. v36}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->zX:[Ljava/lang/String;

    const-string v25, ""

    const-string v26, "Dom"

    const-string v27, "Seg"

    const-string v28, "ter"

    const-string v29, "qua"

    const-string v30, "qui"

    const-string v31, "sex"

    const-string v32, "sab"

    filled-new-array/range {v25 .. v32}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->zZ:[Ljava/lang/String;

    const-string v2, "Goleiro"

    const-string v6, "Lateral"

    const-string v15, "Zagueiro"

    const-string v14, "Meia"

    const-string v13, "Atacante"

    filled-new-array {v2, v6, v15, v14, v13}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Ab:[Ljava/lang/String;

    new-array v2, v1, [I

    fill-array-data v2, :array_72

    sput-object v2, La/ak;->Ao:[I

    const-string v37, "AC"

    const-string v38, "AL"

    const-string v39, "AM"

    const-string v40, "AP"

    const-string v41, "BA"

    const-string v42, "CE"

    const-string v43, "DF"

    const-string v44, "ES"

    const-string v45, "GO"

    const-string v46, "MA"

    const-string v47, "MG"

    const-string v48, "MS"

    const-string v49, "MT"

    const-string v50, "PA"

    const-string v51, "PB"

    const-string v52, "PE"

    const-string v53, "PI"

    const-string v54, "PR"

    const-string v55, "RJ"

    const-string v56, "RN"

    const-string v57, "RO"

    const-string v58, "RR"

    const-string v59, "RS"

    const-string v60, "SC"

    const-string v61, "SE"

    const-string v62, "SP"

    const-string v63, "TO"

    filled-new-array/range {v37 .. v63}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Ap:[Ljava/lang/String;

    const-string v37, "Acre"

    const-string v38, "Alagoas"

    const-string v39, "Amazonas"

    const-string v40, "Amap\u00e1"

    const-string v41, "Bahia"

    const-string v42, "Cear\u00e1"

    const-string v43, "Distrito Federal"

    const-string v44, "Esp\u00edrito Santo"

    const-string v45, "Goi?s"

    const-string v46, "Maranh\u00e3o"

    const-string v47, "Minas Gerais"

    const-string v48, "Mato Grosso Sul"

    const-string v49, "Mato Grosso"

    const-string v50, "Par\u00e1"

    const-string v51, "Para\u00edba"

    const-string v52, "Pernambuco"

    const-string v53, "Piau\u00ed"

    const-string v54, "Paran\u00e1"

    const-string v55, "Rio de Janeiro"

    const-string v56, "Rio Grande Norte"

    const-string v57, "Rondonia"

    const-string v58, "Roraima"

    const-string v59, "Rio Grande Sul"

    const-string v60, "Santa Catarina"

    const-string v61, "Sergipe"

    const-string v62, "S\u00e3o Paulo"

    const-string v63, "Tocantins"

    filled-new-array/range {v37 .. v63}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Aq:[Ljava/lang/String;

    const-string v37, "Acreano"

    const-string v38, "Alagoano"

    const-string v39, "Amazonense"

    const-string v40, "Amapaense"

    const-string v41, "Baiano"

    const-string v42, "Cearense"

    const-string v43, "Brasiliense"

    const-string v44, "Capixaba"

    const-string v45, "Goiano"

    const-string v46, "Maranhense"

    const-string v47, "Mineiro"

    const-string v48, "Sul-matogrossense"

    const-string v49, "Matogrossense"

    const-string v50, "Paraense"

    const-string v51, "Paraibano"

    const-string v52, "Pernambucano"

    const-string v53, "Piauiense"

    const-string v54, "Paranaense"

    const-string v55, "Carioca"

    const-string v56, "Potiguar"

    const-string v57, "Rondonense"

    const-string v58, "Roraimense"

    const-string v59, "Ga\u00facho"

    const-string v60, "Catarinense"

    const-string v61, "Sergipano"

    const-string v62, "Paulista"

    const-string v63, "Tocantinense"

    filled-new-array/range {v37 .. v63}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Ar:[Ljava/lang/String;

    const-string v2, "Rio-SP"

    const-string v6, "Sul-Minas"

    const-string v13, "Copa do Nordeste"

    const-string v14, "Copa Verde"

    filled-new-array {v2, v6, v13, v14}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->As:[Ljava/lang/String;

    new-array v2, v7, [I

    fill-array-data v2, :array_73

    sput-object v2, La/ak;->At:[I

    new-array v2, v1, [I

    fill-array-data v2, :array_74

    sput-object v2, La/ak;->Au:[I

    new-array v2, v9, [I

    fill-array-data v2, :array_75

    sput-object v2, La/ak;->Av:[I

    new-array v2, v8, [I

    fill-array-data v2, :array_76

    sput-object v2, La/ak;->Aw:[I

    new-array v2, v1, [I

    fill-array-data v2, :array_77

    sput-object v2, La/ak;->Ax:[I

    const-string v2, "voc\u00ea solicitou a demiss\u00e3o."

    const-string v6, "voc\u00ea estava levando o clube para o abismo financeiro."

    const-string v13, "a press\u00e3o da torcida estava grande pelos maus resultados."

    const-string v14, "seus resultados n\u00e3o agradaram nem a torcida nem a diretoria."

    filled-new-array {v2, v6, v13, v14}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Ay:[Ljava/lang/String;

    const-string v2, ""

    const-string v6, "Crise financeira"

    const-string v13, "Press\u00e3o torcida"

    const-string v14, "Maus resultados"

    filled-new-array {v2, v6, v13, v14}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Az:[Ljava/lang/String;

    new-array v2, v8, [Z

    fill-array-data v2, :array_78

    sput-object v2, La/ak;->AB:[Z

    new-array v2, v8, [I

    fill-array-data v2, :array_79

    sput-object v2, La/ak;->AH:[I

    new-array v2, v1, [[I

    new-array v6, v8, [I

    fill-array-data v6, :array_7a

    aput-object v6, v2, v3

    new-array v6, v8, [I

    fill-array-data v6, :array_7b

    aput-object v6, v2, v4

    new-array v6, v8, [I

    fill-array-data v6, :array_7c

    aput-object v6, v2, v5

    new-array v6, v8, [I

    fill-array-data v6, :array_7d

    aput-object v6, v2, v0

    new-array v6, v8, [I

    fill-array-data v6, :array_7e

    aput-object v6, v2, v7

    sput-object v2, La/ak;->AI:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_7f

    sput-object v2, La/ak;->AJ:[I

    new-array v2, v5, [I

    fill-array-data v2, :array_80

    sput-object v2, La/ak;->AK:[I

    new-array v2, v8, [[I

    new-array v6, v8, [I

    fill-array-data v6, :array_81

    aput-object v6, v2, v3

    new-array v6, v8, [I

    fill-array-data v6, :array_82

    aput-object v6, v2, v4

    new-array v6, v8, [I

    fill-array-data v6, :array_83

    aput-object v6, v2, v5

    new-array v6, v8, [I

    fill-array-data v6, :array_84

    aput-object v6, v2, v0

    new-array v6, v8, [I

    fill-array-data v6, :array_85

    aput-object v6, v2, v7

    new-array v6, v8, [I

    fill-array-data v6, :array_86

    aput-object v6, v2, v1

    sput-object v2, La/ak;->AL:[[I

    new-array v2, v0, [I

    fill-array-data v2, :array_87

    sput-object v2, La/ak;->AM:[I

    new-array v2, v5, [[I

    new-array v6, v8, [I

    fill-array-data v6, :array_88

    aput-object v6, v2, v3

    new-array v6, v8, [I

    fill-array-data v6, :array_89

    aput-object v6, v2, v4

    sput-object v2, La/ak;->AN:[[I

    new-array v2, v5, [I

    fill-array-data v2, :array_8a

    sput-object v2, La/ak;->AO:[I

    new-array v2, v8, [[I

    new-array v6, v7, [I

    fill-array-data v6, :array_8b

    aput-object v6, v2, v3

    new-array v6, v7, [I

    fill-array-data v6, :array_8c

    aput-object v6, v2, v4

    new-array v6, v7, [I

    fill-array-data v6, :array_8d

    aput-object v6, v2, v5

    new-array v6, v7, [I

    fill-array-data v6, :array_8e

    aput-object v6, v2, v0

    new-array v6, v7, [I

    fill-array-data v6, :array_8f

    aput-object v6, v2, v7

    new-array v6, v7, [I

    fill-array-data v6, :array_90

    aput-object v6, v2, v1

    sput-object v2, La/ak;->AP:[[I

    new-array v2, v1, [[J

    new-array v6, v5, [J

    fill-array-data v6, :array_91

    aput-object v6, v2, v3

    new-array v6, v5, [J

    fill-array-data v6, :array_92

    aput-object v6, v2, v4

    new-array v6, v5, [J

    fill-array-data v6, :array_93

    aput-object v6, v2, v5

    new-array v6, v5, [J

    fill-array-data v6, :array_94

    aput-object v6, v2, v0

    new-array v6, v5, [J

    fill-array-data v6, :array_95

    aput-object v6, v2, v7

    sput-object v2, La/ak;->AQ:[[J

    new-array v2, v1, [[I

    new-array v6, v5, [I

    fill-array-data v6, :array_96

    aput-object v6, v2, v3

    new-array v6, v5, [I

    fill-array-data v6, :array_97

    aput-object v6, v2, v4

    new-array v6, v5, [I

    fill-array-data v6, :array_98

    aput-object v6, v2, v5

    new-array v6, v5, [I

    fill-array-data v6, :array_99

    aput-object v6, v2, v0

    new-array v6, v5, [I

    fill-array-data v6, :array_9a

    aput-object v6, v2, v7

    sput-object v2, La/ak;->AR:[[I

    const/16 v2, 0x1a

    new-array v2, v2, [[I

    new-array v6, v0, [I

    fill-array-data v6, :array_9b

    aput-object v6, v2, v3

    new-array v6, v0, [I

    fill-array-data v6, :array_9c

    aput-object v6, v2, v4

    new-array v6, v0, [I

    fill-array-data v6, :array_9d

    aput-object v6, v2, v5

    new-array v6, v0, [I

    fill-array-data v6, :array_9e

    aput-object v6, v2, v0

    new-array v6, v0, [I

    fill-array-data v6, :array_9f

    aput-object v6, v2, v7

    new-array v6, v0, [I

    fill-array-data v6, :array_a0

    aput-object v6, v2, v1

    new-array v6, v0, [I

    fill-array-data v6, :array_a1

    aput-object v6, v2, v8

    new-array v6, v0, [I

    fill-array-data v6, :array_a2

    aput-object v6, v2, v9

    new-array v6, v0, [I

    fill-array-data v6, :array_a3

    aput-object v6, v2, v10

    new-array v6, v0, [I

    fill-array-data v6, :array_a4

    aput-object v6, v2, v11

    new-array v6, v0, [I

    fill-array-data v6, :array_a5

    aput-object v6, v2, v12

    new-array v6, v0, [I

    fill-array-data v6, :array_a6

    const/16 v13, 0xb

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_a7

    const/16 v13, 0xc

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_a8

    const/16 v13, 0xd

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_a9

    const/16 v13, 0xe

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_aa

    const/16 v13, 0xf

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_ab

    const/16 v13, 0x10

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_ac

    const/16 v13, 0x11

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_ad

    const/16 v13, 0x12

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_ae

    const/16 v13, 0x13

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_af

    const/16 v13, 0x14

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_b0

    const/16 v13, 0x15

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_b1

    const/16 v13, 0x16

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_b2

    const/16 v13, 0x17

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_b3

    const/16 v13, 0x18

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_b4

    const/16 v13, 0x19

    aput-object v6, v2, v13

    sput-object v2, La/ak;->AS:[[I

    const/16 v2, 0x1a

    new-array v2, v2, [[I

    new-array v6, v0, [I

    fill-array-data v6, :array_b5

    aput-object v6, v2, v3

    new-array v6, v0, [I

    fill-array-data v6, :array_b6

    aput-object v6, v2, v4

    new-array v6, v0, [I

    fill-array-data v6, :array_b7

    aput-object v6, v2, v5

    new-array v6, v0, [I

    fill-array-data v6, :array_b8

    aput-object v6, v2, v0

    new-array v6, v0, [I

    fill-array-data v6, :array_b9

    aput-object v6, v2, v7

    new-array v6, v0, [I

    fill-array-data v6, :array_ba

    aput-object v6, v2, v1

    new-array v6, v0, [I

    fill-array-data v6, :array_bb

    aput-object v6, v2, v8

    new-array v6, v0, [I

    fill-array-data v6, :array_bc

    aput-object v6, v2, v9

    new-array v6, v0, [I

    fill-array-data v6, :array_bd

    aput-object v6, v2, v10

    new-array v6, v0, [I

    fill-array-data v6, :array_be

    aput-object v6, v2, v11

    new-array v6, v0, [I

    fill-array-data v6, :array_bf

    aput-object v6, v2, v12

    new-array v6, v0, [I

    fill-array-data v6, :array_c0

    const/16 v13, 0xb

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c1

    const/16 v13, 0xc

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c2

    const/16 v13, 0xd

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c3

    const/16 v13, 0xe

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c4

    const/16 v13, 0xf

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c5

    const/16 v13, 0x10

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c6

    const/16 v13, 0x11

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c7

    const/16 v13, 0x12

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c8

    const/16 v13, 0x13

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_c9

    const/16 v13, 0x14

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_ca

    const/16 v13, 0x15

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_cb

    const/16 v13, 0x16

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_cc

    const/16 v13, 0x17

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_cd

    const/16 v13, 0x18

    aput-object v6, v2, v13

    new-array v6, v0, [I

    fill-array-data v6, :array_ce

    const/16 v13, 0x19

    aput-object v6, v2, v13

    sput-object v2, La/ak;->AT:[[I

    const/16 v2, 0xd

    new-array v6, v2, [I

    fill-array-data v6, :array_cf

    sput-object v6, La/ak;->AU:[I

    new-array v2, v1, [[I

    new-array v6, v1, [I

    fill-array-data v6, :array_d0

    aput-object v6, v2, v3

    new-array v6, v1, [I

    fill-array-data v6, :array_d1

    aput-object v6, v2, v4

    new-array v6, v1, [I

    fill-array-data v6, :array_d2

    aput-object v6, v2, v5

    new-array v6, v1, [I

    fill-array-data v6, :array_d3

    aput-object v6, v2, v0

    new-array v6, v1, [I

    fill-array-data v6, :array_d4

    aput-object v6, v2, v7

    sput-object v2, La/ak;->AV:[[I

    const/16 v2, 0xb

    new-array v6, v2, [I

    fill-array-data v6, :array_d5

    sput-object v6, La/ak;->AW:[I

    new-array v6, v2, [[I

    new-array v13, v2, [I

    fill-array-data v13, :array_d6

    aput-object v13, v6, v3

    new-array v13, v2, [I

    fill-array-data v13, :array_d7

    aput-object v13, v6, v4

    new-array v13, v2, [I

    fill-array-data v13, :array_d8

    aput-object v13, v6, v5

    new-array v13, v2, [I

    fill-array-data v13, :array_d9

    aput-object v13, v6, v0

    new-array v13, v2, [I

    fill-array-data v13, :array_da

    aput-object v13, v6, v7

    new-array v13, v2, [I

    fill-array-data v13, :array_db

    aput-object v13, v6, v1

    new-array v13, v2, [I

    fill-array-data v13, :array_dc

    aput-object v13, v6, v8

    new-array v13, v2, [I

    fill-array-data v13, :array_dd

    aput-object v13, v6, v9

    new-array v13, v2, [I

    fill-array-data v13, :array_de

    aput-object v13, v6, v10

    new-array v13, v2, [I

    fill-array-data v13, :array_df

    aput-object v13, v6, v11

    new-array v13, v2, [I

    fill-array-data v13, :array_e0

    aput-object v13, v6, v12

    sput-object v6, La/ak;->AX:[[I

    const-string v25, "4-2-3-1"

    const-string v26, "5-4-1"

    const-string v27, "5-3-2"

    const-string v28, "4-5-1"

    const-string v29, "4-4-2"

    const-string v30, "4-4-2 def."

    const-string v31, "4-4-2 ofe."

    const-string v32, "4-3-3"

    const-string v33, "4-3-3 def."

    const-string v34, "3-5-2"

    const-string v35, "3-4-3"

    filled-new-array/range {v25 .. v35}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->AY:[Ljava/lang/String;

    const/16 v2, 0xd

    new-array v2, v2, [[I

    new-array v6, v1, [I

    fill-array-data v6, :array_e1

    aput-object v6, v2, v3

    new-array v6, v1, [I

    fill-array-data v6, :array_e2

    aput-object v6, v2, v4

    new-array v6, v1, [I

    fill-array-data v6, :array_e3

    aput-object v6, v2, v5

    new-array v6, v1, [I

    fill-array-data v6, :array_e4

    aput-object v6, v2, v0

    new-array v6, v1, [I

    fill-array-data v6, :array_e5

    aput-object v6, v2, v7

    new-array v6, v1, [I

    fill-array-data v6, :array_e6

    aput-object v6, v2, v1

    new-array v6, v1, [I

    fill-array-data v6, :array_e7

    aput-object v6, v2, v8

    new-array v6, v1, [I

    fill-array-data v6, :array_e8

    aput-object v6, v2, v9

    new-array v6, v1, [I

    fill-array-data v6, :array_e9

    aput-object v6, v2, v10

    new-array v6, v1, [I

    fill-array-data v6, :array_ea

    aput-object v6, v2, v11

    new-array v6, v1, [I

    fill-array-data v6, :array_eb

    aput-object v6, v2, v12

    new-array v6, v1, [I

    fill-array-data v6, :array_ec

    const/16 v13, 0xb

    aput-object v6, v2, v13

    new-array v6, v1, [I

    fill-array-data v6, :array_ed

    const/16 v13, 0xc

    aput-object v6, v2, v13

    sput-object v2, La/ak;->AZ:[[I

    const-string v37, "6 times - padr?o"

    const-string v38, "20 times - 4 grupos - SP 2016"

    const-string v39, "16 times - 4 classificados"

    const-string v40, "14 times - 8 classificados"

    const-string v41, "12 times - 4 classificados"

    const-string v42, "12 times - 8 classificados"

    const-string v43, "12 times - 2 grupos - BA 2016"

    const-string v44, "10 times - 4 classificados"

    const-string v45, "10 times - 2 turnos - SC 2016"

    const-string v46, "8 times - 4 classificados"

    const-string v47, "16 times - 2 grupos - RJ 2016"

    const-string v48, "16 times - 4 grupos - SP 2017"

    const-string v49, "16 times - RJ 2017"

    filled-new-array/range {v37 .. v49}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, La/ak;->Bc:[Ljava/lang/String;

    const/16 v2, 0x14

    new-array v6, v2, [I

    fill-array-data v6, :array_ee

    sput-object v6, La/ak;->Bd:[I

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_ef

    sput-object v2, La/ak;->Be:[I

    const/16 v2, 0xc

    new-array v6, v2, [I

    fill-array-data v6, :array_f0

    sput-object v6, La/ak;->Bf:[I

    const/16 v2, 0x20

    new-array v2, v2, [I

    fill-array-data v2, :array_f1

    sput-object v2, La/ak;->Bg:[I

    const/16 v2, 0x14

    new-array v2, v2, [I

    fill-array-data v2, :array_f2

    sput-object v2, La/ak;->Bh:[I

    const/16 v2, 0x20

    new-array v2, v2, [I

    fill-array-data v2, :array_f3

    sput-object v2, La/ak;->Bi:[I

    const/16 v2, 0xc

    new-array v2, v2, [[I

    new-array v6, v10, [I

    fill-array-data v6, :array_f4

    aput-object v6, v2, v3

    new-array v6, v10, [I

    fill-array-data v6, :array_f5

    aput-object v6, v2, v4

    new-array v6, v10, [I

    fill-array-data v6, :array_f6

    aput-object v6, v2, v5

    new-array v6, v10, [I

    fill-array-data v6, :array_f7

    aput-object v6, v2, v0

    new-array v6, v10, [I

    fill-array-data v6, :array_f8

    aput-object v6, v2, v7

    new-array v6, v10, [I

    fill-array-data v6, :array_f9

    aput-object v6, v2, v1

    new-array v6, v10, [I

    fill-array-data v6, :array_fa

    aput-object v6, v2, v8

    new-array v6, v10, [I

    fill-array-data v6, :array_fb

    aput-object v6, v2, v9

    new-array v6, v10, [I

    fill-array-data v6, :array_fc

    aput-object v6, v2, v10

    new-array v6, v10, [I

    fill-array-data v6, :array_fd

    aput-object v6, v2, v11

    new-array v6, v10, [I

    fill-array-data v6, :array_fe

    aput-object v6, v2, v12

    new-array v6, v10, [I

    fill-array-data v6, :array_ff

    const/16 v11, 0xb

    aput-object v6, v2, v11

    sput-object v2, La/ak;->Bj:[[I

    new-array v2, v10, [[I

    new-array v6, v5, [I

    fill-array-data v6, :array_100

    aput-object v6, v2, v3

    new-array v3, v5, [I

    fill-array-data v3, :array_101

    aput-object v3, v2, v4

    new-array v3, v5, [I

    fill-array-data v3, :array_102

    aput-object v3, v2, v5

    new-array v3, v5, [I

    fill-array-data v3, :array_103

    aput-object v3, v2, v0

    new-array v0, v5, [I

    fill-array-data v0, :array_104

    aput-object v0, v2, v7

    new-array v0, v5, [I

    fill-array-data v0, :array_105

    aput-object v0, v2, v1

    new-array v0, v5, [I

    fill-array-data v0, :array_106

    aput-object v0, v2, v8

    new-array v0, v5, [I

    fill-array-data v0, :array_107

    aput-object v0, v2, v9

    sput-object v2, La/ak;->Bk:[[I

    const-string v11, ""

    const-string v12, "gol"

    const-string v13, "Amarelo"

    const-string v14, "Vermelho"

    const-string v15, "Ama-Ver"

    const-string v16, "Contusao"

    const-string v17, "Substitui??o"

    const-string v18, "Penalty Perdido"

    filled-new-array/range {v11 .. v18}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->Bl:[Ljava/lang/String;

    const-string v1, ""

    const-string v2, "normal"

    const-string v3, "contra"

    const-string v4, "penalty"

    const-string v5, "falta"

    const-string v6, "olimpico"

    const-string v7, "escanteio"

    filled-new-array/range {v1 .. v7}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->Bm:[Ljava/lang/String;

    const-string v0, "/teams/camisas/"

    const-string v1, "/teams/camisas2/"

    const-string v2, "/teams/camisas3/"

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BL:[Ljava/lang/String;

    const-string v0, "/selecoes/camisas/"

    const-string v1, "/selecoes/camisas2/"

    const-string v2, "/selecoes/camisas3/"

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BN:[Ljava/lang/String;

    const-string v11, "Amistoso"

    const-string v12, "Nacional"

    const-string v13, "Copa"

    const-string v14, "Estadual"

    const-string v15, "Internacional 1"

    const-string v16, "Mundial"

    const-string v17, "Internacional 2"

    const-string v18, "Sele??es"

    const-string v19, "Recopa"

    const-string v20, "Eliminat\u00f3rias"

    filled-new-array/range {v11 .. v20}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BO:[Ljava/lang/String;

    const-string v1, "Liga dos Campe\u00f5es"

    const-string v2, "Libertadores"

    const-string v3, "L. CAF"

    const-string v4, "L. AFC"

    const-string v5, "L. Concacaf"

    const-string v6, "L. OFC"

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BP:[Ljava/lang/String;

    const-string v1, "L. Europa"

    const-string v2, "L. Sul"

    const-string v3, ""

    const-string v4, ""

    const-string v5, ""

    const-string v6, ""

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BQ:[Ljava/lang/String;

    const-string v1, "L. Confer\u00eancia"

    const-string v2, ""

    const-string v3, ""

    const-string v4, ""

    const-string v5, ""

    const-string v6, ""

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BX:[Ljava/lang/String;

    const-string v1, "Recopa E."

    const-string v2, "Recopa S."

    const-string v3, ""

    const-string v4, ""

    const-string v5, ""

    const-string v6, ""

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BR:[Ljava/lang/String;

    const-string v11, ""

    const-string v12, ""

    const-string v13, ""

    const-string v14, ""

    const-string v15, ""

    const-string v16, ""

    const-string v17, ""

    const-string v18, ""

    filled-new-array/range {v11 .. v18}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La/ak;->BS:[Ljava/lang/String;

    new-array v0, v10, [Z

    fill-array-data v0, :array_108

    sput-object v0, La/ak;->BT:[Z

    new-array v0, v10, [Z

    fill-array-data v0, :array_109

    sput-object v0, La/ak;->BU:[Z

    new-array v0, v8, [I

    fill-array-data v0, :array_10a

    sput-object v0, La/ak;->BV:[I

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x13
        0x4
        0x9c
    .end array-data

    :array_2
    .array-data 4
        0x86
        0xf
        0x14
    .end array-data

    :array_3
    .array-data 4
        0x94
        0x94
        0x49
    .end array-data

    :array_4
    .array-data 4
        0xb3
        0xb3
        0x64
    .end array-data

    :array_5
    .array-data 4
        0xc0
        0xc0
        0x81
    .end array-data

    :array_6
    .array-data 4
        0xd1
        0xd1
        0xa3
    .end array-data

    :array_7
    .array-data 4
        0xde
        0xde
        0xbc
    .end array-data

    :array_8
    .array-data 4
        0x4650
        0x13880
        0x2328
        0x2bc
    .end array-data

    :array_9
    .array-data 4
        0x4e20
        0x186a0
        0x2710
        0x320
    .end array-data

    :array_a
    .array-data 4
        0x55f0
        0x1adb0
        0x2710
        0x384
    .end array-data

    :array_b
    .array-data 4
        0x61a8
        0x1d4c0
        0x2710
        0x4b0
    .end array-data

    :array_c
    .array-data 4
        0xdf
        0x92
    .end array-data

    :array_d
    .array-data 4
        0xdf
        0x7c
    .end array-data

    :array_e
    .array-data 4
        0x7c
        0x92
    .end array-data

    :array_f
    .array-data 4
        0x130
        0x11b
    .end array-data

    :array_10
    .array-data 4
        0xd9
        0x1d0
    .end array-data

    :array_11
    .array-data 4
        0xd9
        0x18e
    .end array-data

    :array_12
    .array-data 4
        0x18e
        0x1d0
    .end array-data

    :array_13
    .array-data 4
        0xd9
        0x1c9
    .end array-data

    :array_14
    .array-data 4
        0x18e
        0x1c9
    .end array-data

    :array_15
    .array-data 4
        0x1d0
        0x1c9
    .end array-data

    :array_16
    .array-data 4
        0x108
        0x10a
    .end array-data

    :array_17
    .array-data 4
        0x108
        0xb5
    .end array-data

    :array_18
    .array-data 4
        0x108
        0x20c
    .end array-data

    :array_19
    .array-data 4
        0x10a
        0xb5
    .end array-data

    :array_1a
    .array-data 4
        0x10a
        0x20c
    .end array-data

    :array_1b
    .array-data 4
        0x20c
        0xb5
    .end array-data

    :array_1c
    .array-data 4
        0x93
        0xda
    .end array-data

    :array_1d
    .array-data 4
        0x1c4
        0x1de
    .end array-data

    :array_1e
    .array-data 4
        0x1c4
        0x17b
    .end array-data

    :array_1f
    .array-data 4
        0x1de
        0x17b
    .end array-data

    :array_20
    .array-data 4
        0x215
        0x9b
    .end array-data

    :array_21
    .array-data 4
        0xc7
        0x10b
    .end array-data

    :array_22
    .array-data 4
        0x99
        0x105
    .end array-data

    :array_23
    .array-data 4
        0x199
        0x11f
    .end array-data

    :array_24
    .array-data 4
        0xce
        0xde
    .end array-data

    :array_25
    .array-data 4
        0x118
        0x90
    .end array-data

    :array_26
    .array-data 4
        0x195
        0x1b2
    .end array-data

    :array_27
    .array-data 4
        0xaf
        0x1b8
    .end array-data

    :array_28
    .array-data 4
        0x88
        0xcf
    .end array-data

    :array_29
    .array-data 4
        0x88
        0x15e
    .end array-data

    :array_2a
    .array-data 4
        0x15e
        0xcf
    .end array-data

    :array_2b
    .array-data 4
        0xa0
        0x1aa
    .end array-data

    :array_2c
    .array-data 4
        0x102
        0x10f
    .end array-data

    :array_2d
    .array-data 4
        0xa9
        0x19b
    .end array-data

    :array_2e
    .array-data 4
        0x1ba
        0x146
    .end array-data

    :array_2f
    .array-data 4
        0x16c
        0x131
    .end array-data

    :array_30
    .array-data 4
        0x6d
        0x221
    .end array-data

    :array_31
    .array-data 4
        0x196
        0x178
    .end array-data

    :array_32
    .array-data 4
        0xab
        0x1d6
    .end array-data

    :array_33
    .array-data 4
        0xa9
        0x1e2
    .end array-data

    :array_34
    .array-data 4
        0x12d
        0x1a7
    .end array-data

    :array_35
    .array-data 4
        0x180
        0xcb
    .end array-data

    :array_36
    .array-data 4
        0xd4
        0x204
    .end array-data

    :array_37
    .array-data 4
        0x1aa
        0x91
    .end array-data

    :array_38
    .array-data 4
        0x88
        0x1f6
    .end array-data

    :array_39
    .array-data 4
        0x1
        0x28
        0x1e
        0x14
        0x5
    .end array-data

    :array_3a
    .array-data 4
        0x1
        0xa
        0x14
        0x28
        0x32
        0x37
    .end array-data

    :array_3b
    .array-data 4
        0x14
        0x1e
        0x2d
        0x55
        0x64
        0x64
    .end array-data

    :array_3c
    .array-data 4
        0xff
        0xff
        0xff
    .end array-data

    :array_3d
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data

    :array_3e
    .array-data 4
        0xd7
        0x0
        0x0
    .end array-data

    :array_3f
    .array-data 4
        0x99
        0x0
        0x0
    .end array-data

    :array_40
    .array-data 4
        0xf1
        0xa
        0x21
    .end array-data

    :array_41
    .array-data 4
        0xff
        0x33
        0x33
    .end array-data

    :array_42
    .array-data 4
        0x0
        0x0
        0x62
    .end array-data

    :array_43
    .array-data 4
        0x26
        0x39
        0x6a
    .end array-data

    :array_44
    .array-data 4
        0x5
        0x31
        0x7a
    .end array-data

    :array_45
    .array-data 4
        0x33
        0x63
        0x9c
    .end array-data

    :array_46
    .array-data 4
        0x8
        0x51
        0xa4
    .end array-data

    :array_47
    .array-data 4
        0x33
        0xa8
        0xcd
    .end array-data

    :array_48
    .array-data 4
        0x33
        0x33
        0x0
    .end array-data

    :array_49
    .array-data 4
        0x6a
        0x68
        0x71
    .end array-data

    :array_4a
    .array-data 4
        0x14
        0x5c
        0x14
    .end array-data

    :array_4b
    .array-data 4
        0x2
        0x6c
        0x3e
    .end array-data

    :array_4c
    .array-data 4
        0xed
        0xca
        0x3f
    .end array-data

    :array_4d
    .array-data 4
        0xe1
        0xe1
        0x0
    .end array-data

    :array_4e
    .array-data 4
        0xff
        0xff
        0x80
    .end array-data

    :array_4f
    .array-data 4
        0x5
        0xf
        0x14
        0x1e
    .end array-data

    :array_50
    .array-data 4
        0x3
        0xc
        0xf
        0x19
    .end array-data

    :array_51
    .array-data 4
        0x3
        0xc
        0xf
        0x19
    .end array-data

    :array_52
    .array-data 4
        0x3
        0xc
        0xf
        0x19
    .end array-data

    :array_53
    .array-data 4
        0x3
        0xc
        0xf
        0x19
    .end array-data

    :array_54
    .array-data 4
        0x3
        0xc
        0xf
        0x19
    .end array-data

    :array_55
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_56
    .array-data 4
        0xa
        0xf
        0x19
        0x50
    .end array-data

    :array_57
    .array-data 4
        0x7
        0xd
        0x14
        0x46
    .end array-data

    :array_58
    .array-data 4
        0x5
        0xc
        0x11
        0x28
    .end array-data

    :array_59
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_5a
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_5b
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_5c
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_5d
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_5e
    .array-data 4
        0x7
        0xd
        0x14
        0x46
    .end array-data

    :array_5f
    .array-data 4
        0xa
        0xf
        0x19
        0x50
    .end array-data

    :array_60
    .array-data 4
        0xa
        0xf
        0x19
        0x50
    .end array-data

    :array_61
    .array-data 4
        0xa
        0xf
        0x19
        0x50
    .end array-data

    :array_62
    .array-data 4
        0x3
        0x5
        0xc
        0x14
    .end array-data

    :array_63
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_64
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_65
    .array-data 4
        0x5
        0xc
        0x14
        0x32
    .end array-data

    :array_66
    .array-data 4
        0xa
        0xf
        0x19
        0x46
    .end array-data

    :array_67
    .array-data 4
        0xa
        0xf
        0x19
        0x46
    .end array-data

    :array_68
    .array-data 4
        0x1e
        0x2d
        0x41
        0xc8
    .end array-data

    :array_69
    .array-data 4
        0x14
        0x23
        0x37
        0x96
    .end array-data

    :array_6a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_6b
    .array-data 4
        0x14
        0x19
        0x2d
        0x96
    .end array-data

    :array_6c
    .array-data 4
        0x14
        0x19
        0x28
        0x78
    .end array-data

    :array_6d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_6e
    .array-data 4
        0x14
        0x19
        0x2d
        0x96
    .end array-data

    :array_6f
    .array-data 4
        0x14
        0x19
        0x28
        0x78
    .end array-data

    :array_70
    .array-data 4
        0x7d0
        0x3e8
        0x1f4
        0x12c
        0x64
        0x64
    .end array-data

    :array_71
    .array-data 4
        0x7d0
        0x3e8
        0x1f4
        0xc8
        0x64
        0x32
    .end array-data

    :array_72
    .array-data 4
        0x3
        0x48
        0x68
        0x61
        0x41
    .end array-data

    :array_73
    .array-data 4
        0x19
        0x12
        0xa
        0x16
    .end array-data

    :array_74
    .array-data 4
        0x11
        0x17
        0x4
        0xf
        0x5
    .end array-data

    :array_75
    .array-data 4
        0x8
        0x1
        0xd
        0xb
        0x9
        0x13
        0xe
    .end array-data

    :array_76
    .array-data 4
        0x18
        0x0
        0x10
        0xc
        0x2
        0x6
    .end array-data

    :array_77
    .array-data 4
        0x7
        0x1a
        0x14
        0x3
        0x15
    .end array-data

    :array_78
    .array-data 1
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
    .end array-data

    nop

    :array_79
    .array-data 4
        0x186a0
        0xc3500
        0x7a120
        0x493e0
        0x249f0
        0x186a0
    .end array-data

    :array_7a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_7b
    .array-data 4
        0x2160ec0
        0x1312d00
        0xe4e1c0
        0x989680
        0x4c4b40
        0x4c4b40
    .end array-data

    :array_7c
    .array-data 4
        0x989680
        0x4c4b40
        0x1e8480
        0x16e360
        0x3d090
        0x186a0
    .end array-data

    :array_7d
    .array-data 4
        0x4c4b40
        0x2625a0
        0x16e360
        0x13d620
        0x249f0
        0x124f8
    .end array-data

    :array_7e
    .array-data 4
        0x1ab3f0
        0x16e360
        0xf4240
        0xaae60
        0x493e0
        0x249f0
    .end array-data

    :array_7f
    .array-data 4
        0xf4240
        0xf4240
        0x2dc6c0
        0x4c4b40
        0x7a1200
        0xe4e1c0
        0x2160ec0
    .end array-data

    :array_80
    .array-data 4
        0x7a1200
        0x3567e0
    .end array-data

    :array_81
    .array-data 4
        0x5b8d80
        0x7a1200
        0x2160ec0
        0x47868c0
        0x0
        0x0
    .end array-data

    :array_82
    .array-data 4
        0x7a1200
        0xe4e1c0
        0x1c9c380
        0x3938700
        0x0
        0x0
    .end array-data

    :array_83
    .array-data 4
        0x4c4b40
        0x989680
        0x1312d00
        0x1e8480
        0x0
        0x0
    .end array-data

    :array_84
    .array-data 4
        0x4c4b40
        0x989680
        0x1312d00
        0x1e8480
        0x0
        0x0
    .end array-data

    :array_85
    .array-data 4
        0x4c4b40
        0x989680
        0x1312d00
        0x1e8480
        0x0
        0x0
    .end array-data

    :array_86
    .array-data 4
        0x4c4b40
        0x989680
        0x1312d00
        0x1e8480
        0x0
        0x0
    .end array-data

    :array_87
    .array-data 4
        0x1e8480
        0x4c4b40
        0x4c4b40
    .end array-data

    :array_88
    .array-data 4
        0x2dc6c0
        0x3d0900
        0x4c4b40
        0xbebc20
        0x17d7840
        0x0
    .end array-data

    :array_89
    .array-data 4
        0x1e8480
        0x3d0900
        0x5b8d80
        0x895440
        0x17d7840
        0x0
    .end array-data

    :array_8a
    .array-data 4
        0xf4240
        0x7a120
    .end array-data

    :array_8b
    .array-data 4
        0x3
        0xc
        0xf
        0x19
    .end array-data

    :array_8c
    .array-data 4
        0xa
        0xf
        0x19
        0x50
    .end array-data

    :array_8d
    .array-data 4
        0x7
        0xd
        0x14
        0x46
    .end array-data

    :array_8e
    .array-data 4
        0x5
        0xc
        0x11
        0x28
    .end array-data

    :array_8f
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_90
    .array-data 4
        0x3
        0xc
        0xf
        0x1e
    .end array-data

    :array_91
    .array-data 8
        0x44aa20
        0x1e8480
    .end array-data

    :array_92
    .array-data 8
        0x2faf080
        0xb71b00
    .end array-data

    :array_93
    .array-data 8
        0x1036640
        0x989680
    .end array-data

    :array_94
    .array-data 8
        0xd59f80
        0x6acfc0
    .end array-data

    :array_95
    .array-data 8
        0xb71b00
        0x2dc6c0
    .end array-data

    :array_96
    .array-data 4
        0x3567e0
        0x3567e0
    .end array-data

    :array_97
    .array-data 4
        0x1f78a40
        0x1f78a40
    .end array-data

    :array_98
    .array-data 4
        0x989680
        0x989680
    .end array-data

    :array_99
    .array-data 4
        0x4c4b40
        0x4c4b40
    .end array-data

    :array_9a
    .array-data 4
        0x4c4b40
        0x4c4b40
    .end array-data

    :array_9b
    .array-data 4
        0x0
        -0x1
        -0x1
    .end array-data

    :array_9c
    .array-data 4
        0x0
        -0x1
        -0x1
    .end array-data

    :array_9d
    .array-data 4
        0x1
        0x1
        -0x1
    .end array-data

    :array_9e
    .array-data 4
        0x2
        0x1
        -0x1
    .end array-data

    :array_9f
    .array-data 4
        0x2
        -0x1
        -0x1
    .end array-data

    :array_a0
    .array-data 4
        0x2
        0x0
        -0x1
    .end array-data

    :array_a1
    .array-data 4
        0x2
        0x1
        -0x1
    .end array-data

    :array_a2
    .array-data 4
        0x2
        -0x1
        -0x1
    .end array-data

    :array_a3
    .array-data 4
        0x2
        0x0
        -0x1
    .end array-data

    :array_a4
    .array-data 4
        0x1
        0x0
        -0x1
    .end array-data

    :array_a5
    .array-data 4
        0x1
        0x1
        0x1
    .end array-data

    :array_a6
    .array-data 4
        0x3
        0x1
        0x0
    .end array-data

    :array_a7
    .array-data 4
        0x3
        -0x1
        0x0
    .end array-data

    :array_a8
    .array-data 4
        0x3
        0x0
        0x0
    .end array-data

    :array_a9
    .array-data 4
        0x3
        0x1
        0x1
    .end array-data

    :array_aa
    .array-data 4
        0x3
        -0x1
        0x1
    .end array-data

    :array_ab
    .array-data 4
        0x3
        0x0
        0x1
    .end array-data

    :array_ac
    .array-data 4
        0x1
        0x1
        0x0
    .end array-data

    :array_ad
    .array-data 4
        0x4
        0x1
        0x2
    .end array-data

    :array_ae
    .array-data 4
        0x4
        0x1
        -0x1
    .end array-data

    :array_af
    .array-data 4
        0x4
        -0x1
        -0x1
    .end array-data

    :array_b0
    .array-data 4
        0x4
        0x0
        -0x1
    .end array-data

    :array_b1
    .array-data 4
        0x4
        0x1
        -0x1
    .end array-data

    :array_b2
    .array-data 4
        0x4
        -0x1
        -0x1
    .end array-data

    :array_b3
    .array-data 4
        0x4
        0x0
        -0x1
    .end array-data

    :array_b4
    .array-data 4
        0x4
        0x0
        0x2
    .end array-data

    :array_b5
    .array-data 4
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_b6
    .array-data 4
        0x1
        -0x1
        -0x1
    .end array-data

    :array_b7
    .array-data 4
        0x3
        0x6
        -0x1
    .end array-data

    :array_b8
    .array-data 4
        0x2
        0x3
        -0x1
    .end array-data

    :array_b9
    .array-data 4
        0x2
        -0x1
        -0x1
    .end array-data

    :array_ba
    .array-data 4
        0x2
        0x1
        -0x1
    .end array-data

    :array_bb
    .array-data 4
        0x2
        0x3
        -0x1
    .end array-data

    :array_bc
    .array-data 4
        0x2
        -0x1
        -0x1
    .end array-data

    :array_bd
    .array-data 4
        0x2
        0x1
        -0x1
    .end array-data

    :array_be
    .array-data 4
        0x1
        0x4
        -0x1
    .end array-data

    :array_bf
    .array-data 4
        0x6
        0x9
        -0x1
    .end array-data

    :array_c0
    .array-data 4
        0x5
        0x6
        -0x1
    .end array-data

    :array_c1
    .array-data 4
        0x5
        -0x1
        -0x1
    .end array-data

    :array_c2
    .array-data 4
        0x5
        0x4
        -0x1
    .end array-data

    :array_c3
    .array-data 4
        0x8
        0x9
        -0x1
    .end array-data

    :array_c4
    .array-data 4
        0x8
        -0x1
        -0x1
    .end array-data

    :array_c5
    .array-data 4
        0x8
        0x7
        -0x1
    .end array-data

    :array_c6
    .array-data 4
        0x4
        0x7
        -0x1
    .end array-data

    :array_c7
    .array-data 4
        0xc
        -0x1
        -0x1
    .end array-data

    :array_c8
    .array-data 4
        0xb
        0xc
        -0x1
    .end array-data

    :array_c9
    .array-data 4
        0xb
        -0x1
        -0x1
    .end array-data

    :array_ca
    .array-data 4
        0xb
        0xa
        -0x1
    .end array-data

    :array_cb
    .array-data 4
        0xb
        0xc
        -0x1
    .end array-data

    :array_cc
    .array-data 4
        0xb
        -0x1
        -0x1
    .end array-data

    :array_cd
    .array-data 4
        0xb
        0xa
        -0x1
    .end array-data

    :array_ce
    .array-data 4
        0xa
        -0x1
        -0x1
    .end array-data

    :array_cf
    .array-data 4
        0x0
        0x3
        0x6
        0x3
        0x3
        0x3
        0x3
        0x2
        0x3
        0x2
        0x3
        0x6
        0x3
    .end array-data

    :array_d0
    .array-data 4
        0x0
        0x2
        0x1
        0x3
        0x4
    .end array-data

    :array_d1
    .array-data 4
        0x1
        0x3
        0x2
        0x4
        0x0
    .end array-data

    :array_d2
    .array-data 4
        0x2
        0x1
        0x3
        0x4
        0x0
    .end array-data

    :array_d3
    .array-data 4
        0x3
        0x1
        0x2
        0x4
        0x0
    .end array-data

    :array_d4
    .array-data 4
        0x4
        0x3
        0x1
        0x2
        0x0
    .end array-data

    :array_d5
    .array-data 4
        0x1
        0x2
        0x4
        0x4
        0xc
        0xf
        0xf
        0x14
        0x14
        0x17
        0x17
    .end array-data

    :array_d6
    .array-data 4
        0x1
        0x16
        0x10
        0xc
        0xe
        0xf
        0xb
        0x2
        0x9
        0x6
        0x8
    .end array-data

    :array_d7
    .array-data 4
        0x1
        0x14
        0xb
        0xd
        0xe
        0x10
        0x2
        0x9
        0x6
        0x4
        0x8
    .end array-data

    :array_d8
    .array-data 4
        0x1
        0x16
        0x18
        0xc
        0xe
        0x10
        0x2
        0x9
        0x6
        0x4
        0x8
    .end array-data

    :array_d9
    .array-data 4
        0x1
        0x17
        0xb
        0xd
        0xf
        0x2
        0x9
        0x6
        0x8
        0xa
        0x11
    .end array-data

    :array_da
    .array-data 4
        0x1
        0x16
        0x18
        0xb
        0xd
        0xe
        0x10
        0x2
        0x9
        0x3
        0x5
    .end array-data

    :array_db
    .array-data 4
        0x1
        0x13
        0x15
        0xb
        0xc
        0xd
        0xf
        0x2
        0x9
        0x6
        0x8
    .end array-data

    :array_dc
    .array-data 4
        0x1
        0x16
        0x18
        0xc
        0xe
        0xf
        0x10
        0x2
        0x9
        0x6
        0x8
    .end array-data

    :array_dd
    .array-data 4
        0x1
        0x16
        0x17
        0x18
        0xc
        0xe
        0x10
        0x2
        0x9
        0x6
        0x8
    .end array-data

    :array_de
    .array-data 4
        0x1
        0x13
        0x14
        0x15
        0xb
        0xd
        0xf
        0x2
        0x9
        0x6
        0x8
    .end array-data

    :array_df
    .array-data 4
        0x1
        0x16
        0x18
        0xb
        0xd
        0xf
        0x4
        0x6
        0x8
        0xa
        0x11
    .end array-data

    :array_e0
    .array-data 4
        0x1
        0x12
        0x19
        0x17
        0xb
        0xd
        0x4
        0x6
        0x8
        0xa
        0x11
    .end array-data

    :array_e1
    .array-data 4
        0x6
        0x0
        0x2
        0x1
        0x2
    .end array-data

    :array_e2
    .array-data 4
        0x14
        0x4
        0x2
        0x0
        0x4
    .end array-data

    :array_e3
    .array-data 4
        0x10
        0x0
        0x4
        0x0
        0x2
    .end array-data

    :array_e4
    .array-data 4
        0xe
        0x0
        0x8
        0x0
        0x2
    .end array-data

    :array_e5
    .array-data 4
        0xc
        0x0
        0x4
        0x0
        0x2
    .end array-data

    :array_e6
    .array-data 4
        0xc
        0x0
        0x8
        0x0
        0x2
    .end array-data

    :array_e7
    .array-data 4
        0xc
        0x2
        0x8
        0x0
        0x2
    .end array-data

    :array_e8
    .array-data 4
        0xa
        0x0
        0x4
        0x1
        0x2
    .end array-data

    :array_e9
    .array-data 4
        0xa
        0x0
        0x2
        0x1
        0x2
    .end array-data

    :array_ea
    .array-data 4
        0x8
        0x0
        0x4
        0x1
        0x2
    .end array-data

    :array_eb
    .array-data 4
        0x10
        0x2
        0x4
        0x0
        0x2
    .end array-data

    :array_ec
    .array-data 4
        0x10
        0x4
        0x2
        0x0
        0x2
    .end array-data

    :array_ed
    .array-data 4
        0x10
        0x2
        0x4
        0x0
        0x2
    .end array-data

    :array_ee
    .array-data 4
        0x1c9
        0x1cb
        0x151
        0xb6
        0x17f
        0x133
        0x18e
        0x199
        0x17d
        0x1cc
        0x104
        0x1d0
        0x96
        0x21f
        0xc3
        0xd9
        0x68
        0x1b1
        0x1b5
        0x16f
    .end array-data

    :array_ef
    .array-data 4
        0x20c
        0xad
        0x9d
        0x10a
        0xbd
        0x19d
        0x1b3
        0x15c
        0xb5
        0x108
        0x80
        0x15f
        0x217
        0x10d
        0x1f1
        0xb1
    .end array-data

    :array_f0
    .array-data 4
        0x188
        0x1c5
        0x12b
        0xc4
        0x1a2
        0x1a7
        0x1b9
        0x204
        0x12e
        0x121
        0xcc
        0x1d0
    .end array-data

    :array_f1
    .array-data 4
        0x1b8
        0x1f0
        -0x6
        0x1fa
        0x18e
        -0x4
        0x178
        0x1bb
        -0x3
        0xaf
        0xea
        0xb0
        0x176
        0x196
        0x1e0
        -0x2
        0x92
        0xd4
        -0x5
        0x169
        0x147
        0x1f4
        0x11b
        0x1c3
        0x1a3
        0xf7
        0xed
        0x180
        0xcb
        0xd9
        -0x1
        0xd2
    .end array-data

    :array_f2
    .array-data 4
        0x18b
        0xd0
        0x179
        0x193
        0x184
        0x1a7
        0x1a6
        0x17a
        0x17b
        0x194
        0x12d
        0x12c
        0x12b
        0x12a
        0x129
        0x128
        0x127
        0x126
        0x125
        0x124
    .end array-data

    :array_f3
    .array-data 4
        0x104
        0x150
        0x13b
        -0x1
        0x106
        0x18c
        0x149
        -0x2
        0x136
        0x5
        0x183
        -0x3
        0x7
        0x148
        0x22
        -0x4
        0x4
        0x146
        0x154
        -0x5
        0x105
        0x132
        0x13f
        -0x6
        0x145
        0x6
        -0x7
        -0x8
        -0xa
        -0x9
        0x10a
        0x25
    .end array-data

    :array_f4
    .array-data 4
        0x9
        0x11
        0x9
        0x11
        0x9
        0x11
        0x9
        0x11
    .end array-data

    :array_f5
    .array-data 4
        0x4
        0x7
        0x6
        0x8
        0x3
        0x5
        0x9
        0x2
    .end array-data

    :array_f6
    .array-data 4
        0x2
        0xa
        0x2
        0xa
        0x2
        0xa
        0x2
        0xa
    .end array-data

    :array_f7
    .array-data 4
        0x11
        0x10
        0xd
        0x19
        0x9
        0x11
        0x9
        0x11
    .end array-data

    :array_f8
    .array-data 4
        0xc
        0xf
        0xb
        0xd
        0xe
        0x10
        0x11
        0xa
    .end array-data

    :array_f9
    .array-data 4
        0xa
        0xe
        0xb
        0x2
        0x12
        0xa
        0x2
        0x12
    .end array-data

    :array_fa
    .array-data 4
        0x10
        0x19
        0xf
        0x15
        0x12
        0xe
        0xa
        0x12
    .end array-data

    :array_fb
    .array-data 4
        0xf
        0xe
        0x10
        0x13
        0x14
        0x15
        0x12
        0x19
    .end array-data

    :array_fc
    .array-data 4
        0xe
        0xf
        0x10
        0x13
        0x14
        0x15
        0x19
        0x12
    .end array-data

    :array_fd
    .array-data 4
        0x19
        0x15
        0x18
        0x14
        0x17
        0x12
        0x16
        0x13
    .end array-data

    :array_fe
    .array-data 4
        0x17
        0x14
        0x18
        0x16
        0x15
        0x13
        0x12
        0x19
    .end array-data

    :array_ff
    .array-data 4
        0x16
        0x13
        0x17
        0x14
        0x12
        0x18
        0x15
        0x19
    .end array-data

    :array_100
    .array-data 4
        0xa
        0xd
    .end array-data

    :array_101
    .array-data 4
        0xe
        0x11
    .end array-data

    :array_102
    .array-data 4
        0x3
        0x8
    .end array-data

    :array_103
    .array-data 4
        0x2
        0x3
    .end array-data

    :array_104
    .array-data 4
        0x8
        0x9
    .end array-data

    :array_105
    .array-data 4
        0x13
        0x18
    .end array-data

    :array_106
    .array-data 4
        0x1
        0x1
    .end array-data

    :array_107
    .array-data 4
        0xa
        0xd
    .end array-data

    :array_108
    .array-data 1
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x0t
        0x0t
    .end array-data

    :array_109
    .array-data 1
        0x1t
        0x0t
        0x1t
        0x1t
        0x1t
        0x0t
        0x0t
        0x0t
    .end array-data

    :array_10a
    .array-data 4
        0x10
        0x16
        0x1a
        0x1f
        0x28
        0x2a
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final W(II)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x4

    if-ne p0, v0, :cond_0

    sget-object p0, La/ak;->BP:[Ljava/lang/String;

    invoke-static {p1}, La/ak;->cy(I)I

    move-result p1

    aget-object p0, p0, p1

    return-object p0

    :cond_0
    const/4 v0, 0x6

    if-ne p0, v0, :cond_1

    sget-object p0, La/ak;->BQ:[Ljava/lang/String;

    invoke-static {p1}, La/ak;->cy(I)I

    move-result p1

    aget-object p0, p0, p1

    return-object p0

    :cond_1
    const/16 v0, 0xc

    if-ne p0, v0, :cond_2

    sget-object p0, La/ak;->BX:[Ljava/lang/String;

    invoke-static {p1}, La/ak;->cy(I)I

    move-result p1

    aget-object p0, p0, p1

    return-object p0

    :cond_2
    sget-object p1, La/ak;->BO:[Ljava/lang/String;

    aget-object p0, p1, p0

    return-object p0
.end method

.method public static final X(II)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x1

    if-eq p0, v0, :cond_6

    const/4 v0, 0x3

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x4

    if-ne p0, v0, :cond_1

    sget-object p0, La/ak;->BP:[Ljava/lang/String;

    aget-object p0, p0, p1

    return-object p0

    :cond_1
    const/4 v0, 0x6

    if-ne p0, v0, :cond_2

    sget-object p0, La/ak;->BQ:[Ljava/lang/String;

    aget-object p0, p0, p1

    return-object p0

    :cond_2
    const/16 v0, 0xc

    if-ne p0, v0, :cond_3

    sget-object p0, La/ak;->BX:[Ljava/lang/String;

    aget-object p0, p0, p1

    return-object p0

    :cond_3
    const/4 v0, 0x7

    if-ne p0, v0, :cond_4

    sget-object p0, La/ak;->BS:[Ljava/lang/String;

    aget-object p0, p0, p1

    return-object p0

    :cond_4
    const/16 v0, 0x8

    if-ne p0, v0, :cond_5

    sget-object p0, La/ak;->BR:[Ljava/lang/String;

    aget-object p0, p0, p1

    return-object p0

    :cond_5
    sget-object p1, La/ak;->BO:[Ljava/lang/String;

    aget-object p0, p1, p0

    return-object p0

    :cond_6
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, La/ak;->BO:[Ljava/lang/String;

    aget-object p0, v1, p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "? divis?o"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static Y(II)I
    .locals 0

    int-to-float p0, p0

    int-to-float p1, p1

    div-float/2addr p0, p1

    const/high16 p1, 0x42c80000    # 100.0f

    mul-float p0, p0, p1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static Z(II)F
    .locals 0

    int-to-float p0, p0

    int-to-float p1, p1

    div-float/2addr p0, p1

    const/high16 p1, 0x42c80000    # 100.0f

    mul-float p0, p0, p1

    return p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)I
    .locals 2

    const-string v0, "shbffile"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x1

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method public static a(ILandroid/content/Context;Z)Ljava/lang/String;
    .locals 0

    if-nez p1, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    if-eqz p2, :cond_1

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/high16 p2, 0x7f010000

    :goto_0
    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :cond_1
    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f010001

    goto :goto_0

    :goto_1
    if-lez p0, :cond_2

    array-length p2, p1

    if-ge p0, p2, :cond_2

    aget-object p0, p1, p0

    return-object p0

    :cond_2
    const-string p0, ""

    return-object p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2

    const-string v0, "shbffile"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method public static final cy(I)I
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object p0

    invoke-virtual {p0}, La/z;->iw()I

    move-result p0

    return p0
.end method
