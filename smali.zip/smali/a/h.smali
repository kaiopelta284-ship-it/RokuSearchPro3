.class public abstract La/h;
.super Ljava/lang/Object;


# static fields
.field private static oU:Z

.field public static oV:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Le/t;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/h$1;

    invoke-direct {v0}, La/h$1;-><init>()V

    sput-object v0, La/h;->oV:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static B(Z)V
    .locals 0

    sput-boolean p0, La/h;->oU:Z

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, La/h;->gi()V

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v0, La/b;->nz:Ljava/util/ArrayList;

    sget-object v0, Lc/a;->TF:La/b;

    invoke-static {}, La/z;->lj()I

    move-result v1

    new-array v1, v1, [I

    iput-object v1, v0, La/b;->nA:[I

    sget-object v0, Lc/a;->TF:La/b;

    sget-object v1, La/ak;->Ap:[Ljava/lang/String;

    array-length v1, v1

    new-array v1, v1, [I

    iput-object v1, v0, La/b;->nB:[I

    const/4 v0, 0x0

    invoke-static {v0, p0}, La/x;->a(ZLandroid/content/Context;)V

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v2, 0x32

    if-ge v1, v2, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-static {}, La/z;->lj()I

    move-result v2

    new-array v2, v2, [I

    iput-object v2, v1, La/b;->nA:[I

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-static {v0, p0}, La/x;->b(ZLandroid/content/Context;)V

    :cond_1
    sget-object p0, Lc/a;->TF:La/b;

    iget-object p0, p0, La/b;->nz:Ljava/util/ArrayList;

    sget-object v1, La/h;->oV:Ljava/util/Comparator;

    invoke-static {p0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    sget-object p0, Lc/a;->TF:La/b;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/b;->nC:Ljava/util/ArrayList;

    const/4 p0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nA:[I

    array-length v1, v1

    if-ge p0, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nA:[I

    aget v1, v1, p0

    const/16 v2, 0xa

    if-lt v1, v2, :cond_2

    new-instance v1, Lcomponents/bv;

    invoke-direct {v1}, Lcomponents/bv;-><init>()V

    invoke-virtual {v1, p0}, Lcomponents/bv;->setPais(I)V

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->nA:[I

    aget v2, v2, p0

    invoke-virtual {v1, v2}, Lcomponents/bv;->dE(I)V

    invoke-virtual {v1, v0}, Lcomponents/bv;->at(Z)V

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->nC:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 p0, p0, 0x1

    goto :goto_0

    :cond_3
    sget-object p0, Lc/a;->TF:La/b;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b;->nD:Ljava/util/ArrayList;

    invoke-static {}, La/h;->gs()V

    return-void
.end method

.method public static a(Lest/ArrayLigaType;)V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lest/ArrayLigaType;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nD:Ljava/util/ArrayList;

    iget-object v2, p0, Lest/ArrayLigaType;->a:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static aD(I)V
    .locals 4

    new-instance v0, Lest/ArrayLigaType;

    invoke-direct {v0}, Lest/ArrayLigaType;-><init>()V

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lest/ConfigLigaType;

    invoke-virtual {v2}, Lest/ConfigLigaType;->getPais()I

    move-result v2

    if-ne v2, p0, :cond_0

    iget-object v2, v0, Lest/ArrayLigaType;->a:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v3, v3, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "P"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object p0

    invoke-virtual {p0}, La/z;->lk()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ".cfg"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :try_start_0
    new-instance v1, Ljava/io/FileOutputStream;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "user.dir"

    invoke-static {v3}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "/conf_ligas_nacionais/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    new-instance p0, Ljava/io/ObjectOutputStream;

    invoke-direct {p0, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    invoke-virtual {p0, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {p0}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    return-void
.end method

.method public static b(Landroid/content/Context;)V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->nC:Ljava/util/ArrayList;

    invoke-static {v0}, La/h;->y(Ljava/util/ArrayList;)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    invoke-static {}, La/z;->lj()I

    move-result v2

    if-ge v1, v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kD()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    sget-object v1, Lc/a;->TF:La/b;

    const/16 v2, 0x7ea

    invoke-virtual {v1, v2}, La/b;->ak(I)V

    invoke-static {}, La/a;->cL()V

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nC:Ljava/util/ArrayList;

    invoke-static {v1}, La/h;->x(Ljava/util/ArrayList;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eA()Z

    move-result v1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    invoke-static {v3}, La/a;->aa(I)I

    move-result v1

    if-lez v1, :cond_1

    invoke-static {v1, v2, v3}, La/a;->h(III)V

    :cond_1
    invoke-static {}, La/a;->cV()V

    invoke-static {p0}, La/v;->g(Landroid/content/Context;)V

    invoke-static {}, La/h;->gj()V

    const/4 p0, 0x0

    :goto_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p0, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->hF()V

    add-int/lit8 p0, p0, 0x1

    goto :goto_1

    :cond_2
    const/4 p0, 0x0

    :goto_2
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p0, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->hF()V

    add-int/lit8 p0, p0, 0x1

    goto :goto_2

    :cond_3
    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->eh()V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->isJogaSelecoesAll()Z

    move-result p0

    if-eqz p0, :cond_4

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dM()V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dO()V

    :cond_4
    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->isJogaIntClubes()Z

    move-result p0

    if-eqz p0, :cond_6

    invoke-static {}, La/h;->gr()V

    invoke-static {}, La/h;->gq()V

    invoke-static {}, La/h;->gn()V

    invoke-static {}, La/h;->go()V

    invoke-static {}, La/h;->gm()V

    invoke-static {}, La/h;->gp()V

    invoke-static {v2}, La/a;->Z(I)I

    move-result p0

    if-lez p0, :cond_5

    invoke-static {p0, v3, v0}, La/a;->h(III)V

    :cond_5
    invoke-static {}, La/h;->gk()V

    invoke-static {}, La/h;->gl()V

    invoke-static {}, La/h;->gConf()V

    invoke-static {}, La/h;->gRecopa()V

    invoke-static {}, La/h;->gMundial()V

    invoke-static {}, La/h;->gSuperMundial()V

    invoke-static {}, La/h;->gCss()V

    invoke-static {}, La/h;->gCne()V

    invoke-static {}, La/h;->gCv()V

    :cond_6
    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object p0

    sget-object v0, Lcomponents/ce;->RK:Ljava/util/Comparator;

    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->dJ()I

    return-void
.end method

.method private static gCne()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->cneCopa:Ld/cne;

    if-nez v0, :cond_0

    new-instance v0, Ld/cne;

    invoke-direct {v0}, Ld/cne;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    iput-object v0, v1, La/b;->cneCopa:Ld/cne;

    :cond_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ld/cne;->yA()V

    :cond_1
    return-void
.end method

.method private static gConf()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/ag;

    invoke-direct {v1}, Ld/ag;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/ag;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->xi()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0291

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/ag;->setNome(Ljava/lang/String;)V

    return-void
.end method

.method private static gCss()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->cssCopa:Ld/css;

    if-nez v0, :cond_0

    new-instance v0, Ld/css;

    invoke-direct {v0}, Ld/css;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    iput-object v0, v1, La/b;->cssCopa:Ld/css;

    :cond_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ld/css;->yA()V

    :cond_1
    return-void
.end method

.method private static gCv()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->cvCopa:Ld/cv;

    if-nez v0, :cond_0

    new-instance v0, Ld/cv;

    invoke-direct {v0}, Ld/cv;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    iput-object v0, v1, La/b;->cvCopa:Ld/cv;

    :cond_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ld/cv;->yA()V

    :cond_1
    return-void
.end method

.method private static gMundial()V
    .locals 1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ee()Ld/y;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ld/y;->yA()V

    :cond_0
    return-void
.end method

.method private static gRecopa()V
    .locals 1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, La/h;->gRecopaE()V

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-static {}, La/h;->gRecopaS()V

    :cond_1
    return-void
.end method

.method private static gRecopaE()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/z;

    invoke-direct {v1}, Ld/z;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/z;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ej()Ld/z;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ld/z;->yD()V

    :cond_0
    return-void
.end method

.method private static gRecopaS()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/aa;

    invoke-direct {v1}, Ld/aa;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/aa;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ei()Ld/aa;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ld/aa;->yD()V

    :cond_0
    return-void
.end method

.method private static gSuperMundial()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->superMundial:Ld/sm;

    if-nez v0, :cond_0

    new-instance v0, Ld/sm;

    invoke-direct {v0}, Ld/sm;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    iput-object v0, v1, La/b;->superMundial:Ld/sm;

    :cond_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ld/sm;->yA()V

    :cond_1
    return-void
.end method

.method public static gi()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    :goto_0
    invoke-static {}, La/z;->lj()I

    move-result v1

    if-ge v0, v1, :cond_0

    new-instance v1, La/y;

    invoke-direct {v1, v0}, La/y;-><init>(I)V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private static gj()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1, v0}, La/ac;->cc(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-virtual {v0, v1}, La/b;->ap(I)V

    return-void
.end method

.method private static gk()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/ad;

    invoke-direct {v1}, Ld/ad;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/ad;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->gk()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0277

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/ad;->setNome(Ljava/lang/String;)V

    return-void
.end method

.method private static gl()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/v;

    invoke-direct {v1}, Ld/v;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/v;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->xi()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b026e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/v;->setNome(Ljava/lang/String;)V

    return-void
.end method

.method private static gm()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/u;

    invoke-direct {v1}, Ld/u;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/u;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dZ()Ld/u;

    move-result-object v0

    invoke-virtual {v0}, Ld/u;->xi()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dZ()Ld/u;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dZ()Ld/u;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0063

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/u;->setNome(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private static gn()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/s;

    invoke-direct {v1}, Ld/s;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/s;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eb()Ld/s;

    move-result-object v0

    invoke-virtual {v0}, Ld/s;->xi()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eb()Ld/s;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eb()Ld/s;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b001d

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/s;->setNome(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private static go()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/r;

    invoke-direct {v1}, Ld/r;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/r;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ea()Ld/r;

    move-result-object v0

    invoke-virtual {v0}, Ld/r;->xi()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ea()Ld/r;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ea()Ld/r;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b00e0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/r;->setNome(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private static gp()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/w;

    invoke-direct {v1}, Ld/w;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/w;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dY()Ld/w;

    move-result-object v0

    invoke-virtual {v0}, Ld/w;->xi()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dY()Ld/w;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dY()Ld/w;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b00e1

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/w;->setNome(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private static gq()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/t;

    invoke-direct {v1}, Ld/t;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/t;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0054

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/t;->setNome(Ljava/lang/String;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v0

    invoke-virtual {v0}, Ld/t;->xi()V

    return-void
.end method

.method private static gr()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    new-instance v1, Ld/p;

    invoke-direct {v1}, Ld/p;-><init>()V

    invoke-virtual {v0, v1}, La/b;->a(Ld/p;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dR()Ld/p;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b00df

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ld/p;->setNome(Ljava/lang/String;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dR()Ld/p;

    move-result-object v0

    invoke-virtual {v0}, Ld/p;->xi()V

    return-void
.end method

.method public static gs()V
    .locals 1

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public static gt()V
    .locals 29

    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    const-string v2, "AC"

    const-string v3, "AL"

    const-string v4, "AM"

    const-string v5, "AP"

    const-string v6, "BA"

    const-string v7, "CE"

    const-string v8, "DF"

    const-string v9, "ES"

    const-string v10, "GO"

    const-string v11, "MA"

    const-string v12, "MG"

    const-string v13, "MS"

    const-string v14, "MT"

    const-string v15, "PA"

    const-string v16, "PB"

    const-string v17, "PE"

    const-string v18, "PI"

    const-string v19, "PR"

    const-string v20, "RJ"

    const-string v21, "RN"

    const-string v22, "RO"

    const-string v23, "RR"

    const-string v24, "RS"

    const-string v25, "SC"

    const-string v26, "SE"

    const-string v27, "SP"

    const-string v28, "TO"

    filled-new-array/range {v2 .. v28}, [Ljava/lang/String;

    new-array v2, v0, [[Ljava/lang/Integer;

    const/4 v3, 0x2

    new-array v4, v3, [Ljava/lang/Integer;

    const/16 v5, 0x12

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v6, 0x0

    aput-object v5, v4, v6

    const/16 v5, 0x19

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x1

    aput-object v5, v4, v7

    aput-object v4, v2, v6

    new-array v4, v0, [Ljava/lang/Integer;

    const/16 v5, 0xa

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v6

    const/16 v8, 0x11

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v7

    const/16 v8, 0x16

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v3

    const/16 v8, 0x17

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v9, 0x3

    aput-object v8, v4, v9

    aput-object v4, v2, v7

    const/16 v4, 0x9

    new-array v8, v4, [Ljava/lang/Integer;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v8, v6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v8, v7

    const/4 v10, 0x5

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v8, v3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v8, v9

    const/16 v11, 0xe

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v8, v0

    const/16 v11, 0xf

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    aput-object v11, v8, v10

    const/16 v11, 0x10

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const/4 v13, 0x6

    aput-object v12, v8, v13

    const/16 v12, 0x13

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const/4 v14, 0x7

    aput-object v12, v8, v14

    const/16 v12, 0x18

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const/16 v15, 0x8

    aput-object v12, v8, v15

    aput-object v8, v2, v3

    const/16 v8, 0xc

    new-array v12, v8, [Ljava/lang/Integer;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v7

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v3

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v9

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v0

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v10

    const/16 v10, 0xb

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    aput-object v16, v12, v13

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v12, v14

    const/16 v8, 0xd

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v12, v15

    const/16 v8, 0x14

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v12, v4

    const/16 v4, 0x15

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v12, v5

    const/16 v4, 0x1a

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v12, v10

    aput-object v12, v2, v9

    const/4 v4, 0x0

    :goto_0
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    invoke-virtual {v5}, La/ac;->getPais()I

    move-result v5

    const/16 v8, 0x1d

    if-ne v5, v8, :cond_3

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    invoke-virtual {v5}, La/ac;->getEstado()I

    move-result v5

    aget-object v8, v2, v6

    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v8, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_0

    aget v5, v1, v6

    add-int/2addr v5, v7

    aput v5, v1, v6

    goto :goto_1

    :cond_0
    aget-object v8, v2, v7

    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v8, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    aget v5, v1, v7

    add-int/2addr v5, v7

    aput v5, v1, v7

    goto :goto_1

    :cond_1
    aget-object v8, v2, v3

    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v8, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_2

    aget v5, v1, v3

    add-int/2addr v5, v7

    aput v5, v1, v3

    goto :goto_1

    :cond_2
    aget-object v8, v2, v9

    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v8, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    aget v5, v1, v9

    add-int/2addr v5, v7

    aput v5, v1, v9

    :cond_3
    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_0

    :cond_4
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-static {}, La/h;->gu()Ljava/util/ArrayList;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->fr()[Z

    move-result-object v3

    const/4 v4, 0x0

    :goto_2
    if-ge v6, v0, :cond_6

    aget-boolean v5, v3, v6

    if-eqz v5, :cond_5

    aget v5, v1, v6

    if-lt v5, v11, :cond_5

    sget-object v4, Lc/a;->TF:La/b;

    new-instance v5, Ld/ab;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v5, v8, v2}, Ld/ab;-><init>(Ljava/lang/Integer;Ljava/util/ArrayList;)V

    invoke-virtual {v4, v5, v6}, La/b;->a(Ld/ab;I)V

    const/4 v4, 0x1

    :cond_5
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_6
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v4}, La/b;->w(Z)V

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public static gu()Ljava/util/ArrayList;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    sget-object v2, Lc/a;->TF:La/b;

    const/16 v3, 0x1d

    invoke-virtual {v2, v3}, La/b;->ah(I)La/y;

    move-result-object v2

    if-eqz v2, :cond_8

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v4

    invoke-virtual {v4}, Lest/Options;->isConviteRegionais()Z

    move-result v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ne v4, v6, :cond_0

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->getPais()I

    move-result v4

    if-ne v4, v3, :cond_0

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v4, 0x0

    :goto_0
    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_3

    const/4 v7, 0x0

    :goto_1
    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/q;

    invoke-virtual {v8}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_2

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/q;

    invoke-virtual {v8}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_1

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/q;

    invoke-virtual {v8}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->db()I

    move-result v4

    if-le v4, v6, :cond_5

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eL()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_5

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eA()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x4

    if-ne v2, v4, :cond_5

    const/4 v2, 0x0

    :goto_2
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eL()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_5

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eL()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/cr;

    invoke-virtual {v4}, Lcomponents/cr;->ww()La/ac;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-result v4

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eL()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/cr;

    invoke-virtual {v4}, Lcomponents/cr;->ww()La/ac;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_5
    :goto_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v5, v2, :cond_7

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    if-ne v2, v3, :cond_6

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_7
    invoke-static {v1}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_8
    return-object v0
.end method

.method public static gv()Z
    .locals 1

    sget-boolean v0, La/h;->oU:Z

    return v0
.end method

.method public static i(III)V
    .locals 3

    new-instance v0, Lest/ConfigLigaType;

    invoke-direct {v0}, Lest/ConfigLigaType;-><init>()V

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-ne p0, v2, :cond_0

    const/16 p0, 0xa

    invoke-virtual {v0, p0}, Lest/ConfigLigaType;->setnTimes(I)V

    invoke-virtual {v0, v1}, Lest/ConfigLigaType;->setnRebaixados(I)V

    goto :goto_0

    :cond_0
    if-ne p0, v1, :cond_1

    const/16 p0, 0x14

    invoke-virtual {v0, p0}, Lest/ConfigLigaType;->setnTimes(I)V

    const/4 p0, 0x4

    invoke-virtual {v0, p0}, Lest/ConfigLigaType;->setnRebaixados(I)V

    :cond_1
    :goto_0
    invoke-virtual {v0, p1}, Lest/ConfigLigaType;->setPais(I)V

    invoke-virtual {v0, p2}, Lest/ConfigLigaType;->setDivisao(I)V

    sget-object p0, Lc/a;->TF:La/b;

    iget-object p0, p0, La/b;->nD:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public static x(Ljava/util/ArrayList;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bv;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bv;

    invoke-virtual {v1}, Lcomponents/bv;->uU()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bv;

    invoke-virtual {v2}, Lcomponents/bv;->getPais()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kE()V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2, v1}, La/b;->a(La/y;)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public static y(Ljava/util/ArrayList;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bv;",
            ">;)V"
        }
    .end annotation

    const/4 p0, -0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    invoke-static {}, La/z;->lj()I

    move-result p0

    new-array p0, p0, [I

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/t;

    invoke-virtual {v1}, Le/t;->getPais()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v2, v1}, La/b;->am(I)Z

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Le/t;

    invoke-virtual {v2}, Le/t;->getPais()I

    move-result v2

    aget v2, p0, v2

    const/4 v3, 0x1

    const/16 v4, 0xf

    if-lt v2, v4, :cond_0

    if-ne v1, v3, :cond_1

    :cond_0
    new-instance v1, La/ac;

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Le/t;

    invoke-direct {v1, v2}, La/ac;-><init>(Le/t;)V

    sget-object v1, Lc/a;->TF:La/b;

    iget-object v1, v1, La/b;->nz:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/t;

    invoke-virtual {v1}, Le/t;->getPais()I

    move-result v1

    aget v2, p0, v1

    add-int/2addr v2, v3

    aput v2, p0, v1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method
