.class public abstract La/al;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static Cd:Ljava/util/Comparator; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/ay;",
            ">;"
        }
    .end annotation
.end field

.field public static Ce:Ljava/util/Comparator; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/ba;",
            ">;"
        }
    .end annotation
.end field

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private BW:I

.field private BX:Z

.field private BY:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/c;",
            ">;"
        }
    .end annotation
.end field

.field private BZ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/ay;",
            ">;"
        }
    .end annotation
.end field

.field private Ca:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/ba;",
            ">;"
        }
    .end annotation
.end field

.field private Cb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ah;",
            ">;"
        }
    .end annotation
.end field

.field private Cc:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private decisaoTerceiroLugar:Z

.field private pV:I

.field private pq:Ljava/lang/String;

.field private wJ:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/al$1;

    invoke-direct {v0}, La/al$1;-><init>()V

    sput-object v0, La/al;->Cd:Ljava/util/Comparator;

    new-instance v0, La/al$2;

    invoke-direct {v0}, La/al$2;-><init>()V

    sput-object v0, La/al;->Ce:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/al;->pq:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, La/al;->BW:I

    const/4 v1, -0x1

    iput v1, p0, La/al;->wJ:I

    const/4 v2, 0x1

    iput-boolean v2, p0, La/al;->BX:Z

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/al;->BY:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/al;->BZ:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/al;->Ca:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/al;->Cb:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La/al;->Cc:Ljava/util/ArrayList;

    iput-boolean v0, p0, La/al;->decisaoTerceiroLugar:Z

    iput v1, p0, La/al;->pV:I

    return-void
.end method

.method public static a(IZI)Ljava/util/ArrayList;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZI)",
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eA()Z

    move-result v1

    if-eqz v1, :cond_0

    if-nez p0, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    const/16 v2, 0x1d

    invoke-virtual {v1, v2}, La/b;->ah(I)La/y;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ge v2, v3, :cond_6

    const/4 v3, 0x0

    :goto_1
    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v3, v6, :cond_5

    const/4 v6, 0x2

    if-ne p0, v6, :cond_1

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/a;

    invoke-virtual {v7}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    instance-of v7, v7, Ld/q;

    if-eqz v7, :cond_1

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/a;

    invoke-virtual {v7}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ld/q;

    invoke-virtual {v7}, Ld/q;->xT()I

    move-result v7

    const/16 v8, 0x13e

    if-ne v7, v8, :cond_1

    :goto_2
    const/4 v6, 0x1

    goto/16 :goto_3

    :cond_1
    if-ne p0, v6, :cond_2

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v6, v6, Ld/q;

    if-eqz v6, :cond_2

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->xS()I

    move-result v6

    const/16 v7, 0x709

    if-lt v6, v7, :cond_2

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->xS()I

    move-result v6

    const/16 v7, 0x70d

    if-gt v6, v7, :cond_2

    goto :goto_2

    :cond_2
    if-ne p0, v4, :cond_3

    if-ne p2, v5, :cond_3

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/al;

    invoke-virtual {v6}, La/al;->cG()I

    move-result v6

    const/16 v7, 0x9

    if-ne v6, v7, :cond_3

    goto :goto_2

    :cond_3
    const/4 v6, 0x0

    :goto_3
    if-nez v6, :cond_4

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_4

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/al;

    invoke-virtual {v6, p0}, La/al;->cA(I)Z

    move-result v6

    if-eqz v6, :cond_4

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/a;

    invoke-virtual {v6}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1

    :cond_5
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_6
    if-ne p0, v4, :cond_14

    if-eqz p1, :cond_14

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->fe()Ld/o;

    move-result-object p2

    if-eqz p2, :cond_7

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->fe()Ld/o;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_7

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->fe()Ld/o;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->superMundial:Ld/sm;

    if-eqz p2, :cond_8

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->superMundial:Ld/sm;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_8

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->superMundial:Ld/sm;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cssCopa:Ld/css;

    if-eqz p2, :cond_9

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cssCopa:Ld/css;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_9

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cssCopa:Ld/css;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cpaulistaCopa:Ld/cpaulista;

    if-eqz p2, :cond_a

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cpaulistaCopa:Ld/cpaulista;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_a

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cpaulistaCopa:Ld/cpaulista;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cneCopa:Ld/cne;

    if-eqz p2, :cond_b

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cneCopa:Ld/cne;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_b

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cneCopa:Ld/cne;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_b
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cvCopa:Ld/cv;

    if-eqz p2, :cond_c

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cvCopa:Ld/cv;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_c

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->cvCopa:Ld/cv;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_c
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->fg()Ld/n;

    move-result-object p2

    if-eqz p2, :cond_d

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->fg()Ld/n;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_d

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->fg()Ld/n;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_d
    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->ff()Ld/c;

    move-result-object p2

    if-eqz p2, :cond_14

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->ff()Ld/c;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_14

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->ff()Ld/c;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->ouroCopa:Ld/ouro;

    if-eqz p2, :cond_e

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_e
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->africaCopa:Ld/africa;

    if-eqz p2, :cond_f

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_f
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->asiaCopa:Ld/asia;

    if-eqz p2, :cond_10

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_10
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->ofcCopa:Ld/ofc;

    if-eqz p2, :cond_11

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_11
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->elimccCopa:Ld/elimcc;

    if-eqz p2, :cond_12

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_12
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->africaElimCopa:Ld/elimaf;

    if-eqz p2, :cond_13

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_13
    sget-object p2, Lc/a;->TF:La/b;

    iget-object p2, p2, La/b;->asiaElimCopa:Ld/elimas;

    if-eqz p2, :cond_14

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_14
    if-eqz p1, :cond_15

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ee()Ld/y;

    move-result-object p0

    if-eqz p0, :cond_15

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ee()Ld/y;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_15

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ee()Ld/y;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_15
    if-eqz p1, :cond_16

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->ej()Ld/z;

    move-result-object p2

    if-eqz p2, :cond_16

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->ej()Ld/z;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_16

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->ej()Ld/z;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_16
    if-eqz p1, :cond_17

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ei()Ld/aa;

    move-result-object p0

    if-eqz p0, :cond_17

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ei()Ld/aa;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_17

    sget-object p0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/b;->ei()Ld/aa;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_17
    return-object v0
.end method

.method public static getSerialversionuid()J
    .locals 2

    const-wide/16 v0, 0x1

    return-wide v0
.end method


# virtual methods
.method public T(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/ay;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/al;->BZ:Ljava/util/ArrayList;

    return-void
.end method

.method public X(Z)V
    .locals 0

    iput-boolean p1, p0, La/al;->BX:Z

    return-void
.end method

.method public Y(Z)V
    .locals 0

    iput-boolean p1, p0, La/al;->decisaoTerceiroLugar:Z

    return-void
.end method

.method public Z(Z)Ljava/lang/String;
    .locals 0

    const-string p1, ""

    return-object p1
.end method

.method public aa(II)V
    .locals 0

    iput p1, p0, La/al;->BW:I

    iput p2, p0, La/al;->wJ:I

    return-void
.end method

.method public bk(I)V
    .locals 0

    iput p1, p0, La/al;->pV:I

    return-void
.end method

.method public cA(I)Z
    .locals 4

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez p1, :cond_1

    iget p1, p0, La/al;->BW:I

    if-ne p1, v2, :cond_0

    return v1

    :cond_0
    iget p1, p0, La/al;->BW:I

    if-ne p1, v0, :cond_9

    return v2

    :cond_1
    if-ne p1, v2, :cond_6

    iget p1, p0, La/al;->BW:I

    const/4 v0, 0x4

    if-ne p1, v0, :cond_2

    return v2

    :cond_2
    iget p1, p0, La/al;->BW:I

    const/4 v0, 0x5

    if-ne p1, v0, :cond_3

    return v2

    :cond_3
    iget p1, p0, La/al;->BW:I

    const/4 v0, 0x6

    if-ne p1, v0, :cond_4

    return v2

    :cond_4
    iget p1, p0, La/al;->BW:I

    const/16 v0, 0x8

    if-ne p1, v0, :cond_5

    return v2

    :cond_5
    iget p1, p0, La/al;->BW:I

    const/16 v0, 0xc

    if-ne p1, v0, :cond_9

    return v2

    :cond_6
    const/4 v3, 0x3

    if-ne p1, v0, :cond_7

    iget p1, p0, La/al;->BW:I

    if-ne p1, v3, :cond_9

    return v2

    :cond_7
    if-ne p1, v3, :cond_9

    iget p1, p0, La/al;->BW:I

    const/4 v0, 0x7

    if-eq p1, v0, :cond_8

    iget p1, p0, La/al;->BW:I

    const/16 v0, 0x9

    if-ne p1, v0, :cond_9

    :cond_8
    return v2

    :cond_9
    return v1
.end method

.method public cB(I)V
    .locals 11

    invoke-virtual {p0}, La/al;->nX()V

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    move-object v1, p0

    check-cast v1, Ld/q;

    invoke-virtual {v1}, Ld/q;->yb()I

    move-result v1

    new-instance v2, La/ah;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->db()I

    move-result v3

    invoke-direct {v2, v3}, La/ah;-><init>(I)V

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->db()I

    move-result v3

    invoke-virtual {v2, v3}, La/ah;->ad(I)V

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    array-length v5, v0

    if-ge v4, v5, :cond_2

    const/4 v5, 0x0

    :goto_1
    iget-object v6, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_1

    iget-object v6, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcomponents/ba;

    invoke-virtual {v6}, Lcomponents/ba;->tn()I

    move-result v6

    aget v7, v0, v4

    if-ne v6, v7, :cond_0

    iget-object v6, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcomponents/ba;

    invoke-virtual {v6}, Lcomponents/ba;->tm()D

    move-result-wide v6

    int-to-double v8, v1

    cmpl-double v10, v6, v8

    if-ltz v10, :cond_0

    invoke-virtual {v2}, La/ah;->nA()Ljava/util/ArrayList;

    move-result-object v6

    iget-object v7, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/ba;

    invoke-virtual {v7}, Lcomponents/ba;->nD()La/p;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_0

    invoke-virtual {v2}, La/ah;->nA()Ljava/util/ArrayList;

    move-result-object v6

    iget-object v7, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/ba;

    invoke-virtual {v7}, Lcomponents/ba;->nD()La/p;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2}, La/ah;->nB()Ljava/util/ArrayList;

    move-result-object v6

    iget-object v7, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcomponents/ba;

    invoke-virtual {v5}, Lcomponents/ba;->nD()La/p;

    move-result-object v5

    invoke-virtual {v5}, La/p;->hE()La/ac;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_0
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_1
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    iget-object v0, p0, La/al;->Cb:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_3
    iget-object v0, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_4

    iget-object v0, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/ba;

    invoke-virtual {v0}, Lcomponents/ba;->tm()D

    move-result-wide v4

    int-to-double v6, v1

    cmpl-double v0, v4, v6

    if-ltz v0, :cond_3

    iget-object v0, p0, La/al;->Cc:Ljava/util/ArrayList;

    iget-object v1, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ba;

    invoke-virtual {v1}, Lcomponents/ba;->nD()La/p;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v0, p0, La/al;->BW:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_4

    if-nez p1, :cond_4

    iget-object p1, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/ba;

    invoke-virtual {p1}, Lcomponents/ba;->nD()La/p;

    move-result-object p1

    if-eqz p1, :cond_4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p1, v0}, La/p;->a(Ljava/lang/Boolean;)V

    return-void

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_4
    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x1
        0x2
        0x2
        0x5
        0x6
        0x6
        0x3
        0x3
        0x4
        0x4
    .end array-data
.end method

.method public cC(I)Ljava/util/ArrayList;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/ArrayList<",
            "Lcomponents/ba;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, p0

    check-cast v1, Ld/q;

    invoke-virtual {v1}, Ld/q;->yb()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    iget-object v4, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_3

    iget-object v4, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/ba;

    invoke-virtual {v4}, Lcomponents/ba;->tn()I

    move-result v4

    const/16 v5, 0x14

    if-ne v4, p1, :cond_1

    iget-object v4, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/ba;

    invoke-virtual {v4}, Lcomponents/ba;->tm()D

    move-result-wide v6

    int-to-double v8, v1

    cmpl-double v4, v6, v8

    if-ltz v4, :cond_1

    if-ge v3, v5, :cond_0

    iget-object v4, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v3, v3, 0x1

    :cond_1
    if-ne v3, v5, :cond_2

    return-object v0

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-object v0
.end method

.method public cD(I)V
    .locals 0

    iput p1, p0, La/al;->wJ:I

    return-void
.end method

.method public cG()I
    .locals 1

    iget v0, p0, La/al;->BW:I

    return v0
.end method

.method public cz(I)La/ac;
    .locals 3

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/c;

    invoke-virtual {v1}, La/c;->db()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    sub-int/2addr v2, p1

    if-ne v1, v2, :cond_0

    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/c;

    invoke-virtual {p1}, La/c;->fu()La/ac;

    move-result-object p1

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public getIcon()I
    .locals 1

    const/4 v0, -0x1

    return v0
.end method

.method public getNome()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/al;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public iM()I
    .locals 1

    iget v0, p0, La/al;->pV:I

    return v0
.end method

.method public iw()I
    .locals 1

    iget v0, p0, La/al;->wJ:I

    return v0
.end method

.method public l(La/p;)Lcomponents/ay;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ay;

    invoke-virtual {v1}, Lcomponents/ay;->nD()La/p;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/ay;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, Lcomponents/ay;

    invoke-direct {v0, p0, p1}, Lcomponents/ay;-><init>(La/al;La/p;)V

    iget-object p1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method public m(La/al;)V
    .locals 0

    instance-of p1, p0, Ld/p;

    if-eqz p1, :cond_0

    return-void

    :cond_0
    instance-of p1, p0, Ld/t;

    if-eqz p1, :cond_1

    return-void

    :cond_1
    instance-of p1, p0, Ld/v;

    if-eqz p1, :cond_2

    return-void

    :cond_2
    instance-of p1, p0, Ld/ag;

    if-eqz p1, :cond_3

    return-void

    :cond_3
    instance-of p1, p0, Ld/ad;

    if-eqz p1, :cond_4

    return-void

    :cond_4
    instance-of p1, p0, Ld/y;

    if-eqz p1, :cond_5

    return-void

    :cond_5
    instance-of p1, p0, Ld/z;

    if-eqz p1, :cond_6

    return-void

    :cond_6
    instance-of p1, p0, Ld/aa;

    if-eqz p1, :cond_7

    return-void

    :cond_7
    instance-of p1, p0, La/y;

    if-eqz p1, :cond_8

    return-void

    :cond_8
    instance-of p1, p0, Ld/m;

    return-void
.end method

.method public m(La/p;)V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ay;

    invoke-virtual {v1}, Lcomponents/ay;->nD()La/p;

    move-result-object v1

    if-ne v1, p1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_1
    if-ltz v0, :cond_2

    iget-object p1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public n(La/p;)Lcomponents/ay;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ay;

    invoke-virtual {v1}, Lcomponents/ay;->nD()La/p;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/ay;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public nL()Z
    .locals 1

    iget-boolean v0, p0, La/al;->BX:Z

    return v0
.end method

.method public nM()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/c;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/al;->BY:Ljava/util/ArrayList;

    return-object v0
.end method

.method public nN()La/c;
    .locals 3

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/c;

    invoke-virtual {v1}, La/c;->db()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    if-ne v1, v2, :cond_0

    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/c;

    return-object v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public nO()La/c;
    .locals 3

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/c;

    invoke-virtual {v1}, La/c;->db()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-ne v1, v2, :cond_0

    invoke-virtual {p0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/c;

    return-object v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public nP()Z
    .locals 1

    iget-boolean v0, p0, La/al;->decisaoTerceiroLugar:Z

    return v0
.end method

.method public nQ()Ld/m;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public nR()La/y;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public nS()I
    .locals 1

    const/4 v0, -0x1

    return v0
.end method

.method public nT()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/al;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public nU()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/ay;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    return-object v0
.end method

.method public nV()Lcomponents/ay;
    .locals 2

    invoke-virtual {p0}, La/al;->nW()V

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/ay;

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public nW()V
    .locals 3

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    if-eqz v0, :cond_2

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ay;

    invoke-virtual {v1}, Lcomponents/ay;->nD()La/p;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ay;

    invoke-virtual {v1}, Lcomponents/ay;->nD()La/p;

    move-result-object v1

    invoke-virtual {v1, p0}, La/p;->i(La/al;)La/s;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v2, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/ay;

    invoke-virtual {v1}, La/s;->fC()I

    move-result v1

    invoke-virtual {v2, v1}, Lcomponents/ay;->dr(I)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    sget-object v1, La/al;->Cd:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_2
    return-void
.end method

.method public nX()V
    .locals 2

    iget-object v0, p0, La/al;->Ca:Ljava/util/ArrayList;

    sget-object v1, La/al;->Ce:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method public nY()V
    .locals 1

    iget-object v0, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public nZ()V
    .locals 1

    iget-object v0, p0, La/al;->BZ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public o(La/p;)Lcomponents/ba;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/ba;

    invoke-virtual {v1}, Lcomponents/ba;->nD()La/p;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/ba;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, Lcomponents/ba;

    invoke-direct {v0, p0, p1}, Lcomponents/ba;-><init>(La/al;La/p;)V

    iget-object p1, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method public oa()Ljava/util/ArrayList;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/ba;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, p0

    check-cast v1, Ld/q;

    invoke-virtual {v1}, Ld/q;->yb()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    iget-object v4, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_2

    iget-object v4, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/ba;

    invoke-virtual {v4}, Lcomponents/ba;->tm()D

    move-result-wide v4

    int-to-double v6, v1

    cmpl-double v8, v4, v6

    const/16 v4, 0x14

    if-ltz v8, :cond_0

    if-ge v3, v4, :cond_0

    iget-object v5, p0, La/al;->Ca:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    :cond_0
    if-lt v3, v4, :cond_1

    return-object v0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public ob()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ah;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/al;->Cb:Ljava/util/ArrayList;

    return-object v0
.end method

.method public oc()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/al;->Cc:Ljava/util/ArrayList;

    return-object v0
.end method

.method public p(La/p;)V
    .locals 7

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    const/16 v1, 0x11

    const/16 v2, 0xa

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-eq v0, v5, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-ne v0, v5, :cond_1

    invoke-virtual {p1}, La/p;->getLado()I

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    const/16 v6, 0x9

    if-eq v0, v6, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    const/4 v6, 0x2

    if-ne v0, v5, :cond_2

    invoke-virtual {p1}, La/p;->getLado()I

    move-result v0

    if-ne v0, v5, :cond_2

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-eq v0, v6, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-ne v0, v6, :cond_3

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-lt v0, v4, :cond_6

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    const/16 v6, 0x8

    if-le v0, v6, :cond_5

    goto :goto_0

    :cond_3
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-ne v0, v4, :cond_4

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-lt v0, v2, :cond_6

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-le v0, v1, :cond_5

    goto :goto_0

    :cond_4
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    const/4 v6, 0x4

    if-ne v0, v6, :cond_5

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    const/16 v6, 0x12

    if-ge v0, v6, :cond_5

    goto :goto_0

    :cond_5
    const/4 v3, 0x1

    :cond_6
    :goto_0
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-ne v0, v5, :cond_7

    invoke-virtual {p1}, La/p;->getLado()I

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-ne v0, v1, :cond_7

    const/4 v3, 0x1

    :cond_7
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    if-ne v0, v5, :cond_8

    invoke-virtual {p1}, La/p;->getLado()I

    move-result v0

    if-ne v0, v5, :cond_8

    invoke-virtual {p1}, La/p;->io()I

    move-result v0

    if-ne v0, v2, :cond_8

    const/4 v3, 0x1

    :cond_8
    const/16 v0, 0x1a

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    if-eqz v3, :cond_d

    invoke-virtual {p0, p1}, La/al;->o(La/p;)Lcomponents/ba;

    move-result-object v1

    invoke-virtual {p1}, La/p;->iB()D

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcomponents/ba;->d(D)V

    invoke-virtual {p1}, La/p;->io()I

    move-result v2

    aget v2, v0, v2

    if-ne v2, v4, :cond_9

    invoke-virtual {p1}, La/p;->ia()I

    move-result v2

    if-nez v2, :cond_9

    const/4 p1, 0x6

    :goto_1
    invoke-virtual {v1, p1}, Lcomponents/ba;->ds(I)V

    return-void

    :cond_9
    invoke-virtual {p1}, La/p;->io()I

    move-result v2

    aget v2, v0, v2

    if-ne v2, v4, :cond_a

    invoke-virtual {p1}, La/p;->ia()I

    move-result v2

    if-ne v2, v5, :cond_a

    :goto_2
    invoke-virtual {v1, v4}, Lcomponents/ba;->ds(I)V

    return-void

    :cond_a
    invoke-virtual {p1}, La/p;->io()I

    move-result v2

    aget v2, v0, v2

    const/4 v3, 0x5

    if-ne v2, v3, :cond_b

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    if-ne v2, v4, :cond_b

    goto :goto_2

    :cond_b
    invoke-virtual {p1}, La/p;->io()I

    move-result v2

    aget v2, v0, v2

    if-ne v2, v5, :cond_c

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    if-ne v2, v4, :cond_c

    goto :goto_2

    :cond_c
    invoke-virtual {p1}, La/p;->io()I

    move-result p1

    aget p1, v0, p1

    goto :goto_1

    :cond_d
    return-void

    :array_0
    .array-data 4
        -0x1
        0x0
        0x5
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x1
        0x3
        0x6
        0x6
        0x6
        0x3
        0x3
        0x3
        0x3
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
    .end array-data
.end method

.method public setNome(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/al;->pq:Ljava/lang/String;

    return-void
.end method
