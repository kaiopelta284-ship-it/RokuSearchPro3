.class public La/ac;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static iwCache:[I = null

.field private static final serialVersionUID:J = 0x1L

.field public static xO:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public agCond:I

.field public agIn:[I

.field public agInNome:[Ljava/lang/String;

.field public agMin:[I

.field public agOff:Z

.field public agOut:[I

.field public agOutNome:[Ljava/lang/String;

.field private camisa:I

.field private divisao:I

.field public formStr:Ljava/lang/String;

.field public nivelHist:Ljava/lang/String;

.field private pV:I

.field private pais:I

.field private pq:Ljava/lang/String;

.field public precoArq:I

.field public precoCad:I

.field public precoCam:I

.field public precoGeral:I

.field private qX:La/l;

.field public rcChem:I

.field public rcRiseYear:I

.field private sn:I

.field private so:I

.field private xA:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ae;",
            ">;"
        }
    .end annotation
.end field

.field private xB:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ad;",
            ">;"
        }
    .end annotation
.end field

.field private xC:[I

.field private xD:Z

.field private xE:I

.field private xF:Z

.field private xG:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private xH:La/n;

.field private xI:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cf;",
            ">;"
        }
    .end annotation
.end field

.field private xJ:Lcomponents/cf;

.field private xK:[I

.field private xL:[[I

.field private xM:I

.field private xN:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ai;",
            ">;"
        }
    .end annotation
.end field

.field private xSponsor:I

.field private xf:I

.field private xg:Ljava/lang/String;

.field private xh:Ljava/lang/Boolean;

.field private xi:Ljava/lang/Boolean;

.field private xj:I

.field private xk:I

.field private transient xl:La/af;

.field private xm:I

.field private xn:J

.field private xo:I

.field private xp:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private xq:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;"
        }
    .end annotation
.end field

.field private xr:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private xs:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private xt:La/p;

.field private xu:La/p;

.field private xv:La/p;

.field private xw:La/p;

.field private xx:I

.field private xy:Ljava/lang/String;

.field private xz:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/ac$1;

    invoke-direct {v0}, La/ac$1;-><init>()V

    sput-object v0, La/ac;->xO:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/ac;->xf:I

    iput v0, p0, La/ac;->pV:I

    const/4 v1, 0x0

    iput-object v1, p0, La/ac;->xg:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/ac;->xh:Ljava/lang/Boolean;

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/ac;->xi:Ljava/lang/Boolean;

    iput v2, p0, La/ac;->divisao:I

    iput v0, p0, La/ac;->xm:I

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/ac;->xn:J

    iput v2, p0, La/ac;->xo:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xq:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xr:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xs:Ljava/util/ArrayList;

    iput-object v1, p0, La/ac;->xt:La/p;

    iput-object v1, p0, La/ac;->xu:La/p;

    iput-object v1, p0, La/ac;->xv:La/p;

    iput-object v1, p0, La/ac;->xw:La/p;

    const-string v0, "#ffffff"

    iput-object v0, p0, La/ac;->xy:Ljava/lang/String;

    const-string v0, "#2d3690"

    iput-object v0, p0, La/ac;->xz:Ljava/lang/String;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xA:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xB:Ljava/util/ArrayList;

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, La/ac;->xC:[I

    iput v2, p0, La/ac;->xE:I

    iput-boolean v2, p0, La/ac;->xF:Z

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v3, 0x3e8

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ac;->sn:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xG:Ljava/util/ArrayList;

    new-instance v0, La/n;

    invoke-direct {v0}, La/n;-><init>()V

    iput-object v0, p0, La/ac;->xH:La/n;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xI:Ljava/util/ArrayList;

    iput-object v1, p0, La/ac;->xJ:Lcomponents/cf;

    iput v2, p0, La/ac;->camisa:I

    const/16 v0, 0x9

    new-array v1, v0, [I

    iput-object v1, p0, La/ac;->xK:[I

    const/4 v1, 0x3

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const-class v1, I

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[I

    iput-object v0, p0, La/ac;->xL:[[I

    iput v2, p0, La/ac;->xM:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xN:Ljava/util/ArrayList;

    const-string v0, ""

    iput-object v0, p0, La/ac;->pq:Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>(Le/t;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/ac;->xf:I

    iput v0, p0, La/ac;->pV:I

    const/4 v1, 0x0

    iput-object v1, p0, La/ac;->xg:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/ac;->xh:Ljava/lang/Boolean;

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    iput-object v3, p0, La/ac;->xi:Ljava/lang/Boolean;

    iput v2, p0, La/ac;->divisao:I

    iput v0, p0, La/ac;->xm:I

    const-wide/16 v3, 0x0

    iput-wide v3, p0, La/ac;->xn:J

    iput v2, p0, La/ac;->xo:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xq:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xr:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xs:Ljava/util/ArrayList;

    iput-object v1, p0, La/ac;->xt:La/p;

    iput-object v1, p0, La/ac;->xu:La/p;

    iput-object v1, p0, La/ac;->xv:La/p;

    iput-object v1, p0, La/ac;->xw:La/p;

    const-string v0, "#ffffff"

    iput-object v0, p0, La/ac;->xy:Ljava/lang/String;

    const-string v0, "#2d3690"

    iput-object v0, p0, La/ac;->xz:Ljava/lang/String;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xA:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xB:Ljava/util/ArrayList;

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, La/ac;->xC:[I

    iput v2, p0, La/ac;->xE:I

    iput-boolean v2, p0, La/ac;->xF:Z

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v3, 0x3e8

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/ac;->sn:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xG:Ljava/util/ArrayList;

    new-instance v0, La/n;

    invoke-direct {v0}, La/n;-><init>()V

    iput-object v0, p0, La/ac;->xH:La/n;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xI:Ljava/util/ArrayList;

    iput-object v1, p0, La/ac;->xJ:Lcomponents/cf;

    iput v2, p0, La/ac;->camisa:I

    const/16 v0, 0x9

    new-array v1, v0, [I

    iput-object v1, p0, La/ac;->xK:[I

    const/4 v1, 0x3

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const-class v1, I

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[I

    iput-object v0, p0, La/ac;->xL:[[I

    iput v2, p0, La/ac;->xM:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xN:Ljava/util/ArrayList;

    const-string v0, ""

    iput-object v0, p0, La/ac;->pq:Ljava/lang/String;

    invoke-virtual {p1}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/ac;->pq:Ljava/lang/String;

    invoke-virtual {p1}, Le/t;->getFileRef()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/ac;->xg:Ljava/lang/String;

    invoke-virtual {p1}, Le/t;->getId()I

    move-result v0

    iput v0, p0, La/ac;->xj:I

    invoke-virtual {p1}, Le/t;->getPais()I

    move-result v0

    iput v0, p0, La/ac;->pais:I

    invoke-virtual {p1}, Le/t;->getEstado()I

    move-result v0

    iput v0, p0, La/ac;->xk:I

    invoke-virtual {p1}, Le/t;->getReputacao()I

    move-result v0

    invoke-virtual {p0, v0}, La/ac;->setReputacao(I)V

    invoke-virtual {p1}, Le/t;->getCorF()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/ac;->xy:Ljava/lang/String;

    invoke-virtual {p1}, Le/t;->getCorT()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/ac;->xz:Ljava/lang/String;

    invoke-virtual {p1}, Le/t;->getNivel()I

    move-result v0

    invoke-virtual {p0, v0}, La/ac;->setNivel(I)V

    invoke-virtual {p1}, Le/t;->getEstadio()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Le/t;->getCapacidade()I

    move-result v1

    invoke-virtual {p0, v0, v1}, La/ac;->a(Ljava/lang/String;I)V

    new-instance v0, La/af;

    invoke-virtual {p1}, Le/t;->getTecnico()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/af;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Le/t;->getTecNac()I

    move-result v1

    invoke-virtual {v0, v1}, La/af;->cj(I)V

    iput-object v0, p0, La/ac;->xl:La/af;

    invoke-virtual {v0}, La/af;->getUniqueId()I

    move-result v1

    iput v1, p0, La/ac;->xm:I

    iget-object v1, p0, La/ac;->xl:La/af;

    invoke-virtual {v1, p0}, La/af;->i(La/ac;)V

    iget-object v1, p0, La/ac;->xl:La/af;

    invoke-virtual {p1}, Le/t;->getReputacao()I

    move-result v3

    invoke-virtual {v1, v3}, La/af;->setReputacao(I)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0}, La/b;->a(La/af;)V

    invoke-virtual {p1}, Le/t;->getCorBase()I

    move-result v0

    iput v0, p0, La/ac;->xx:I

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    new-instance v1, La/p;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/g;

    invoke-direct {v1, v3, v2, p0}, La/p;-><init>(Le/g;ZLa/ac;)V

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3, v1}, La/b;->a(La/p;)V

    iget-object v3, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/ac;->lY()V

    invoke-virtual {p0}, La/ac;->lX()V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1, p0}, La/b;->b(La/ac;)V

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;IIIILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/ArrayList;Z)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "IIII",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Ljava/util/ArrayList<",
            "Lcomponents/bx;",
            ">;Z)V"
        }
    .end annotation

    move-object v0, p0

    move v1, p8

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, -0x1

    iput v2, v0, La/ac;->xf:I

    iput v2, v0, La/ac;->pV:I

    const/4 v3, 0x0

    iput-object v3, v0, La/ac;->xg:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    iput-object v5, v0, La/ac;->xh:Ljava/lang/Boolean;

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    iput-object v5, v0, La/ac;->xi:Ljava/lang/Boolean;

    iput v4, v0, La/ac;->divisao:I

    iput v2, v0, La/ac;->xm:I

    const-wide/16 v5, 0x0

    iput-wide v5, v0, La/ac;->xn:J

    iput v4, v0, La/ac;->xo:I

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xp:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xq:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xr:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xs:Ljava/util/ArrayList;

    iput-object v3, v0, La/ac;->xt:La/p;

    iput-object v3, v0, La/ac;->xu:La/p;

    iput-object v3, v0, La/ac;->xv:La/p;

    iput-object v3, v0, La/ac;->xw:La/p;

    const-string v2, "#ffffff"

    iput-object v2, v0, La/ac;->xy:Ljava/lang/String;

    const-string v2, "#2d3690"

    iput-object v2, v0, La/ac;->xz:Ljava/lang/String;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xA:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xB:Ljava/util/ArrayList;

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    iput-object v2, v0, La/ac;->xC:[I

    iput v4, v0, La/ac;->xE:I

    iput-boolean v4, v0, La/ac;->xF:Z

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/16 v5, 0x3e8

    invoke-virtual {v2, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, La/ac;->sn:I

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xG:Ljava/util/ArrayList;

    new-instance v2, La/n;

    invoke-direct {v2}, La/n;-><init>()V

    iput-object v2, v0, La/ac;->xH:La/n;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xI:Ljava/util/ArrayList;

    iput-object v3, v0, La/ac;->xJ:Lcomponents/cf;

    iput v4, v0, La/ac;->camisa:I

    const/16 v2, 0x9

    new-array v3, v2, [I

    iput-object v3, v0, La/ac;->xK:[I

    const/4 v3, 0x3

    filled-new-array {v2, v3}, [I

    move-result-object v2

    const-class v3, I

    invoke-static {v3, v2}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [[I

    iput-object v2, v0, La/ac;->xL:[[I

    iput v4, v0, La/ac;->xM:I

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, La/ac;->xN:Ljava/util/ArrayList;

    const-string v2, ""

    iput-object v2, v0, La/ac;->pq:Ljava/lang/String;

    move-object v2, p1

    iput-object v2, v0, La/ac;->pq:Ljava/lang/String;

    move-object v2, p2

    iput-object v2, v0, La/ac;->xg:Ljava/lang/String;

    move v2, p3

    iput v2, v0, La/ac;->xj:I

    move v2, p4

    iput v2, v0, La/ac;->pais:I

    move v2, p5

    iput v2, v0, La/ac;->xk:I

    invoke-virtual {v0, v1}, La/ac;->setReputacao(I)V

    move-object/from16 v2, p9

    iput-object v2, v0, La/ac;->xy:Ljava/lang/String;

    move-object/from16 v2, p10

    iput-object v2, v0, La/ac;->xz:Ljava/lang/String;

    move v2, p6

    invoke-virtual {v0, v2}, La/ac;->setNivel(I)V

    if-nez p14, :cond_0

    move-object/from16 v2, p11

    move/from16 v3, p12

    invoke-virtual {v0, v2, v3}, La/ac;->a(Ljava/lang/String;I)V

    new-instance v2, La/af;

    move-object v3, p7

    invoke-direct {v2, v3}, La/af;-><init>(Ljava/lang/String;)V

    iput-object v2, v0, La/ac;->xl:La/af;

    iget-object v3, v0, La/ac;->xl:La/af;

    invoke-virtual {v3, v0}, La/af;->i(La/ac;)V

    invoke-virtual {v2}, La/af;->getUniqueId()I

    move-result v3

    iput v3, v0, La/ac;->xm:I

    iget-object v3, v0, La/ac;->xl:La/af;

    invoke-virtual {v3, v1}, La/af;->setReputacao(I)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v2}, La/b;->a(La/af;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0}, La/b;->b(La/ac;)V

    :goto_0
    invoke-virtual/range {p13 .. p13}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v4, v1, :cond_1

    new-instance v1, La/p;

    move-object/from16 v2, p13

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bx;

    invoke-direct {v1, v3, v0}, La/p;-><init>(Lcomponents/bx;La/ac;)V

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3, v1}, La/b;->a(La/p;)V

    iget-object v3, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, La/ac;->getReputacao()I

    move-result v1

    iput v1, v0, La/ac;->xo:I

    :cond_1
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public static a(Ljava/util/ArrayList;IZZ)La/p;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;IZZ)",
            "La/p;"
        }
    .end annotation

    sget-object v0, La/ak;->AS:[[I

    aget-object v0, v0, p1

    const/4 v1, 0x0

    aget v0, v0, v1

    sget-object v2, La/ak;->AS:[[I

    aget-object v2, v2, p1

    const/4 v3, 0x1

    aget v2, v2, v3

    sget-object v4, La/ak;->AS:[[I

    aget-object v4, v4, p1

    const/4 v5, 0x2

    aget v4, v4, v5

    const/4 v6, -0x1

    if-ne v2, v6, :cond_0

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    :goto_0
    if-ne v4, v6, :cond_1

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    :goto_1
    const/16 v9, 0x12

    if-lt p1, v9, :cond_2

    const/4 v4, -0x1

    :cond_2
    const/4 p1, 0x0

    :goto_2
    const/4 p2, 0x4

    if-gt p1, p2, :cond_c

    sget-object v6, La/ak;->AV:[[I

    aget-object v6, v6, v0

    aget v6, v6, p1

    move v9, v4

    move v4, v2

    const/4 v2, 0x1

    :goto_3
    if-gt v2, p2, :cond_b

    move v10, v9

    move v9, v4

    const/4 v4, 0x0

    :goto_4
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v4, v11, :cond_a

    if-eqz v7, :cond_3

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->getLado()I

    move-result v9

    :cond_3
    if-eqz v8, :cond_4

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/p;

    invoke-virtual {v10}, La/p;->ia()I

    move-result v10

    :cond_4
    if-ne v2, v5, :cond_5

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->getLado()I

    move-result v9

    :cond_5
    const/4 v11, 0x3

    if-ne v2, v11, :cond_6

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->getLado()I

    move-result v9

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/p;

    invoke-virtual {v10}, La/p;->ia()I

    move-result v10

    :cond_6
    if-ne v2, p2, :cond_8

    if-nez p3, :cond_7

    :goto_5
    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    goto :goto_6

    :cond_7
    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/p;

    invoke-virtual {v11}, La/p;->getPosicao()I

    move-result v11

    if-eqz v11, :cond_8

    goto :goto_5

    :cond_8
    :goto_6
    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/p;

    invoke-virtual {v11}, La/p;->getPosicao()I

    move-result v11

    if-ne v6, v11, :cond_9

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/p;

    invoke-virtual {v11}, La/p;->getLado()I

    move-result v11

    if-ne v9, v11, :cond_9

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/p;

    invoke-virtual {v11}, La/p;->ia()I

    move-result v11

    if-ne v10, v11, :cond_9

    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/p;

    return-object p0

    :cond_9
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_4

    :cond_a
    add-int/lit8 v2, v2, 0x1

    move v4, v9

    move v9, v10

    goto/16 :goto_3

    :cond_b
    add-int/lit8 p1, p1, 0x1

    move v2, v4

    move v4, v9

    goto/16 :goto_2

    :cond_c
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(La/ac;La/t;IIZ)V
    .locals 16

    move-object/from16 v0, p0

    move/from16 v1, p2

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x6

    new-array v4, v3, [I

    fill-array-data v4, :array_0

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_0
    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-ge v6, v7, :cond_3

    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    const/4 v12, -0x1

    invoke-virtual {v7, v12}, La/p;->bd(I)V

    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    move-object/from16 v12, p1

    invoke-virtual {v7, v12, v5}, La/p;->a(La/t;Z)Z

    move-result v7

    if-eqz v7, :cond_2

    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    invoke-virtual {v7}, La/p;->getPosicao()I

    move-result v7

    if-ltz v7, :cond_0

    if-gt v7, v10, :cond_0

    aget v10, v4, v7

    add-int/2addr v10, v11

    aput v10, v4, v7

    :cond_0
    if-ne v7, v9, :cond_1

    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    invoke-virtual {v7}, La/p;->ia()I

    move-result v7

    if-nez v7, :cond_1

    aget v7, v4, v8

    add-int/2addr v7, v11

    aput v7, v4, v8

    :cond_1
    iget-object v7, v0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    invoke-virtual {v7}, La/p;->ia()I

    :cond_2
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_3
    move-object/from16 v12, p1

    sget-object v4, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {v2, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v4, v0, La/ac;->xr:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    iget-object v4, v0, La/ac;->xs:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/16 v6, 0x64

    invoke-virtual {v4, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    add-int/2addr v4, v11

    const/16 v7, 0x8

    const/4 v13, 0x7

    const/4 v14, 0x2

    if-ltz v4, :cond_4

    if-gt v4, v14, :cond_4

    const/4 v13, 0x1

    goto :goto_1

    :cond_4
    if-lt v4, v9, :cond_5

    if-gt v4, v10, :cond_5

    const/4 v13, 0x2

    goto :goto_1

    :cond_5
    if-lt v4, v8, :cond_6

    if-gt v4, v13, :cond_6

    const/4 v13, 0x3

    goto :goto_1

    :cond_6
    if-lt v4, v7, :cond_8

    const/16 v15, 0x26

    if-gt v4, v15, :cond_8

    :cond_7
    const/4 v13, 0x4

    goto :goto_1

    :cond_8
    const/16 v15, 0x27

    if-lt v4, v15, :cond_9

    const/16 v15, 0x31

    if-gt v4, v15, :cond_9

    const/4 v13, 0x5

    goto :goto_1

    :cond_9
    const/16 v15, 0x32

    if-lt v4, v15, :cond_a

    const/16 v15, 0x3c

    if-gt v4, v15, :cond_a

    const/4 v13, 0x6

    goto :goto_1

    :cond_a
    const/16 v15, 0x3d

    if-lt v4, v15, :cond_b

    const/16 v15, 0x41

    if-gt v4, v15, :cond_b

    goto :goto_1

    :cond_b
    const/16 v13, 0x42

    if-lt v4, v13, :cond_c

    const/16 v13, 0x48

    if-gt v4, v13, :cond_c

    const/16 v13, 0x8

    goto :goto_1

    :cond_c
    const/16 v7, 0x49

    if-lt v4, v7, :cond_d

    const/16 v7, 0x62

    if-gt v4, v7, :cond_d

    const/16 v4, 0x9

    const/16 v13, 0x9

    goto :goto_1

    :cond_d
    const/16 v7, 0x63

    if-lt v4, v7, :cond_7

    const/16 v7, 0x65

    if-gt v4, v7, :cond_7

    const/16 v4, 0xa

    const/16 v13, 0xa

    :goto_1
    if-lez p3, :cond_e

    move/from16 v13, p3

    :cond_e
    const/4 v4, 0x0

    :goto_2
    const/16 v7, 0xb

    if-ge v4, v7, :cond_12

    sget-object v7, La/ak;->AX:[[I

    aget-object v7, v7, v13

    aget v7, v7, v4

    invoke-static {v2, v7, v5, v5}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v15

    if-eqz v15, :cond_11

    invoke-virtual {v15, v7}, La/p;->bd(I)V

    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v15, v7}, La/p;->b(Ljava/lang/Boolean;)V

    iget-object v7, v0, La/ac;->xr:Ljava/util/ArrayList;

    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-ne v1, v11, :cond_f

    invoke-virtual/range {p1 .. p1}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual/range {p1 .. p1}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v7

    :goto_3
    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_f
    if-ne v1, v14, :cond_10

    invoke-virtual/range {p1 .. p1}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual/range {p1 .. p1}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v7

    goto :goto_3

    :cond_10
    :goto_4
    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_11
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_12
    const/4 v4, 0x0

    :goto_5
    sget-object v7, La/ak;->AW:[I

    array-length v7, v7

    if-ge v4, v7, :cond_16

    sget-object v7, La/ak;->AW:[I

    aget v7, v7, v4

    invoke-static {v2, v7, v11, v5}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v7

    if-eqz v7, :cond_15

    iget-object v15, v0, La/ac;->xs:Ljava/util/ArrayList;

    invoke-virtual {v15, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-ne v1, v11, :cond_13

    invoke-virtual/range {p1 .. p1}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v15

    :goto_6
    invoke-virtual {v15, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_13
    if-ne v1, v14, :cond_14

    invoke-virtual/range {p1 .. p1}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v15

    goto :goto_6

    :cond_14
    :goto_7
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_15
    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    :cond_16
    invoke-virtual {v0, v11}, La/ac;->S(Z)V

    if-eqz p4, :cond_1f

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/2addr v1, v11

    const/16 v2, 0x47

    const/16 v4, 0x46

    if-ltz v1, :cond_18

    if-gt v1, v4, :cond_18

    :cond_17
    const/4 v1, 0x0

    goto :goto_8

    :cond_18
    if-lt v1, v2, :cond_19

    const/16 v7, 0x50

    if-gt v1, v7, :cond_19

    const/4 v1, 0x1

    goto :goto_8

    :cond_19
    const/16 v7, 0x51

    if-lt v1, v7, :cond_17

    if-gt v1, v6, :cond_17

    const/4 v1, 0x2

    :goto_8
    new-instance v7, Ljava/util/Random;

    invoke-direct {v7}, Ljava/util/Random;-><init>()V

    invoke-virtual {v7, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    add-int/2addr v7, v11

    if-lt v7, v11, :cond_1a

    if-gt v7, v8, :cond_1a

    const/4 v3, 0x2

    goto :goto_a

    :cond_1a
    if-lt v7, v3, :cond_1b

    if-gt v7, v4, :cond_1b

    goto :goto_9

    :cond_1b
    if-lt v7, v2, :cond_1c

    if-gt v7, v6, :cond_1c

    const/4 v3, 0x1

    goto :goto_a

    :cond_1c
    :goto_9
    const/4 v3, 0x0

    :goto_a
    new-instance v7, Ljava/util/Random;

    invoke-direct {v7}, Ljava/util/Random;-><init>()V

    invoke-virtual {v7, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    add-int/2addr v7, v11

    if-lt v7, v11, :cond_1d

    if-gt v7, v4, :cond_1d

    goto :goto_b

    :cond_1d
    if-lt v7, v2, :cond_1e

    if-gt v7, v6, :cond_1e

    const/4 v2, 0x1

    goto :goto_c

    :cond_1e
    :goto_b
    const/4 v2, 0x0

    :goto_c
    new-array v4, v10, [I

    aput v13, v4, v5

    aput v1, v4, v11

    aput v3, v4, v14

    aput v2, v4, v9

    invoke-virtual {v0, v4}, La/ac;->j([I)V

    :cond_1f
    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method private a(La/al;I)V
    .locals 5

    move-object v4, p1

    invoke-virtual {p0}, La/ac;->getDivisao()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr p2, v1

    invoke-virtual {p1}, La/al;->cG()I

    move-result v2

    const/4 v3, 0x3

    if-ne v2, v1, :cond_0

    sget-object v2, La/ak;->AI:[[I

    array-length v2, v2

    if-ge v0, v2, :cond_0

    sget-object p1, La/ak;->AI:[[I

    aget-object p1, p1, v0

    array-length p1, p1

    if-ge p2, p1, :cond_1

    sget-object p1, La/ak;->AI:[[I

    aget-object p1, p1, v0

    aget p1, p1, p2

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/al;->cG()I

    move-result v0

    if-ne v0, v3, :cond_1

    invoke-virtual {p1}, La/al;->nS()I

    move-result p1

    if-ne p1, v1, :cond_1

    sget-object p1, La/ak;->AK:[I

    array-length p1, p1

    if-ge p2, p1, :cond_1

    sget-object p1, La/ak;->AK:[I

    aget p1, p1, p2

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    if-lez p1, :cond_2

    invoke-virtual {p0, p1, v3}, La/ac;->U(II)V

    invoke-static {p0, v4, p1}, Lcom/brasfoot/v2028/Recopa;->recordPrize(La/ac;La/al;I)V

    :cond_2
    return-void
.end method

.method public static a(La/t;La/ac;I)V
    .locals 16

    move-object/from16 v0, p0

    move/from16 v1, p2

    const/16 v2, 0x1a

    new-array v2, v2, [I

    const/16 v3, 0xd

    new-array v3, v3, [I

    const/4 v4, 0x1

    if-ne v1, v4, :cond_0

    invoke-virtual/range {p0 .. p0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v5

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v5

    :goto_0
    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    :goto_1
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v9

    const-wide v10, 0x3fe6666666666666L    # 0.7

    if-ge v7, v9, :cond_5

    move v9, v8

    const/4 v8, 0x0

    :goto_2
    if-gt v8, v4, :cond_4

    sget-object v12, La/ak;->AT:[[I

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/p;

    invoke-virtual {v13}, La/p;->io()I

    move-result v13

    aget-object v12, v12, v13

    aget v12, v12, v8

    if-lez v12, :cond_3

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/p;

    invoke-virtual {v12}, La/p;->getPosicao()I

    move-result v12

    sget-object v13, La/ak;->AS:[[I

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La/p;

    invoke-virtual {v14}, La/p;->io()I

    move-result v14

    aget-object v13, v13, v14

    aget v13, v13, v6

    if-eq v12, v13, :cond_1

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/p;

    invoke-virtual {v12}, La/p;->ip()I

    move-result v12

    int-to-double v12, v12

    mul-double v12, v12, v10

    invoke-static {v12, v13}, Ljava/lang/Math;->round(D)J

    move-result-wide v12

    long-to-int v12, v12

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/p;

    invoke-virtual {v13}, La/p;->io()I

    move-result v13

    if-ne v13, v4, :cond_2

    const-wide v13, 0x3fd3333333333333L    # 0.3

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/p;

    invoke-virtual {v9}, La/p;->ip()I

    move-result v9

    int-to-double v10, v9

    mul-double v10, v10, v13

    invoke-static {v10, v11}, Ljava/lang/Math;->round(D)J

    const/4 v9, 0x1

    goto :goto_3

    :cond_1
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/p;

    invoke-virtual {v10}, La/p;->ip()I

    move-result v12

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/p;

    invoke-virtual {v10}, La/p;->io()I

    move-result v10

    if-ne v10, v4, :cond_2

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/p;

    invoke-virtual {v10}, La/p;->ip()I

    :cond_2
    :goto_3
    sget-object v10, La/ak;->AT:[[I

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/p;

    invoke-virtual {v11}, La/p;->io()I

    move-result v11

    aget-object v10, v10, v11

    aget v10, v10, v8

    sget-object v11, La/ak;->AT:[[I

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/p;

    invoke-virtual {v13}, La/p;->io()I

    move-result v13

    aget-object v11, v11, v13

    aget v11, v11, v8

    aget v11, v3, v11

    add-int/2addr v11, v12

    aput v11, v3, v10

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/p;

    invoke-virtual {v10}, La/p;->io()I

    move-result v10

    aget v11, v2, v10

    add-int/2addr v11, v4

    aput v11, v2, v10

    :cond_3
    add-int/lit8 v8, v8, 0x1

    const-wide v10, 0x3fe6666666666666L    # 0.7

    goto/16 :goto_2

    :cond_4
    add-int/lit8 v7, v7, 0x1

    move v8, v9

    goto/16 :goto_1

    :cond_5
    const/4 v5, 0x3

    const/4 v7, 0x3

    const/4 v9, 0x0

    :goto_4
    const/16 v10, 0x8

    if-gt v7, v10, :cond_7

    aget v10, v2, v7

    if-lez v10, :cond_6

    add-int/lit8 v9, v9, 0x1

    :cond_6
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_7
    const/4 v7, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    :goto_5
    const/16 v12, 0x9

    if-gt v10, v12, :cond_9

    aget v12, v2, v10

    if-lez v12, :cond_8

    add-int/lit8 v11, v11, 0x1

    :cond_8
    add-int/lit8 v10, v10, 0x1

    goto :goto_5

    :cond_9
    const/16 v10, 0xb

    const/4 v12, 0x0

    :goto_6
    const/16 v13, 0x10

    if-gt v10, v13, :cond_b

    aget v13, v2, v10

    if-lez v13, :cond_a

    add-int/lit8 v12, v12, 0x1

    :cond_a
    add-int/lit8 v10, v10, 0x1

    goto :goto_6

    :cond_b
    const/16 v10, 0xa

    const/4 v13, 0x0

    :goto_7
    const/16 v14, 0x11

    if-gt v10, v14, :cond_d

    aget v14, v2, v10

    if-lez v14, :cond_c

    add-int/lit8 v13, v13, 0x1

    :cond_c
    add-int/lit8 v10, v10, 0x1

    goto :goto_7

    :cond_d
    const/16 v10, 0x12

    const/4 v14, 0x0

    :goto_8
    const/16 v6, 0x19

    if-gt v10, v6, :cond_f

    aget v6, v2, v10

    if-lez v6, :cond_e

    add-int/lit8 v14, v14, 0x1

    :cond_e
    add-int/lit8 v10, v10, 0x1

    goto :goto_8

    :cond_f
    const/16 v2, 0xc

    if-eq v9, v4, :cond_13

    if-ge v11, v7, :cond_10

    goto :goto_c

    :cond_10
    if-eqz v9, :cond_12

    if-eqz v8, :cond_11

    goto :goto_a

    :cond_11
    if-le v9, v5, :cond_14

    const/4 v6, 0x1

    :goto_9
    if-gt v6, v2, :cond_14

    aget v7, v3, v6

    int-to-double v7, v7

    const-wide v9, 0x3fe6666666666666L    # 0.7

    mul-double v7, v7, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->round(D)J

    move-result-wide v7

    long-to-int v7, v7

    aput v7, v3, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_9

    :cond_12
    :goto_a
    const/4 v6, 0x1

    :goto_b
    if-gt v6, v2, :cond_14

    aget v7, v3, v6

    int-to-double v7, v7

    const-wide v9, 0x3fc999999999999aL    # 0.2

    mul-double v7, v7, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->round(D)J

    move-result-wide v7

    long-to-int v7, v7

    aput v7, v3, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_b

    :cond_13
    :goto_c
    const/4 v6, 0x1

    :goto_d
    if-gt v6, v2, :cond_14

    aget v7, v3, v6

    int-to-double v7, v7

    const-wide v9, 0x3fe6666666666666L    # 0.7

    mul-double v7, v7, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->round(D)J

    move-result-wide v7

    long-to-int v7, v7

    aput v7, v3, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_d

    :cond_14
    const/4 v6, 0x4

    if-le v12, v6, :cond_15

    const/4 v6, 0x1

    :goto_e
    if-gt v6, v2, :cond_15

    aget v7, v3, v6

    int-to-double v7, v7

    const-wide v9, 0x3fe6666666666666L    # 0.7

    mul-double v7, v7, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->round(D)J

    move-result-wide v7

    long-to-int v7, v7

    aput v7, v3, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_e

    :cond_15
    if-le v14, v5, :cond_16

    const/4 v5, 0x1

    :goto_f
    if-gt v5, v2, :cond_16

    aget v6, v3, v5

    int-to-double v6, v6

    const-wide v8, 0x3fe6666666666666L    # 0.7

    mul-double v6, v6, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v6

    long-to-int v6, v6

    aput v6, v3, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_f

    :cond_16
    const/4 v5, 0x5

    if-le v13, v5, :cond_17

    const/4 v5, 0x1

    :goto_10
    if-gt v5, v2, :cond_17

    aget v6, v3, v5

    int-to-double v6, v6

    const-wide/high16 v8, 0x3fe0000000000000L    # 0.5

    mul-double v6, v6, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v6

    long-to-int v6, v6

    aput v6, v3, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_10

    :cond_17
    const/4 v5, 0x1

    const/4 v6, 0x0

    :goto_11
    if-gt v5, v2, :cond_18

    aget v7, v3, v5

    add-int/2addr v6, v7

    add-int/lit8 v5, v5, 0x1

    goto :goto_11

    :cond_18
    if-ne v1, v4, :cond_19

    invoke-virtual {v0, v6}, La/t;->bq(I)V

    return-void

    :cond_19
    invoke-virtual {v0, v6}, La/t;->br(I)V

    return-void
.end method

.method private b(La/al;II)V
    .locals 7

    invoke-virtual {p1}, La/al;->cG()I

    move-result p3

    const/4 v0, 0x1

    if-ne p3, v0, :cond_0

    invoke-virtual {p1}, La/al;->nS()I

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, -0x1

    :goto_0
    const/4 v2, 0x2

    if-eq p2, v0, :cond_1

    if-ne p2, v2, :cond_2

    :cond_1
    add-int/lit8 v3, p2, -0x1

    invoke-direct {p0, v3, p3, v1}, La/ac;->j(III)V

    :cond_2
    const/16 v1, 0xd

    new-array v1, v1, [[I

    const/4 v3, 0x0

    const/16 v4, 0xb

    new-array v5, v4, [I

    fill-array-data v5, :array_0

    aput-object v5, v1, v3

    new-array v3, v4, [I

    fill-array-data v3, :array_1

    aput-object v3, v1, v0

    new-array v3, v4, [I

    fill-array-data v3, :array_2

    aput-object v3, v1, v2

    new-array v3, v4, [I

    fill-array-data v3, :array_3

    const/4 v5, 0x3

    aput-object v3, v1, v5

    const/4 v3, 0x4

    new-array v6, v4, [I

    fill-array-data v6, :array_4

    aput-object v6, v1, v3

    const/4 v3, 0x5

    new-array v6, v4, [I

    fill-array-data v6, :array_5

    aput-object v6, v1, v3

    const/4 v3, 0x6

    new-array v6, v4, [I

    fill-array-data v6, :array_6

    aput-object v6, v1, v3

    const/4 v3, 0x7

    new-array v6, v4, [I

    fill-array-data v6, :array_7

    aput-object v6, v1, v3

    new-array v3, v4, [I

    fill-array-data v3, :array_8

    const/16 v6, 0x8

    aput-object v3, v1, v6

    const/16 v3, 0x9

    new-array v6, v4, [I

    fill-array-data v6, :array_0

    aput-object v6, v1, v3

    const/16 v3, 0xa

    new-array v6, v4, [I

    fill-array-data v6, :array_0

    aput-object v6, v1, v3

    const/16 v3, 0xb

    new-array v6, v4, [I

    fill-array-data v6, :array_0

    aput-object v6, v1, v3

    const/16 v3, 0xc

    new-array v6, v4, [I

    fill-array-data v6, :array_c

    aput-object v6, v1, v3

    aget-object v1, v1, p3

    if-ne p3, v0, :cond_4

    invoke-virtual {p1}, La/al;->nS()I

    move-result v3

    if-le v3, v0, :cond_4

    invoke-virtual {p1}, La/al;->nS()I

    move-result v1

    if-ne v1, v2, :cond_3

    new-array v1, v4, [I

    fill-array-data v1, :array_9

    goto :goto_1

    :cond_3
    new-array v1, v4, [I

    fill-array-data v1, :array_a

    :cond_4
    :goto_1
    if-ne p3, v5, :cond_5

    invoke-virtual {p1}, La/al;->nS()I

    move-result p1

    if-le p1, v0, :cond_5

    new-array v1, v4, [I

    fill-array-data v1, :array_b

    :cond_5
    const/16 v6, 0xc

    if-gt p3, v6, :cond_6

    iget-object p1, p0, La/ac;->xK:[I

    iget-object v0, p0, La/ac;->xK:[I

    aget v0, v0, p3

    aget p2, v1, p2

    add-int/2addr v0, p2

    aput v0, p1, p3

    :cond_6
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0xc
        0xa
        0x8
        0x7
        0x6
        0x5
        0x4
        0x3
        0x2
        0x1
    .end array-data

    :array_2
    .array-data 4
        0x0
        0xa
        0x7
        0x3
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x5
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x14
        0xf
        0x7
        0x7
        0x3
        0x3
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0xa
        0x5
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0xc
        0xa
        0x5
        0x5
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x5
        0x3
        0x2
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        0x0
        0x2
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_c
    .array-data 4
        0x0
        0xa
        0x7
        0x3
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method private iwRaw()I
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/ac;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    return v0
.end method

.method private j(III)V
    .locals 4

    const/4 v0, 0x2

    new-array v0, v0, [[I

    const/16 v1, 0xd

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    aput-object v2, v0, v3

    new-array v1, v1, [I

    fill-array-data v1, :array_1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    aget-object p1, v0, p1

    aget p1, p1, p2

    if-ne p2, v2, :cond_0

    if-le p3, v2, :cond_0

    const/16 p1, 0x32

    :cond_0
    iget p2, p0, La/ac;->xE:I

    add-int/2addr p2, p1

    iput p2, p0, La/ac;->xE:I

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x1f4
        0xc8
        0xa
        0x1388
        0x9c40
        0x3e8
        0x0
        0x1f4
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x5a
        0x32
        0x5
        0x3e8
        0x3e8
        0x1f4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public static lG()V
    .locals 9

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_8

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lE()Z

    move-result v3

    const/4 v4, -0x1

    const/16 v5, 0xc

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v3, :cond_3

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dD()I

    move-result v3

    if-eqz v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dD()I

    move-result v3

    if-ne v3, v6, :cond_2

    :cond_0
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v3, v5, :cond_2

    :cond_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v8}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getPais()I

    move-result v8

    invoke-virtual {v3, v8}, La/b;->al(I)La/y;

    move-result-object v3

    invoke-virtual {v3, v1}, La/y;->N(Z)V

    :cond_2
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->aiFormation(La/ac;)I

    move-result v4

    invoke-static {v3, v8, v7, v4, v7}, La/ac;->a(La/ac;La/t;IIZ)V

    :cond_3
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lE()Z

    move-result v3

    if-nez v3, :cond_7

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dD()I

    move-result v3

    if-eqz v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dD()I

    move-result v3

    if-ne v3, v6, :cond_6

    :cond_4
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    if-eqz v3, :cond_5

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v3, v5, :cond_6

    :cond_5
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jj()La/ac;

    move-result-object v5

    invoke-virtual {v5}, La/ac;->getPais()I

    move-result v5

    invoke-virtual {v3, v5}, La/b;->al(I)La/y;

    move-result-object v3

    invoke-virtual {v3, v1}, La/y;->N(Z)V

    :cond_6
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    const/4 v6, 0x2

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->aiFormation(La/ac;)I

    move-result v4

    invoke-static {v3, v5, v6, v4, v7}, La/ac;->a(La/ac;La/t;IIZ)V

    :cond_7
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_8
    return-void
.end method


# virtual methods
.method public L(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/ac;->xp:Ljava/util/ArrayList;

    return-void
.end method

.method public M(Ljava/util/ArrayList;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    invoke-virtual {p0}, La/ac;->lC()La/p;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/ac;->lC()La/p;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p0, p1}, La/ac;->N(Ljava/util/ArrayList;)V

    :cond_1
    return-void
.end method

.method public N(Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_0

    sget-object p1, La/ac;->xO:Ljava/util/Comparator;

    invoke-static {v0, p1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->hE()La/ac;

    move-result-object v1

    if-ne v1, p0, :cond_0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    iput-object p1, p0, La/ac;->xt:La/p;

    :cond_0
    return-void
.end method

.method public O(Ljava/util/ArrayList;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    invoke-virtual {p0}, La/ac;->lD()La/p;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/ac;->lD()La/p;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p0, p1}, La/ac;->P(Ljava/util/ArrayList;)V

    :cond_1
    return-void
.end method

.method public P(Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_6

    sget-object p1, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {v0, p1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 p1, 0x0

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getCr1()I

    move-result v2

    const/16 v3, 0x9

    if-ne v2, v3, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    if-nez v1, :cond_3

    const/4 v2, 0x0

    :goto_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->getPosicao()I

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    goto :goto_3

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    :goto_3
    if-nez v1, :cond_5

    :goto_4
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p1, v2, :cond_5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v2

    if-eqz v2, :cond_4

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    check-cast v1, La/p;

    goto :goto_5

    :cond_4
    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_5
    :goto_5
    if-eqz v1, :cond_6

    iput-object v1, p0, La/ac;->xu:La/p;

    :cond_6
    return-void
.end method

.method public Q(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La/ac;->xq:Ljava/util/ArrayList;

    return-void
.end method

.method public S(Z)V
    .locals 0

    iput-boolean p1, p0, La/ac;->xF:Z

    return-void
.end method

.method public T(II)V
    .locals 1

    iget-object v0, p0, La/ac;->xC:[I

    aput p2, v0, p1

    return-void
.end method

.method public T(Z)[I
    .locals 7

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->getPosicao()I

    move-result v5

    aget v6, v0, v5

    add-int/2addr v6, v4

    aput v6, v0, v5

    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->getPosicao()I

    move-result v5

    if-ne v5, v3, :cond_1

    iget-object v3, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->ia()I

    move-result v3

    if-ne v3, v4, :cond_1

    aget v3, v0, v2

    add-int/2addr v3, v4

    aput v3, v0, v2

    goto :goto_1

    :cond_0
    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-nez v5, :cond_1

    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->getPosicao()I

    move-result v5

    aget v6, v0, v5

    add-int/2addr v6, v4

    aput v6, v0, v5

    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->getPosicao()I

    move-result v5

    if-ne v5, v3, :cond_1

    iget-object v3, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->ia()I

    move-result v3

    if-nez v3, :cond_1

    aget v3, v0, v2

    add-int/2addr v3, v4

    aput v3, v0, v2

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_2
    return-object v0

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public U(II)V
    .locals 6

    const/4 v0, 0x3

    if-ne p2, v0, :cond_0

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lest/Options;->isFinRealista()Z

    move-result v0

    if-eqz v0, :cond_0

    div-int/lit8 p1, p1, 0x5

    mul-int/lit8 p1, p1, 0x3

    :cond_0
    iget-wide v0, p0, La/ac;->xn:J

    int-to-long v2, p1

    add-long v4, v0, v2

    invoke-virtual {p0, v4, v5}, La/ac;->d(J)V

    iget-object v0, p0, La/ac;->xH:La/n;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, La/ac;->xH:La/n;

    invoke-virtual {v0, p1, p2}, La/n;->J(II)V

    :cond_1
    return-void
.end method

.method public U(Z)V
    .locals 0

    iput-boolean p1, p0, La/ac;->xD:Z

    return-void
.end method

.method public V(II)V
    .locals 6

    iget-wide v0, p0, La/ac;->xn:J

    int-to-long v2, p1

    sub-long v4, v0, v2

    invoke-virtual {p0, v4, v5}, La/ac;->d(J)V

    iget-object v0, p0, La/ac;->xH:La/n;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, La/ac;->xH:La/n;

    invoke-virtual {v0, p1, p2}, La/n;->K(II)V

    :cond_0
    return-void
.end method

.method public a(La/al;II)V
    .locals 2

    invoke-virtual {p0, p1}, La/ac;->n(La/al;)La/ad;

    move-result-object v0

    invoke-virtual {v0, p2}, La/ad;->ch(I)V

    invoke-virtual {v0, p3}, La/ad;->ci(I)V

    const/16 v0, 0xa

    if-gt p2, v0, :cond_3

    invoke-direct {p0, p1, p2, p3}, La/ac;->b(La/al;II)V

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, La/af;->b(La/al;II)V

    :cond_0
    invoke-virtual {p0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    const/4 v0, 0x1

    if-eqz p3, :cond_2

    invoke-virtual {p1}, La/al;->cG()I

    move-result p3

    if-eq p3, v0, :cond_1

    invoke-virtual {p1}, La/al;->cG()I

    move-result p3

    const/4 v1, 0x3

    if-ne p3, v1, :cond_2

    :cond_1
    invoke-direct {p0, p1, p2}, La/ac;->a(La/al;I)V

    :cond_2
    if-ne p2, v0, :cond_3

    invoke-virtual {p0, p1}, La/ac;->p(La/al;)V

    :cond_3
    return-void
.end method

.method public a(La/l;)V
    .locals 0

    iput-object p1, p0, La/ac;->qX:La/l;

    return-void
.end method

.method public a(La/q;)V
    .locals 1

    iget-object v0, p0, La/ac;->xq:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public a(La/t;Ld/q;)V
    .locals 2

    invoke-virtual {p1}, La/t;->jb()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-ltz v0, :cond_0

    const/16 v1, 0x8

    :cond_0
    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v0

    const/4 v1, 0x0

    if-ne v0, p0, :cond_1

    invoke-virtual {p1}, La/t;->jD()I

    move-result v1

    invoke-virtual {p1}, La/t;->jF()I

    move-result p1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object v0

    if-ne v0, p0, :cond_2

    invoke-virtual {p1}, La/t;->jF()I

    move-result v1

    invoke-virtual {p1}, La/t;->jD()I

    move-result p1

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p0, p2}, La/ac;->c(Ld/q;)La/ae;

    move-result-object v0

    if-nez v0, :cond_3

    new-instance v0, La/ae;

    invoke-direct {v0, p0, p2}, La/ae;-><init>(La/ac;Ld/q;)V

    iget-object p2, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    invoke-virtual {v0}, La/ae;->fD()V

    invoke-virtual {v0, v1}, La/ae;->cf(I)V

    invoke-virtual {v0, p1}, La/ae;->cg(I)V

    if-le v1, p1, :cond_4

    invoke-virtual {v0}, La/ae;->fF()V

    const/4 p1, 0x3

    :goto_1
    invoke-virtual {v0, p1}, La/ae;->ce(I)V

    return-void

    :cond_4
    if-ge v1, p1, :cond_5

    invoke-virtual {v0}, La/ae;->fH()V

    return-void

    :cond_5
    if-ne v1, p1, :cond_6

    const/4 p1, 0x1

    goto :goto_1

    :cond_6
    return-void
.end method

.method public a(Lcomponents/cf;)V
    .locals 0

    iput-object p1, p0, La/ac;->xJ:Lcomponents/cf;

    return-void
.end method

.method public a(Ljava/lang/String;I)V
    .locals 1

    new-instance v0, La/l;

    invoke-direct {v0, p1, p2, p0}, La/l;-><init>(Ljava/lang/String;ILa/ac;)V

    iput-object v0, p0, La/ac;->qX:La/l;

    return-void
.end method

.method public a(La/p;Z)Z
    .locals 6

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    const/16 v2, 0x1e

    if-lt v0, v2, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    sget-object v2, La/ak;->zj:[I

    invoke-virtual {p0}, La/ac;->getDivisao()I

    move-result v3

    aget v2, v2, v3

    if-ge v0, v2, :cond_2

    return v1

    :cond_1
    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    sget-object v2, La/ak;->zk:[I

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result v3

    aget v2, v2, v3

    if-ge v0, v2, :cond_2

    return v1

    :cond_2
    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    sget-object v2, La/ak;->zl:[I

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result v3

    aget v2, v2, v3

    if-le v0, v2, :cond_3

    return v1

    :cond_3
    const/4 v0, 0x1

    if-eqz p2, :cond_8

    invoke-virtual {p0, v1}, La/ac;->T(Z)[I

    move-result-object p2

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    const/4 v3, 0x3

    if-nez v2, :cond_4

    aget v2, p2, v1

    if-le v2, v3, :cond_4

    return v1

    :cond_4
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    const/4 v4, 0x5

    if-ne v2, v0, :cond_5

    aget v2, p2, v0

    if-le v2, v4, :cond_5

    return v1

    :cond_5
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    const/4 v5, 0x2

    if-ne v2, v5, :cond_6

    aget v2, p2, v5

    if-le v2, v4, :cond_6

    return v1

    :cond_6
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    if-ne v2, v3, :cond_7

    aget v2, p2, v3

    const/16 v3, 0xa

    if-le v2, v3, :cond_7

    return v1

    :cond_7
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result p1

    const/4 v2, 0x4

    if-ne p1, v2, :cond_8

    aget p1, p2, v2

    if-le p1, v4, :cond_8

    return v1

    :cond_8
    return v0
.end method

.method public addRankPts(II)V
    .locals 2

    iget-object v0, p0, La/ac;->xK:[I

    aget v1, v0, p1

    add-int/2addr v1, p2

    aput v1, v0, p1

    return-void
.end method

.method public b(Ljava/lang/String;I)V
    .locals 7

    iget-object v0, p0, La/ac;->xl:La/af;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/ac;->xl:La/af;

    invoke-virtual {v0}, La/af;->nc()V

    iget-object v0, p0, La/ac;->xl:La/af;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/af;->i(La/ac;)V

    :cond_0
    new-instance v0, La/af;

    invoke-direct {v0, p1}, La/af;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, La/af;->cj(I)V

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {v0, p2}, La/af;->j(Ljava/lang/Boolean;)V

    iput-object v0, p0, La/ac;->xl:La/af;

    iget-object p2, p0, La/ac;->xl:La/af;

    invoke-virtual {p2}, La/af;->getUniqueId()I

    move-result p2

    iput p2, p0, La/ac;->xm:I

    iget-object p2, p0, La/ac;->xl:La/af;

    invoke-virtual {p2, p0}, La/af;->i(La/ac;)V

    iget-object p2, p0, La/ac;->xl:La/af;

    iget v1, p0, La/ac;->xo:I

    invoke-virtual {p2, v1}, La/af;->setReputacao(I)V

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p0, p1}, La/ac;->j(Ljava/lang/Boolean;)V

    invoke-virtual {p0}, La/ac;->lR()V

    new-instance v1, Lcomponents/co;

    iget-object v2, p0, La/ac;->xl:La/af;

    const/4 v3, 0x0

    const/16 v4, 0x49

    invoke-virtual {p0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v5

    const-string v6, ""

    invoke-direct/range {v1 .. v6}, Lcomponents/co;-><init>(La/af;IILjava/lang/String;Ljava/lang/String;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1, v0}, La/b;->a(La/af;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0}, La/ac;->mx()V

    return-void
.end method

.method public b(La/p;Z)Z
    .locals 2

    iget-object p2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v0, 0x0

    const/16 v1, 0x1e

    if-lt p2, v1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-virtual {p1}, La/p;->hG()I

    move-result p1

    sget-object p2, La/ak;->zj:[I

    invoke-virtual {p0}, La/ac;->getDivisao()I

    move-result v1

    aget p2, p2, v1

    if-ge p1, p2, :cond_2

    return v0

    :cond_1
    invoke-virtual {p1}, La/p;->hG()I

    move-result p1

    sget-object p2, La/ak;->zk:[I

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result v1

    aget p2, p2, v1

    if-ge p1, p2, :cond_2

    return v0

    :cond_2
    const/4 p1, 0x1

    return p1
.end method

.method public bX(I)I
    .locals 1

    iget-object v0, p0, La/ac;->xC:[I

    aget p1, v0, p1

    return p1
.end method

.method public bY(I)V
    .locals 0

    iput p1, p0, La/ac;->sn:I

    return-void
.end method

.method public bZ(I)I
    .locals 4

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v2

    aget v3, v0, v2

    add-int/lit8 v3, v3, 0x1

    aput v3, v0, v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    aget p1, v0, p1

    return p1

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public bk(I)V
    .locals 0

    iput p1, p0, La/ac;->pV:I

    return-void
.end method

.method public c(Ld/q;)La/ae;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ae;

    invoke-virtual {v1}, La/ae;->mR()Ld/q;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object p1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/ae;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public ca(I)V
    .locals 0

    iput p1, p0, La/ac;->camisa:I

    return-void
.end method

.method public cb(I)V
    .locals 0

    iput p1, p0, La/ac;->xM:I

    return-void
.end method

.method public cc(I)V
    .locals 0

    iput p1, p0, La/ac;->xf:I

    return-void
.end method

.method public cd(I)Z
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v2

    const/4 v3, 0x2

    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v2

    if-ne v2, p1, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2, p0}, La/a;->a(La/ac;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public d(J)V
    .locals 2

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isModoBilionario()Z

    move-result v0

    if-eqz v0, :cond_0

    const-wide/32 v0, 0x3b9aca00

    iput-wide v0, p0, La/ac;->xn:J

    return-void

    :cond_0
    iput-wide p1, p0, La/ac;->xn:J

    return-void
.end method

.method public d(Ld/q;)[I
    .locals 3

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ae;

    invoke-virtual {v2}, La/ae;->mR()Ld/q;

    move-result-object v2

    if-ne v2, p1, :cond_0

    iget-object p1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/ae;

    invoke-virtual {p1}, La/ae;->mQ()[I

    move-result-object p1

    return-object p1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public e(La/af;)V
    .locals 0

    iput-object p1, p0, La/ac;->xl:La/af;

    iget-object p1, p0, La/ac;->xl:La/af;

    if-eqz p1, :cond_0

    iget-object p1, p0, La/ac;->xl:La/af;

    invoke-virtual {p1}, La/af;->getUniqueId()I

    move-result p1

    :goto_0
    iput p1, p0, La/ac;->xm:I

    return-void

    :cond_0
    const/4 p1, -0x1

    goto :goto_0

    return-void
.end method

.method public e(Ld/q;)V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ae;

    invoke-virtual {v1}, La/ae;->mR()Ld/q;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object v1, p0, La/ac;->xA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ae;

    invoke-virtual {v1}, La/ae;->mP()V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public f(Landroid/content/Context;)I
    .locals 4

    invoke-virtual {p0}, La/ac;->lx()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "sel_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, La/ac;->pais:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    if-eqz v3, :cond_0

    return v3

    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "flag_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, La/ac;->pais:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v1, v2, p1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public f(La/p;)V
    .locals 0

    iput-object p1, p0, La/ac;->xt:La/p;

    return-void
.end method

.method public f(La/t;)V
    .locals 7

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v0

    const/4 v1, 0x0

    if-ne v0, p0, :cond_0

    invoke-virtual {p1}, La/t;->jD()I

    move-result v0

    invoke-virtual {p1}, La/t;->jF()I

    move-result v2

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object v0

    if-ne v0, p0, :cond_1

    invoke-virtual {p1}, La/t;->jF()I

    move-result v0

    invoke-virtual {p1}, La/t;->jD()I

    move-result v2

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object v3

    invoke-virtual {p0, v3}, La/ac;->n(La/al;)La/ad;

    move-result-object v3

    invoke-virtual {v3}, La/ad;->fD()V

    invoke-virtual {v3, v0}, La/ad;->cf(I)V

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const/4 v5, 0x1

    invoke-virtual {p0, v4, v5, v0}, La/ac;->k(III)V

    invoke-virtual {v3, v2}, La/ad;->cg(I)V

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const/4 v6, 0x2

    invoke-virtual {p0, v4, v6, v2}, La/ac;->k(III)V

    if-le v0, v2, :cond_2

    invoke-virtual {v3}, La/ad;->fF()V

    const/4 v0, 0x3

    invoke-virtual {v3, v0}, La/ad;->ce(I)V

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object p1

    invoke-virtual {p1}, La/al;->cG()I

    move-result p1

    invoke-virtual {p0, p1, v1, v0}, La/ac;->k(III)V

    return-void

    :cond_2
    if-ge v0, v2, :cond_3

    invoke-virtual {v3}, La/ad;->fH()V

    return-void

    :cond_3
    if-ne v0, v2, :cond_4

    invoke-virtual {v3, v5}, La/ad;->ce(I)V

    invoke-virtual {p1}, La/t;->jH()La/al;

    move-result-object p1

    invoke-virtual {p1}, La/al;->cG()I

    move-result p1

    invoke-virtual {p0, p1, v1, v5}, La/ac;->k(III)V

    :cond_4
    return-void
.end method

.method public g(La/p;)V
    .locals 0

    iput-object p1, p0, La/ac;->xu:La/p;

    return-void
.end method

.method public getDivisao()I
    .locals 1

    iget v0, p0, La/ac;->divisao:I

    return v0
.end method

.method public getEstado()I
    .locals 1

    iget v0, p0, La/ac;->xk:I

    return v0
.end method

.method public getNivel()I
    .locals 1

    iget v0, p0, La/ac;->so:I

    return v0
.end method

.method public getNome()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/ac;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public getPais()I
    .locals 1

    iget v0, p0, La/ac;->pais:I

    return v0
.end method

.method public getPrecoArq()I
    .locals 1

    iget v0, p0, La/ac;->precoArq:I

    if-gtz v0, :cond_0

    const/16 v0, 0x28

    :cond_0
    return v0
.end method

.method public getPrecoCad()I
    .locals 1

    iget v0, p0, La/ac;->precoCad:I

    if-gtz v0, :cond_0

    const/16 v0, 0x50

    :cond_0
    return v0
.end method

.method public getPrecoCam()I
    .locals 1

    iget v0, p0, La/ac;->precoCam:I

    if-gtz v0, :cond_0

    const/16 v0, 0xc8

    :cond_0
    return v0
.end method

.method public getPrecoGeral()I
    .locals 1

    iget v0, p0, La/ac;->precoGeral:I

    if-gtz v0, :cond_0

    const/16 v0, 0x14

    :cond_0
    return v0
.end method

.method public getReputacao()I
    .locals 2

    iget v0, p0, La/ac;->xo:I

    const/4 v1, 0x5

    if-le v0, v1, :cond_0

    iput v1, p0, La/ac;->xo:I

    goto :goto_0

    :cond_0
    iget v0, p0, La/ac;->xo:I

    if-gez v0, :cond_1

    const/4 v0, 0x0

    iput v0, p0, La/ac;->xo:I

    :cond_1
    :goto_0
    iget v0, p0, La/ac;->xo:I

    return v0
.end method

.method public getSponsorId()I
    .locals 1

    iget v0, p0, La/ac;->xSponsor:I

    return v0
.end method

.method public getSponsorLogoResId()I
    .locals 2

    iget v0, p0, La/ac;->xSponsor:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_0

    const v0, 0x7f0501bf

    return v0

    :cond_0
    const/4 v1, 0x4

    if-ne v0, v1, :cond_1

    const v0, 0x7f0501c0

    return v0

    :cond_1
    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    const v0, 0x7f0501c1

    return v0

    :cond_2
    const/4 v1, 0x2

    if-ne v0, v1, :cond_3

    const v0, 0x7f0501c2

    return v0

    :cond_3
    const/4 v0, 0x0

    return v0
.end method

.method public getSponsorName()Ljava/lang/String;
    .locals 2

    iget v0, p0, La/ac;->xSponsor:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_0

    const-string v0, "Nike"

    return-object v0

    :cond_0
    const/4 v1, 0x4

    if-ne v0, v1, :cond_1

    const-string v0, "Adidas"

    return-object v0

    :cond_1
    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    const-string v0, "Puma"

    return-object v0

    :cond_2
    const/4 v1, 0x2

    if-ne v0, v1, :cond_3

    const-string v0, "Umbro"

    return-object v0

    :cond_3
    const-string v0, ""

    return-object v0
.end method

.method public getSponsorValue()I
    .locals 2

    iget v0, p0, La/ac;->xSponsor:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_0

    const v0, 0x1f78a40

    return v0

    :cond_0
    const/4 v1, 0x4

    if-ne v0, v1, :cond_1

    const v0, 0x989680

    return v0

    :cond_1
    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    const v0, 0x4c4b40

    return v0

    :cond_2
    const/4 v1, 0x2

    if-ne v0, v1, :cond_3

    const v0, 0x3567e0

    return v0

    :cond_3
    const/4 v1, 0x1

    if-ne v0, v1, :cond_4

    const v0, 0x7a120

    return v0

    :cond_4
    const/4 v0, 0x0

    return v0
.end method

.method public getXK(I)I
    .locals 1

    iget-object v0, p0, La/ac;->xK:[I

    aget v0, v0, p1

    return v0
.end method

.method public getXL(II)I
    .locals 1

    iget-object v0, p0, La/ac;->xL:[[I

    aget-object v0, v0, p1

    aget v0, v0, p2

    return v0
.end method

.method public h(La/p;)V
    .locals 1

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public i(La/p;)V
    .locals 0

    iput-object p1, p0, La/ac;->xv:La/p;

    return-void
.end method

.method public iM()I
    .locals 1

    iget v0, p0, La/ac;->pV:I

    return v0
.end method

.method public iw()I
    .locals 4

    sget-object v0, La/ac;->iwCache:[I

    if-nez v0, :cond_0

    const/16 v0, 0x100

    new-array v0, v0, [I

    const/4 v1, -0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    sput-object v0, La/ac;->iwCache:[I

    :cond_0
    iget v1, p0, La/ac;->pais:I

    if-ltz v1, :cond_1

    const/16 v2, 0x100

    if-ge v1, v2, :cond_1

    aget v2, v0, v1

    const/4 v3, -0x1

    if-eq v2, v3, :cond_1

    return v2

    :cond_1
    invoke-direct {p0}, La/ac;->iwRaw()I

    move-result v2

    if-ltz v1, :cond_2

    const/16 v3, 0x100

    if-ge v1, v3, :cond_2

    aput v2, v0, v1

    :cond_2
    return v2
.end method

.method public j(La/p;)V
    .locals 0

    iput-object p1, p0, La/ac;->xw:La/p;

    return-void
.end method

.method public j(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/ac;->xh:Ljava/lang/Boolean;

    return-void
.end method

.method public j([I)V
    .locals 0

    iput-object p1, p0, La/ac;->xC:[I

    return-void
.end method

.method public jO()La/l;
    .locals 1

    iget-object v0, p0, La/ac;->qX:La/l;

    return-object v0
.end method

.method public k(III)V
    .locals 2

    const/16 v0, 0x8

    if-gt p1, v0, :cond_0

    iget-object v0, p0, La/ac;->xL:[[I

    aget-object v0, v0, p1

    iget-object v1, p0, La/ac;->xL:[[I

    aget-object p1, v1, p1

    aget p1, p1, p2

    add-int/2addr p1, p3

    aput p1, v0, p2

    :cond_0
    return-void
.end method

.method public k(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/ac;->xi:Ljava/lang/Boolean;

    return-void
.end method

.method public lA()J
    .locals 6

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v4

    invoke-virtual {v4}, Lest/Options;->isModoBilionario()Z

    move-result v4

    if-eqz v4, :cond_1

    const-wide/32 v2, 0x3b9aca00

    iget-wide v0, p0, La/ac;->xn:J

    cmp-long v4, v0, v2

    if-eqz v4, :cond_0

    iput-wide v2, p0, La/ac;->xn:J

    :cond_0
    return-wide v2

    :cond_1
    iget-wide v0, p0, La/ac;->xn:J

    return-wide v0
.end method

.method public lB()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    return-object v0
.end method

.method public lC()La/p;
    .locals 3

    iget-object v0, p0, La/ac;->xt:La/p;

    if-eqz v0, :cond_1

    iget-object v0, p0, La/ac;->xt:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eq v0, p0, :cond_1

    invoke-virtual {p0}, La/ac;->mI()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    :goto_0
    iput-object v1, p0, La/ac;->xt:La/p;

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v2, p0, La/ac;->xt:La/p;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v0, p0, La/ac;->xt:La/p;

    return-object v0
.end method

.method public lD()La/p;
    .locals 3

    iget-object v0, p0, La/ac;->xu:La/p;

    if-eqz v0, :cond_1

    iget-object v0, p0, La/ac;->xu:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eq v0, p0, :cond_1

    invoke-virtual {p0}, La/ac;->mI()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    :goto_0
    iput-object v1, p0, La/ac;->xu:La/p;

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v2, p0, La/ac;->xu:La/p;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v0, p0, La/ac;->xu:La/p;

    return-object v0
.end method

.method public lE()Z
    .locals 1

    iget-boolean v0, p0, La/ac;->xF:Z

    return v0
.end method

.method public lF()Z
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget v1, p0, La/ac;->xk:I

    invoke-virtual {v0, v1}, La/b;->ai(I)Ld/m;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p0}, Ld/m;->K(La/ac;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public lH()Z
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, La/ak;->Ao:[I

    array-length v2, v2

    if-ge v1, v2, :cond_1

    sget-object v2, La/ak;->Ao:[I

    aget v2, v2, v1

    iget v3, p0, La/ac;->pais:I

    if-ne v2, v3, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public lI()[I
    .locals 1

    iget-object v0, p0, La/ac;->xC:[I

    return-object v0
.end method

.method public lJ()V
    .locals 2

    iget v0, p0, La/ac;->xE:I

    const v1, 0x186a0

    if-le v0, v1, :cond_0

    const/4 v0, 0x5

    goto :goto_0

    :cond_0
    iget v0, p0, La/ac;->xE:I

    const/16 v1, 0x2710

    if-le v0, v1, :cond_1

    const/4 v0, 0x4

    goto :goto_0

    :cond_1
    iget v0, p0, La/ac;->xE:I

    const/16 v1, 0x3e8

    if-le v0, v1, :cond_2

    const/4 v0, 0x3

    goto :goto_0

    :cond_2
    iget v0, p0, La/ac;->xE:I

    const/16 v1, 0x64

    if-le v0, v1, :cond_3

    const/4 v0, 0x2

    goto :goto_0

    :cond_3
    iget v0, p0, La/ac;->xE:I

    const/16 v1, 0xa

    if-le v0, v1, :cond_4

    const/4 v0, 0x1

    goto :goto_0

    :cond_4
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, La/ac;->xo:I

    if-le v0, v1, :cond_5

    iput v0, p0, La/ac;->xo:I

    :cond_5
    return-void
.end method

.method public lK()I
    .locals 1

    iget v0, p0, La/ac;->xj:I

    return v0
.end method

.method public lL()I
    .locals 1

    iget v0, p0, La/ac;->sn:I

    return v0
.end method

.method public lM()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ae;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xA:Ljava/util/ArrayList;

    return-object v0
.end method

.method public lN()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/ac;->xi:Ljava/lang/Boolean;

    return-object v0
.end method

.method public lO()V
    .locals 9

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La/ac;->T(Z)[I

    move-result-object v1

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    invoke-virtual {p0}, La/ac;->lR()V

    iget-object v3, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-static {v3}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x4

    if-gt v3, v4, :cond_2

    aget v4, v1, v3

    aget v5, v2, v3

    if-le v4, v5, :cond_1

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/16 v5, 0x64

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/16 v6, 0x32

    if-le v4, v6, :cond_1

    const/4 v4, 0x0

    :goto_1
    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_1

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v6

    if-ne v6, v3, :cond_0

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getStatus()I

    move-result v6

    if-nez v6, :cond_0

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-nez v6, :cond_0

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-nez v6, :cond_0

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-nez v6, :cond_0

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->hK()V

    iget-object v6, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    const/4 v7, 0x1

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    invoke-virtual {v6, v8}, La/p;->c(Ljava/lang/Boolean;)V

    new-instance v6, Ljava/util/Random;

    invoke-direct {v6}, Ljava/util/Random;-><init>()V

    invoke-virtual {v6, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v5

    const/16 v6, 0x5a

    if-le v5, v6, :cond_1

    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->hG()I

    move-result v5

    const/16 v6, 0x64

    if-ge v5, v6, :cond_1

    iget-object v5, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v4, v5}, La/p;->g(Ljava/lang/Boolean;)V

    goto :goto_2

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_1

    :cond_1
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :cond_2
    return-void

    :array_0
    .array-data 4
        0x2
        0x3
        0x3
        0x5
        0x4
    .end array-data
.end method

.method public lP()I
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-eqz v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->uD()La/ac;

    move-result-object v2

    if-ne v2, p0, :cond_0

    add-int/lit8 v1, v1, 0x1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public lQ()I
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_0

    add-int/lit8 v1, v1, 0x1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public lR()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v2, v3}, La/p;->c(Ljava/lang/Boolean;)V

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v2, v3}, La/p;->g(Ljava/lang/Boolean;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public lS()[I
    .locals 4

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v2

    aget v3, v0, v2

    add-int/lit8 v3, v3, 0x1

    aput v3, v0, v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public lT()V
    .locals 7

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La/ac;->T(Z)[I

    move-result-object v1

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x4

    if-gt v3, v4, :cond_2

    aget v4, v1, v3

    aget v5, v2, v3

    if-ge v4, v5, :cond_1

    invoke-virtual {p0}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_0

    sget-object v4, La/ak;->zj:[I

    invoke-virtual {p0}, La/ac;->getDivisao()I

    move-result v5

    aget v4, v4, v5

    goto :goto_1

    :cond_0
    sget-object v4, La/ak;->zk:[I

    invoke-virtual {p0}, La/ac;->getReputacao()I

    move-result v5

    aget v4, v4, v5

    :goto_1
    const/4 v5, 0x2

    new-array v5, v5, [I

    aput v3, v5, v0

    const/4 v6, 0x1

    aput v4, v5, v6

    invoke-static {p0, v5}, La/f;->a(La/ac;[I)V

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    return-void

    nop

    :array_0
    .array-data 4
        0x2
        0x3
        0x3
        0x5
        0x3
        0x2
    .end array-data
.end method

.method public lU()I
    .locals 1

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public lV()I
    .locals 1

    iget-object v0, p0, La/ac;->xq:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public lW()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/q;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xq:Ljava/util/ArrayList;

    return-object v0
.end method

.method public lX()V
    .locals 2

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    sget-object v1, La/ac;->xO:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, La/ac;->xt:La/p;

    :cond_0
    return-void
.end method

.method public lY()V
    .locals 5

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_6

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getStatus()I

    move-result v2

    if-ne v2, v3, :cond_0

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getCr1()I

    move-result v2

    const/16 v4, 0x9

    if-ne v2, v4, :cond_0

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    if-nez v1, :cond_3

    const/4 v2, 0x0

    :goto_2
    iget-object v4, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_3

    iget-object v4, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getStatus()I

    move-result v4

    if-ne v4, v3, :cond_2

    iget-object v4, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    if-eqz v4, :cond_2

    iget-object v1, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    goto :goto_3

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    :goto_3
    if-nez v1, :cond_5

    :goto_4
    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_5

    iget-object v2, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v2

    if-eqz v2, :cond_4

    iget-object v1, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, La/p;

    goto :goto_5

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_5
    :goto_5
    if-eqz v1, :cond_6

    iput-object v1, p0, La/ac;->xu:La/p;

    :cond_6
    return-void
.end method

.method public lZ()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/ac;->xy:Ljava/lang/String;

    return-object v0
.end method

.method public lx()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/ac;->xg:Ljava/lang/String;

    return-object v0
.end method

.method public ly()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/ac;->xh:Ljava/lang/Boolean;

    return-object v0
.end method

.method public lz()La/af;
    .locals 2

    iget-object v0, p0, La/ac;->xl:La/af;

    if-nez v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    iget v1, p0, La/ac;->xm:I

    invoke-virtual {v0, v1}, La/b;->au(I)La/af;

    move-result-object v0

    iput-object v0, p0, La/ac;->xl:La/af;

    :cond_0
    iget-object v0, p0, La/ac;->xl:La/af;

    return-object v0
.end method

.method public mA()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ai;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xN:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mB()V
    .locals 1

    new-instance v0, La/n;

    invoke-direct {v0}, La/n;-><init>()V

    iput-object v0, p0, La/ac;->xH:La/n;

    invoke-virtual {p0}, La/ac;->mf()V

    return-void
.end method

.method public mC()Z
    .locals 2

    iget-object v0, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public mD()I
    .locals 1

    iget v0, p0, La/ac;->xx:I

    return v0
.end method

.method public mE()I
    .locals 1

    iget v0, p0, La/ac;->xf:I

    return v0
.end method

.method public mF()La/p;
    .locals 3

    iget-object v0, p0, La/ac;->xv:La/p;

    if-eqz v0, :cond_1

    iget-object v0, p0, La/ac;->xv:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eq v0, p0, :cond_1

    invoke-virtual {p0}, La/ac;->mI()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    :goto_0
    iput-object v1, p0, La/ac;->xv:La/p;

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v2, p0, La/ac;->xv:La/p;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v0, p0, La/ac;->xv:La/p;

    return-object v0
.end method

.method public mG()La/p;
    .locals 3

    iget-object v0, p0, La/ac;->xw:La/p;

    if-eqz v0, :cond_1

    iget-object v0, p0, La/ac;->xw:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    if-eq v0, p0, :cond_1

    invoke-virtual {p0}, La/ac;->mI()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    :goto_0
    iput-object v1, p0, La/ac;->xw:La/p;

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v2, p0, La/ac;->xw:La/p;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v0, p0, La/ac;->xw:La/p;

    return-object v0
.end method

.method public mH()Z
    .locals 1

    iget-boolean v0, p0, La/ac;->xD:Z

    return v0
.end method

.method public mI()Z
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->lh()La/ac;

    move-result-object v2

    if-ne v2, p0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public ma()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/ac;->xz:Ljava/lang/String;

    return-object v0
.end method

.method public mb()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xG:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mc()La/af;
    .locals 5

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0}, La/af;->nc()V

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, La/b;->a(La/ac;I)La/af;

    move-result-object v0

    if-nez v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v2, 0x1

    invoke-virtual {v0, p0, v2}, La/b;->a(La/ac;I)La/af;

    move-result-object v0

    :cond_0
    if-nez v0, :cond_1

    iget v2, p0, La/ac;->xo:I

    const/4 v3, 0x3

    if-gt v2, v3, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v2, 0x2

    invoke-virtual {v0, p0, v2}, La/b;->a(La/ac;I)La/af;

    move-result-object v0

    :cond_1
    if-nez v0, :cond_2

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v2}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_2

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v2, -0x1

    invoke-virtual {v0, p0, v2}, La/b;->a(La/ac;I)La/af;

    move-result-object v0

    :cond_2
    if-nez v0, :cond_3

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v2}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ey()La/af;

    move-result-object v0

    :cond_3
    if-nez v0, :cond_5

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v2}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_5

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, La/b;->b(La/af;Z)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_4

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v3

    :cond_4
    if-eqz v0, :cond_6

    if-eqz v3, :cond_6

    if-eq v0, v3, :cond_6

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0, v3}, La/b;->a(La/af;La/af;)V

    return-object v0

    :cond_5
    if-eqz v0, :cond_6

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v1

    if-eq v0, v1, :cond_6

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v1, p0, v2, v0}, La/b;->a(La/ac;La/af;La/af;)V

    :cond_6
    return-object v0
.end method

.method public md()Ld/q;
    .locals 5

    sget-object v0, Lc/a;->TF:La/b;

    iget v1, p0, La/ac;->pais:I

    invoke-virtual {v0, v1}, La/b;->ah(I)La/y;

    move-result-object v0

    if-eqz v0, :cond_2

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    const/4 v3, 0x0

    :goto_1
    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-ne v4, p0, :cond_0

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    return-object v0

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    return-object v0
.end method

.method public me()V
    .locals 6

    iget v0, p0, La/ac;->pais:I

    const/16 v1, 0x1d

    if-eq v0, v1, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-wide v0, p0, La/ac;->xn:J

    long-to-double v0, v0

    const-wide v2, 0x400999999999999aL    # 3.2

    invoke-virtual {p0}, La/ac;->mi()I

    move-result v4

    int-to-double v4, v4

    mul-double v4, v4, v2

    add-double/2addr v0, v4

    double-to-long v0, v0

    invoke-virtual {p0, v0, v1}, La/ac;->d(J)V

    :cond_0
    iget v0, p0, La/ac;->divisao:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ltz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iget v3, p0, La/ac;->divisao:I

    const/4 v4, 0x4

    if-gt v3, v4, :cond_2

    goto :goto_1

    :cond_2
    const/4 v1, 0x0

    :goto_1
    and-int/2addr v0, v1

    if-eqz v0, :cond_3

    invoke-virtual {p0}, La/ac;->getSponsorValue()I

    move-result v0

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/Recopa;->spAdjust(La/ac;I)I

    move-result v0

    const/4 v1, 0x6

    invoke-virtual {p0, v0, v1}, La/ac;->U(II)V

    :cond_3
    return-void
.end method

.method public mf()V
    .locals 8

    iget v0, p0, La/ac;->divisao:I

    sget-object v1, La/ak;->AQ:[[J

    aget-object v0, v1, v0

    const/4 v1, 0x0

    aget-wide v2, v0, v1

    invoke-virtual {p0, v2, v3}, La/ac;->d(J)V

    iget v0, p0, La/ac;->pais:I

    const/16 v2, 0x1d

    if-eq v0, v2, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-wide v2, p0, La/ac;->xn:J

    long-to-double v2, v2

    const-wide v4, 0x400999999999999aL    # 3.2

    invoke-virtual {p0}, La/ac;->mi()I

    move-result v0

    int-to-double v6, v0

    mul-double v6, v6, v4

    add-double/2addr v2, v6

    double-to-long v2, v2

    invoke-virtual {p0, v2, v3}, La/ac;->d(J)V

    :cond_0
    iget-object v0, p0, La/ac;->xH:La/n;

    invoke-virtual {p0}, La/ac;->getSponsorValue()I

    move-result v1

    invoke-static {p0, v1}, Lcom/brasfoot/v2028/Recopa;->spAdjust(La/ac;I)I

    move-result v1

    const/4 v2, 0x6

    invoke-virtual {v0, v1, v2}, La/n;->J(II)V

    return-void
.end method

.method public mg()V
    .locals 1

    iget-object v0, p0, La/ac;->xH:La/n;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/ac;->xH:La/n;

    invoke-virtual {v0}, La/n;->hb()V

    :cond_0
    return-void
.end method

.method public mh()V
    .locals 2

    invoke-virtual {p0}, La/ac;->mi()I

    move-result v0

    const/4 v1, 0x2

    invoke-virtual {p0, v0, v1}, La/ac;->V(II)V

    return-void
.end method

.method public mi()I
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_0

    iget-object v3, p0, La/ac;->xp:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->hH()I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    :goto_1
    iget-object v1, p0, La/ac;->xq:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/ac;->xq:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/q;

    invoke-virtual {v1}, La/q;->hH()I

    move-result v1

    add-int/2addr v2, v1

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1
    return v2
.end method

.method public mj()La/n;
    .locals 1

    iget-object v0, p0, La/ac;->xH:La/n;

    return-object v0
.end method

.method public mk()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/io/File;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "user.dir"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "/teams/escudos/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, La/ac;->xg:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".png"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const-string v0, ""

    return-object v0
.end method

.method public ml()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/cf;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xI:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/ac;->xI:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, La/ac;->xI:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mm()I
    .locals 1

    iget v0, p0, La/ac;->camisa:I

    return v0
.end method

.method public mn()Lcomponents/cf;
    .locals 1

    iget-object v0, p0, La/ac;->xJ:Lcomponents/cf;

    return-object v0
.end method

.method public mo()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xr:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mp()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xs:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mq()[I
    .locals 1

    iget-object v0, p0, La/ac;->xK:[I

    return-object v0
.end method

.method public mr()I
    .locals 3

    const/4 v0, 0x1

    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0x8

    if-gt v0, v2, :cond_0

    iget-object v2, p0, La/ac;->xK:[I

    aget v2, v2, v0

    add-int/2addr v1, v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return v1
.end method

.method public ms()Z
    .locals 5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {p0}, La/ac;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/b;->ah(I)La/y;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    const/4 v3, 0x0

    :goto_1
    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public mt()[[I
    .locals 1

    iget-object v0, p0, La/ac;->xL:[[I

    return-object v0
.end method

.method public mu()[I
    .locals 6

    const/4 v0, 0x3

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x1

    const/4 v2, 0x1

    :goto_0
    const/16 v3, 0x8

    if-gt v2, v3, :cond_0

    const/4 v3, 0x0

    aget v4, v0, v3

    iget-object v5, p0, La/ac;->xL:[[I

    aget-object v5, v5, v2

    aget v5, v5, v3

    add-int/2addr v4, v5

    aput v4, v0, v3

    aget v3, v0, v1

    iget-object v4, p0, La/ac;->xL:[[I

    aget-object v4, v4, v2

    aget v4, v4, v1

    add-int/2addr v3, v4

    aput v3, v0, v1

    const/4 v3, 0x2

    aget v4, v0, v3

    iget-object v5, p0, La/ac;->xL:[[I

    aget-object v5, v5, v2

    aget v5, v5, v3

    add-int/2addr v4, v5

    aput v4, v0, v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v0

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public mv()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/ad;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La/ac;->xB:Ljava/util/ArrayList;

    return-object v0
.end method

.method public mw()V
    .locals 1

    invoke-virtual {p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public mx()V
    .locals 10

    invoke-virtual {p0}, La/ac;->mw()V

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    array-length v3, v0

    if-ge v2, v3, :cond_0

    aget v5, v0, v2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    move-object v4, p0

    invoke-static/range {v4 .. v9}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x1
        0x2
        0x3
        0x3
        0x4
    .end array-data
.end method

.method public my()V
    .locals 8

    invoke-virtual {p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0xa

    if-ge v0, v1, :cond_2

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/4 v2, 0x3

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x2

    invoke-virtual {p0}, La/ac;->getNivel()I

    move-result v2

    const/16 v3, 0x14

    if-lt v2, v3, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    invoke-virtual {p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/2addr v2, v0

    if-lt v2, v1, :cond_1

    invoke-virtual {p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    sub-int/2addr v1, v0

    add-int/lit8 v0, v1, -0x2

    :cond_1
    if-lez v0, :cond_2

    const/4 v1, 0x0

    :goto_0
    if-gt v1, v0, :cond_2

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    move-object v2, p0

    invoke-static/range {v2 .. v7}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public mz()I
    .locals 1

    iget v0, p0, La/ac;->xM:I

    return v0
.end method

.method public n(La/al;)La/ad;
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/ac;->xB:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La/ac;->xB:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ad;

    invoke-virtual {v1}, La/ad;->jb()La/al;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object v1, p0, La/ac;->xB:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ad;

    invoke-virtual {v1}, La/ad;->db()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    if-ne v1, v2, :cond_0

    iget-object p1, p0, La/ac;->xB:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/ad;

    return-object p1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, La/ad;

    invoke-direct {v0, p1, p0}, La/ad;-><init>(La/al;La/ac;)V

    iget-object p1, p0, La/ac;->xB:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method public o(La/al;)[I
    .locals 11

    const/4 v0, 0x3

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v4, -0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p1, :cond_2

    instance-of v7, p1, Ld/q;

    if-eqz v7, :cond_2

    invoke-virtual {p1}, La/al;->cG()I

    move-result v7

    if-eq v7, v3, :cond_0

    invoke-virtual {p1}, La/al;->cG()I

    move-result v7

    if-ne v7, v0, :cond_2

    :cond_0
    move-object v7, p1

    check-cast v7, Ld/q;

    invoke-virtual {v7, p0}, Ld/q;->N(La/ac;)I

    move-result v8

    invoke-virtual {v7}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    invoke-virtual {v7}, Ld/q;->getnRebaixados()I

    move-result v7

    invoke-virtual {p1}, La/al;->cG()I

    move-result p1

    if-ne p1, v0, :cond_1

    const/4 p1, 0x2

    goto :goto_0

    :cond_1
    const/4 p1, 0x4

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    const/4 v7, 0x0

    const/4 v8, -0x1

    const/4 v9, 0x0

    :goto_0
    if-ne v8, v4, :cond_3

    aput v4, v1, v5

    return-object v1

    :cond_3
    const/16 v4, 0x14

    if-ge v9, v4, :cond_4

    const/4 v4, 0x2

    goto :goto_1

    :cond_4
    const/4 v4, 0x4

    :goto_1
    if-ne v8, v3, :cond_5

    move v0, v8

    goto :goto_2

    :cond_5
    sub-int v10, v9, v7

    if-le v8, v10, :cond_6

    const/4 v0, 0x5

    goto :goto_2

    :cond_6
    if-gt v8, p1, :cond_7

    const/4 v0, 0x2

    goto :goto_2

    :cond_7
    add-int/2addr v7, v4

    sub-int/2addr v9, v7

    if-le v8, v9, :cond_8

    const/4 v0, 0x4

    :cond_8
    :goto_2
    aput v8, v1, v6

    aput v0, v1, v3

    return-object v1

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public p(La/al;)V
    .locals 3

    new-instance v0, La/ai;

    invoke-direct {v0}, La/ai;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->db()I

    move-result v1

    invoke-virtual {v0, v1}, La/ai;->ad(I)V

    invoke-virtual {p0}, La/ac;->mE()I

    move-result v1

    invoke-virtual {v0, v1}, La/ai;->aw(I)V

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, La/ac;->lz()La/af;

    move-result-object v1

    invoke-virtual {v1}, La/af;->getUniqueId()I

    move-result v1

    invoke-virtual {v0, v1}, La/ai;->cu(I)V

    :cond_0
    invoke-virtual {p1}, La/al;->cG()I

    move-result v1

    invoke-virtual {v0, v1}, La/ai;->W(I)V

    invoke-virtual {v0, p1}, La/ai;->l(La/al;)V

    invoke-virtual {p1}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_2

    invoke-virtual {p1}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, La/al;->iw()I

    move-result p1

    goto :goto_1

    :cond_2
    :goto_0
    invoke-virtual {p1}, La/al;->nS()I

    move-result p1

    :goto_1
    invoke-virtual {v0, p1}, La/ai;->aJ(I)V

    iget-object p1, p0, La/ac;->xN:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public p(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/ac;->xy:Ljava/lang/String;

    return-void
.end method

.method public q(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/ac;->xz:Ljava/lang/String;

    return-void
.end method

.method public setDivisao(I)V
    .locals 1

    const/4 v0, 0x4

    if-le p1, v0, :cond_0

    const/4 p1, 0x0

    :cond_0
    iput p1, p0, La/ac;->divisao:I

    return-void
.end method

.method public setNivel(I)V
    .locals 1

    const/4 v0, 0x1

    if-lt p1, v0, :cond_0

    const/16 v0, 0x19

    if-le p1, v0, :cond_1

    :cond_0
    const/16 p1, 0xa

    :cond_1
    iput p1, p0, La/ac;->so:I

    return-void
.end method

.method public setPais(I)V
    .locals 0

    iput p1, p0, La/ac;->pais:I

    return-void
.end method

.method public setPrecoArq(I)V
    .locals 0

    iput p1, p0, La/ac;->precoArq:I

    return-void
.end method

.method public setPrecoCad(I)V
    .locals 0

    iput p1, p0, La/ac;->precoCad:I

    return-void
.end method

.method public setPrecoCam(I)V
    .locals 0

    iput p1, p0, La/ac;->precoCam:I

    return-void
.end method

.method public setPrecoGeral(I)V
    .locals 0

    iput p1, p0, La/ac;->precoGeral:I

    return-void
.end method

.method public setReputacao(I)V
    .locals 1

    const/4 v0, 0x5

    if-le p1, v0, :cond_0

    const/4 p1, 0x5

    :cond_0
    iput p1, p0, La/ac;->xo:I

    return-void
.end method

.method public setSponsorId(I)V
    .locals 0

    iput p1, p0, La/ac;->xSponsor:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    invoke-virtual {p0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public w(La/ac;)Z
    .locals 1

    iget-object v0, p0, La/ac;->xG:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method
