.class public La/m;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private lU:I

.field private minutos:I

.field public narr:Ljava/lang/String;

.field private pA:I

.field private pB:Z

.field private pu:La/ac;

.field private pv:I

.field private pw:I

.field private px:La/p;

.field private py:La/p;

.field private pz:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/m;->pu:La/ac;

    const/4 v1, -0x1

    iput v1, p0, La/m;->lU:I

    iput v1, p0, La/m;->pv:I

    iput v1, p0, La/m;->minutos:I

    iput v1, p0, La/m;->pw:I

    iput-object v0, p0, La/m;->px:La/p;

    iput-object v0, p0, La/m;->py:La/p;

    const/4 v0, 0x0

    iput-boolean v0, p0, La/m;->pz:Z

    iput-boolean v0, p0, La/m;->pB:Z

    return-void
.end method

.method public constructor <init>(I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/m;->pu:La/ac;

    const/4 v1, -0x1

    iput v1, p0, La/m;->lU:I

    iput v1, p0, La/m;->pv:I

    iput v1, p0, La/m;->minutos:I

    iput v1, p0, La/m;->pw:I

    iput-object v0, p0, La/m;->px:La/p;

    iput-object v0, p0, La/m;->py:La/p;

    const/4 v0, 0x0

    iput-boolean v0, p0, La/m;->pz:Z

    iput-boolean v0, p0, La/m;->pB:Z

    iput p1, p0, La/m;->pA:I

    return-void
.end method

.method public constructor <init>(IZ)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/m;->pu:La/ac;

    const/4 v1, -0x1

    iput v1, p0, La/m;->lU:I

    iput v1, p0, La/m;->pv:I

    iput v1, p0, La/m;->minutos:I

    iput v1, p0, La/m;->pw:I

    iput-object v0, p0, La/m;->px:La/p;

    iput-object v0, p0, La/m;->py:La/p;

    const/4 v0, 0x0

    iput-boolean v0, p0, La/m;->pz:Z

    iput-boolean v0, p0, La/m;->pB:Z

    iput p1, p0, La/m;->lU:I

    iput-boolean p2, p0, La/m;->pz:Z

    return-void
.end method


# virtual methods
.method public F(Z)V
    .locals 0

    iput-boolean p1, p0, La/m;->pz:Z

    return-void
.end method

.method public G(Z)V
    .locals 0

    iput-boolean p1, p0, La/m;->pB:Z

    return-void
.end method

.method public W(I)V
    .locals 0

    iput p1, p0, La/m;->lU:I

    return-void
.end method

.method public aJ(I)V
    .locals 0

    iput p1, p0, La/m;->pv:I

    return-void
.end method

.method public aK(I)V
    .locals 0

    iput p1, p0, La/m;->minutos:I

    return-void
.end method

.method public aL(I)V
    .locals 0

    iput p1, p0, La/m;->pw:I

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget v2, v0, La/m;->lU:I

    const/16 v3, 0x14

    if-ne v2, v3, :cond_1

    iget-object v2, v0, La/m;->narr:Ljava/lang/String;

    if-nez v2, :cond_0

    const-string v2, ""

    :cond_0
    return-object v2

    :cond_1
    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    iget-object v2, v2, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    const-string v4, ""

    const-string v5, "pt_BR"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const v8, 0x7f0b009b

    const/4 v9, 0x5

    const v10, 0x7f0b009c

    const/4 v11, 0x4

    const v12, 0x7f0b009d

    const/4 v13, 0x3

    const v14, 0x7f0b009a

    const/4 v15, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_11

    iget v2, v0, La/m;->pw:I

    if-lez v2, :cond_2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, " - "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v0, La/m;->pw:I

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "\u00ba "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :cond_2
    iget v2, v0, La/m;->lU:I

    if-ne v2, v5, :cond_7

    iget-object v2, v0, La/m;->px:La/p;

    if-nez v2, :cond_3

    const-string v1, ""

    return-object v1

    :cond_3
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v0, La/m;->minutos:I

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\'"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget v3, v0, La/m;->pv:I

    if-ne v3, v15, :cond_4

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_3

    :cond_4
    iget v3, v0, La/m;->pv:I

    if-ne v3, v13, :cond_5

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v12}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_5
    iget v3, v0, La/m;->pv:I

    if-ne v3, v11, :cond_6

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_6
    iget v3, v0, La/m;->pv:I

    if-ne v3, v9, :cond_f

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_7
    iget v2, v0, La/m;->lU:I

    if-ne v2, v7, :cond_b

    iget-object v1, v0, La/m;->px:La/p;

    if-eqz v1, :cond_a

    iget-object v1, v0, La/m;->py:La/p;

    if-nez v1, :cond_8

    goto :goto_1

    :cond_8
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, v0, La/m;->minutos:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget v2, v0, La/m;->minutos:I

    if-nez v2, :cond_9

    iget v2, v0, La/m;->pw:I

    if-ne v2, v15, :cond_9

    const-string v1, "(interv.)"

    const-string v2, ""

    move-object v4, v2

    :cond_9
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ") "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->py:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    :cond_a
    :goto_1
    const-string v1, ""

    return-object v1

    :cond_b
    iget v2, v0, La/m;->lU:I

    if-ne v2, v6, :cond_d

    iget-object v2, v0, La/m;->px:La/p;

    if-nez v2, :cond_c

    const-string v1, ""

    return-object v1

    :cond_c
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v0, La/m;->minutos:I

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\'("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v3, 0x7f0b009e

    invoke-virtual {v1, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    :goto_2
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_3

    :cond_d
    iget-object v1, v0, La/m;->px:La/p;

    if-nez v1, :cond_e

    const-string v1, ""

    return-object v1

    :cond_e
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, La/m;->px:La/p;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v0, La/m;->minutos:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_f
    :goto_3
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v0, La/m;->lU:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_10

    iget-object v2, v0, La/m;->py:La/p;

    if-eqz v2, :cond_10

    const-string v3, " (assist. "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, La/m;->py:La/p;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_10
    :goto_4
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    :cond_11
    iget v2, v0, La/m;->minutos:I

    iget v4, v0, La/m;->pw:I

    if-lez v4, :cond_12

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, " - "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, v0, La/m;->pw:I

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "\u00ba "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_12
    iget v4, v0, La/m;->pw:I

    if-le v4, v5, :cond_13

    iget v2, v0, La/m;->minutos:I

    add-int/lit8 v2, v2, 0x2d

    :cond_13
    iget v4, v0, La/m;->lU:I

    if-ne v4, v5, :cond_19

    iget-object v4, v0, La/m;->px:La/p;

    if-nez v4, :cond_14

    const-string v1, ""

    return-object v1

    :cond_14
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\'"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget v3, v0, La/m;->pv:I

    if-ne v3, v15, :cond_15

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    :goto_5
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    :cond_15
    iget v3, v0, La/m;->pv:I

    if-ne v3, v13, :cond_16

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v12}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_5

    :cond_16
    iget v3, v0, La/m;->pv:I

    if-ne v3, v11, :cond_17

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_5

    :cond_17
    iget v3, v0, La/m;->pv:I

    if-ne v3, v9, :cond_18

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_5

    :cond_18
    move-object v1, v2

    return-object v1

    :cond_19
    iget v4, v0, La/m;->lU:I

    if-ne v4, v7, :cond_1c

    iget-object v1, v0, La/m;->px:La/p;

    if-eqz v1, :cond_1b

    iget-object v1, v0, La/m;->py:La/p;

    if-nez v1, :cond_1a

    goto :goto_7

    :cond_1a
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "("

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ") "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->py:La/p;

    :goto_6
    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :cond_1b
    :goto_7
    const-string v1, ""

    return-object v1

    :cond_1c
    iget v4, v0, La/m;->lU:I

    const/4 v5, 0x7

    if-ne v4, v5, :cond_1e

    iget-object v4, v0, La/m;->px:La/p;

    if-nez v4, :cond_1d

    const-string v1, ""

    return-object v1

    :cond_1d
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\'("

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v2, 0x7f0b009e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    :cond_1e
    iget-object v1, v0, La/m;->px:La/p;

    if-nez v1, :cond_1f

    const-string v1, ""

    return-object v1

    :cond_1f
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, La/m;->px:La/p;

    goto :goto_6

    return-object v1
.end method

.method public c(La/p;)V
    .locals 0

    iput-object p1, p0, La/m;->px:La/p;

    return-void
.end method

.method public cG()I
    .locals 1

    iget v0, p0, La/m;->lU:I

    return v0
.end method

.method public d(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .locals 5

    iget v0, p0, La/m;->lU:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget v0, p0, La/m;->lU:I

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v3, :cond_2

    iget v0, p0, La/m;->pv:I

    if-ne v0, v1, :cond_1

    :goto_0
    const-string v0, "ic_egolc"

    goto :goto_1

    :cond_1
    const-string v0, "ic_egol"

    goto :goto_1

    :cond_2
    iget v0, p0, La/m;->lU:I

    if-ne v0, v1, :cond_3

    const-string v0, "ic_eca"

    goto :goto_1

    :cond_3
    iget v0, p0, La/m;->lU:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_4

    const-string v0, "ic_ecacv"

    goto :goto_1

    :cond_4
    iget v0, p0, La/m;->lU:I

    const/4 v1, 0x4

    if-ne v0, v1, :cond_5

    const-string v0, "ic_ecv"

    goto :goto_1

    :cond_5
    iget v0, p0, La/m;->lU:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_6

    const-string v0, "ic_ect"

    goto :goto_1

    :cond_6
    iget v0, p0, La/m;->lU:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_7

    goto :goto_0

    :cond_7
    iget v0, p0, La/m;->lU:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_8

    const-string v0, "ic_esubs"

    goto :goto_1

    :cond_8
    move-object v0, v2

    :goto_1
    if-eqz v0, :cond_9

    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, v0, v4, p1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/IllegalStateException;->printStackTrace()V

    :cond_9
    move-object p1, v2

    return-object p1
.end method

.method public d(La/p;)V
    .locals 0

    iput-object p1, p0, La/m;->py:La/p;

    return-void
.end method

.method public f(La/ac;)V
    .locals 0

    iput-object p1, p0, La/m;->pu:La/ac;

    return-void
.end method

.method public gS()La/ac;
    .locals 1

    iget-object v0, p0, La/m;->pu:La/ac;

    return-object v0
.end method

.method public gT()I
    .locals 1

    iget v0, p0, La/m;->pv:I

    return v0
.end method

.method public gU()I
    .locals 1

    iget v0, p0, La/m;->minutos:I

    return v0
.end method

.method public gV()I
    .locals 1

    iget v0, p0, La/m;->pw:I

    return v0
.end method

.method public gW()La/p;
    .locals 1

    iget-object v0, p0, La/m;->px:La/p;

    return-object v0
.end method

.method public gX()La/p;
    .locals 1

    iget-object v0, p0, La/m;->py:La/p;

    return-object v0
.end method

.method public gY()I
    .locals 1

    iget v0, p0, La/m;->pA:I

    return v0
.end method

.method public gZ()Z
    .locals 1

    iget-boolean v0, p0, La/m;->pB:Z

    return v0
.end method

.method public isDone()Z
    .locals 1

    iget-boolean v0, p0, La/m;->pz:Z

    return v0
.end method
