.class final La/h$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Le/t;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Le/t;Le/t;)I
    .locals 0

    invoke-virtual {p1}, Le/t;->getNivel()I

    move-result p1

    invoke-virtual {p2}, Le/t;->getNivel()I

    move-result p2

    if-eq p1, p2, :cond_0

    sub-int/2addr p2, p1

    return p2

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Le/t;

    check-cast p2, Le/t;

    invoke-virtual {p0, p1, p2}, La/h$1;->a(Le/t;Le/t;)I

    move-result p1

    return p1
.end method
