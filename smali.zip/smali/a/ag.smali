.class public La/ag;
.super Ljava/lang/Object;


# static fields
.field private static d:I = 0x1

.field private static pw:I = 0x1

.field private static ym:La/ag; = null

.field private static yn:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bo;",
            ">;"
        }
    .end annotation
.end field

.field private static yo:I = 0x0

.field private static yp:Ljava/util/Timer; = null

.field private static yt:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private static yu:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private static yv:Ljava/util/ArrayList; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation
.end field

.field private static yw:Z = true

.field private static yy:La/al; = null

.field private static yz:I = -0x1


# instance fields
.field private yq:Z

.field private yr:I

.field private ys:Landroid/graphics/Color;

.field private yx:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/ag;->yn:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/ag;->yt:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/ag;->yu:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La/ag;->yv:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, La/ag;->yq:Z

    const/4 v0, -0x1

    iput v0, p0, La/ag;->yr:I

    const/4 v0, 0x0

    iput-object v0, p0, La/ag;->ys:Landroid/graphics/Color;

    const/16 v0, 0x2d0

    iput v0, p0, La/ag;->yx:I

    sput-object p0, La/ag;->ym:La/ag;

    iput p1, p0, La/ag;->yx:I

    return-void
.end method

.method public static V(Z)V
    .locals 5

    const/4 v0, 0x0

    if-nez p0, :cond_1

    const/4 p0, 0x0

    :goto_0
    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p0, v1, :cond_1

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->le()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->kn()[I

    move-result-object v1

    sget v2, La/ag;->pw:I

    aget v1, v1, v2

    sget v2, La/ag;->yo:I

    if-gt v1, v2, :cond_0

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    sget v2, La/ag;->yo:I

    sget v3, La/ag;->pw:I

    invoke-virtual {v1, v2, v3}, La/t;->P(II)V

    :cond_0
    add-int/lit8 p0, p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_1
    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p0, v1, :cond_4

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    :goto_2
    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/m;

    invoke-virtual {v2}, La/m;->isDone()Z

    move-result v2

    if-nez v2, :cond_2

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/m;

    invoke-virtual {v2}, La/m;->gV()I

    move-result v2

    invoke-static {}, La/ag;->gV()I

    move-result v3

    if-ne v2, v3, :cond_2

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/m;

    invoke-virtual {v2}, La/m;->gU()I

    move-result v2

    invoke-static {}, La/ag;->ns()I

    move-result v3

    if-gt v2, v3, :cond_2

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    sget-object v3, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uE()La/t;

    move-result-object v3

    sget-object v4, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v4, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bo;

    invoke-virtual {v4}, Lcomponents/bo;->uE()La/t;

    move-result-object v4

    invoke-virtual {v4}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/m;

    invoke-static {v2, v3, v4, p0}, La/ag;->a(Lcomponents/bo;La/t;La/m;I)V

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_2

    :cond_3
    add-int/lit8 p0, p0, 0x1

    goto/16 :goto_1

    :cond_4
    sget-object p0, La/ag;->ym:La/ag;

    iget p0, p0, La/ag;->yr:I

    if-ltz p0, :cond_5

    sput-boolean v0, La/ag;->yw:Z

    sget-object p0, La/ag;->ym:La/ag;

    sget-object v1, La/ag;->ym:La/ag;

    iget v1, v1, La/ag;->yr:I

    invoke-direct {p0, v1, v0}, La/ag;->d(IZ)V

    const/4 p0, 0x1

    sput-boolean p0, La/ag;->yw:Z

    sget-object p0, La/ag;->ym:La/ag;

    const/4 v0, -0x1

    iput v0, p0, La/ag;->yr:I

    :cond_5
    sget-boolean p0, La/ag;->yw:Z

    if-eqz p0, :cond_6

    sget-object p0, La/ag;->ym:La/ag;

    invoke-virtual {p0}, La/ag;->nj()V

    :cond_6
    return-void
.end method

.method public static W(Z)V
    .locals 0

    sput-boolean p0, La/ag;->yw:Z

    return-void
.end method

.method public static a(ILjava/util/ArrayList;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x1

    if-ne p0, v0, :cond_0

    sput-object p1, La/ag;->yt:Ljava/util/ArrayList;

    return-void

    :cond_0
    sput-object p1, La/ag;->yu:Ljava/util/ArrayList;

    return-void
.end method

.method private a(La/t;La/ac;)V
    .locals 0

    return-void
.end method

.method public static a(Lcomponents/bo;La/t;La/m;I)V
    .locals 5

    invoke-virtual {p2}, La/m;->isDone()Z

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x1

    invoke-virtual {p2, v0}, La/m;->F(Z)V

    invoke-virtual {p2}, La/m;->gS()La/ac;

    move-result-object v1

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v2

    const/4 v3, 0x0

    if-ne v1, v2, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, La/m;->gS()La/ac;

    move-result-object v1

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    if-ne v1, p1, :cond_1

    const/4 p1, 0x2

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    if-lez p1, :cond_8

    invoke-virtual {p0, p2}, Lcomponents/bo;->a(La/m;)V

    invoke-virtual {p2}, La/m;->cG()I

    move-result v1

    const/4 v2, 0x4

    const/4 v4, 0x3

    if-ne v1, v0, :cond_3

    invoke-virtual {p2}, La/m;->gT()I

    move-result p3

    if-ne p3, v4, :cond_2

    invoke-virtual {p0}, Lcomponents/bo;->le()Z

    move-result p3

    if-eqz p3, :cond_2

    invoke-static {v2}, La/ag;->cs(I)V

    invoke-virtual {p2, v0}, La/m;->G(Z)V

    :cond_2
    invoke-virtual {p0, p1}, Lcomponents/bo;->dC(I)V

    invoke-virtual {p0}, Lcomponents/bo;->le()Z

    move-result p0

    if-eqz p0, :cond_8

    invoke-virtual {p2}, La/m;->gS()La/ac;

    move-result-object p0

    invoke-virtual {p0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return-void

    :cond_3
    invoke-virtual {p2}, La/m;->cG()I

    move-result p1

    const/4 v0, 0x5

    if-eq p1, v4, :cond_6

    invoke-virtual {p2}, La/m;->cG()I

    move-result p1

    if-ne p1, v2, :cond_4

    goto :goto_1

    :cond_4
    invoke-virtual {p2}, La/m;->cG()I

    move-result p1

    if-ne p1, v0, :cond_8

    invoke-virtual {p0}, Lcomponents/bo;->le()Z

    move-result p0

    if-eqz p0, :cond_5

    const/4 p0, 0x6

    invoke-static {p0}, La/ag;->cs(I)V

    :cond_5
    invoke-virtual {p2}, La/m;->gS()La/ac;

    move-result-object p0

    invoke-virtual {p0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_8

    goto :goto_2

    :cond_6
    :goto_1
    invoke-virtual {p0}, Lcomponents/bo;->le()Z

    move-result p0

    if-eqz p0, :cond_7

    invoke-static {v0}, La/ag;->cs(I)V

    :cond_7
    invoke-virtual {p2}, La/m;->gS()La/ac;

    move-result-object p0

    invoke-virtual {p0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_8

    :goto_2
    sget-object p0, La/ag;->ym:La/ag;

    invoke-direct {p0, p3, v3}, La/ag;->d(IZ)V

    :cond_8
    return-void
.end method

.method public static cs(I)V
    .locals 0

    return-void
.end method

.method private d(IZ)V
    .locals 0

    return-void
.end method

.method public static gV()I
    .locals 1

    sget v0, La/ag;->pw:I

    return v0
.end method

.method private h(La/t;)V
    .locals 0

    invoke-virtual {p1}, La/t;->jt()V

    return-void
.end method

.method public static i(La/t;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, La/t;->jH()La/al;

    move-result-object v1

    invoke-virtual {v1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, La/t;->jH()La/al;

    move-result-object p0

    invoke-virtual {p0}, La/al;->nS()I

    move-result p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private nl()V
    .locals 2

    iget-boolean v0, p0, La/ag;->yq:Z

    if-nez v0, :cond_1

    const/4 v0, 0x1

    iput-boolean v0, p0, La/ag;->yq:Z

    invoke-static {v0}, La/ag;->cs(I)V

    invoke-virtual {p0}, La/ag;->nn()V

    invoke-direct {p0}, La/ag;->nm()V

    sget-object v0, La/ag;->yv:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, La/ag;->yv:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    sget-object v1, La/ag;->yv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-direct {p0, v1}, La/ag;->h(La/t;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-static {}, La/i;->gG()V

    :cond_1
    return-void
.end method

.method private nm()V
    .locals 3

    sget-object v0, La/ag;->yv:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    :goto_0
    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    if-eqz v1, :cond_2

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ke()Z

    move-result v1

    if-eqz v1, :cond_2

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ju()Z

    move-result v1

    if-eqz v1, :cond_2

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->getVerDecisaoPenNaoHumano()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_2

    :cond_1
    :goto_1
    sget-object v1, La/ag;->yv:Ljava/util/ArrayList;

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_3
    return-void
.end method

.method private np()V
    .locals 1

    sget v0, La/ag;->yz:I

    if-ltz v0, :cond_0

    sget v0, La/ag;->yz:I

    iput v0, p0, La/ag;->yr:I

    :cond_0
    return-void
.end method

.method private nq()V
    .locals 0

    return-void
.end method

.method public static ns()I
    .locals 1

    sget v0, La/ag;->yo:I

    return v0
.end method

.method public static nt()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    sget-object v0, La/ag;->yt:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static nu()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation

    sget-object v0, La/ag;->yu:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static nv()La/al;
    .locals 1

    sget-object v0, La/ag;->yy:La/al;

    return-object v0
.end method

.method public static nw()Z
    .locals 1

    sget-boolean v0, La/ag;->yw:Z

    return v0
.end method

.method static synthetic ny()Ljava/util/Timer;
    .locals 1

    sget-object v0, La/ag;->yp:Ljava/util/Timer;

    return-object v0
.end method

.method public static q(La/al;)V
    .locals 0

    sput-object p0, La/ag;->yy:La/al;

    return-void
.end method

.method private setVelocidade(I)V
    .locals 1

    sget-object v0, La/ak;->zV:[I

    array-length v0, v0

    if-ge p1, v0, :cond_0

    sget-object v0, La/ak;->zV:[I

    aget p1, v0, p1

    sput p1, La/ag;->d:I

    :cond_0
    return-void
.end method


# virtual methods
.method public S(Ljava/util/ArrayList;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    sput v0, La/ag;->yo:I

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x1

    sput v1, La/ag;->pw:I

    iput-boolean v0, p0, La/ag;->yq:Z

    sput-boolean v1, La/ag;->yw:Z

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_7

    const-string v3, ""

    const-string v4, ""

    filled-new-array {v3, v4}, [Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v4, 0x1

    :goto_1
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_6

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jH()La/al;

    move-result-object v5

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-ne v5, v6, :cond_5

    if-eqz v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->jQ()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5, v0}, La/t;->J(Z)[Ljava/lang/String;

    move-result-object v5

    if-eqz v2, :cond_1

    new-instance v6, Lcomponents/bo;

    invoke-direct {v6}, Lcomponents/bo;-><init>()V

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "<html>&nbsp;&nbsp;<b>"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v8, v5, v0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v5, v5, v1

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "</b></html>"

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Lcomponents/bo;->Y(Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jH()La/al;

    move-result-object v5

    invoke-virtual {v5}, La/al;->cG()I

    move-result v5

    const/4 v7, 0x3

    if-ne v5, v7, :cond_0

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->isVerEstaduaisAgrupados()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-virtual {v6, v4}, Lcomponents/bo;->Y(Ljava/lang/String;)V

    :cond_0
    sget-object v4, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v4, 0x0

    :cond_2
    new-instance v5, Lcomponents/bo;

    invoke-direct {v5}, Lcomponents/bo;-><init>()V

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/t;

    invoke-virtual {v5, v6}, Lcomponents/bo;->o(La/t;)V

    invoke-virtual {v5}, Lcomponents/bo;->uJ()V

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v6

    invoke-virtual {v6}, La/t;->ji()La/ac;

    move-result-object v6

    if-eqz v6, :cond_3

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v6

    invoke-virtual {v6}, La/t;->ji()La/ac;

    move-result-object v6

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v7

    invoke-virtual {v7}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v6, v7}, La/ac;->O(Ljava/util/ArrayList;)V

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v6

    invoke-virtual {v6}, La/t;->ji()La/ac;

    move-result-object v6

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v7

    invoke-virtual {v7}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v6, v7}, La/ac;->M(Ljava/util/ArrayList;)V

    :cond_3
    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v6

    invoke-virtual {v6}, La/t;->jj()La/ac;

    move-result-object v6

    if-eqz v6, :cond_4

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v6

    invoke-virtual {v6}, La/t;->jj()La/ac;

    move-result-object v6

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v7

    invoke-virtual {v7}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v6, v7}, La/ac;->O(Ljava/util/ArrayList;)V

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v6

    invoke-virtual {v6}, La/t;->jj()La/ac;

    move-result-object v6

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v7

    invoke-virtual {v7}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v6, v7}, La/ac;->M(Ljava/util/ArrayList;)V

    :cond_4
    sget-object v6, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1

    :cond_6
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_7
    const/4 p1, -0x1

    const/4 v2, 0x0

    :goto_2
    sget-object v3, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_9

    sget-object v3, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->le()Z

    move-result v3

    if-eqz v3, :cond_8

    move p1, v2

    const/4 v0, 0x1

    goto :goto_3

    :cond_8
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_9
    :goto_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->getVelocidade()I

    move-result v2

    if-nez v0, :cond_a

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->getVelocidadeNH()I

    move-result v2

    :cond_a
    if-eqz v0, :cond_b

    sget-object v0, La/ak;->zV:[I

    aget v0, v0, v2

    :goto_4
    sput v0, La/ag;->d:I

    goto :goto_5

    :cond_b
    sget-object v0, La/ak;->zW:[I

    aget v0, v0, v2

    goto :goto_4

    :goto_5
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_c

    sput v1, La/ag;->d:I

    :cond_c
    const/16 v0, 0xa

    sput v0, La/ag;->d:I

    sput p1, La/ag;->yz:I

    invoke-virtual {p0}, La/ag;->nj()V

    return-void
.end method

.method public nj()V
    .locals 4

    new-instance v0, Ljava/util/Timer;

    invoke-direct {v0}, Ljava/util/Timer;-><init>()V

    sput-object v0, La/ag;->yp:Ljava/util/Timer;

    sget-object v0, La/ag;->yp:Ljava/util/Timer;

    new-instance v1, La/ag$1;

    invoke-direct {v1, p0}, La/ag$1;-><init>(La/ag;)V

    sget v2, La/ag;->d:I

    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    return-void
.end method

.method public nk()V
    .locals 4

    invoke-virtual {p0}, La/ag;->nx()V

    invoke-static {}, La/ag;->gV()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    invoke-static {}, La/ag;->ns()I

    move-result v0

    const/16 v1, 0x30

    if-le v0, v1, :cond_1

    invoke-virtual {p0}, La/ag;->no()V

    goto :goto_0

    :cond_0
    invoke-static {}, La/ag;->gV()I

    move-result v0

    const/4 v3, 0x2

    if-ne v0, v3, :cond_1

    invoke-static {}, La/ag;->ns()I

    move-result v0

    const/16 v3, 0x33

    if-lt v0, v3, :cond_1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    :goto_1
    if-eqz v1, :cond_2

    invoke-direct {p0}, La/ag;->nl()V

    return-void

    :cond_2
    invoke-static {v2}, La/ag;->V(Z)V

    return-void
.end method

.method public nn()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    if-eqz v2, :cond_0

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jD()I

    move-result v2

    sget-object v3, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uG()I

    move-result v3

    if-eq v2, v3, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    :goto_1
    if-eqz v2, :cond_1

    sget-object v2, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jP()V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public no()V
    .locals 3

    const/4 v0, 0x0

    sput v0, La/ag;->yo:I

    const/4 v1, 0x2

    sput v1, La/ag;->pw:I

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->getVerJanelaSubs()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_1

    invoke-static {v0}, La/ag;->cs(I)V

    :goto_0
    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, La/ag;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->le()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0, v0, v2}, La/ag;->d(IZ)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public nr()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcomponents/bo;",
            ">;"
        }
    .end annotation

    sget-object v0, La/ag;->yn:Ljava/util/ArrayList;

    return-object v0
.end method

.method public nx()V
    .locals 1

    sget v0, La/ag;->yo:I

    add-int/lit8 v0, v0, 0x1

    sput v0, La/ag;->yo:I

    return-void
.end method
