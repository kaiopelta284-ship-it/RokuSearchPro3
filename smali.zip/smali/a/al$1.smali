.class final La/al$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/al;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcomponents/ay;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcomponents/ay;Lcomponents/ay;)I
    .locals 2

    invoke-virtual {p1}, Lcomponents/ay;->fy()I

    move-result v0

    invoke-virtual {p2}, Lcomponents/ay;->fy()I

    move-result v1

    invoke-virtual {p1}, Lcomponents/ay;->mX()I

    move-result p1

    invoke-virtual {p2}, Lcomponents/ay;->mX()I

    move-result p2

    if-eq v0, v1, :cond_0

    sub-int/2addr v1, v0

    return v1

    :cond_0
    if-eq p1, p2, :cond_1

    sub-int/2addr p1, p2

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcomponents/ay;

    check-cast p2, Lcomponents/ay;

    invoke-virtual {p0, p1, p2}, La/al$1;->a(Lcomponents/ay;Lcomponents/ay;)I

    move-result p1

    return p1
.end method
