.class public La/k;
.super Ljava/lang/Object;


# instance fields
.field private nx:La/t;

.field private pl:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cl;",
            ">;"
        }
    .end annotation
.end field

.field private pm:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private pn:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private po:La/ac;

.field private pp:I


# direct methods
.method public constructor <init>(La/ac;La/t;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/k;->pl:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/k;->pm:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/k;->pn:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, La/k;->po:La/ac;

    const/4 v0, 0x0

    iput v0, p0, La/k;->pp:I

    iput-object p1, p0, La/k;->po:La/ac;

    iput-object p2, p0, La/k;->nx:La/t;

    iget-object p1, p0, La/k;->nx:La/t;

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object p1

    iget-object p2, p0, La/k;->po:La/ac;

    if-ne p1, p2, :cond_0

    iput v0, p0, La/k;->pp:I

    goto :goto_0

    :cond_0
    const/4 p1, 0x1

    iput p1, p0, La/k;->pp:I

    :goto_0
    invoke-virtual {p0, v0}, La/k;->C(Z)V

    return-void
.end method

.method private D(Z)V
    .locals 3

    if-eqz p1, :cond_2

    iget-object p1, p0, La/k;->po:La/ac;

    invoke-virtual {p1}, La/ac;->mn()Lcomponents/cf;

    move-result-object p1

    if-nez p1, :cond_0

    new-instance p1, Lcomponents/cf;

    invoke-direct {p1}, Lcomponents/cf;-><init>()V

    iget-object v0, p0, La/k;->po:La/ac;

    invoke-virtual {v0, p1}, La/ac;->a(Lcomponents/cf;)V

    :cond_0
    invoke-virtual {p1}, Lcomponents/cf;->clear()V

    const/4 v0, 0x0

    :goto_0
    const/16 v1, 0x21

    if-ge v0, v1, :cond_2

    iget-object v1, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/cl;

    invoke-virtual {v1}, Lcomponents/cl;->nD()La/p;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v1

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Lcomponents/cf;->vs()Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method private aH(I)V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->vH()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, La/k;->pn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x0

    :goto_1
    const/16 v2, 0x51

    if-gt v1, v2, :cond_1

    new-instance v2, Lcomponents/cl;

    invoke-direct {v2}, Lcomponents/cl;-><init>()V

    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, p0, La/k;->pm:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    sget-object v2, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {v1, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v2, 0x0

    :goto_2
    const/16 v3, 0xb

    if-ge v2, v3, :cond_3

    sget-object v3, La/ak;->AX:[[I

    aget-object v3, v3, p1

    aget v3, v3, v2

    invoke-static {v1, v3, v0, v0}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v4

    if-eqz v4, :cond_2

    iget-object v5, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3, v4}, Lcomponents/cl;->k(La/p;)V

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v3, p0, La/k;->pn:Ljava/util/ArrayList;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    const/16 p1, 0x1a

    const/4 p1, 0x0

    const/16 v2, 0x1a

    :goto_3
    sget-object v3, La/ak;->AW:[I

    array-length v3, v3

    if-ge p1, v3, :cond_5

    sget-object v3, La/ak;->AW:[I

    aget v3, v3, p1

    const/4 v4, 0x1

    invoke-static {v1, v3, v4, v0}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v3

    if-eqz v3, :cond_4

    iget-object v4, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/cl;

    invoke-virtual {v4, v3}, Lcomponents/cl;->k(La/p;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v4, p0, La/k;->pn:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    :cond_4
    add-int/lit8 p1, p1, 0x1

    goto :goto_3

    :cond_5
    const/16 p1, 0x21

    :goto_4
    iget-object v1, p0, La/k;->pm:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_7

    iget-object v1, p0, La/k;->pn:Ljava/util/ArrayList;

    iget-object v2, p0, La/k;->pm:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    iget-object v1, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/cl;

    iget-object v2, p0, La/k;->pm:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v1, v2}, Lcomponents/cl;->k(La/p;)V

    add-int/lit8 p1, p1, 0x1

    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_7
    return-void
.end method


# virtual methods
.method public C(Z)V
    .locals 4

    iget-object v0, p0, La/k;->pm:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, La/k;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, La/k;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, La/k;->nx:La/t;

    invoke-virtual {v2, v3, v0}, La/p;->a(La/t;Z)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, La/k;->pm:Ljava/util/ArrayList;

    iget-object v3, p0, La/k;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    if-eqz p1, :cond_2

    :goto_1
    iget-object p1, p0, La/k;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v0, p1, :cond_2

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public gL()V
    .locals 4

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    :goto_0
    const/16 v3, 0x19

    if-gt v1, v3, :cond_1

    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    if-eqz v3, :cond_0

    add-int/lit8 v2, v2, 0x1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/16 v1, 0xb

    if-eq v2, v1, :cond_2

    return-void

    :cond_2
    invoke-direct {p0, v0}, La/k;->D(Z)V

    invoke-virtual {p0}, La/k;->gM()V

    return-void
.end method

.method public gM()V
    .locals 4

    iget-object v0, p0, La/k;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mo()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget v0, p0, La/k;->pp:I

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, La/k;->nx:La/t;

    invoke-virtual {v0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/k;->nx:La/t;

    invoke-virtual {v0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/k;->nx:La/t;

    invoke-virtual {v0}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    goto :goto_1

    :cond_0
    iget v0, p0, La/k;->pp:I

    if-ne v0, v1, :cond_1

    iget-object v0, p0, La/k;->nx:La/t;

    invoke-virtual {v0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/k;->nx:La/t;

    invoke-virtual {v0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La/k;->nx:La/t;

    invoke-virtual {v0}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v0, 0x1

    :goto_2
    const/16 v2, 0x19

    if-gt v0, v2, :cond_4

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    if-eqz v2, :cond_3

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2, v0}, La/p;->bd(I)V

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v2, v3}, La/p;->b(Ljava/lang/Boolean;)V

    iget-object v2, p0, La/k;->po:La/ac;

    invoke-virtual {v2}, La/ac;->mo()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v2, p0, La/k;->pp:I

    if-nez v2, :cond_2

    iget-object v2, p0, La/k;->nx:La/t;

    invoke-virtual {v2}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, La/k;->nx:La/t;

    invoke-virtual {v2}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v2

    :goto_3
    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_2
    iget v2, p0, La/k;->pp:I

    if-ne v2, v1, :cond_3

    iget-object v2, p0, La/k;->nx:La/t;

    invoke-virtual {v2}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, La/k;->nx:La/t;

    invoke-virtual {v2}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v2

    goto :goto_3

    :cond_3
    :goto_4
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_2

    :cond_4
    iget-object v0, p0, La/k;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mp()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/16 v0, 0x1a

    :goto_5
    const/16 v2, 0x20

    if-gt v0, v2, :cond_7

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    if-eqz v2, :cond_6

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2, v0}, La/p;->bd(I)V

    iget-object v2, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cl;

    invoke-virtual {v2}, Lcomponents/cl;->nD()La/p;

    move-result-object v2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v2, v3}, La/p;->b(Ljava/lang/Boolean;)V

    iget-object v2, p0, La/k;->po:La/ac;

    invoke-virtual {v2}, La/ac;->mp()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v2, p0, La/k;->pp:I

    if-nez v2, :cond_5

    iget-object v2, p0, La/k;->nx:La/t;

    invoke-virtual {v2}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v2

    :goto_6
    iget-object v3, p0, La/k;->pl:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cl;

    invoke-virtual {v3}, Lcomponents/cl;->nD()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_5
    iget v2, p0, La/k;->pp:I

    if-ne v2, v1, :cond_6

    iget-object v2, p0, La/k;->nx:La/t;

    invoke-virtual {v2}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v2

    goto :goto_6

    :cond_6
    :goto_7
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_7
    iget-object v0, p0, La/k;->po:La/ac;

    invoke-virtual {v0, v1}, La/ac;->S(Z)V

    invoke-static {}, La/o;->hv()V

    return-void
.end method
