.class public La/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private d:I

.field private mo:I

.field private of:I

.field private oo:I

.field private op:I

.field private oq:I

.field private or:I


# direct methods
.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/d;->oo:I

    return-void
.end method

.method public constructor <init>(La/ac;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/d;->oo:I

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    iput v0, p0, La/d;->mo:I

    invoke-virtual {p1}, La/ac;->mE()I

    move-result p1

    iput p1, p0, La/d;->oo:I

    return-void
.end method

.method public constructor <init>([I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/d;->oo:I

    const/4 v0, 0x0

    aget v0, p1, v0

    iput v0, p0, La/d;->of:I

    const/4 v0, 0x1

    aget v0, p1, v0

    iput v0, p0, La/d;->op:I

    const/4 v0, 0x2

    aget v0, p1, v0

    iput v0, p0, La/d;->d:I

    const/4 v0, 0x3

    aget v0, p1, v0

    iput v0, p0, La/d;->oq:I

    const/4 v0, 0x4

    aget p1, p1, v0

    iput p1, p0, La/d;->or:I

    return-void
.end method


# virtual methods
.method public ad(I)V
    .locals 0

    iput p1, p0, La/d;->mo:I

    return-void
.end method

.method public av(I)V
    .locals 1

    iget v0, p0, La/d;->oq:I

    add-int/2addr v0, p1

    iput v0, p0, La/d;->oq:I

    return-void
.end method

.method public aw(I)V
    .locals 0

    iput p1, p0, La/d;->oo:I

    return-void
.end method

.method public db()I
    .locals 1

    iget v0, p0, La/d;->mo:I

    return v0
.end method

.method public fB()Ljava/lang/String;
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->mE()I

    move-result v2

    iget v3, p0, La/d;->oo:I

    if-ne v2, v3, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    :goto_1
    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_2
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->lh()La/ac;

    move-result-object v1

    if-eqz v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->lh()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->mE()I

    move-result v1

    iget v2, p0, La/d;->oo:I

    if-ne v1, v2, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dT()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    invoke-virtual {v0}, La/y;->lh()La/ac;

    move-result-object v0

    goto :goto_1

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_3
    const/4 v0, 0x0

    return-object v0
.end method

.method public fC()I
    .locals 1

    iget v0, p0, La/d;->of:I

    return v0
.end method

.method public fD()V
    .locals 1

    iget v0, p0, La/d;->of:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d;->of:I

    return-void
.end method

.method public fE()I
    .locals 1

    iget v0, p0, La/d;->op:I

    return v0
.end method

.method public fF()V
    .locals 1

    iget v0, p0, La/d;->op:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d;->op:I

    return-void
.end method

.method public fG()I
    .locals 1

    iget v0, p0, La/d;->d:I

    return v0
.end method

.method public fH()V
    .locals 1

    iget v0, p0, La/d;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d;->d:I

    return-void
.end method

.method public fI()I
    .locals 1

    iget v0, p0, La/d;->oq:I

    return v0
.end method

.method public fJ()I
    .locals 1

    iget v0, p0, La/d;->or:I

    return v0
.end method

.method public fK()V
    .locals 1

    iget v0, p0, La/d;->or:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d;->or:I

    return-void
.end method

.method public fL()I
    .locals 1

    iget v0, p0, La/d;->oo:I

    return v0
.end method
