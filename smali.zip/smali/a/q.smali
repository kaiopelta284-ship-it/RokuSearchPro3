.class public La/q;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private forca:I

.field private pX:Ljava/lang/Boolean;

.field private pZ:I

.field private pais:I

.field private posicao:I

.field private pq:Ljava/lang/String;

.field private qF:I

.field private qN:I

.field private qO:D

.field private qc:I

.field private qd:I

.field private qe:I

.field private qi:I

.field private qj:I

.field private salario:I


# direct methods
.method constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, p0, La/q;->pX:Ljava/lang/Boolean;

    iput v0, p0, La/q;->qc:I

    iput v0, p0, La/q;->qi:I

    iput v0, p0, La/q;->qj:I

    iput v0, p0, La/q;->qN:I

    iput v0, p0, La/q;->qF:I

    const-wide/16 v0, 0x0

    iput-wide v0, p0, La/q;->qO:D

    return-void
.end method

.method public static a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;
    .locals 17

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p4

    if-nez p2, :cond_1

    new-instance v3, La/q;

    invoke-direct {v3}, La/q;-><init>()V

    invoke-virtual/range {p5 .. p5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual/range {p0 .. p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    invoke-virtual/range {p0 .. p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v4

    :goto_0
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    invoke-virtual/range {p0 .. p0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dt()Ljava/util/ArrayList;

    move-result-object v4

    goto :goto_0

    :cond_1
    move-object/from16 v3, p2

    :cond_2
    :goto_1
    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/16 v5, 0x64

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/4 v6, 0x1

    add-int/2addr v4, v6

    invoke-virtual/range {p0 .. p0}, La/ac;->getNivel()I

    move-result v7

    const/16 v8, 0x13

    const/16 v9, 0x5a

    const/16 v10, 0x1e

    const/16 v12, 0x8

    const/16 v15, 0xa

    const/4 v11, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x3

    const/4 v6, 0x4

    if-ge v7, v8, :cond_16

    invoke-virtual/range {p0 .. p0}, La/ac;->getReputacao()I

    move-result v7

    if-le v7, v14, :cond_3

    goto/16 :goto_2

    :cond_3
    invoke-virtual/range {p0 .. p0}, La/ac;->getNivel()I

    move-result v7

    const/16 v8, 0xf

    if-lt v7, v8, :cond_d

    if-gt v4, v13, :cond_4

    goto/16 :goto_3

    :cond_4
    if-gt v4, v11, :cond_5

    goto/16 :goto_4

    :cond_5
    if-gt v4, v6, :cond_6

    goto/16 :goto_5

    :cond_6
    if-gt v4, v15, :cond_7

    goto/16 :goto_6

    :cond_7
    if-gt v4, v10, :cond_8

    goto/16 :goto_c

    :cond_8
    const/16 v7, 0x41

    if-gt v4, v7, :cond_9

    goto/16 :goto_7

    :cond_9
    if-gt v4, v9, :cond_a

    goto/16 :goto_8

    :cond_a
    const/16 v7, 0x5f

    if-gt v4, v7, :cond_b

    goto/16 :goto_9

    :cond_b
    const/16 v7, 0x62

    if-gt v4, v7, :cond_c

    goto/16 :goto_a

    :cond_c
    if-gt v4, v5, :cond_17

    goto/16 :goto_b

    :cond_d
    if-gt v4, v6, :cond_e

    goto :goto_3

    :cond_e
    if-gt v4, v12, :cond_f

    goto :goto_4

    :cond_f
    if-gt v4, v8, :cond_10

    goto :goto_5

    :cond_10
    const/16 v7, 0x19

    if-gt v4, v7, :cond_11

    goto :goto_6

    :cond_11
    const/16 v7, 0x32

    if-gt v4, v7, :cond_12

    goto :goto_c

    :cond_12
    const/16 v7, 0x4b

    if-gt v4, v7, :cond_13

    goto :goto_7

    :cond_13
    const/16 v7, 0x5f

    if-gt v4, v7, :cond_14

    goto :goto_8

    :cond_14
    const/16 v7, 0x63

    if-gt v4, v7, :cond_15

    goto :goto_9

    :cond_15
    if-gt v4, v5, :cond_17

    goto :goto_a

    :cond_16
    :goto_2
    if-gt v4, v13, :cond_18

    :cond_17
    :goto_3
    const/4 v11, 0x1

    goto :goto_c

    :cond_18
    if-gt v4, v11, :cond_19

    :goto_4
    const/4 v11, 0x2

    goto :goto_c

    :cond_19
    if-gt v4, v6, :cond_1a

    :goto_5
    const/4 v11, 0x3

    goto :goto_c

    :cond_1a
    if-gt v4, v15, :cond_1b

    :goto_6
    const/4 v11, 0x4

    goto :goto_c

    :cond_1b
    const/16 v7, 0x19

    if-gt v4, v7, :cond_1c

    goto :goto_c

    :cond_1c
    const/16 v7, 0x3c

    if-gt v4, v7, :cond_1d

    :goto_7
    const/4 v11, 0x6

    goto :goto_c

    :cond_1d
    const/16 v7, 0x50

    if-gt v4, v7, :cond_1e

    :goto_8
    const/4 v11, 0x7

    goto :goto_c

    :cond_1e
    if-gt v4, v9, :cond_1f

    :goto_9
    const/16 v11, 0x8

    goto :goto_c

    :cond_1f
    const/16 v7, 0x62

    if-gt v4, v7, :cond_20

    :goto_a
    const/16 v11, 0x9

    goto :goto_c

    :cond_20
    if-gt v4, v5, :cond_17

    :goto_b
    const/16 v11, 0xa

    :goto_c
    iput v11, v3, La/q;->qd:I

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-ne v4, v8, :cond_21

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    :goto_d
    iput-object v4, v3, La/q;->pX:Ljava/lang/Boolean;

    goto :goto_e

    :cond_21
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    goto :goto_d

    :goto_e
    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    invoke-virtual {v4, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    add-int/lit8 v4, v4, 0x10

    iput v4, v3, La/q;->pZ:I

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/4 v5, 0x1

    add-int/2addr v4, v5

    if-gt v4, v15, :cond_22

    iput v7, v3, La/q;->posicao:I

    goto :goto_f

    :cond_22
    if-gt v4, v10, :cond_23

    iput v5, v3, La/q;->posicao:I

    goto :goto_f

    :cond_23
    const/16 v5, 0x32

    if-gt v4, v5, :cond_24

    iput v13, v3, La/q;->posicao:I

    goto :goto_f

    :cond_24
    const/16 v5, 0x50

    if-gt v4, v5, :cond_25

    iput v14, v3, La/q;->posicao:I

    goto :goto_f

    :cond_25
    iput v6, v3, La/q;->posicao:I

    :goto_f
    if-ltz v1, :cond_26

    iput v1, v3, La/q;->posicao:I

    :cond_26
    iget v1, v3, La/q;->posicao:I

    invoke-static {v1}, La/p;->be(I)[I

    move-result-object v1

    aget v5, v1, v7

    iput v5, v3, La/q;->qi:I

    const/4 v5, 0x1

    aget v1, v1, v5

    iput v1, v3, La/q;->qj:I

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v1

    iput v1, v3, La/q;->pais:I

    if-ne v4, v5, :cond_33

    invoke-virtual/range {p0 .. p0}, La/ac;->getNivel()I

    move-result v1

    const/16 v4, 0x12

    if-lt v1, v4, :cond_33

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/4 v4, 0x6

    invoke-virtual {v1, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    const/16 v5, 0x1d

    if-ne v4, v5, :cond_2c

    if-nez v1, :cond_27

    const/16 v1, 0xb

    :goto_10
    iput v1, v3, La/q;->pais:I

    goto/16 :goto_11

    :cond_27
    const/4 v4, 0x1

    if-ne v1, v4, :cond_28

    const/16 v1, 0x2b

    goto :goto_10

    :cond_28
    if-ne v1, v13, :cond_29

    const/16 v1, 0xc3

    goto :goto_10

    :cond_29
    if-ne v1, v14, :cond_2a

    const/16 v1, 0x96

    goto :goto_10

    :cond_2a
    if-ne v1, v6, :cond_2b

    const/16 v1, 0x54

    goto :goto_10

    :cond_2b
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/16 v4, 0xc8

    invoke-virtual {v1, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    goto :goto_10

    :cond_2c
    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    if-eq v4, v14, :cond_2d

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    const/16 v5, 0x9a

    if-eq v4, v5, :cond_2d

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    const/16 v5, 0x55

    if-eq v4, v5, :cond_2d

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    const/16 v5, 0x68

    if-eq v4, v5, :cond_2d

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    const/16 v5, 0x48

    if-ne v4, v5, :cond_33

    :cond_2d
    if-nez v1, :cond_2e

    iput v14, v3, La/q;->pais:I

    goto :goto_11

    :cond_2e
    const/4 v4, 0x1

    if-ne v1, v4, :cond_2f

    const/16 v1, 0x9a

    goto :goto_10

    :cond_2f
    if-ne v1, v13, :cond_30

    const/16 v1, 0x55

    goto :goto_10

    :cond_30
    if-ne v1, v14, :cond_31

    const/16 v1, 0x68

    goto :goto_10

    :cond_31
    if-ne v1, v6, :cond_32

    const/16 v1, 0xae

    goto :goto_10

    :cond_32
    const/16 v1, 0x48

    goto :goto_10

    :cond_33
    :goto_11
    iget v1, v3, La/q;->pais:I

    invoke-virtual/range {p0 .. p0}, La/ac;->getPais()I

    move-result v4

    if-eq v1, v4, :cond_34

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    const/4 v4, 0x7

    add-int/2addr v1, v4

    iput v1, v3, La/q;->qd:I

    :cond_34
    if-nez v2, :cond_35

    iget v1, v3, La/q;->pais:I

    invoke-static {v1}, La/p;->bf(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v3, La/q;->pq:Ljava/lang/String;

    goto :goto_12

    :cond_35
    iput-object v2, v3, La/q;->pq:Ljava/lang/String;

    :goto_12
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1, v13}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    iput v1, v3, La/q;->qc:I

    invoke-virtual {v3, v0}, La/q;->o(La/ac;)V

    invoke-virtual {v3, v0}, La/q;->p(La/ac;)V

    invoke-virtual {v3}, La/q;->iV()V

    invoke-virtual {v3}, La/q;->iW()V

    return-object v3
.end method


# virtual methods
.method public a(Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, La/q;->pX:Ljava/lang/Boolean;

    return-void
.end method

.method public aP(I)V
    .locals 0

    iput p1, p0, La/q;->forca:I

    return-void
.end method

.method public aQ(I)V
    .locals 0

    iput p1, p0, La/q;->salario:I

    return-void
.end method

.method public aR(I)V
    .locals 0

    iput p1, p0, La/q;->qe:I

    return-void
.end method

.method public ba(I)V
    .locals 0

    iput p1, p0, La/q;->qd:I

    return-void
.end method

.method public bc(I)V
    .locals 0

    iput p1, p0, La/q;->qF:I

    return-void
.end method

.method public bp(I)V
    .locals 0

    iput p1, p0, La/q;->qN:I

    return-void
.end method

.method public c(D)V
    .locals 0

    iput-wide p1, p0, La/q;->qO:D

    return-void
.end method

.method public f(Landroid/content/Context;)I
    .locals 3

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "flag_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, La/q;->pais:I

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v1, v2, p1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public forceQd(I)V
    .locals 0

    iput p1, p0, La/q;->qd:I

    invoke-virtual {p0}, La/q;->iV()V

    invoke-virtual {p0}, La/q;->iW()V

    return-void
.end method

.method public gN()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/q;->pq:Ljava/lang/String;

    return-object v0
.end method

.method public getCr1()I
    .locals 1

    iget v0, p0, La/q;->qi:I

    return v0
.end method

.method public getCr2()I
    .locals 1

    iget v0, p0, La/q;->qj:I

    return v0
.end method

.method public getIdade()I
    .locals 1

    iget v0, p0, La/q;->pZ:I

    return v0
.end method

.method public getLado()I
    .locals 1

    iget v0, p0, La/q;->qc:I

    return v0
.end method

.method public getPais()I
    .locals 1

    iget v0, p0, La/q;->pais:I

    return v0
.end method

.method public getPosicao()I
    .locals 1

    iget v0, p0, La/q;->posicao:I

    return v0
.end method

.method public hG()I
    .locals 1

    iget v0, p0, La/q;->forca:I

    return v0
.end method

.method public hH()I
    .locals 1

    iget v0, p0, La/q;->salario:I

    return v0
.end method

.method public hI()I
    .locals 1

    iget v0, p0, La/q;->qe:I

    return v0
.end method

.method public hS()D
    .locals 1

    iget-wide v0, p0, La/q;->qO:D

    return-wide v0
.end method

.method public iU()V
    .locals 5

    iget v0, p0, La/q;->pZ:I

    const/16 v1, 0x14

    if-gt v0, v1, :cond_9

    const-wide v2, 0x3f847ae147ae147bL    # 0.01

    iget v0, p0, La/q;->pZ:I

    const/16 v4, 0x11

    if-gt v0, v4, :cond_0

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    goto :goto_0

    :cond_0
    iget v0, p0, La/q;->pZ:I

    const/16 v4, 0x12

    if-ne v0, v4, :cond_1

    const-wide/high16 v2, 0x3fd8000000000000L    # 0.375

    goto :goto_0

    :cond_1
    iget v0, p0, La/q;->pZ:I

    const/16 v4, 0x13

    if-ne v0, v4, :cond_2

    const-wide v2, 0x3fd6666666666666L    # 0.35

    goto :goto_0

    :cond_2
    iget v0, p0, La/q;->pZ:I

    if-ne v0, v1, :cond_3

    const-wide/high16 v2, 0x3fc0000000000000L    # 0.125

    :cond_3
    :goto_0
    iget v0, p0, La/q;->qd:I

    const/4 v1, 0x3

    if-gt v0, v1, :cond_4

    const-wide v0, 0x3f9eb851eb851eb8L    # 0.03

    :goto_1
    add-double/2addr v2, v0

    goto :goto_2

    :cond_4
    iget v0, p0, La/q;->qd:I

    const/4 v1, 0x6

    if-gt v0, v1, :cond_5

    const-wide v0, 0x3fa47ae147ae147bL    # 0.04

    goto :goto_1

    :cond_5
    iget v0, p0, La/q;->qd:I

    const/16 v1, 0x8

    if-gt v0, v1, :cond_6

    const-wide v0, 0x3fb1eb851eb851ecL    # 0.07

    goto :goto_1

    :cond_6
    iget v0, p0, La/q;->qd:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_7

    const-wide v0, 0x3fb999999999999aL    # 0.1

    goto :goto_1

    :cond_7
    iget v0, p0, La/q;->qd:I

    const/16 v1, 0xa

    if-ne v0, v1, :cond_8

    const-wide v0, 0x3fbc28f5c28f5c29L    # 0.11

    goto :goto_1

    :cond_8
    :goto_2
    iget-wide v0, p0, La/q;->qO:D

    add-double/2addr v0, v2

    iput-wide v0, p0, La/q;->qO:D

    iget-wide v0, p0, La/q;->qO:D

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    cmpl-double v4, v0, v2

    if-lez v4, :cond_9

    iget v0, p0, La/q;->qF:I

    const/16 v1, 0x64

    if-ge v0, v1, :cond_9

    iget v0, p0, La/q;->qF:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/q;->qF:I

    iget-wide v0, p0, La/q;->qO:D

    sub-double/2addr v0, v2

    iput-wide v0, p0, La/q;->qO:D

    :cond_9
    return-void
.end method

.method public iV()V
    .locals 3

    iget v0, p0, La/q;->pZ:I

    const/16 v1, 0x10

    if-ne v0, v1, :cond_0

    const/16 v0, 0xf

    goto :goto_0

    :cond_0
    iget v0, p0, La/q;->pZ:I

    const/16 v1, 0x11

    if-ne v0, v1, :cond_1

    const/16 v0, 0x23

    goto :goto_0

    :cond_1
    iget v0, p0, La/q;->pZ:I

    const/16 v1, 0x12

    if-ne v0, v1, :cond_2

    const/16 v0, 0x37

    goto :goto_0

    :cond_2
    iget v0, p0, La/q;->pZ:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_3

    const/16 v0, 0x46

    goto :goto_0

    :cond_3
    iget v0, p0, La/q;->pZ:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_4

    const/16 v0, 0x4b

    goto :goto_0

    :cond_4
    const/4 v0, 0x0

    :goto_0
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/4 v2, 0x5

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    const/4 v2, 0x1

    add-int/2addr v1, v2

    add-int/2addr v0, v1

    iget v1, p0, La/q;->qd:I

    add-int/2addr v0, v1

    if-ge v0, v2, :cond_5

    const/4 v0, 0x1

    :cond_5
    const/16 v1, 0x64

    if-le v0, v1, :cond_6

    const/16 v0, 0x5f

    :cond_6
    iput v0, p0, La/q;->qF:I

    return-void
.end method

.method public iW()V
    .locals 3

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v1, 0x1

    add-int/2addr v0, v1

    const/16 v2, 0xf

    if-gt v0, v2, :cond_0

    iget v0, p0, La/q;->qd:I

    goto :goto_0

    :cond_0
    const/16 v2, 0x3c

    if-gt v0, v2, :cond_1

    iget v0, p0, La/q;->qd:I

    sub-int/2addr v0, v1

    goto :goto_0

    :cond_1
    iget v0, p0, La/q;->qd:I

    add-int/2addr v0, v1

    :goto_0
    if-ge v0, v1, :cond_2

    const/4 v0, 0x1

    :cond_2
    const/16 v1, 0xa

    if-le v0, v1, :cond_3

    const/16 v0, 0xa

    :cond_3
    iput v0, p0, La/q;->qN:I

    return-void
.end method

.method public iX()Ljava/lang/Boolean;
    .locals 1

    iget-object v0, p0, La/q;->pX:Ljava/lang/Boolean;

    return-object v0
.end method

.method public iY()I
    .locals 1

    iget v0, p0, La/q;->qN:I

    return v0
.end method

.method public iZ()D
    .locals 2

    iget-wide v0, p0, La/q;->qO:D

    return-wide v0
.end method

.method public ic()I
    .locals 1

    iget v0, p0, La/q;->qd:I

    return v0
.end method

.method public ih()I
    .locals 1

    iget v0, p0, La/q;->qF:I

    return v0
.end method

.method public m(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/q;->pq:Ljava/lang/String;

    return-void
.end method

.method public n(La/ac;)V
    .locals 9

    iget v0, p0, La/q;->pZ:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, La/q;->pZ:I

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    if-eqz p1, :cond_2

    iget v2, p0, La/q;->pZ:I

    const/16 v3, 0x14

    if-lt v2, v3, :cond_2

    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v2

    aget v0, v0, v2

    invoke-virtual {p1, v1}, La/ac;->T(Z)[I

    move-result-object v2

    const/4 v3, 0x5

    new-array v3, v3, [I

    fill-array-data v3, :array_1

    iget v4, p0, La/q;->qd:I

    if-lt v4, v0, :cond_0

    iget v0, p0, La/q;->posicao:I

    aget v0, v2, v0

    iget v2, p0, La/q;->posicao:I

    aget v2, v3, v2

    if-ge v0, v2, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {p1}, La/ac;->lU()I

    move-result v0

    const/16 v2, 0x1e

    if-ge v0, v2, :cond_2

    invoke-static {v1, p0, p1}, La/u;->a(ZLa/q;La/ac;)V

    invoke-virtual {p1}, La/ac;->lV()I

    move-result v0

    const/16 v2, 0xa

    if-ge v0, v2, :cond_2

    const/4 v4, -0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    move-object v3, p1

    invoke-static/range {v3 .. v8}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    return-void

    :cond_1
    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_2

    const/4 v3, -0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    move-object v2, p1

    move-object v4, p0

    invoke-static/range {v2 .. v7}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    :cond_2
    return-void

    :array_0
    .array-data 4
        0x1
        0x4
        0x5
        0x6
        0x6
        0x6
    .end array-data

    :array_1
    .array-data 4
        0x3
        0x5
        0x5
        0x8
        0x6
    .end array-data
.end method

.method public o(La/ac;)V
    .locals 6

    if-eqz p1, :cond_5

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v0

    invoke-virtual {p1}, La/ac;->getNivel()I

    move-result v1

    const/4 v2, 0x1

    invoke-virtual {p1}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/16 v4, 0xf

    const/4 v5, 0x5

    if-eqz v3, :cond_0

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    const/16 v0, 0x14

    const/16 v2, 0x14

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v0

    packed-switch v0, :pswitch_data_1

    goto :goto_0

    :pswitch_1
    const/16 v2, 0x16

    goto :goto_0

    :pswitch_2
    const/16 v2, 0xf

    goto :goto_0

    :pswitch_3
    const/4 v2, 0x5

    :goto_0
    if-gt v1, v4, :cond_1

    goto :goto_1

    :cond_1
    packed-switch v1, :pswitch_data_2

    const/4 v1, 0x0

    goto :goto_1

    :pswitch_4
    const/16 v1, 0x1e

    goto :goto_1

    :pswitch_5
    const/16 v1, 0x1d

    goto :goto_1

    :pswitch_6
    const/16 v1, 0x1c

    goto :goto_1

    :pswitch_7
    const/16 v1, 0x1b

    goto :goto_1

    :pswitch_8
    const/16 v1, 0x1a

    goto :goto_1

    :pswitch_9
    const/16 v1, 0x19

    goto :goto_1

    :pswitch_a
    const/16 v1, 0x15

    goto :goto_1

    :pswitch_b
    const/16 v1, 0x13

    goto :goto_1

    :pswitch_c
    const/16 v1, 0x12

    goto :goto_1

    :pswitch_d
    const/16 v1, 0x11

    :goto_1
    add-int/2addr v1, v2

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/4 v2, 0x3

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/2addr v1, v0

    iget-object v0, p0, La/q;->pX:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_2

    add-int/lit8 v1, v1, 0x9

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/2addr v1, v0

    :cond_2
    add-int/lit8 v1, v1, -0x17

    if-ge v1, v5, :cond_3

    const/16 v1, 0xa

    :cond_3
    invoke-virtual {p0}, La/q;->iV()V

    invoke-virtual {p0}, La/q;->iW()V

    const/16 v0, 0x64

    if-le v1, v0, :cond_4

    goto :goto_2

    :cond_4
    move v0, v1

    :goto_2
    invoke-virtual {p0, v0}, La/q;->aP(I)V

    invoke-virtual {p0, p1}, La/q;->q(La/ac;)V

    invoke-virtual {p0, p1}, La/q;->p(La/ac;)V

    :cond_5
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_2
        :pswitch_3
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x10
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch
.end method

.method public p(La/ac;)V
    .locals 9

    if-eqz p1, :cond_13

    invoke-virtual {p1}, La/ac;->lH()Z

    move-result v0

    const/16 v1, 0x1c2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 v5, 0x1f4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/16 v8, 0x15e

    if-eqz v0, :cond_3

    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v0

    if-ne v0, v7, :cond_0

    const/16 v1, 0x2ee

    goto :goto_2

    :cond_0
    if-ne v0, v6, :cond_1

    const/16 v1, 0x226

    goto :goto_2

    :cond_1
    if-ne v0, v3, :cond_2

    goto :goto_0

    :cond_2
    if-eq v0, v4, :cond_9

    if-ne v0, v2, :cond_7

    goto :goto_2

    :cond_3
    invoke-virtual {p1}, La/ac;->getDivisao()I

    move-result v0

    if-ne v0, v7, :cond_4

    const/16 v1, 0x258

    goto :goto_2

    :cond_4
    if-ne v0, v6, :cond_5

    :goto_0
    const/16 v1, 0x1f4

    goto :goto_2

    :cond_5
    if-ne v0, v3, :cond_6

    goto :goto_2

    :cond_6
    if-eq v0, v4, :cond_8

    if-ne v0, v2, :cond_7

    goto :goto_1

    :cond_7
    const/16 v1, 0x15e

    goto :goto_2

    :cond_8
    :goto_1
    const/16 v1, 0x190

    :cond_9
    :goto_2
    invoke-virtual {p1}, La/ac;->getNivel()I

    move-result p1

    const/16 v0, 0x14

    if-le p1, v0, :cond_a

    add-int/lit8 v1, v1, 0x32

    :cond_a
    iget p1, p0, La/q;->posicao:I

    if-nez p1, :cond_b

    add-int/lit8 v1, v1, -0x46

    goto :goto_3

    :cond_b
    if-ne p1, v7, :cond_c

    add-int/lit8 v1, v1, -0x1e

    goto :goto_3

    :cond_c
    if-ne p1, v6, :cond_d

    add-int/lit8 v1, v1, -0x28

    goto :goto_3

    :cond_d
    if-ne p1, v4, :cond_e

    add-int/lit8 v1, v1, -0x32

    :cond_e
    :goto_3
    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    int-to-double v0, v1

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int p1, v0

    iget v0, p0, La/q;->forca:I

    mul-int/lit8 v0, v0, 0x2

    mul-int v0, v0, p1

    iget p1, p0, La/q;->pZ:I

    const/16 v1, 0x20

    sub-int/2addr p1, v1

    mul-int/lit16 p1, p1, 0x12c

    const/4 v2, 0x0

    iget-object v3, p0, La/q;->pX:Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_f

    iget v2, p0, La/q;->forca:I

    mul-int/lit16 v2, v2, 0xfa

    :cond_f
    iget v3, p0, La/q;->pZ:I

    if-ge v3, v1, :cond_10

    :goto_4
    add-int/2addr v0, v2

    goto :goto_5

    :cond_10
    sub-int/2addr v0, p1

    goto :goto_4

    :goto_5
    if-ge v0, v5, :cond_11

    const/16 v0, 0x1f4

    :cond_11
    int-to-double v0, v0

    const-wide v2, 0x3fb999999999999aL    # 0.1

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int p1, v0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isSalarioMensal()Z

    move-result v0

    if-ne v0, v7, :cond_12

    mul-int/lit8 p1, p1, 0x4

    :cond_12
    iput p1, p0, La/q;->salario:I

    :cond_13
    return-void
.end method

.method public q(La/ac;)V
    .locals 10

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/q;->pais:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->iw()I

    move-result v0

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/ac;->getNivel()I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iget v2, p0, La/q;->forca:I

    mul-int/lit8 v2, v2, 0x2

    mul-int v2, v2, v2

    const/16 v3, 0x14

    const/16 v4, 0x15

    if-lt p1, v4, :cond_1

    const/16 v5, 0x2ee

    goto :goto_1

    :cond_1
    if-lt p1, v3, :cond_2

    const/16 v5, 0x258

    goto :goto_1

    :cond_2
    const/16 v5, 0x12

    if-lt p1, v5, :cond_3

    const/16 v5, 0x1f4

    goto :goto_1

    :cond_3
    const/16 v5, 0xc

    if-lt p1, v5, :cond_4

    const/16 v5, 0x190

    goto :goto_1

    :cond_4
    const/16 v5, 0x16e

    :goto_1
    iget-object v6, p0, La/q;->pX:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    const/16 v7, 0x16

    if-eqz v6, :cond_7

    if-lt p1, v7, :cond_5

    if-nez v0, :cond_5

    mul-int/lit8 v5, v5, 0x3

    goto :goto_2

    :cond_5
    if-lt p1, v4, :cond_6

    if-nez v0, :cond_6

    mul-int/lit8 v5, v5, 0x2

    goto :goto_2

    :cond_6
    const-wide v8, 0x3ffb333333333333L    # 1.7

    int-to-double v4, v5

    mul-double v4, v4, v8

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    long-to-int v5, v4

    :cond_7
    :goto_2
    iget p1, p0, La/q;->posicao:I

    const/4 v4, 0x4

    if-ne p1, v4, :cond_8

    const-wide v8, 0x3ff4cccccccccccdL    # 1.3

    int-to-double v4, v5

    mul-double v4, v4, v8

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    long-to-int v5, v4

    :cond_8
    iget p1, p0, La/q;->pZ:I

    const/16 v0, 0x10

    if-ge p1, v0, :cond_9

    iput v0, p0, La/q;->pZ:I

    :cond_9
    iget p1, p0, La/q;->pZ:I

    const/16 v0, 0xa

    const/16 v4, 0x20

    if-ge p1, v3, :cond_a

    iget p1, p0, La/q;->pZ:I

    sub-int/2addr v4, p1

    mul-int/lit8 v4, v4, 0x1b

    goto :goto_3

    :cond_a
    iget p1, p0, La/q;->pZ:I

    const/16 v3, 0x19

    if-gt p1, v3, :cond_b

    iget p1, p0, La/q;->pZ:I

    sub-int/2addr v4, p1

    mul-int/lit8 v4, v4, 0x16

    goto :goto_3

    :cond_b
    iget p1, p0, La/q;->pZ:I

    if-ge p1, v4, :cond_c

    iget p1, p0, La/q;->pZ:I

    sub-int/2addr v4, p1

    mul-int/lit8 v4, v4, 0xf

    goto :goto_3

    :cond_c
    iget p1, p0, La/q;->pZ:I

    const/16 v3, 0x22

    if-ge p1, v3, :cond_d

    iget p1, p0, La/q;->pZ:I

    sub-int/2addr v3, p1

    mul-int/lit8 v4, v3, 0xa

    goto :goto_3

    :cond_d
    iget p1, p0, La/q;->pZ:I

    sub-int/2addr p1, v3

    mul-int/lit8 p1, p1, 0x32

    rsub-int/lit8 v4, p1, 0x0

    :goto_3
    add-int/2addr v5, v4

    if-gtz v5, :cond_e

    const/16 v5, 0x3c

    :cond_e
    mul-int v2, v2, v5

    int-to-double v1, v2

    const-wide v3, 0x3f9eb851eb851eb8L    # 0.03

    mul-double v1, v1, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J

    move-result-wide v1

    long-to-int p1, v1

    iget v1, p0, La/q;->qd:I

    mul-int p1, p1, v1

    iget v1, p0, La/q;->qd:I

    if-ne v1, v0, :cond_f

    int-to-double v0, p1

    const-wide/high16 v2, 0x3ff8000000000000L    # 1.5

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int p1, v0

    :cond_f
    iput p1, p0, La/q;->qe:I

    return-void
.end method

.method public setCr1(I)V
    .locals 0

    iput p1, p0, La/q;->qi:I

    return-void
.end method

.method public setCr2(I)V
    .locals 0

    iput p1, p0, La/q;->qj:I

    return-void
.end method

.method public setIdade(I)V
    .locals 0

    iput p1, p0, La/q;->pZ:I

    return-void
.end method

.method public setLado(I)V
    .locals 0

    iput p1, p0, La/q;->qc:I

    return-void
.end method

.method public setPais(I)V
    .locals 0

    iput p1, p0, La/q;->pais:I

    return-void
.end method

.method public setPosicao(I)V
    .locals 0

    iput p1, p0, La/q;->posicao:I

    return-void
.end method
