.class Lcom/brasfoot/v2028/ActivityPenalty$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityPenalty;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Lb:Lcom/brasfoot/v2028/ActivityPenalty;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityPenalty;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$1;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty$1;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    iget-object v0, v0, Lcom/brasfoot/v2028/ActivityPenalty;->Jx:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty$1;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityPenalty;->ry()V

    return-void
.end method
