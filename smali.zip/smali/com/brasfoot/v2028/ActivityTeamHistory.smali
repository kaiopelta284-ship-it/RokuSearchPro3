.class public Lcom/brasfoot/v2028/ActivityTeamHistory;
.super Landroid/app/Activity;


# instance fields
.field EY:La/ac;

.field private Mr:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cd;",
            ">;"
        }
    .end annotation
.end field

.field Ms:Lcomponents/ag;

.field Mt:Landroid/widget/ListView;

.field Mu:Landroid/widget/ListView;

.field Mv:Landroid/widget/Button;

.field Mw:Landroid/widget/Button;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mr:Ljava/util/ArrayList;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityTeamHistory;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->cK(I)V

    return-void
.end method

.method private addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V
    .locals 7

    :try_start_0
    const v0, 0x7f060169

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p3}, Landroid/widget/LinearLayout;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    :cond_0
    if-lez p1, :cond_1

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v1, p3}, Landroid/widget/LinearLayout;->setTag(Ljava/lang/Object;)V

    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v5, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, p2, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object v4, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const v4, 0x7f04003b

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v4

    const v5, 0x7f040039

    invoke-virtual {v3, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v5

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v6, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    const v5, 0x7f040040

    invoke-virtual {v3, v5}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    const v4, 0x7f030010

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " ("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method private addSmTrophyRow(I)V
    .locals 7

    if-gtz p1, :cond_0

    return-void

    :cond_0
    :try_start_0
    const v0, 0x7f060169

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    const/16 v2, 0x8

    if-gt v1, v2, :cond_1

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "tr_supermundial"

    const-string v5, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object v4, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const v4, 0x7f04003b

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v4

    const v5, 0x7f040039

    invoke-virtual {v3, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v5

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v6, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    const v5, 0x7f040040

    invoke-virtual {v3, v5}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    const v4, 0x7f030010

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Super Mundial FIFA ("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method private cK(I)V
    .locals 10

    const v0, 0x7f060169

    const v1, 0x7f06019b

    const v2, 0x7f060146

    const v3, 0x7f030010

    const v4, 0x7f030007

    const v5, 0x7f030038

    const v6, 0x7f030013

    const/16 v7, 0x8

    const/4 v8, 0x0

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v8}, Landroid/widget/ListView;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v7}, Landroid/widget/ListView;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private si()V
    .locals 13

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mr:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x6

    new-array v0, v0, [I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    if-ltz v1, :cond_3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v5}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ad;

    invoke-virtual {v5}, La/ad;->db()I

    move-result v5

    new-instance v6, Lcomponents/cd;

    invoke-direct {v6}, Lcomponents/cd;-><init>()V

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ad;

    invoke-virtual {v7}, La/ad;->db()I

    move-result v7

    invoke-virtual {v6, v7}, Lcomponents/cd;->ad(I)V

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ad;

    invoke-virtual {v7}, La/ad;->jb()La/al;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcomponents/cd;->l(La/al;)V

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ad;

    invoke-virtual {v7}, La/ad;->fC()I

    move-result v7

    invoke-virtual {v6, v7}, Lcomponents/cd;->dq(I)V

    aget v7, v0, v3

    invoke-virtual {v6}, Lcomponents/cd;->fC()I

    move-result v8

    add-int/2addr v7, v8

    aput v7, v0, v3

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ad;

    invoke-virtual {v7}, La/ad;->fE()I

    move-result v7

    invoke-virtual {v6, v7}, Lcomponents/cd;->dR(I)V

    aget v7, v0, v2

    invoke-virtual {v6}, Lcomponents/cd;->fE()I

    move-result v8

    add-int/2addr v7, v8

    aput v7, v0, v2

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ad;

    invoke-virtual {v7}, La/ad;->fG()I

    move-result v7

    invoke-virtual {v6, v7}, Lcomponents/cd;->dS(I)V

    const/4 v7, 0x2

    aget v8, v0, v7

    invoke-virtual {v6}, Lcomponents/cd;->fG()I

    move-result v9

    add-int/2addr v8, v9

    aput v8, v0, v7

    iget-object v8, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v8}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/ad;

    invoke-virtual {v8}, La/ad;->fC()I

    move-result v8

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v9}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ad;

    invoke-virtual {v9}, La/ad;->fE()I

    move-result v9

    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v10}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/ad;

    invoke-virtual {v10}, La/ad;->fG()I

    move-result v10

    add-int/2addr v9, v10

    sub-int/2addr v8, v9

    invoke-virtual {v6, v8}, Lcomponents/cd;->dV(I)V

    const/4 v8, 0x3

    aget v9, v0, v8

    invoke-virtual {v6}, Lcomponents/cd;->vj()I

    move-result v10

    add-int/2addr v9, v10

    aput v9, v0, v8

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v9}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ad;

    invoke-virtual {v9}, La/ad;->mK()I

    move-result v9

    invoke-virtual {v6, v9}, Lcomponents/cd;->dT(I)V

    const/4 v9, 0x4

    aget v10, v0, v9

    invoke-virtual {v6}, Lcomponents/cd;->mK()I

    move-result v11

    add-int/2addr v10, v11

    aput v10, v0, v9

    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v10}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/ad;

    invoke-virtual {v10}, La/ad;->mL()I

    move-result v10

    invoke-virtual {v6, v10}, Lcomponents/cd;->dU(I)V

    const/4 v10, 0x5

    aget v11, v0, v10

    invoke-virtual {v6}, Lcomponents/cd;->mL()I

    move-result v12

    add-int/2addr v11, v12

    aput v11, v0, v10

    iget-object v11, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v11}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/ad;

    invoke-virtual {v11}, La/ad;->mO()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Lcomponents/cd;->aj(Ljava/lang/String;)V

    iget-object v11, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mr:Ljava/util/ArrayList;

    invoke-virtual {v11, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v1, -0x1

    if-gez v6, :cond_0

    const/4 v4, 0x1

    :cond_0
    if-nez v4, :cond_1

    iget-object v11, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v11}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ad;

    invoke-virtual {v6}, La/ad;->db()I

    move-result v6

    if-eq v5, v6, :cond_1

    const/4 v4, 0x1

    :cond_1
    if-eqz v4, :cond_2

    new-instance v4, Lcomponents/cd;

    invoke-direct {v4}, Lcomponents/cd;-><init>()V

    invoke-virtual {v4, v2}, Lcomponents/cd;->ap(Z)V

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v5}, La/ac;->mv()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ad;

    invoke-virtual {v5}, La/ad;->db()I

    move-result v5

    invoke-virtual {v4, v5}, Lcomponents/cd;->ad(I)V

    aget v5, v0, v3

    invoke-virtual {v4, v5}, Lcomponents/cd;->dq(I)V

    aget v5, v0, v2

    invoke-virtual {v4, v5}, Lcomponents/cd;->dR(I)V

    aget v5, v0, v7

    invoke-virtual {v4, v5}, Lcomponents/cd;->dS(I)V

    aget v5, v0, v8

    invoke-virtual {v4, v5}, Lcomponents/cd;->dV(I)V

    aget v5, v0, v9

    invoke-virtual {v4, v5}, Lcomponents/cd;->dT(I)V

    aget v5, v0, v10

    invoke-virtual {v4, v5}, Lcomponents/cd;->dU(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mr:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aput v3, v0, v3

    aput v3, v0, v2

    aput v3, v0, v7

    aput v3, v0, v8

    aput v3, v0, v9

    aput v3, v0, v10

    const/4 v4, 0x0

    :cond_2
    add-int/lit8 v1, v1, -0x1

    goto/16 :goto_0

    :cond_3
    return-void
.end method

.method private sj()V
    .locals 28

    move-object/from16 v0, p0

    const/16 v1, 0xe

    new-array v1, v1, [I

    const/4 v2, 0x6

    new-array v3, v2, [I

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v4}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v6, 0x1

    if-lez v4, :cond_1

    const/4 v4, 0x0

    :goto_0
    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_1

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->cG()I

    move-result v7

    if-lez v7, :cond_0

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->cG()I

    move-result v7

    array-length v8, v1

    if-ge v7, v8, :cond_0

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->cG()I

    move-result v7

    aget v8, v1, v7

    add-int/2addr v8, v6

    aput v8, v1, v7

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->cG()I

    move-result v7

    if-ne v7, v6, :cond_0

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->gT()I

    move-result v7

    if-lez v7, :cond_0

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->gT()I

    move-result v7

    array-length v8, v3

    if-ge v7, v8, :cond_0

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v7}, La/ac;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->gT()I

    move-result v7

    aget v8, v3, v7

    add-int/2addr v8, v6

    aput v8, v3, v7

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_0

    :cond_1
    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v4}, Lcom/brasfoot/v2028/Recopa;->smTitles(La/ac;)I

    move-result v4

    invoke-direct {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addSmTrophyRow(I)V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    const/16 v7, 0xe

    invoke-static {v4, v7}, Lcom/brasfoot/v2028/Recopa;->titleCount(La/ac;I)I

    move-result v4

    const-string v7, "tr_copasul"

    const-string v8, "Copa Sul-Sudeste"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    const/16 v7, 0x1a

    invoke-static {v4, v7}, Lcom/brasfoot/v2028/Recopa;->titleCount(La/ac;I)I

    move-result v4

    const-string v7, "tr_copasul"

    const-string v8, "Copa Paulista"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    const/16 v7, 0xf

    invoke-static {v4, v7}, Lcom/brasfoot/v2028/Recopa;->titleCount(La/ac;I)I

    move-result v4

    const-string v7, "tr_copanordeste"

    const-string v8, "Copa do Nordeste"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    const/16 v7, 0x11

    invoke-static {v4, v7}, Lcom/brasfoot/v2028/Recopa;->titleCount(La/ac;I)I

    move-result v4

    const-string v7, "tr_copaverde"

    const-string v8, "Copa Verde"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->fe()Ld/o;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    :goto_1
    const-string v7, "tr_copamundo"

    const-string v8, "Copa do Mundo"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->ff()Ld/c;

    move-result-object v5

    if-eqz v5, :cond_3

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    :goto_2
    const-string v7, "tr_copaamerica"

    const-string v8, "Copa Am\u00e9rica"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->fg()Ld/n;

    move-result-object v5

    if-eqz v5, :cond_4

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_3

    :cond_4
    const/4 v4, 0x0

    :goto_3
    const-string v7, "tr_euro"

    const-string v8, "Eurocopa"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    iget-object v5, v5, La/b;->ouroCopa:Ld/ouro;

    if-eqz v5, :cond_5

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_4

    :cond_5
    const/4 v4, 0x0

    :goto_4
    const-string v7, "tr_copaouro"

    const-string v8, "Copa Ouro"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    iget-object v5, v5, La/b;->africaCopa:Ld/africa;

    if-eqz v5, :cond_6

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_5

    :cond_6
    const/4 v4, 0x0

    :goto_5
    const-string v7, "tr_copaafrica"

    const-string v8, "Copa Africana"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    iget-object v5, v5, La/b;->asiaCopa:Ld/asia;

    if-eqz v5, :cond_7

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_6

    :cond_7
    const/4 v4, 0x0

    :goto_6
    const-string v7, "tr_copaasia"

    const-string v8, "Copa da Asia"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    iget-object v5, v5, La/b;->ofcCopa:Ld/ofc;

    if-eqz v5, :cond_8

    invoke-virtual {v5}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    goto :goto_7

    :cond_8
    const/4 v4, 0x0

    :goto_7
    const-string v7, "tr_copaoceania"

    const-string v8, "Copa da Oceania"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->ffin()Ljava/util/ArrayList;

    move-result-object v5

    iget-object v7, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {v5, v7}, Lcom/brasfoot/v2028/Recopa;->countChamps(Ljava/util/ArrayList;La/ac;)I

    move-result v4

    const-string v7, "tr_finalissima"

    const-string v8, "Finalissima"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    const/16 v7, 0x10

    invoke-static {v4, v7}, Lcom/brasfoot/v2028/Recopa;->titleCount(La/ac;I)I

    move-result v4

    const-string v7, "tr_supercopas"

    const-string v8, "Supercopa das Copas"

    invoke-direct {v0, v4, v7, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->addModTrophyRow(ILjava/lang/String;Ljava/lang/String;)V

    const v4, 0x7f06033f

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    const v7, 0x7f060171

    invoke-virtual {v0, v7}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/LinearLayout;

    const v8, 0x7f060339

    invoke-virtual {v0, v8}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    const v9, 0x7f06016b

    invoke-virtual {v0, v9}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/LinearLayout;

    const v10, 0x7f06033c

    invoke-virtual {v0, v10}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    const v11, 0x7f06016e

    invoke-virtual {v0, v11}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v11

    check-cast v11, Landroid/widget/LinearLayout;

    const v12, 0x7f06033d

    invoke-virtual {v0, v12}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v12

    check-cast v12, Landroid/widget/TextView;

    const v13, 0x7f06016f

    invoke-virtual {v0, v13}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/LinearLayout;

    const v14, 0x7f06033e

    invoke-virtual {v0, v14}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    const v15, 0x7f060170

    invoke-virtual {v0, v15}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/LinearLayout;

    const v5, 0x7f06016c

    invoke-virtual {v0, v5}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    const v2, 0x7f06033a

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const v6, 0x7f06016d

    invoke-virtual {v0, v6}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/LinearLayout;

    move-object/from16 v18, v15

    const v15, 0x7f06033b

    invoke-virtual {v0, v15}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    move-object/from16 v19, v14

    const v14, 0x7f060172

    invoke-virtual {v0, v14}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/LinearLayout;

    move-object/from16 v20, v15

    const v15, 0x7f060340

    invoke-virtual {v0, v15}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    move-object/from16 v21, v15

    const/4 v15, 0x3

    aget v22, v1, v15

    if-lez v22, :cond_9

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const v15, 0x7f0b021c

    invoke-virtual {v0, v15}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v15, " ("

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v23, v14

    const/4 v15, 0x3

    aget v14, v1, v15

    invoke-static {v14}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, ")"

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_8
    const/4 v2, 0x1

    goto :goto_9

    :cond_9
    move-object/from16 v23, v14

    const/16 v2, 0x8

    invoke-virtual {v5, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_8

    :goto_9
    aget v5, v1, v2

    const/4 v15, 0x2

    const/4 v14, 0x4

    if-lez v5, :cond_e

    const/4 v5, 0x6

    new-array v7, v5, [Ljava/lang/String;

    const v5, 0x7f0b0073

    invoke-virtual {v0, v5}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/16 v16, 0x0

    aput-object v5, v7, v16

    const v5, 0x7f0b0075

    invoke-virtual {v0, v5}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v7, v2

    const v2, 0x7f0b0077

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v7, v15

    const v2, 0x7f0b0079

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    aput-object v2, v7, v5

    const v2, 0x7f0b007b

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v7, v14

    const v2, 0x7f0b007d

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    aput-object v2, v7, v5

    const-string v2, ""

    const-string v5, ""

    const-string v14, ""

    const-string v15, ""

    const/16 v17, 0x1

    aget v22, v3, v17

    if-lez v22, :cond_a

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v24, v5

    const-string v5, "  "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v5, v7, v17

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " ("

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v5, v3, v17

    invoke-static {v5}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ")"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_a

    :cond_a
    move-object/from16 v24, v5

    :goto_a
    const/4 v5, 0x2

    aget v17, v3, v5

    if-lez v17, :cond_b

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v25, v2

    const-string v2, "  "

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v26, v6

    const/4 v2, 0x2

    aget-object v6, v7, v2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " ("

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v6, v3, v2

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_b

    :cond_b
    move-object/from16 v25, v2

    move-object/from16 v26, v6

    move-object/from16 v5, v24

    :goto_b
    const/4 v2, 0x3

    aget v6, v3, v2

    if-lez v6, :cond_c

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v27, v10

    const-string v10, "  "

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v10, v7, v2

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, " ("

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v10, v3, v2

    invoke-static {v10}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v25, v2

    goto :goto_c

    :cond_c
    move-object/from16 v27, v10

    :goto_c
    const/4 v2, 0x4

    aget v6, v3, v2

    if-lez v6, :cond_d

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "  "

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v7, v7, v2

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, " ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v3, v3, v2

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v25

    :cond_d
    move-object/from16 v2, v25

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v6, 0x7f0b010f

    invoke-virtual {v0, v6}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_d

    :cond_e
    move-object/from16 v26, v6

    move-object/from16 v27, v10

    const/16 v2, 0x8

    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :goto_d
    const/4 v2, 0x2

    aget v3, v1, v2

    if-lez v3, :cond_f

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b010e

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v4, v1, v2

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x8

    goto :goto_e

    :cond_f
    const/16 v2, 0x8

    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :goto_e
    invoke-virtual {v11, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const/4 v2, 0x4

    aget v3, v1, v2

    if-lez v3, :cond_14

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-nez v2, :cond_10

    const/4 v2, 0x0

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0054

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    aget v3, v1, v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_10

    :cond_10
    const v2, 0x7f0602a4

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/4 v3, 0x0

    invoke-virtual {v11, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b00df

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    aget v5, v1, v4

    invoke-static {v5}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move-object/from16 v10, v27

    invoke-virtual {v10, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v3, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    const/4 v4, 0x3

    if-ne v3, v4, :cond_11

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b001d

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    aget v4, v1, v4

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "tr_ligaafc"

    const-string v5, "drawable"

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_10

    :cond_11
    iget-object v3, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    const/4 v4, 0x4

    if-ne v3, v4, :cond_12

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "tr_ligaconcacaf"

    const-string v5, "drawable"

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0063

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    aget v3, v1, v3

    :goto_f
    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_10

    :cond_12
    iget-object v3, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_13

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "tr_ligacaf"

    const-string v5, "drawable"

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b00e0

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    aget v3, v1, v3

    goto :goto_f

    :cond_13
    iget-object v3, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v3}, La/ac;->iw()I

    move-result v3

    const/4 v4, 0x5

    if-ne v3, v4, :cond_14

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "tr_ligaofc"

    const-string v5, "drawable"

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b00e1

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    aget v3, v1, v3

    goto :goto_f

    :cond_14
    :goto_10
    move-object/from16 v6, v26

    const/16 v2, 0x8

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    move-object/from16 v14, v23

    invoke-virtual {v14, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const/4 v2, 0x6

    aget v3, v1, v2

    if-lez v3, :cond_16

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    if-nez v2, :cond_15

    const/4 v2, 0x0

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b026e

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    aget v3, v1, v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v15, v20

    :goto_11
    invoke-virtual {v15, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_12

    :cond_15
    const/4 v2, 0x0

    invoke-virtual {v14, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0277

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    aget v3, v1, v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v15, v21

    goto :goto_11

    :cond_16
    :goto_12
    const/16 v2, 0xc

    aget v3, v1, v2

    if-lez v3, :cond_17

    const/4 v2, 0x0

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "tr_ligaconferencia"

    const-string v5, "drawable"

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0291

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0xc

    aget v3, v1, v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v15, v12

    invoke-virtual {v15, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_17
    const/16 v2, 0x8

    aget v3, v1, v2

    if-lez v3, :cond_1a

    const v2, 0x7f06016d

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setVisibility(I)V

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    instance-of v5, v3, Landroid/widget/ImageView;

    if-eqz v5, :cond_19

    check-cast v3, Landroid/widget/ImageView;

    iget-object v5, v0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v5}, La/ac;->iw()I

    move-result v5

    if-nez v5, :cond_18

    const-string v5, "tr_recopauefa"

    goto :goto_13

    :cond_18
    const-string v5, "tr_recopasul"

    :goto_13
    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const-string v7, "drawable"

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v5, v7, v8}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    if-eqz v5, :cond_19

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_19
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b006e

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x8

    aget v4, v1, v4

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move-object/from16 v15, v20

    invoke-virtual {v15, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1a
    const/4 v2, 0x5

    aget v3, v1, v2

    if-lez v3, :cond_1b

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b005e

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityTeamHistory;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v1, v1, v2

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move-object/from16 v14, v19

    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_1b
    move-object/from16 v15, v18

    const/16 v1, 0x8

    invoke-virtual {v15, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070026

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    const p1, 0x7f0602e2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {p1, v0}, Lcom/brasfoot/v2028/Recopa;->teamNameLevel(Landroid/widget/TextView;La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v0}, La/ac;->ma()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-virtual {v0}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackgroundColor(I)V

    const p1, 0x7f06019b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mt:Landroid/widget/ListView;

    new-instance p1, Lcomponents/ag;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mr:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/ag;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Ms:Lcomponents/ag;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mt:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Ms:Lcomponents/ag;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->si()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Ms:Lcomponents/ag;

    invoke-virtual {p1}, Lcomponents/ag;->notifyDataSetChanged()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->sj()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->EY:La/ac;

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/Recopa;->applyCountryTrophies(Landroid/app/Activity;La/ac;)V

    const p1, 0x7f060046

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mv:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mv:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityTeamHistory$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTeamHistory$1;-><init>(Lcom/brasfoot/v2028/ActivityTeamHistory;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060061

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeamHistory;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mw:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory;->Mw:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityTeamHistory$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTeamHistory$2;-><init>(Lcom/brasfoot/v2028/ActivityTeamHistory;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->showTrophy(Landroid/app/Activity;)V

    return-void
.end method
