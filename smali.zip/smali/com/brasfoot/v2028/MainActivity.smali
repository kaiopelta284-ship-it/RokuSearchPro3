.class public Lcom/brasfoot/v2028/MainActivity;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/MainActivity$a;,
        Lcom/brasfoot/v2028/MainActivity$b;
    }
.end annotation


# static fields
.field public static Cy:Landroid/app/Activity;

.field private static Ks:La/t;

.field private static Kt:La/ac;

.field public static NZ:La/af;

.field public static Oa:Z

.field private static Ob:La/p;

.field public static pQ:Landroid/content/Context;


# instance fields
.field public JP:Lcom/brasfoot/v2028/b;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static B(La/ac;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Kt:La/ac;

    return-void
.end method

.method private O(Ljava/lang/String;)V
    .locals 8

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->pQ:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/String;

    :try_start_0
    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v2, v3

    goto :goto_0

    :catch_0
    move-exception v3

    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    :goto_0
    array-length v3, v2

    const/4 v4, 0x0

    :goto_1
    if-ge v4, v3, :cond_1

    aget-object v5, v2, v4

    const-string v6, ""

    invoke-virtual {v5, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    :try_start_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v6

    invoke-virtual {p0, v5, v1}, Lcom/brasfoot/v2028/MainActivity;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v5

    invoke-direct {p0, v6, v5}, Lcom/brasfoot/v2028/MainActivity;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    invoke-virtual {v5}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    move-exception v5

    invoke-virtual {v5}, Ljava/io/IOException;->printStackTrace()V

    :cond_0
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->sY()V

    return-void
.end method

.method private a(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .locals 3

    const/16 v0, 0x400

    new-array v0, v0, [B

    :goto_0
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_0

    const/4 v2, 0x0

    invoke-virtual {p2, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->tf()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->td()V

    return-void
.end method

.method static synthetic d(Lcom/brasfoot/v2028/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->tg()V

    return-void
.end method

.method public static getContext()Landroid/content/Context;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->pQ:Landroid/content/Context;

    if-nez v0, :cond_0

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    sput-object v0, Lcom/brasfoot/v2028/MainActivity;->pQ:Landroid/content/Context;

    :cond_0
    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->pQ:Landroid/content/Context;

    return-object v0
.end method

.method private h(Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->pQ:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/String;

    :try_start_0
    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v2, v3

    goto :goto_0

    :catch_0
    move-exception v3

    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    :goto_0
    array-length v3, v2

    const/4 v4, 0x0

    :goto_1
    if-ge v4, v3, :cond_1

    aget-object v5, v2, v4

    invoke-virtual {v5, p2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    :try_start_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v6

    invoke-virtual {p0, v5, v1}, Lcom/brasfoot/v2028/MainActivity;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v5

    invoke-direct {p0, v6, v5}, Lcom/brasfoot/v2028/MainActivity;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    invoke-virtual {v5}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    move-exception v5

    invoke-virtual {v5}, Ljava/io/IOException;->printStackTrace()V

    :cond_0
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    return-void
.end method

.method public static k(La/t;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Ks:La/t;

    return-void
.end method

.method private pw()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/MainActivity$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/MainActivity$3;-><init>(Lcom/brasfoot/v2028/MainActivity;)V

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public static qV()La/t;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Ks:La/t;

    return-object v0
.end method

.method public static qW()La/ac;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Kt:La/ac;

    return-object v0
.end method

.method public static s(La/p;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Ob:La/p;

    return-void
.end method

.method public static sU()La/p;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Ob:La/p;

    return-object v0
.end method

.method private sX()V
    .locals 3

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0b001f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/MainActivity$1;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/MainActivity$1;-><init>(Lcom/brasfoot/v2028/MainActivity;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/MainActivity$2;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/MainActivity$2;-><init>(Lcom/brasfoot/v2028/MainActivity;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private sY()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->sW()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->sZ()V

    return-void
.end method

.method private sZ()V
    .locals 1

    const-string v0, "teams"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    const-string v0, "pack_arg"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    const-string v0, "pack_de"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    const-string v0, "pack_fr"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    const-string v0, "pack_ing"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    const-string v0, "pack_it"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    const-string v0, "pack_pt"

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->O(Ljava/lang/String;)V

    return-void
.end method

.method public static setContext(Landroid/content/Context;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->pQ:Landroid/content/Context;

    return-void
.end method

.method private td()V
    .locals 3

    new-instance v0, Lc/a;

    invoke-direct {v0}, Lc/a;-><init>()V

    invoke-static {p0}, La/h;->a(Landroid/content/Context;)V

    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/StartOptions;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b0086

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private tf()V
    .locals 3

    new-instance v0, Lcom/brasfoot/v2028/b;

    const v1, 0x7f0b00e4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lcom/brasfoot/v2028/b;-><init>(Landroid/content/Context;Ljava/lang/String;I)V

    iput-object v0, p0, Lcom/brasfoot/v2028/MainActivity;->JP:Lcom/brasfoot/v2028/b;

    iget-object v0, p0, Lcom/brasfoot/v2028/MainActivity;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/b;->setCancelable(Z)V

    iget-object v0, p0, Lcom/brasfoot/v2028/MainActivity;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->show()V

    return-void
.end method

.method private tg()V
    .locals 2

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityEditor;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    new-instance p1, Lcom/brasfoot/v2028/MainActivity$b;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lcom/brasfoot/v2028/MainActivity$b;-><init>(Lcom/brasfoot/v2028/MainActivity;Lcom/brasfoot/v2028/MainActivity$1;)V

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {p1, v0}, Lcom/brasfoot/v2028/MainActivity$b;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method public onClick3(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityLoad;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/MainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickEditor(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->tc()V

    return-void
.end method

.method public onClickPr(Landroid/view/View;)V
    .locals 1

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivitySub;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/MainActivity;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->te()V

    return-void
.end method

.method public onClickYoutube(Landroid/view/View;)V
    .locals 3

    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    const-string v2, "https://www.youtube.com/@superbrasfoot2026"

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070018

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/MainActivity;->setContentView(I)V

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f010004

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, La/g;->a([Ljava/lang/String;)V

    invoke-static {p0}, La/o;->e(Landroid/content/Context;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/MainActivity;->setContext(Landroid/content/Context;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/CrashLogger;->install(Landroid/content/Context;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->sV()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkLicense(Landroid/app/Activity;)V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const v1, 0x7f080001

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 p1, 0x1

    return p1
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 2

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f060003

    if-ne v0, v1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-super {p0, p1}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method protected onStart()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->te()V

    return-void
.end method

.method protected onStop()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method

.method public pv()V
    .locals 2

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    return-void
.end method

.method public qM()V
    .locals 7

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    const/4 v3, 0x0

    if-eqz v0, :cond_3

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v4, 0x0

    :goto_1
    if-ge v3, v1, :cond_2

    aget-object v5, v0, v3

    invoke-virtual {v5}, Ljava/io/File;->isFile()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    const-string v6, ".png"

    invoke-virtual {v5, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    add-int/lit8 v4, v4, 0x1

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_2
    move v3, v4

    :cond_3
    const/16 v0, 0xa

    if-le v3, v0, :cond_4

    sput-boolean v2, Lcom/brasfoot/v2028/MainActivity;->Oa:Z

    :cond_4
    return-void
.end method

.method public sV()V
    .locals 6

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->qM()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    const/4 v2, 0x0

    if-eqz v0, :cond_3

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v3, 0x0

    :goto_1
    if-ge v2, v1, :cond_2

    aget-object v4, v0, v2

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, ".ban"

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    add-int/lit8 v3, v3, 0x1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    move v2, v3

    :cond_3
    const/16 v0, 0x64

    const v1, 0x31575

    if-ge v2, v0, :cond_4

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->sZ()V

    const-string v0, "tB"

    const/16 v2, 0x7ea

    invoke-static {p0, v0, v2}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    const-string v0, "uP"

    invoke-static {p0, v0, v1}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    return-void

    :cond_4
    const-string v0, "uP"

    invoke-static {p0, v0}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eq v0, v1, :cond_5

    const-string v0, "uP"

    invoke-static {p0, v0, v1}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->sX()V

    :cond_5
    return-void
.end method

.method public sW()V
    .locals 6

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    if-eqz v0, :cond_2

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, ".ban"

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    :try_start_0
    invoke-virtual {v3}, Ljava/io/File;->delete()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public ta()V
    .locals 2

    const v0, 0x7f060024

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    return-void
.end method

.method public tb()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    invoke-static {}, La/z;->lj()I

    move-result v1

    if-ge v0, v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public tc()V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->pw()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/MainActivity;->tg()V

    return-void
.end method

.method public te()V
    .locals 1

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/MainActivity;->ta()V

    :cond_0
    return-void
.end method
