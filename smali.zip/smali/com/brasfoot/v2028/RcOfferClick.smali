.class public Lcom/brasfoot/v2028/RcOfferClick;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public act:Landroid/app/Activity;

.field public action:I

.field public buyer:La/ac;

.field public offer:I

.field public player:La/p;


# direct methods
.method public constructor <init>(La/p;La/ac;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/RcOfferClick;->player:La/p;

    iput-object p2, p0, Lcom/brasfoot/v2028/RcOfferClick;->buyer:La/ac;

    iput p3, p0, Lcom/brasfoot/v2028/RcOfferClick;->offer:I

    iput p4, p0, Lcom/brasfoot/v2028/RcOfferClick;->action:I

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 6

    :try_start_0
    iget v0, p0, Lcom/brasfoot/v2028/RcOfferClick;->action:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/RcOfferClick;->player:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/RcOfferClick;->buyer:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/RcOfferClick;->offer:I

    if-eqz v0, :cond_3

    if-eqz v1, :cond_3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, La/p;->a(La/ac;IZZZ)V

    iget-object v0, p0, Lcom/brasfoot/v2028/RcOfferClick;->act:Landroid/app/Activity;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    :cond_0
    return-void

    :cond_1
    const/4 v1, 0x2

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/RcOfferClick;->player:La/p;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/p;->hI()I

    move-result v1

    mul-int/lit8 v1, v1, 0x46

    div-int/lit8 v1, v1, 0x64

    invoke-virtual {v0, v1}, La/p;->aR(I)V

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->protectFromLoan(La/p;)V

    return-void

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/RcOfferClick;->player:La/p;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/p;->hI()I

    move-result v1

    new-instance v2, Lcomponents/ck;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v2, v0, v1, v3, v4}, Lcomponents/ck;-><init>(La/p;IZZ)V

    iget-object v0, p0, Lcom/brasfoot/v2028/RcOfferClick;->act:Landroid/app/Activity;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    return-void

    :catch_0
    move-exception v0

    const-string v1, "BRASDBG"

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
