.class public Lcom/brasfoot/v2028/DialogA;
.super Landroid/app/Activity;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070009

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogA;->setContentView(I)V

    const p1, 0x7f06009b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogA;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, 0x7f0b00cf

    :goto_0
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogA;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_0
    const v0, 0x7f0b00d0

    goto :goto_0

    return-void
.end method
