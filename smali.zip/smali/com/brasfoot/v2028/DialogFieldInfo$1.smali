.class Lcom/brasfoot/v2028/DialogFieldInfo$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogFieldInfo;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Nc:Lcom/brasfoot/v2028/DialogFieldInfo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    invoke-static {p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->a(Lcom/brasfoot/v2028/DialogFieldInfo;)I

    move-result p1

    const/4 p2, 0x1

    if-le p1, p2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    invoke-static {p1, p3}, Lcom/brasfoot/v2028/DialogFieldInfo;->a(Lcom/brasfoot/v2028/DialogFieldInfo;I)I

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    invoke-static {p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->b(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    iget-object p1, p1, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    const/4 p2, -0x1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    iget-object p1, p1, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    iget-object p1, p1, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1, p2}, Lcomponents/r;->dm(I)V

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    iget-object p1, p1, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    iget-object p1, p1, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo$1;->Nc:Lcom/brasfoot/v2028/DialogFieldInfo;

    iget-object p1, p1, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {p1, p2}, Lcomponents/s;->dm(I)V

    :cond_1
    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
