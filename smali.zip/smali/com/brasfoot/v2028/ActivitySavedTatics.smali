.class public Lcom/brasfoot/v2028/ActivitySavedTatics;
.super Landroid/app/Activity;


# instance fields
.field LZ:Landroid/widget/Spinner;

.field Ma:Landroid/widget/EditText;

.field Mb:Landroid/widget/TextView;

.field nx:La/t;

.field po:La/ac;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private rZ()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cf;

    invoke-virtual {v2}, Lcomponents/cf;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v2, 0x1090009

    invoke-virtual {v1, v2}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    invoke-virtual {v2, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_1
    return-void
.end method

.method private sa()V
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SetTextI18n"
        }
    .end annotation

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Ma:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Mb:Landroid/widget/TextView;

    const v3, 0x7f0b0219

    :goto_0
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(I)V

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Ma:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v3, 0x63

    if-le v0, v3, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Mb:Landroid/widget/TextView;

    const v3, 0x7f0b021a

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    if-eqz v1, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Mb:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    return-void

    :cond_2
    new-instance v0, Lcomponents/cf;

    invoke-direct {v0}, Lcomponents/cf;-><init>()V

    const/4 v1, 0x0

    :goto_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v3}, La/ac;->mn()Lcomponents/cf;

    move-result-object v3

    invoke-virtual {v3}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_3

    invoke-virtual {v0}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v4}, La/ac;->mn()Lcomponents/cf;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_3
    const/4 v1, 0x0

    :goto_3
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v3}, La/ac;->mn()Lcomponents/cf;

    move-result-object v3

    invoke-virtual {v3}, Lcomponents/cf;->vs()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_4

    invoke-virtual {v0}, Lcomponents/cf;->vs()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v4}, La/ac;->mn()Lcomponents/cf;

    move-result-object v4

    invoke-virtual {v4}, Lcomponents/cf;->vs()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_4
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v1}, La/ac;->mn()Lcomponents/cf;

    move-result-object v1

    invoke-virtual {v1}, Lcomponents/cf;->vq()I

    move-result v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, La/ak;->AY:[Ljava/lang/String;

    aget-object v4, v4, v1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Ma:Landroid/widget/EditText;

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcomponents/cf;->setNome(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcomponents/cf;->dW(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v1}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Mb:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Mb:Landroid/widget/TextView;

    const v1, 0x7f0b022c

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Ma:Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->rZ()V

    return-void
.end method


# virtual methods
.method public onClickDelT(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->sc()V

    return-void
.end method

.method public onClickLoadT(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->sb()V

    return-void
.end method

.method public onClickSaveT(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->sa()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070022

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySavedTatics;->setContentView(I)V

    :try_start_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qz()La/t;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->nx:La/t;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->nx:La/t;

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->nx:La/t;

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    :goto_0
    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    goto :goto_1

    :cond_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->nx:La/t;

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object p1

    goto :goto_0

    :goto_1
    const p1, 0x7f060228

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySavedTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    const p1, 0x7f0600bb

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySavedTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Ma:Landroid/widget/EditText;

    const p1, 0x7f060262

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySavedTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->Mb:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->rZ()V

    return-void
.end method

.method public sb()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    if-le v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cf;

    sput-object v0, Lcom/brasfoot/v2028/ActivityEscala;->If:Lcomponents/cf;

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityEscala;->Ie:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->finish()V

    :cond_0
    return-void
.end method

.method public sc()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    if-le v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ml()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySavedTatics;->LZ:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySavedTatics;->rZ()V

    :cond_0
    return-void
.end method
