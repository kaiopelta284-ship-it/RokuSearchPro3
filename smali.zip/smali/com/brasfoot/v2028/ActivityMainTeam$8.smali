.class Lcom/brasfoot/v2028/ActivityMainTeam$8;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityMainTeam;->e(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic JK:I

.field final synthetic KF:Lcom/brasfoot/v2028/ActivityMainTeam;

.field final synthetic cSnap:La/ac;

.field final synthetic pSnap:La/p;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityMainTeam;ILandroid/app/Dialog;La/p;La/ac;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->KF:Lcom/brasfoot/v2028/ActivityMainTeam;

    iput p2, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->JK:I

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->Fm:Landroid/app/Dialog;

    iput-object p4, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->pSnap:La/p;

    iput-object p5, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->cSnap:La/ac;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->KF:Lcom/brasfoot/v2028/ActivityMainTeam;

    iget v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->JK:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->pSnap:La/p;

    if-eqz v2, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->cSnap:La/ac;

    invoke-virtual {v0, v2, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->ddLoan(La/p;La/ac;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->dd(I)V

    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam$8;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
