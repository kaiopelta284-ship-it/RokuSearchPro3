.class Lcom/brasfoot/v2028/ActivityTimes$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityTimes;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic MK:Lcom/brasfoot/v2028/ActivityTimes;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityTimes;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$3;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemLongClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)Z"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$3;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1, p3}, Lcomponents/ap;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$3;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityTimes;->py()V

    const/4 p1, 0x1

    return p1
.end method
