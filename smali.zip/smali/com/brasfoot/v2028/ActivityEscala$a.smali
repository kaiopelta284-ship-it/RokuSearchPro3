.class Lcom/brasfoot/v2028/ActivityEscala$a;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityEscala;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic Ig:Lcom/brasfoot/v2028/ActivityEscala;


# direct methods
.method private constructor <init>(Lcom/brasfoot/v2028/ActivityEscala;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala$a;->Ig:Lcom/brasfoot/v2028/ActivityEscala;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/brasfoot/v2028/ActivityEscala;Lcom/brasfoot/v2028/ActivityEscala$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala$a;-><init>(Lcom/brasfoot/v2028/ActivityEscala;)V

    return-void
.end method


# virtual methods
.method protected varargs b([Ljava/lang/String;)Ljava/lang/Boolean;
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala$a;->Ig:Lcom/brasfoot/v2028/ActivityEscala;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityEscala;->b(Lcom/brasfoot/v2028/ActivityEscala;)V

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala$a;->b([Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected l(Ljava/lang/Boolean;)V
    .locals 0

    return-void
.end method

.method protected synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala$a;->l(Ljava/lang/Boolean;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala$a;->Ig:Lcom/brasfoot/v2028/ActivityEscala;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityEscala;->pv()V

    return-void
.end method
