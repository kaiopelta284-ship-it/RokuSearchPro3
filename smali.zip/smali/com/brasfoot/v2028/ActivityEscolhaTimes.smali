.class public Lcom/brasfoot/v2028/ActivityEscolhaTimes;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;
    }
.end annotation


# instance fields
.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Ih:Landroid/widget/Spinner;

.field Ii:Landroid/widget/Spinner;

.field Ij:Landroid/widget/Spinner;

.field Ik:Landroid/widget/Spinner;

.field Il:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Im:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field In:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Io:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Ip:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field Iq:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field Ir:I

.field Is:I

.field It:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Il:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Im:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->In:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Io:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ha:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Hb:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ir:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Is:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->It:I

    return-void
.end method


# virtual methods
.method public E(Ljava/lang/String;)Z
    .locals 2

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    if-ge v0, v1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0b0282

    goto :goto_1

    :cond_1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    const/16 v0, 0x23

    if-le p1, v0, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0b0283

    goto :goto_1

    :cond_2
    const/4 p1, 0x0

    goto :goto_2

    :cond_3
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0b0281

    :goto_1
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    :goto_2
    const/4 v0, 0x1

    if-eqz p1, :cond_4

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    const/4 p1, 0x0

    return p1

    :cond_4
    return v0
.end method

.method public F(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ih:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ii:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ij:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ik:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-static {v0}, La/g;->aB(I)I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ij:Landroid/widget/Spinner;

    invoke-virtual {v2}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    const v2, 0x7f06007b

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/CheckBox;

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    :cond_0
    const/4 v2, -0x1

    if-ne v0, v2, :cond_1

    const/16 v0, 0x1d

    :cond_1
    invoke-virtual {v1, p1, v0}, La/ac;->b(Ljava/lang/String;I)V

    return-void
.end method

.method public cN(I)V
    .locals 10

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0b0074

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v3, 0x7f0b0076

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v3, 0x7f0b0078

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v3, 0x7f0b007a

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Im:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x0

    :goto_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/16 v5, 0x1d

    if-ge v1, v4, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kC()I

    move-result v4

    if-ne v4, v5, :cond_0

    if-ne v1, v3, :cond_0

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->isJogaEstadual()Z

    move-result v4

    if-eqz v4, :cond_0

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eA()Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_2

    :cond_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Im:Ljava/util/ArrayList;

    aget-object v5, v0, v1

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    :goto_1
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    invoke-virtual {v5}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/q;

    invoke-virtual {v5}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_1

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_2
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    if-eqz v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eA()Z

    move-result v0

    if-eqz v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    invoke-virtual {v0}, La/y;->kC()I

    move-result v0

    if-ne v0, v5, :cond_5

    const/4 v0, 0x0

    :goto_3
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_4

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->lF()Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Iq:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Im:Ljava/util/ArrayList;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0b00da

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ii:Landroid/widget/Spinner;

    new-instance v0, Lcomponents/av;

    const v5, 0x7f070066

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Im:Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, v0

    move-object v4, p0

    invoke-direct/range {v3 .. v9}, Lcomponents/av;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;ZZ)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->cO(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ii:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$2;-><init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    return-void
.end method

.method public cO(I)V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ih:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->In:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    if-ge p1, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kC()I

    move-result v1

    const/16 v3, 0x1d

    if-ne v1, v3, :cond_1

    const/4 v1, 0x3

    if-ne p1, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eA()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 p1, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->lF()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RK:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v2, p1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->In:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ij:Landroid/widget/Spinner;

    new-instance v7, Lcomponents/av;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->In:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, v7

    move-object v1, p0

    invoke-direct/range {v0 .. v6}, Lcomponents/av;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;ZZ)V

    invoke-virtual {p1, v7}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_4

    const p1, 0x7f06034c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    if-eqz p1, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->lx()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_5

    :cond_4
    return-void

    :cond_5
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getFilesDir()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".png"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v1, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method public iniciarJogo(Landroid/view/View;)V
    .locals 1

    const p1, 0x7f0600f7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->E(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_0

    new-instance p1, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;-><init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;Lcom/brasfoot/v2028/ActivityEscolhaTimes$1;)V

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {p1, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :cond_0
    return-void
.end method

.method public onBackPressed()V
    .locals 2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07000e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->setContentView(I)V

    const p1, 0x7f06023c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ih:Landroid/widget/Spinner;

    const p1, 0x7f06023b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ii:Landroid/widget/Spinner;

    const p1, 0x7f06023e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ij:Landroid/widget/Spinner;

    const p1, 0x7f06023d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ik:Landroid/widget/Spinner;

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Il:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kX()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Io:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2, p0}, La/y;->f(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ih:Landroid/widget/Spinner;

    new-instance v7, Lcomponents/aw;

    const v3, 0x7f070066

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Il:Ljava/util/ArrayList;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Io:Ljava/util/ArrayList;

    const/4 v6, 0x0

    move-object v1, v7

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {v0, v7}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->cN(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ih:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEscolhaTimes$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$1;-><init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    :goto_1
    invoke-static {}, La/z;->lj()I

    move-result v0

    if-ge p1, v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Hb:Ljava/util/ArrayList;

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bz;

    invoke-virtual {v1}, Lcomponents/bz;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ha:Ljava/util/ArrayList;

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bz;

    invoke-virtual {v1, p0}, Lcomponents/bz;->f(Landroid/content/Context;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ik:Landroid/widget/Spinner;

    new-instance v6, Lcomponents/aw;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Hb:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ha:Ljava/util/ArrayList;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {p1, v6}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ik:Landroid/widget/Spinner;

    const/16 v0, 0x1d

    invoke-static {v0}, La/g;->aA(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    const p1, 0x7f060027

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ih:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->requestFocus()Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ij:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;-><init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const v0, 0x7f06034c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-eqz v0, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ij:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    if-ltz v1, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->lx()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3

    :cond_2
    return-void

    :cond_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getFilesDir()Ljava/io/File;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".png"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v2, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method public pv()V
    .locals 2

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    return-void
.end method

.method public qh()V
    .locals 3

    const v0, 0x7f0600f7

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, La/b;->p(Z)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->F(Ljava/lang/String;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ft()I

    move-result v0

    const/16 v1, 0x16

    if-ne v0, v1, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fs()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, La/h;->gt()V

    :cond_0
    invoke-static {}, La/o;->hu()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->finish()V

    return-void
.end method
