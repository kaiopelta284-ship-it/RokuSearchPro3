.class Lcom/brasfoot/v2028/DialogIgrokInfo$19;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogIgrokInfo;->sC()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$19;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    iput-object p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$19;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$19;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$19;->Fm:Landroid/app/Dialog;

    const v1, 0x7f06022d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$19;->Fm:Landroid/app/Dialog;

    const v2, 0x7f0600b5

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->e(ILjava/lang/String;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$19;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
