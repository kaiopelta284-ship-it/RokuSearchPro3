.class Lcom/brasfoot/v2028/ActivityEscala$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityEscala;->qe()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Ig:Lcom/brasfoot/v2028/ActivityEscala;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityEscala;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala$3;->Ig:Lcom/brasfoot/v2028/ActivityEscala;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala$3;->Ig:Lcom/brasfoot/v2028/ActivityEscala;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {p1, p3}, Lcomponents/s;->dm(I)V

    return-void
.end method
