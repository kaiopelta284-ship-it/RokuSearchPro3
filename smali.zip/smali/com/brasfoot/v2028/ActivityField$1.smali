.class Lcom/brasfoot/v2028/ActivityField$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityField;
.end annotation


# instance fields
.field final huIdx:I


# direct methods
.method constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/brasfoot/v2028/ActivityField$1;->huIdx:I

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    sget-object v0, Lcom/brasfoot/v2028/ActivityField;->sInst:Lcom/brasfoot/v2028/ActivityField;

    if-eqz v0, :cond_0

    iget v1, p0, Lcom/brasfoot/v2028/ActivityField$1;->huIdx:I

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityField;->onTitularClick(I)V

    :cond_0
    return-void
.end method
