.class Lcom/brasfoot/v2028/ActivityConvoca$10;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityConvoca;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic GX:Lcom/brasfoot/v2028/ActivityConvoca;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityConvoca;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$10;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$10;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->a(Lcom/brasfoot/v2028/ActivityConvoca;I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$10;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityConvoca;->a(Lcom/brasfoot/v2028/ActivityConvoca;)V

    return-void
.end method
