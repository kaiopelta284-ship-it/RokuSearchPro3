.class public Lcom/brasfoot/v2028/ActivityResults;
.super Landroid/app/Activity;


# static fields
.field public static Hw:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/bh;",
            ">;"
        }
    .end annotation
.end field

.field public static LM:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/bh;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private FC:La/t;

.field FE:Landroid/widget/Spinner;

.field private FT:Ld/q;

.field private FU:La/al;

.field private Gi:I

.field private Jg:La/t;

.field private LA:I

.field private LB:I

.field LC:Landroid/widget/ListView;

.field LD:Landroid/widget/ListView;

.field LE:Landroid/widget/ListView;

.field LF:Lcomponents/af;

.field LG:Lcomponents/ae;

.field LH:Lcomponents/ae;

.field LI:Lcomponents/u;

.field LJ:Landroid/widget/Button;

.field LK:Landroid/widget/Button;

.field LL:Landroid/widget/ImageView;

.field LN:La/ac;

.field LO:La/af;

.field private Lw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/m;",
            ">;"
        }
    .end annotation
.end field

.field private Lx:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bh;",
            ">;"
        }
    .end annotation
.end field

.field private Ly:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bh;",
            ">;"
        }
    .end annotation
.end field

.field private Lz:La/y;

.field private lU:I

.field private oW:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private oX:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field private yn:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bs;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/ActivityResults$8;

    invoke-direct {v0}, Lcom/brasfoot/v2028/ActivityResults$8;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/ActivityResults;->LM:Ljava/util/Comparator;

    new-instance v0, Lcom/brasfoot/v2028/ActivityResults$9;

    invoke-direct {v0}, Lcom/brasfoot/v2028/ActivityResults$9;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/ActivityResults;->Hw:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Lx:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Ly:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/4 v1, 0x0

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->FU:La/al;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->FT:Ld/q;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->Lz:La/y;

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityResults;)I
    .locals 1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Gi:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Gi:I

    return v0
.end method

.method private a(Ljava/util/ArrayList;La/p;)I
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/bh;",
            ">;",
            "La/p;",
            ")I"
        }
    .end annotation

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bh;

    invoke-virtual {v1}, Lcomponents/bh;->tt()La/p;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, -0x1

    return p1
.end method

.method private a(La/t;I)V
    .locals 6

    const/4 v0, 0x1

    if-ne p2, v0, :cond_0

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityResults;->Lx:Ljava/util/ArrayList;

    invoke-virtual {p1}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v1

    goto :goto_0

    :cond_0
    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityResults;->Ly:Ljava/util/ArrayList;

    invoke-virtual {p1}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object v1

    :goto_0
    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    new-instance v4, Lcomponents/bh;

    invoke-direct {v4}, Lcomponents/bh;-><init>()V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v4, v5}, Lcomponents/bh;->u(La/p;)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->io()I

    move-result v5

    invoke-virtual {v4, v5}, Lcomponents/bh;->dt(I)V

    invoke-virtual {p2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    sget-object v0, Lcom/brasfoot/v2028/ActivityResults;->LM:Ljava/util/Comparator;

    invoke-static {p2, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_2
    invoke-virtual {p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v2, v0, :cond_3

    invoke-virtual {p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/m;

    invoke-virtual {v0}, La/m;->cG()I

    move-result v0

    const/4 v3, 0x6

    if-ne v0, v3, :cond_2

    invoke-virtual {p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/m;

    invoke-virtual {v0}, La/m;->gS()La/ac;

    move-result-object v0

    if-ne v0, v1, :cond_2

    invoke-virtual {p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/m;

    invoke-virtual {v0}, La/m;->gW()La/p;

    move-result-object v0

    invoke-direct {p0, p2, v0}, Lcom/brasfoot/v2028/ActivityResults;->a(Ljava/util/ArrayList;La/p;)I

    move-result v0

    if-ltz v0, :cond_2

    new-instance v3, Lcomponents/bh;

    invoke-direct {v3}, Lcomponents/bh;-><init>()V

    invoke-virtual {p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/m;

    invoke-virtual {v4}, La/m;->gX()La/p;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcomponents/bh;->u(La/p;)V

    invoke-virtual {p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/m;

    invoke-virtual {v4}, La/m;->gU()I

    move-result v4

    invoke-virtual {v3, v4}, Lcomponents/bh;->dy(I)V

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p2, v0, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LG:Lcomponents/ae;

    invoke-virtual {p1}, Lcomponents/ae;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LH:Lcomponents/ae;

    invoke-virtual {p1}, Lcomponents/ae;->notifyDataSetChanged()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityResults;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->cK(I)V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityResults;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityResults;->ru()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityResults;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->cI(I)V

    return-void
.end method

.method private cI(I)V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uR()La/al;

    move-result-object p1

    check-cast p1, La/y;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->e(La/y;)V

    return-void

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uR()La/al;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->s(La/al;)V

    :cond_1
    return-void
.end method

.method private cK(I)V
    .locals 10

    const v0, 0x7f060220

    const v1, 0x7f06021f

    const v2, 0x7f060160

    const v3, 0x7f030010

    const v4, 0x7f030007

    const v5, 0x7f030038

    const v6, 0x7f030013

    const/4 v7, 0x0

    const/16 v8, 0x8

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LK:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LK:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LJ:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LJ:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LJ:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LJ:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LK:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LK:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private pw()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/ActivityResults$11;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityResults$11;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private r(La/al;)V
    .locals 4

    new-instance v0, Lcomponents/bu;

    invoke-direct {v0}, Lcomponents/bu;-><init>()V

    invoke-virtual {v0, p1}, Lcomponents/bu;->u(La/al;)V

    invoke-virtual {p1}, La/al;->nT()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcomponents/bu;->Q(Ljava/lang/String;)V

    iget v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    invoke-virtual {v0, v1}, Lcomponents/bu;->W(I)V

    iget v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    const/4 v2, 0x1

    if-eq v1, v2, :cond_0

    iget v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    const/4 v3, 0x2

    if-ne v1, v3, :cond_2

    :cond_0
    instance-of v1, p1, La/y;

    if-eqz v1, :cond_1

    check-cast p1, La/y;

    invoke-virtual {p1, p0}, La/y;->f(Landroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v1}, Lcomponents/bu;->dD(I)V

    iget v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    if-ne v1, v2, :cond_2

    invoke-virtual {p1}, La/y;->kC()I

    move-result p1

    invoke-static {p1}, Lcom/brasfoot/v2028/Recopa;->ligaDisplay(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcomponents/bu;->Q(Ljava/lang/String;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, La/al;->nR()La/y;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {p1}, La/al;->nR()La/y;

    move-result-object p1

    invoke-virtual {p1, p0}, La/y;->f(Landroid/content/Context;)I

    move-result p1

    invoke-virtual {v0, p1}, Lcomponents/bu;->dD(I)V

    :cond_2
    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private rQ()V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_2

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/al;

    invoke-direct {p0, v4}, Lcom/brasfoot/v2028/ActivityResults;->r(La/al;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    if-eqz v4, :cond_1

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {v4}, La/t;->jH()La/al;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    if-eq v4, v5, :cond_0

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {v4}, La/t;->jb()La/al;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_1

    :cond_0
    const/4 v2, 0x1

    move v3, v1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    if-nez v2, :cond_8

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/al;

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x4

    if-ne v1, v2, :cond_8

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_1
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_4

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/af;

    invoke-virtual {v4}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    goto :goto_2

    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_4
    :goto_2
    if-eqz v1, :cond_8

    invoke-virtual {v1}, La/af;->hE()La/ac;

    move-result-object v2

    if-eqz v2, :cond_5

    invoke-virtual {v1}, La/af;->hE()La/ac;

    move-result-object v1

    :goto_3
    invoke-virtual {v1}, La/ac;->iw()I

    move-result v1

    goto :goto_4

    :cond_5
    invoke-virtual {v1}, La/af;->mT()La/ac;

    move-result-object v2

    if-eqz v2, :cond_6

    invoke-virtual {v1}, La/af;->mT()La/ac;

    move-result-object v1

    goto :goto_3

    :cond_6
    const/4 v1, 0x0

    :goto_4
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_8

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    invoke-virtual {v2}, La/al;->iw()I

    move-result v2

    if-ne v2, v1, :cond_7

    goto :goto_5

    :cond_7
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_8
    move v0, v3

    :goto_5
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bu;

    invoke-virtual {v1}, Lcomponents/bu;->uR()La/al;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityResults;->s(La/al;)V

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    return-void
.end method

.method private rR()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_5

    move v4, v3

    const/4 v3, 0x0

    :goto_1
    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/al;

    invoke-virtual {v5}, La/al;->nR()La/y;

    move-result-object v5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-ne v5, v6, :cond_3

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_3

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/al;

    invoke-direct {p0, v5}, Lcom/brasfoot/v2028/ActivityResults;->r(La/al;)V

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    if-eqz v5, :cond_3

    move v5, v4

    const/4 v4, 0x0

    :goto_2
    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/y;

    invoke-virtual {v6}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_2

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/y;

    invoke-virtual {v7}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    if-eq v6, v7, :cond_0

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/y;

    invoke-virtual {v7}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    if-ne v6, v7, :cond_1

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_2
    move v4, v5

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1

    :cond_4
    add-int/lit8 v2, v2, 0x1

    move v3, v4

    goto/16 :goto_0

    :cond_5
    if-gez v3, :cond_6

    goto :goto_3

    :cond_6
    move v1, v3

    :goto_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->e(La/y;)V

    iput v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    return-void

    :cond_7
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_8

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityResults;->e(La/y;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    :cond_8
    return-void
.end method

.method private rS()V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_4

    const-string v2, ""

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/al;

    invoke-virtual {v3}, La/al;->nS()I

    move-result v3

    const/4 v4, 0x1

    if-le v3, v4, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/al;

    invoke-virtual {v3}, La/al;->nS()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "\u00aa D"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_0
    new-instance v3, Lcomponents/bu;

    invoke-direct {v3}, Lcomponents/bu;-><init>()V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/al;

    invoke-virtual {v3, v4}, Lcomponents/bu;->u(La/al;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/al;

    invoke-virtual {v5}, La/al;->nQ()Ld/m;

    move-result-object v5

    invoke-virtual {v5}, Ld/m;->xb()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcomponents/bu;->Q(Ljava/lang/String;)V

    const/4 v2, 0x3

    invoke-virtual {v3, v2}, Lcomponents/bu;->W(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/al;

    invoke-virtual {v2}, La/al;->nQ()Ld/m;

    move-result-object v2

    invoke-virtual {v2, p0}, Ld/m;->f(Landroid/content/Context;)I

    move-result v2

    invoke-virtual {v3, v2}, Lcomponents/bu;->dD(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/al;

    invoke-virtual {v2}, La/al;->nQ()Ld/m;

    move-result-object v2

    invoke-virtual {v2}, Ld/m;->getEstado()I

    move-result v2

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityResults;->df(I)Z

    move-result v2

    if-eqz v2, :cond_1

    move v1, v0

    :cond_1
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {v2}, La/t;->jH()La/al;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-eq v2, v3, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {v2}, La/t;->jb()La/al;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_3

    :cond_2
    move v1, v0

    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->uR()La/al;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->s(La/al;)V

    iput v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    return-void
.end method

.method private rT()I
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bs;

    invoke-virtual {v1}, Lcomponents/bs;->uE()La/t;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bs;

    invoke-virtual {v1}, Lcomponents/bs;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bs;

    invoke-virtual {v1}, Lcomponents/bs;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    return v0

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, -0x1

    return v0
.end method

.method private ru()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    invoke-virtual {v0}, La/ac;->mc()La/af;

    move-result-object v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b0118

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityResults;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->n(Z)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b0113

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityResults;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LL:Landroid/widget/ImageView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    :cond_1
    return-void
.end method


# virtual methods
.method public ag(Z)V
    .locals 2

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_3

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bs;

    invoke-virtual {v1}, Lcomponents/bs;->uE()La/t;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bs;

    invoke-virtual {p1}, Lcomponents/bs;->uE()La/t;

    move-result-object p1

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz p1, :cond_3

    goto :goto_2

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    invoke-virtual {p1}, Lcomponents/af;->th()I

    move-result p1

    if-ltz p1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    invoke-virtual {v0}, Lcomponents/af;->th()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bs;

    invoke-virtual {p1}, Lcomponents/bs;->uE()La/t;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Lcomponents/bs;->uE()La/t;

    move-result-object p1

    :goto_2
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->l(La/t;)V

    :cond_3
    return-void
.end method

.method public df(I)Z
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->hE()La/ac;

    move-result-object v2

    if-nez v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->mT()La/ac;

    move-result-object v2

    :cond_0
    if-eqz v2, :cond_1

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v3

    const/16 v4, 0x1d

    if-ne v3, v4, :cond_1

    invoke-virtual {v2}, La/ac;->getEstado()I

    move-result v2

    if-ne p1, v2, :cond_1

    const/4 v1, 0x1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public dg(I)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, p0, v0}, La/ak;->a(ILandroid/content/Context;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public e(La/y;)V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->Lz:La/y;

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    :goto_0
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v2, v5, :cond_3

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jH()La/al;

    move-result-object v5

    invoke-virtual {v5}, La/al;->nR()La/y;

    move-result-object v5

    if-ne v5, p1, :cond_2

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/t;

    invoke-virtual {v5}, La/t;->jH()La/al;

    move-result-object v5

    invoke-virtual {v5}, La/al;->nS()I

    move-result v5

    if-eq v5, v3, :cond_0

    const/4 v4, 0x1

    :cond_0
    if-eqz v4, :cond_1

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityResults;->dg(I)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lcomponents/bs;

    invoke-direct {v4}, Lcomponents/bs;-><init>()V

    invoke-virtual {v4, v3}, Lcomponents/bs;->Y(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v3, v5

    const/4 v4, 0x0

    :cond_1
    new-instance v5, Lcomponents/bs;

    invoke-direct {v5}, Lcomponents/bs;-><init>()V

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/t;

    invoke-virtual {v5, v6}, Lcomponents/bs;->o(La/t;)V

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    if-eqz p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    invoke-virtual {p1}, Lcomponents/af;->notifyDataSetChanged()V

    :cond_4
    return-void
.end method

.method public l(La/t;)V
    .locals 17

    invoke-static/range {p0 .. p1}, Lcom/brasfoot/v2028/Recopa;->applyResultsTheme(Landroid/app/Activity;La/t;)V

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, La/t;->J(Z)[Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f060310

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    aget-object v3, v3, v2

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v3, v0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/4 v5, 0x5

    if-ne v3, v5, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->ee()Ld/y;

    move-result-object v3

    invoke-virtual {v3, v0, v2}, Ld/y;->b(Landroid/content/Context;Z)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    const v3, 0x7f0601ca

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0601cb

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    const v6, 0x7f06013a

    invoke-virtual {v0, v6}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    const v7, 0x7f06012b

    invoke-virtual {v0, v7}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    const v8, 0x7f06012a

    invoke-virtual {v0, v8}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    const v9, 0x7f06012f

    invoke-virtual {v0, v9}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/TextView;

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v10

    invoke-virtual {v10}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setBackgroundColor(I)V

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v10

    invoke-virtual {v10}, La/ac;->ma()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v10

    invoke-virtual {v10}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v4, v10}, Landroid/widget/TextView;->setBackgroundColor(I)V

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v10

    invoke-virtual {v10}, La/ac;->ma()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v4, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual/range {p1 .. p1}, La/t;->jO()La/l;

    move-result-object v11

    if-eqz v11, :cond_1

    invoke-virtual/range {p1 .. p1}, La/t;->jO()La/l;

    move-result-object v11

    invoke-virtual {v11}, La/l;->gN()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p1 .. p1}, La/t;->jZ()I

    move-result v11

    int-to-long v11, v11

    invoke-static {v11, v12}, La/n;->b(J)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p1 .. p1}, La/t;->kg()I

    move-result v11

    invoke-static {v11}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    iget v11, v0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/4 v12, 0x7

    const/16 v13, 0x8

    if-eq v11, v12, :cond_2

    iget v11, v0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/16 v12, 0x9

    if-ne v11, v12, :cond_3

    :cond_2
    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v7, v13}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_3
    iget v11, v0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/4 v12, 0x6

    const/4 v14, 0x4

    if-ne v11, v14, :cond_6

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v11

    instance-of v11, v11, Ld/t;

    if-nez v11, :cond_4

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v11

    instance-of v11, v11, Ld/p;

    if-eqz v11, :cond_a

    :cond_4
    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v11

    if-eqz v11, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v11

    instance-of v11, v11, Ld/x;

    if-eqz v11, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v11

    check-cast v11, Ld/x;

    invoke-virtual {v11}, Ld/x;->yp()I

    move-result v15

    invoke-virtual {v11}, Ld/x;->xO()I

    move-result v5

    const/4 v14, 0x3

    if-ne v5, v14, :cond_a

    if-ne v5, v15, :cond_a

    invoke-virtual {v11}, Ld/x;->yo()Ljava/util/List;

    move-result-object v14

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v14

    if-ge v5, v14, :cond_a

    invoke-virtual {v11}, Ld/x;->yo()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/ac;

    invoke-virtual {v5}, Ld/ac;->yK()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/t;

    if-eqz v5, :cond_5

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    check-cast v5, Ld/t;

    invoke-static {}, Ld/t;->xs()Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_0

    :cond_5
    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/p;

    if-eqz v5, :cond_9

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    check-cast v5, Ld/p;

    invoke-static {}, Ld/p;->xs()Ljava/lang/String;

    move-result-object v5

    goto :goto_0

    :cond_6
    iget v5, v0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    if-ne v5, v12, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/ad;

    if-nez v5, :cond_7

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/v;

    if-eqz v5, :cond_a

    :cond_7
    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v5

    if-eqz v5, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/x;

    if-eqz v5, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jb()La/al;

    move-result-object v5

    check-cast v5, Ld/x;

    invoke-virtual {v5}, Ld/x;->yp()I

    move-result v11

    invoke-virtual {v5}, Ld/x;->xO()I

    move-result v14

    if-ne v14, v11, :cond_a

    invoke-virtual {v5}, Ld/x;->yo()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    if-ge v14, v11, :cond_a

    invoke-virtual {v5}, Ld/x;->yo()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/ac;

    invoke-virtual {v5}, Ld/ac;->yK()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_a

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/ad;

    if-eqz v5, :cond_8

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    check-cast v5, Ld/ad;

    invoke-static {}, Ld/ad;->xs()Ljava/lang/String;

    move-result-object v5

    :goto_0
    invoke-virtual {v9, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_8
    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    instance-of v5, v5, Ld/v;

    if-eqz v5, :cond_9

    invoke-virtual/range {p1 .. p1}, La/t;->jH()La/al;

    move-result-object v5

    check-cast v5, Ld/v;

    invoke-static {}, Ld/v;->xs()Ljava/lang/String;

    move-result-object v5

    goto :goto_0

    :cond_9
    :goto_1
    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v7, v13}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_a
    invoke-virtual/range {p1 .. p1}, La/t;->kc()[I

    move-result-object v5

    aget v7, v5, v10

    if-ltz v7, :cond_b

    aget v7, v5, v2

    if-ltz v7, :cond_b

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const v8, 0x7f0b0144

    invoke-virtual {v0, v8}, Lcom/brasfoot/v2028/ActivityResults;->getString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, ": "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v8, v5, v10

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, " x "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v5, v5, v2

    invoke-static {v5}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_2

    :cond_b
    const-string v5, ""

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setVisibility(I)V

    :goto_2
    const v5, 0x7f060001

    invoke-virtual {v0, v5}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f060002

    invoke-virtual {v0, v6}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    invoke-virtual/range {p1 .. p1}, La/t;->jD()I

    move-result v7

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p1 .. p1}, La/t;->jF()I

    move-result v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p1 .. p1}, La/t;->ji()La/ac;

    move-result-object v5

    invoke-virtual {v5}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p1 .. p1}, La/t;->jj()La/ac;

    move-result-object v3

    invoke-virtual {v3}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f060258

    invoke-virtual {v0, v3}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f060259

    invoke-virtual {v0, v4}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    const v5, 0x7f06025a

    invoke-virtual {v0, v5}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f06025b

    invoke-virtual {v0, v6}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    const v7, 0x7f06025c

    invoke-virtual {v0, v7}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    const v7, 0x7f06025d

    invoke-virtual {v0, v7}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    const v7, 0x7f06025e

    invoke-virtual {v0, v7}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    const v8, 0x7f06025f

    invoke-virtual {v0, v8}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p1 .. p1}, La/t;->jI()[I

    move-result-object v11

    aget v11, v11, v10

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, "%"

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p1 .. p1}, La/t;->jI()[I

    move-result-object v9

    aget v9, v9, v2

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, "%"

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, La/t;->bu(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, La/t;->bB(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, La/t;->bu(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, La/t;->bB(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v10}, La/t;->bv(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v2}, La/t;->bv(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-direct {v0, v1, v2}, Lcom/brasfoot/v2028/ActivityResults;->a(La/t;I)V

    const/4 v3, 0x2

    invoke-direct {v0, v1, v3}, Lcom/brasfoot/v2028/ActivityResults;->a(La/t;I)V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityResults;->LG:Lcomponents/ae;

    invoke-virtual {v4}, Lcomponents/ae;->notifyDataSetChanged()V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityResults;->LH:Lcomponents/ae;

    invoke-virtual {v4}, Lcomponents/ae;->notifyDataSetChanged()V

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    const/4 v4, 0x0

    move-object v5, v4

    move-object v6, v5

    move-object v7, v6

    :goto_3
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v10, v8, :cond_15

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/m;

    invoke-virtual {v8}, La/m;->cG()I

    move-result v8

    if-ne v8, v2, :cond_d

    if-nez v4, :cond_c

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :cond_c
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_4
    const/4 v9, 0x4

    :goto_5
    const/4 v11, 0x5

    goto/16 :goto_6

    :cond_d
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/m;

    invoke-virtual {v8}, La/m;->cG()I

    move-result v8

    if-ne v8, v12, :cond_f

    if-nez v6, :cond_e

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    :cond_e
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_f
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/m;

    invoke-virtual {v8}, La/m;->cG()I

    move-result v8

    if-lt v8, v3, :cond_11

    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/m;

    invoke-virtual {v8}, La/m;->cG()I

    move-result v8

    const/4 v9, 0x4

    if-gt v8, v9, :cond_12

    if-nez v5, :cond_10

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    :cond_10
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_11
    const/4 v9, 0x4

    :cond_12
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/m;

    invoke-virtual {v8}, La/m;->cG()I

    move-result v8

    const/4 v11, 0x5

    if-ne v8, v11, :cond_14

    if-nez v7, :cond_13

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    :cond_13
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_14
    :goto_6
    invoke-virtual/range {p1 .. p1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/m;

    invoke-virtual {v8, v2}, La/m;->F(Z)V

    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_3

    :cond_15
    if-eqz v4, :cond_16

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    new-instance v3, La/m;

    const/16 v8, 0x5b

    invoke-direct {v3, v8, v2}, La/m;-><init>(IZ)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_16
    if-eqz v5, :cond_17

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    new-instance v3, La/m;

    const/16 v4, 0x5c

    invoke-direct {v3, v4, v2}, La/m;-><init>(IZ)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_17
    if-eqz v7, :cond_18

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    new-instance v3, La/m;

    const/16 v4, 0x5f

    invoke-direct {v3, v4, v2}, La/m;-><init>(IZ)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_18
    if-eqz v6, :cond_19

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    new-instance v3, La/m;

    const/16 v4, 0x60

    invoke-direct {v3, v4, v2}, La/m;-><init>(IZ)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_19
    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityResults;->LI:Lcomponents/u;

    invoke-virtual {v1}, Lcomponents/u;->notifyDataSetChanged()V

    const v1, 0x7f06034a

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    if-eqz v1, :cond_1a

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2, v0}, La/ac;->f(Landroid/content/Context;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lx()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_1a

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityResults;->getFilesDir()Ljava/io/File;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".png"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v3, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_1a

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_1a
    const v1, 0x7f06034b

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    if-eqz v1, :cond_1b

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2, v0}, La/ac;->f(Landroid/content/Context;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lx()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_1b

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityResults;->getFilesDir()Ljava/io/File;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".png"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v3, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_1b

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_1b
    return-void
.end method

.method public onBackPressed()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->qr()V

    return-void
.end method

.method public onClickClass(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->FC:La/t;

    invoke-static {p1}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityClass;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickContinuar(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rU()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070020

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->finish()V

    :cond_0
    :goto_0
    const p1, 0x7f060232

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->FE:Landroid/widget/Spinner;

    const p1, 0x7f060189

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LC:Landroid/widget/ListView;

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rP()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rO()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rM()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rL()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rN()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rK()V

    iget v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    if-ltz v0, :cond_4

    iget v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->FE:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    if-ge v0, v1, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->FE:Landroid/widget/Spinner;

    iget v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LB:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_4
    const v0, 0x7f06004a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LJ:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LJ:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityResults$1;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f060049

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LK:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LK:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$4;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityResults$4;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f060043

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LL:Landroid/widget/ImageView;

    :goto_2
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_6

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    invoke-virtual {v0}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_5

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/af;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    invoke-virtual {p1}, La/af;->hE()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    goto :goto_3

    :cond_5
    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    :cond_6
    :goto_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    const/16 v0, 0x8

    if-eqz p1, :cond_7

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    if-nez p1, :cond_8

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LL:Landroid/widget/ImageView;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_8
    iget p1, p0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/4 v1, 0x1

    if-eq p1, v1, :cond_9

    iget p1, p0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    const/4 v1, 0x3

    if-eq p1, v1, :cond_9

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LL:Landroid/widget/ImageView;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_9
    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announce(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceSuperMundial(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceCss(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceCne(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceCpaulista(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceCv(Landroid/app/Activity;)V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->maybeScheduleFinalissima()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceFinalissima(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceInjurySusp(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->maybeShowJornal(Landroid/app/Activity;)V

    return-void
.end method

.method public oncliCkDemissao(Landroid/view/View;)V
    .locals 5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LO:La/af;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    if-eqz p1, :cond_0

    new-instance p1, Landroid/app/Dialog;

    invoke-direct {p1, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {p1, v1}, Landroid/app/Dialog;->setContentView(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0b01a6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->LN:La/ac;

    invoke-virtual {v4}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v3

    invoke-virtual {v1, v2, v0}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f0600a6

    invoke-virtual {p1, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060062

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$2;

    invoke-direct {v1, p0, p1}, Lcom/brasfoot/v2028/ActivityResults$2;-><init>(Lcom/brasfoot/v2028/ActivityResults;Landroid/app/Dialog;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f06004d

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$3;

    invoke-direct {v1, p0, p1}, Lcom/brasfoot/v2028/ActivityResults$3;-><init>(Lcom/brasfoot/v2028/ActivityResults;Landroid/app/Dialog;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    :cond_0
    return-void
.end method

.method public oncliCkTimeRodada(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->Lz:La/y;

    invoke-static {p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->f(La/y;)V

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/DialogTimeRodada;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "tipo"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {p1, v0}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityResults;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public pv()V
    .locals 2

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method

.method public qr()V
    .locals 1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->finish()V

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->rV()V

    invoke-static {}, La/o;->hx()V

    return-void
.end method

.method public rK()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->Jg:La/t;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->l(La/t;)V

    return-void

    :cond_0
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->ag(Z)V

    return-void
.end method

.method public rL()V
    .locals 3

    const v0, 0x7f06021f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/ae;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->Lx:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/ae;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LG:Lcomponents/ae;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LG:Lcomponents/ae;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$5;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityResults$5;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const v0, 0x7f060220

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/ae;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->Ly:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/ae;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LH:Lcomponents/ae;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LH:Lcomponents/ae;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$6;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityResults$6;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public rM()V
    .locals 3

    const v0, 0x7f060189

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/af;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/af;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$7;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityResults$7;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public rN()V
    .locals 3

    const v0, 0x7f06017c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityResults;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/u;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->Lw:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/u;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LI:Lcomponents/u;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LI:Lcomponents/u;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    return-void
.end method

.method public rO()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->tE()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->FE:Landroid/widget/Spinner;

    new-instance v2, Lcomponents/aj;

    const v3, 0x7f070066

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->oX:Ljava/util/ArrayList;

    invoke-direct {v2, p0, v3, v0, v4}, Lcomponents/aj;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->FE:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityResults$10;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityResults$10;-><init>(Lcom/brasfoot/v2028/ActivityResults;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    return-void
.end method

.method public rP()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dd()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->filterRecopaDay(Ljava/util/ArrayList;)V

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/al;

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityResults;->LA:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/al;

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityResults;->rR()V

    :goto_0
    iput v2, p0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    return-void

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/al;

    invoke-virtual {v1}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_1

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityResults;->rS()V

    goto :goto_0

    :cond_1
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityResults;->oW:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/al;

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityResults;->rQ()V

    :cond_2
    return-void
.end method

.method public rU()V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityResults;->pw()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityResults;->qr()V

    return-void
.end method

.method public rV()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->kq()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->kr()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jr()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    const/4 v2, 0x0

    iput-object v2, v1, La/t;->rI:Lcomponents/cn;

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_0
    return-void
.end method

.method public s(La/al;)V
    .locals 10

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, -0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, -0x1

    const/4 v7, -0x1

    :goto_0
    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v3, v8, :cond_6

    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v8}, La/t;->jH()La/al;

    move-result-object v8

    if-ne v8, p1, :cond_5

    if-eq v0, v4, :cond_0

    const/4 v5, 0x1

    :cond_0
    if-eqz v5, :cond_1

    iget v8, p0, Lcom/brasfoot/v2028/ActivityResults;->lU:I

    if-eq v8, v2, :cond_1

    const/4 v5, 0x0

    :cond_1
    if-eqz v5, :cond_2

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4, v2}, La/t;->J(Z)[Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lcomponents/bs;

    invoke-direct {v5}, Lcomponents/bs;-><init>()V

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v9, v4, v1

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, " "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v4, v4, v2

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcomponents/bs;->Y(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, -0x1

    const/4 v5, 0x0

    :cond_2
    new-instance v8, Lcomponents/bs;

    invoke-direct {v8}, Lcomponents/bs;-><init>()V

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/t;

    invoke-virtual {v8, v9}, Lcomponents/bs;->o(La/t;)V

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-ne v6, v0, :cond_3

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    sub-int/2addr v6, v2

    :cond_3
    if-ne v7, v0, :cond_5

    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v8}, La/t;->ji()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-nez v8, :cond_4

    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v8}, La/t;->jj()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-eqz v8, :cond_5

    :cond_4
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityResults;->yn:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    sub-int/2addr v7, v2

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :cond_6
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    if-eqz p1, :cond_7

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    invoke-virtual {p1}, Lcomponents/af;->notifyDataSetChanged()V

    :cond_7
    return-void
.end method
