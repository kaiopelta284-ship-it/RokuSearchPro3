.class public Lcom/brasfoot/v2028/ActivityMainTeam;
.super Landroid/app/Activity;


# static fields
.field private static Kd:Z = true

.field private static Ke:D = 0.1

.field public static Kf:Z = false

.field private static Kg:La/al; = null

.field public static Kl:Z = false

.field public static Km:Z = false

.field public static Kn:Z = true

.field public static Kq:Lcom/brasfoot/v2028/ActivityMainTeam;

.field private static Ks:La/t;

.field private static Kt:La/ac;


# instance fields
.field private JX:La/p;

.field private JY:La/ac;

.field private JZ:Z

.field private KA:Landroid/widget/TextView;

.field private KB:Landroid/widget/TextView;

.field private KC:Landroid/widget/TextView;

.field private KD:Landroid/graphics/Color;

.field private KE:Landroid/graphics/Color;

.field private Ka:I

.field private Kb:Z

.field private Kc:Z

.field Kh:Lcomponents/q;

.field private Ki:La/p;

.field private Kj:La/ac;

.field private Kk:I

.field Ko:Landroid/widget/Spinner;

.field Kp:Lcomponents/ak;

.field private Kr:I

.field private Ku:Landroid/widget/ImageButton;

.field private Kv:Landroid/widget/ImageButton;

.field private Kw:Landroid/widget/ImageButton;

.field private Kx:Landroid/widget/ImageButton;

.field private Ky:Landroid/widget/TextView;

.field private Kz:Landroid/widget/TextView;

.field private nx:La/t;

.field private po:La/ac;

.field private pp:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JX:La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    const/4 v1, 0x0

    iput v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->pp:I

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JZ:Z

    iput v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ka:I

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kc:Z

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    iput v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kk:I

    iput v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kr:I

    return-void
.end method

.method public static B(La/ac;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityMainTeam;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->qZ()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityMainTeam;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->cW(I)V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityMainTeam;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->ru()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityMainTeam;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->cY(I)V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivityMainTeam;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rt()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivityMainTeam;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->cZ(I)V

    return-void
.end method

.method private cW(I)V
    .locals 1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kr:I

    if-eq p1, v0, :cond_0

    iput p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kr:I

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->cX(I)V

    :cond_0
    return-void
.end method

.method private cX(I)V
    .locals 7

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->Rs:Ljava/util/Comparator;

    :goto_0
    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    goto :goto_1

    :cond_0
    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->RB:Ljava/util/Comparator;

    goto :goto_0

    :cond_1
    const/4 v0, 0x3

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->Rv:Ljava/util/Comparator;

    goto :goto_0

    :cond_2
    const/4 v0, 0x4

    if-ne p1, v0, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->Ry:Ljava/util/Comparator;

    goto :goto_0

    :cond_3
    const/4 v0, 0x5

    if-ne p1, v0, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->RC:Ljava/util/Comparator;

    goto :goto_0

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->RD:Ljava/util/Comparator;

    goto :goto_0

    :goto_1
    const p1, 0x7f06017b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v6, Lcomponents/q;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const-string v0, "indCorLista"

    invoke-static {p0, v0}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    move-object v0, v6

    move-object v2, p0

    move-object v3, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/q;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;Ljava/lang/Boolean;I)V

    iput-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kh:Lcomponents/q;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kh:Lcomponents/q;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->s(La/p;)V

    :cond_5
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance v0, Lcom/brasfoot/v2028/ActivityMainTeam$12;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$12;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const p1, 0x7f0602dd

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0602d9

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "$"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lA()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz v0, :cond_6

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_6
    return-void
.end method

.method private cY(I)V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    const v0, 0x7f0601aa

    if-ne p1, v0, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityClass;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :goto_0
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    const v0, 0x7f0601a9

    if-ne p1, v0, :cond_1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityCalendario;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_1
    const v0, 0x7f0601a8

    if-ne p1, v0, :cond_4

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz p1, :cond_2

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_2
    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_3

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityAmistosos2024;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b00c8

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_4
    return-void
.end method

.method private cZ(I)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    const v0, 0x7f0601af

    if-ne p1, v0, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityTimes;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :goto_0
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    const v0, 0x7f0601ab

    if-ne p1, v0, :cond_1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityEstadio;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_1
    const v0, 0x7f0601ad

    if-ne p1, v0, :cond_2

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityJuniores;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_2
    const v0, 0x7f0601ae

    if-ne p1, v0, :cond_3

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityProcura;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_3
    const v0, 0x7f0601ac

    if-ne p1, v0, :cond_4

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityFinancas;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_4
    return-void
.end method

.method static synthetic d(Lcom/brasfoot/v2028/ActivityMainTeam;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->da(I)V

    return-void
.end method

.method private da(I)V
    .locals 3

    const v0, 0x7777001

    if-ne p1, v0, :cond_0

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityRankings;->selMode:Z

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityRankings;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/b;->al(I)La/y;

    move-result-object v0

    invoke-static {v0}, Lcom/brasfoot/v2028/DialogTimeRodada;->f(La/y;)V

    const v0, 0x7f0601b2

    if-ne p1, v0, :cond_1

    const/4 v2, 0x0

    sput-boolean v2, Lcom/brasfoot/v2028/ActivityRankings;->selMode:Z

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityRankings;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :goto_0
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_1
    const v0, 0x7f0601b3

    if-ne p1, v0, :cond_2

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_2
    const v0, 0x7f0601b1

    if-ne p1, v0, :cond_3

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityCampeoes;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_3
    const v0, 0x7f0601b0

    if-ne p1, v0, :cond_4

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityArt;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_4
    const v0, 0x7f0601b4

    if-ne p1, v0, :cond_5

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/DialogTimeRodada;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "tipo"

    const/4 v2, 0x0

    :goto_1
    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {p1, v0}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    goto :goto_0

    :cond_5
    const v0, 0x7f0601b5

    if-ne p1, v0, :cond_6

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/DialogTimeRodada;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "tipo"

    const/4 v2, 0x1

    goto :goto_1

    :cond_6
    const v0, 0x7f060fff

    if-ne p1, v0, :cond_7

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityBolaDeOuro;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_7
    return-void
.end method

.method private db(I)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0}, La/af;->li()La/ac;

    move-result-object v0

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0}, La/af;->li()La/ac;

    move-result-object v0

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    const v0, 0x7f0601bf

    if-ne p1, v0, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityCalendario;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :goto_0
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    const v0, 0x7f0601bd

    if-ne p1, v0, :cond_1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_1
    const v0, 0x7f0601bc

    if-ne p1, v0, :cond_2

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_2
    const v0, 0x7f0601be

    if-ne p1, v0, :cond_3

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rs()V

    return-void

    :cond_3
    const v0, 0x7f06040e

    if-ne p1, v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v0}, La/af;->li()La/ac;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/Recopa;->showIdolosSelecao(Landroid/app/Activity;La/ac;)V

    :cond_4
    return-void
.end method

.method private dc(I)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    const v0, 0x7f0601b9

    if-ne p1, v0, :cond_0

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivitySave;->LT:Z

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivitySave;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :goto_0
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    const v0, 0x7f0601b7

    if-ne p1, v0, :cond_2

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz p1, :cond_1

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rs()V

    return-void

    :cond_1
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rr()V

    return-void

    :cond_2
    const v0, 0x7f0601b8

    if-ne p1, v0, :cond_3

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityPref;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    goto :goto_0

    :cond_3
    const v0, 0x7f0601bb

    if-ne p1, v0, :cond_4

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rv()V

    return-void

    :cond_4
    const v0, 0x7f0601ba

    if-ne p1, v0, :cond_5

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rm()V

    return-void

    :cond_5
    const v0, 0x7f06040d

    if-ne p1, v0, :cond_6

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->showJornal(Landroid/app/Activity;)V

    return-void

    :cond_6
    const v0, 0x7f0601b6

    if-ne p1, v0, :cond_7

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rn()V

    :cond_7
    return-void
.end method

.method static synthetic e(Lcom/brasfoot/v2028/ActivityMainTeam;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->dc(I)V

    return-void
.end method

.method static synthetic f(Lcom/brasfoot/v2028/ActivityMainTeam;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->db(I)V

    return-void
.end method

.method public static k(La/t;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    return-void
.end method

.method private px()V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->cX(I)V

    return-void
.end method

.method public static qV()La/t;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    return-object v0
.end method

.method public static qW()La/ac;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    return-object v0
.end method

.method public static qX()Lcom/brasfoot/v2028/ActivityMainTeam;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kq:Lcom/brasfoot/v2028/ActivityMainTeam;

    return-object v0
.end method

.method private qY()V
    .locals 9

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v2, 0x7f070036

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setContentView(I)V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    const v3, 0x7f0600fc

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0b01c7

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f0600fe

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0b0149

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f060102

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0b0172

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f060100

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0b016b

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f0600f8

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0b0055

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f0600fa

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0b014d

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v4, 0x7f0b01c5

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v4}, La/p;->getLado()I

    move-result v4

    if-ne v4, v1, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v4, 0x7f0b01c3

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :cond_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    if-nez v4, :cond_1

    const-string v3, ""

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f010005

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v5}, La/p;->getCr1()I

    move-result v5

    aget-object v5, v4, v5

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v6}, La/p;->getCr2()I

    move-result v6

    aget-object v4, v4, v6

    const/4 v6, 0x5

    new-array v6, v6, [Ljava/lang/String;

    const v7, 0x7f0b0183

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v2

    const v2, 0x7f0b0188

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v6, v1

    const/4 v1, 0x2

    const v2, 0x7f0b0181

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v6, v1

    const/4 v1, 0x3

    const v2, 0x7f0b0185

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v6, v1

    const/4 v1, 0x4

    const v2, 0x7f0b0180

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v6, v1

    const v1, 0x7f0600fd

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2}, La/p;->hG()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0600ff

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2}, La/p;->getIdade()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f060103

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2}, La/p;->hI()I

    move-result v2

    int-to-long v7, v2

    invoke-static {v7, v8}, La/n;->b(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f060101

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2}, La/p;->hH()I

    move-result v2

    int-to-long v7, v2

    invoke-static {v7, v8}, La/n;->b(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0600f9

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "/"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0600fb

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v4}, La/p;->hN()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "%"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602df

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602e0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    aget-object v4, v6, v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f060317

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2}, La/p;->ii()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v2

    invoke-virtual {v2}, La/z;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0601e6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    invoke-virtual {v2, p0}, La/p;->f(Landroid/content/Context;)I

    move-result v2

    invoke-static {p0, v2}, Lcom/brasfoot/v2028/Recopa;->crest(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kk:I

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f060336

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    invoke-virtual {v4}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v4, 0x7f0b0253

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v2, 0x7f060341

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f060034

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityMainTeam$1;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$1;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06000c

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityMainTeam$10;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$10;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private qZ()V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    iget v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kk:I

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v6}, La/p;->a(La/ac;IZZZ)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->px()V

    :cond_0
    return-void
.end method

.method private ra()V
    .locals 4

    const v0, 0x7f060234

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ko:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b0135

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0137

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0133

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0138

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0136

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0134

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcomponents/ak;

    const v2, 0x7f070066

    const/4 v3, 0x0

    invoke-direct {v1, p0, v2, v0, v3}, Lcomponents/ak;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kp:Lcomponents/ak;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ko:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kp:Lcomponents/ak;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ko:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityMainTeam$11;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$11;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    return-void
.end method

.method private rf()V
    .locals 9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ka:I

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->k(La/t;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rp()V

    const v0, 0x7f0601d0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->ma()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sget-boolean v1, Lcom/brasfoot/v2028/MainActivity;->Oa:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v3, 0x7f04004e

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getFilesDir()Ljava/io/File;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v4}, La/ac;->lx()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_1

    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v6}, La/ac;->lx()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ".png"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/drawable/Drawable;->createFromPath(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    check-cast v3, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v3}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v3

    new-instance v4, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-static {v3, v1, v1, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-direct {v4, v5, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v4, v1, v1, v1}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/16 v1, 0x14

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    const v1, 0x7f0602ec

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lz()La/af;

    move-result-object v3

    invoke-virtual {v3}, La/af;->gN()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lz()La/af;

    move-result-object v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lz()La/af;

    move-result-object v1

    invoke-virtual {v1}, La/af;->li()La/ac;

    move-result-object v1

    if-nez v1, :cond_2

    const v1, 0x7f060274

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_2
    const v1, 0x7f060005

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ProgressBar;

    const v3, 0x7f060004

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ProgressBar;

    const v4, 0x7f0602b4

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v6}, La/ac;->lz()La/af;

    move-result-object v6

    invoke-virtual {v6}, La/af;->nb()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "%"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v4, 0x7f0602b2

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v6}, La/ac;->lz()La/af;

    move-result-object v6

    invoke-virtual {v6}, La/af;->na()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "%"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v5}, La/ac;->lz()La/af;

    move-result-object v5

    invoke-virtual {v5}, La/af;->na()I

    move-result v5

    const/4 v6, 0x0

    const/16 v7, 0x63

    if-ge v5, v7, :cond_3

    const/4 v5, 0x1

    goto :goto_0

    :cond_3
    const/4 v5, 0x0

    :goto_0
    and-int/2addr v4, v5

    if-eqz v4, :cond_4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v4}, La/ac;->lz()La/af;

    move-result-object v4

    invoke-virtual {v4, v7}, La/af;->co(I)V

    :cond_4
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v5}, La/ac;->lz()La/af;

    move-result-object v5

    invoke-virtual {v5}, La/af;->nb()I

    move-result v5

    if-ge v5, v7, :cond_5

    const/4 v5, 0x1

    goto :goto_1

    :cond_5
    const/4 v5, 0x0

    :goto_1
    and-int/2addr v4, v5

    if-eqz v4, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v4}, La/ac;->lz()La/af;

    move-result-object v4

    invoke-virtual {v4, v7}, La/af;->cp(I)V

    :cond_6
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v4}, La/ac;->lz()La/af;

    move-result-object v4

    invoke-virtual {v4}, La/af;->na()I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v4}, La/ac;->lz()La/af;

    move-result-object v4

    invoke-virtual {v4}, La/af;->nb()I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-virtual {v1}, Landroid/widget/ProgressBar;->getProgressDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/LayerDrawable;

    const/4 v4, 0x2

    invoke-virtual {v1, v4}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v5}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    sget-object v7, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v1, v5, v7}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v3}, Landroid/widget/ProgressBar;->getProgressDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {v1, v4}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    sget-object v4, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v1, v3, v4}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    const v1, 0x7f0602c5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dn()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602e9

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v3, 0x7f0602ea

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0602d9

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "$"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v7}, La/ac;->lA()J

    move-result-wide v7

    invoke-static {v7, v8}, La/n;->b(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-boolean v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz v5, :cond_7

    const-string v5, ""

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_7
    const-wide v4, 0x3fb999999999999aL    # 0.1

    sput-wide v4, Lcom/brasfoot/v2028/ActivityMainTeam;->Ke:D

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/16 v5, 0x64

    invoke-virtual {v4, v5}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/16 v5, 0x50

    if-le v4, v5, :cond_8

    const-wide v4, 0x3fc3333333333333L    # 0.15

    sput-wide v4, Lcom/brasfoot/v2028/ActivityMainTeam;->Ke:D

    :cond_8
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    if-eqz v4, :cond_c

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v4}, La/t;->ji()La/ac;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-ne v4, v5, :cond_9

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v4}, La/t;->jj()La/ac;

    move-result-object v4

    iput-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    iput v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->pp:I

    goto :goto_2

    :cond_9
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v4}, La/t;->ji()La/ac;

    move-result-object v4

    iput-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    iput v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->pp:I

    :goto_2
    iget v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ka:I

    const/4 v5, 0x7

    if-eq v4, v5, :cond_a

    iget v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ka:I

    const/16 v5, 0x9

    if-ne v4, v5, :cond_b

    :cond_a
    iput-boolean v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kc:Z

    iput-boolean v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    :cond_b
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v4}, La/t;->ko()Z

    move-result v4

    iput-boolean v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JZ:Z

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v4}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v4

    sget-object v5, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {v4, v5}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_c
    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f010002

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v5}, La/t;->jH()La/al;

    move-result-object v5

    if-eqz v5, :cond_f

    const-string v5, ""

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/q;

    if-eqz v6, :cond_d

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    check-cast v6, Ld/q;

    invoke-virtual {v6}, Ld/q;->xO()I

    move-result v6

    if-le v6, v2, :cond_d

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    check-cast v6, Ld/q;

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v6, v7}, Ld/q;->O(La/ac;)I

    move-result v6

    if-lez v6, :cond_d

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " ("

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v6, v4, v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ")"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_d
    const-string v6, ""

    if-eq v5, v6, :cond_e

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v7}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_e
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v0}, La/t;->jU()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    :cond_f
    const-string v0, ""

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, ""

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_3
    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JZ:Z

    if-eqz v0, :cond_10

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v1, 0x7f0b0072

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_10
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    if-eqz v0, :cond_18

    const-string v0, ""

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v1}, La/t;->jH()La/al;

    move-result-object v1

    instance-of v1, v1, Ld/q;

    if-eqz v1, :cond_11

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v1}, La/t;->jH()La/al;

    move-result-object v1

    check-cast v1, Ld/q;

    invoke-virtual {v1}, Ld/q;->xO()I

    move-result v1

    if-le v1, v2, :cond_11

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v1}, La/t;->jH()La/al;

    move-result-object v1

    check-cast v1, Ld/q;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    invoke-virtual {v1, v5}, Ld/q;->O(La/ac;)I

    move-result v1

    if-lez v1, :cond_11

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "("

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v1, v4, v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_11
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b00bc

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " - "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->pp:I

    if-ne v4, v2, :cond_12

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v2, 0x7f0b0023

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " - "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_12
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    if-eqz v2, :cond_13

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v2}, La/t;->jH()La/al;

    move-result-object v2

    instance-of v2, v2, Ld/y;

    if-eqz v2, :cond_13

    const-string v1, ""

    :cond_13
    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz v2, :cond_14

    const-string v1, ""

    :cond_14
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    invoke-static {v1}, Lcom/brasfoot/v2028/Recopa;->formBars(La/ac;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_15

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "  "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_15
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    iget-object v8, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    invoke-static {v7, v8}, Lcom/brasfoot/v2028/Recopa;->h2hStr(La/ac;La/ac;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_16

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_16
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-static {v7}, Lcom/brasfoot/v2028/Recopa;->firstLegLine(La/t;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_17

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_17
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602e8

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    :cond_18
    return-void
.end method

.method private rg()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ks:La/t;

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityEscala;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private rh()V
    .locals 4

    const v0, 0x7f06026d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    new-instance v1, Landroid/view/ContextThemeWrapper;

    const v2, 0x7f0c000f

    invoke-direct {v1, p0, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    new-instance v2, Landroid/widget/PopupMenu;

    invoke-direct {v2, v1, v0}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const v3, 0x7f080002

    invoke-virtual {v0, v3, v1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    new-instance v0, Lcom/brasfoot/v2028/ActivityMainTeam$13;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$13;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {v2, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->show()V

    return-void
.end method

.method private ri()V
    .locals 6

    const v0, 0x7f06026f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    new-instance v1, Landroid/view/ContextThemeWrapper;

    const v2, 0x7f0c000f

    invoke-direct {v1, p0, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    new-instance v2, Landroid/widget/PopupMenu;

    invoke-direct {v2, v1, v0}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const v3, 0x7f080003

    invoke-virtual {v0, v3, v1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 v3, 0x0

    const/16 v4, 0x7777

    const/16 v5, 0x63

    const-string v0, "Idolos"

    invoke-interface {v1, v3, v4, v5, v0}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v4, 0x7778

    const/16 v5, 0x64

    const-string v0, "Recordes"

    invoke-interface {v1, v3, v4, v5, v0}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v4, 0x7779

    const/16 v5, 0x65

    const-string v0, "Loja de Juniores"

    invoke-interface {v1, v3, v4, v5, v0}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    const/16 v4, 0x777a

    const/16 v5, 0x66

    const-string v0, "Jogadores Emprestados"

    invoke-interface {v1, v3, v4, v5, v0}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    new-instance v0, Lcom/brasfoot/v2028/ActivityMainTeam$14;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$14;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {v2, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->show()V

    return-void
.end method

.method private rj()V
    .locals 6

    const v0, 0x7f060271

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    new-instance v1, Landroid/view/ContextThemeWrapper;

    const v2, 0x7f0c000f

    invoke-direct {v1, p0, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    new-instance v2, Landroid/widget/PopupMenu;

    invoke-direct {v2, v1, v0}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const v3, 0x7f080005

    invoke-virtual {v0, v3, v1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 v0, 0x0

    const v3, 0x7777001

    const v4, 0x50000

    const-string v5, "Ranking Selecoes"

    invoke-interface {v1, v0, v3, v4, v5}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    new-instance v0, Lcom/brasfoot/v2028/ActivityMainTeam$15;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$15;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {v2, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->show()V

    return-void
.end method

.method private rk()V
    .locals 4

    const v0, 0x7f060271

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    new-instance v1, Landroid/view/ContextThemeWrapper;

    const v2, 0x7f0c000f

    invoke-direct {v1, p0, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    new-instance v2, Landroid/widget/PopupMenu;

    invoke-direct {v2, v1, v0}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const v3, 0x7f080004

    invoke-virtual {v0, v3, v1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v0

    const v1, 0x7f0601b6

    invoke-interface {v0, v1}, Landroid/view/Menu;->removeItem(I)V

    :cond_0
    new-instance v0, Lcom/brasfoot/v2028/ActivityMainTeam$16;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$16;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {v2, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->show()V

    return-void
.end method

.method private rl()V
    .locals 4

    const v0, 0x7f060275

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    new-instance v1, Landroid/view/ContextThemeWrapper;

    const v2, 0x7f0c000f

    invoke-direct {v1, p0, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    new-instance v2, Landroid/widget/PopupMenu;

    invoke-direct {v2, v1, v0}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const v3, 0x7f080006

    invoke-virtual {v0, v3, v1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    new-instance v0, Lcom/brasfoot/v2028/ActivityMainTeam$17;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityMainTeam$17;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V

    invoke-virtual {v2, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    invoke-virtual {v2}, Landroid/widget/PopupMenu;->show()V

    return-void
.end method

.method private rm()V
    .locals 2

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/DialogA;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private rn()V
    .locals 2

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivitySub;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private ro()V
    .locals 7

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, La/b;->ag(I)Ljava/util/ArrayList;

    move-result-object v0

    sput-object v0, La/o;->pT:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0xa

    if-ge v1, v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->mc()La/af;

    move-result-object v3

    new-instance v4, Lcomponents/be;

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    const/4 v6, 0x2

    invoke-direct {v4, v5, v2, v3, v6}, Lcomponents/be;-><init>(La/ac;La/af;La/af;I)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    sput-object v0, La/o;->pT:Ljava/util/ArrayList;

    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    sget-object v0, La/o;->pT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/DialogDemissoes;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    :cond_1
    return-void
.end method

.method private rp()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ka:I

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    invoke-virtual {v3}, La/t;->jH()La/al;

    move-result-object v3

    invoke-virtual {v2, v3}, La/p;->f(La/al;)I

    move-result v2

    invoke-virtual {v1, v2}, La/p;->bi(I)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private rq()V
    .locals 3

    const/4 v0, 0x0

    sput-object v0, La/o;->pR:Ljava/util/ArrayList;

    sput-object v0, La/o;->pU:La/af;

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lz()La/af;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, La/b;->b(La/af;Z)Ljava/util/ArrayList;

    move-result-object v0

    sput-object v0, La/o;->pR:Ljava/util/ArrayList;

    sget-object v0, La/o;->pR:Ljava/util/ArrayList;

    if-eqz v0, :cond_2

    sget-object v0, La/o;->pR:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/af;

    invoke-virtual {v1}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    sput-object v0, La/o;->pU:La/af;

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityConvite;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    :cond_2
    return-void
.end method

.method private rr()V
    .locals 5

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v2, 0x7f07002e

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setContentView(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    new-array v1, v1, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v1, v4

    const v3, 0x7f0b01a6

    invoke-virtual {v2, v3, v1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f0600a6

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityMainTeam$2;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$2;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityMainTeam$3;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$3;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private rs()V
    .locals 3

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0b01a5

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityMainTeam$4;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$4;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityMainTeam$5;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$5;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private rt()V
    .locals 5

    sget-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sput-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    :cond_0
    sget-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/af;->li()La/ac;

    move-result-object v0

    if-eqz v0, :cond_3

    sget-object v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0}, La/af;->li()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0}, La/b;->al(I)La/y;

    move-result-object v0

    sget-object v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kt:La/ac;

    invoke-virtual {v1}, La/ac;->lz()La/af;

    move-result-object v1

    invoke-virtual {v0}, La/y;->kS()La/af;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, La/af;->v(La/ac;)V

    invoke-virtual {v0}, La/y;->li()La/ac;

    move-result-object v1

    invoke-virtual {v1, v3}, La/ac;->e(La/af;)V

    invoke-virtual {v0}, La/y;->li()La/ac;

    move-result-object v1

    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v1, v4}, La/ac;->j(Ljava/lang/Boolean;)V

    if-eqz v2, :cond_1

    invoke-virtual {v0, v2}, La/y;->c(La/af;)V

    :cond_1
    invoke-virtual {v0, v3}, La/y;->N(Z)V

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz v0, :cond_2

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    if-nez v0, :cond_2

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, La/b;->n(Z)V

    invoke-static {}, La/o;->hv()V

    return-void

    :cond_2
    const v0, 0x7f060274

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void

    :cond_3
    return-void
.end method

.method private ru()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mc()La/af;

    move-result-object v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b0118

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->n(Z)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b0113

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-static {}, La/o;->hv()V

    return-void
.end method

.method private rx()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b00bc

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->pp:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b0023

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-virtual {v2}, La/af;->gN()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lest/InfoArquivoSalvoType;->setTc(Ljava/lang/String;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lest/InfoArquivoSalvoType;->setN(Ljava/lang/String;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->db()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Lest/InfoArquivoSalvoType;->setA(Ljava/lang/Integer;)V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->JY:La/ac;

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lest/InfoArquivoSalvoType;->setI(Ljava/lang/String;)V

    :cond_1
    return-void
.end method


# virtual methods
.method public D(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityMainTeam$6;

    invoke-direct {v1, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$6;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityMainTeam$7;

    invoke-direct {v1, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$7;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public ae(Z)Z
    .locals 10

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lQ()I

    move-result v2

    if-gtz v2, :cond_0

    return v1

    :cond_0
    if-nez p1, :cond_3

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    goto :goto_3

    :cond_3
    const/4 v2, 0x0

    :goto_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_5

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_5
    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    goto :goto_1

    :goto_3
    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_6

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, La/p;

    :cond_6
    const/4 v0, 0x1

    if-eqz v3, :cond_a

    new-instance v2, La/f;

    invoke-virtual {v3}, La/p;->hI()I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    move-object v4, v2

    move-object v5, v3

    invoke-direct/range {v4 .. v9}, La/f;-><init>(La/p;IZZI)V

    invoke-virtual {v2, v0}, La/f;->x(Z)La/ac;

    move-result-object v2

    const-wide v4, 0x3fd3333333333333L    # 0.3

    invoke-virtual {v3}, La/p;->getIdade()I

    move-result v6

    const/16 v7, 0x14

    if-ge v6, v7, :cond_7

    const-wide/high16 v4, 0x3fe0000000000000L    # 0.5

    goto :goto_4

    :cond_7
    invoke-virtual {v3}, La/p;->getIdade()I

    move-result v6

    const/16 v7, 0x19

    if-ge v6, v7, :cond_8

    const-wide v4, 0x3fd6666666666666L    # 0.35

    :cond_8
    :goto_4
    invoke-virtual {v3}, La/p;->hI()I

    move-result v6

    int-to-long v6, v6

    invoke-virtual {v3}, La/p;->hI()I

    move-result v8

    int-to-double v8, v8

    mul-double v8, v8, v4

    invoke-static {v8, v9}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    add-long v8, v6, v4

    long-to-int v4, v8

    if-eqz v2, :cond_a

    int-to-long v5, v4

    invoke-static {v5, v6}, La/n;->b(J)Ljava/lang/String;

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    iput-object v3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    if-eqz p1, :cond_9

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v4, 0x7f0b0214

    invoke-virtual {p1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    new-array v5, v4, [Ljava/lang/Object;

    invoke-virtual {v2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v5, v1

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v5, v0

    invoke-static {p1, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v4}, Lcom/brasfoot/v2028/ActivityMainTeam;->e(Ljava/lang/String;I)V

    return v0

    :cond_9
    iput v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kk:I

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->qY()V

    :cond_a
    return v0
.end method

.method public dd(I)V
    .locals 6

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    if-eqz p1, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kk:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, La/p;->a(La/ac;IZZZ)V

    :cond_0
    :goto_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->px()V

    return-void

    :cond_1
    const/4 v0, 0x2

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    invoke-virtual {p1, v0}, La/p;->l(La/ac;)V

    goto :goto_0

    :cond_2
    return-void
.end method

.method public ddLoan(La/p;La/ac;)V
    .locals 2

    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "EMPDIAG emprestou="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " para="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->flog(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, La/p;->l(La/ac;)V

    :cond_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->px()V

    return-void
.end method

.method public e(Ljava/lang/String;I)V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    if-eqz v0, :cond_1

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->isOnLoan(La/p;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, La/p;->getPendSaleClub()La/ac;

    move-result-object v1

    if-eqz v1, :cond_1

    :cond_0
    return-void

    :cond_1
    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityMainTeam$8;

    move-object v2, p0

    move v3, p2

    move-object v4, v0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    invoke-direct/range {v1 .. v6}, Lcom/brasfoot/v2028/ActivityMainTeam$8;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;ILandroid/app/Dialog;La/p;La/ac;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance p2, Lcom/brasfoot/v2028/ActivityMainTeam$9;

    invoke-direct {p2, p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam$9;-><init>(Lcom/brasfoot/v2028/ActivityMainTeam;Landroid/app/Dialog;)V

    invoke-virtual {p1, p2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public onBackPressed()V
    .locals 0

    return-void
.end method

.method public onClick1(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rg()V

    return-void
.end method

.method public onClick2(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rh()V

    return-void
.end method

.method public onClick3(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->ri()V

    return-void
.end method

.method public onClick4(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rj()V

    return-void
.end method

.method public onClick5(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rk()V

    return-void
.end method

.method public onClick6(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rl()V

    return-void
.end method

.method public onClickAgenda(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityAgenda;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickHist(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityHist;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickJornal(Landroid/view/View;)V
    .locals 2

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityJornal;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickTec(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object p1

    sput-object p1, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    sget-object p1, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    if-eqz p1, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityTecnico;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onClickTime(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {p1}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityTeamHistory;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070019

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->finish()V

    :cond_0
    :goto_0
    sput-object p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kq:Lcom/brasfoot/v2028/ActivityMainTeam;

    const p1, 0x7f06026b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ku:Landroid/widget/ImageButton;

    const p1, 0x7f06026d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kv:Landroid/widget/ImageButton;

    const p1, 0x7f06026f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kw:Landroid/widget/ImageButton;

    const p1, 0x7f060271

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kx:Landroid/widget/ImageButton;

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dI()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->eB()La/t;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kf:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0}, La/af;->li()La/ac;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-ne v0, v1, :cond_1

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kf:Z

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    if-nez v0, :cond_6

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_6

    const/4 v0, 0x0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dd()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v0

    :cond_2
    if-eqz v0, :cond_6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_6

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->lE()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-nez v1, :cond_3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    :goto_2
    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    :cond_3
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/t;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    goto :goto_3

    :cond_4
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->lE()Z

    move-result v1

    if-nez v1, :cond_5

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-nez v1, :cond_3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    goto :goto_2

    :cond_5
    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_6
    :goto_3
    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-eqz p1, :cond_7

    const p1, 0x7f06026e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->nx:La/t;

    if-eqz p1, :cond_9

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-nez p1, :cond_8

    goto :goto_4

    :cond_8
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rf()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->px()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rx()V

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_a

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rb()V

    goto :goto_5

    :cond_9
    :goto_4
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->finish()V

    invoke-static {}, La/o;->hv()V

    :cond_a
    :goto_5
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->ra()V

    return-void
.end method

.method protected onResume()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkMarket(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkUnhappy(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkSponsor(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkReneg(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkLicense(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->checkClassico(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->maybePress(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->showChem(Landroid/app/Activity;)V

    return-void
.end method

.method protected onStart()V
    .locals 5

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->ensureWorldBest()V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->resetAllAwardsOnce()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->maybeAskMeta(Landroid/app/Activity;)V

    const/high16 v0, 0x4000000

    :try_start_0
    sget-object v1, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v1, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->finish()V

    :cond_0
    :goto_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eQ()Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eQ()Z

    move-result v2

    const/4 v3, 0x0

    if-nez v2, :cond_3

    sget-boolean v2, Lcom/brasfoot/v2028/ActivityMainTeam;->Kn:Z

    if-nez v2, :cond_3

    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kb:Z

    if-nez v2, :cond_4

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/16 v4, 0x3c

    invoke-virtual {v2, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    if-ne v2, v1, :cond_1

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityMainTeam;->ae(Z)Z

    goto :goto_1

    :cond_1
    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/4 v4, 0x2

    invoke-virtual {v2, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    if-ne v2, v1, :cond_2

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityMainTeam;->ae(Z)Z

    :cond_2
    :goto_1
    sput-boolean v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kn:Z

    goto :goto_2

    :cond_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2, v3}, La/b;->p(Z)V

    :cond_4
    :goto_2
    sget-boolean v2, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    if-eqz v2, :cond_5

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->px()V

    sput-boolean v3, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    :cond_5
    sget-boolean v2, Lcom/brasfoot/v2028/ActivityMainTeam;->Km:Z

    if-eqz v2, :cond_6

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rf()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->px()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rx()V

    sput-boolean v3, Lcom/brasfoot/v2028/ActivityMainTeam;->Km:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->re()V

    if-eqz v0, :cond_6

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rd()V

    :cond_6
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_9

    sget-object v0, Lc/a;->TF:La/b;

    iget-boolean v0, v0, La/b;->nJ:Z

    if-eqz v0, :cond_7

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kd:Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v3}, La/b;->q(Z)V

    :cond_7
    sget-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kd:Z

    if-eqz v0, :cond_8

    sput-boolean v3, Lcom/brasfoot/v2028/ActivityMainTeam;->Kd:Z

    :cond_8
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->rg()V

    :cond_9
    return-void
.end method

.method public rb()V
    .locals 10

    const-string v0, "abriu_rate"

    invoke-static {p0, v0}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const-string v1, "nvezes_rate"

    invoke-static {p0, v1}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    const-string v2, "shbffile"

    const/4 v3, 0x0

    invoke-virtual {p0, v2, v3}, Lcom/brasfoot/v2028/ActivityMainTeam;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "dateLaunch"

    const-wide/16 v6, 0x0

    invoke-interface {v2, v5, v6, v7}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->commit()Z

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const-wide/32 v6, 0x14997000

    add-long v8, v4, v6

    const/4 v2, 0x1

    if-eq v0, v2, :cond_1

    const/4 v0, 0x5

    if-lt v1, v0, :cond_0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    cmp-long v2, v0, v8

    if-ltz v2, :cond_1

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityDialogRate;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    const-string v0, "nvezes_rate"

    invoke-static {p0, v0, v3}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    return-void

    :cond_0
    add-int/2addr v1, v2

    const-string v0, "nvezes_rate"

    invoke-static {p0, v0, v1}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    :cond_1
    return-void
.end method

.method public rc()V
    .locals 6

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-static {v0}, Ld/a;->I(La/ac;)Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->isBot()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    const/16 v3, 0x1d

    invoke-virtual {v2, v3}, La/b;->ah(I)La/y;

    move-result-object v2

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-eq v4, v2, :cond_0

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static {v4, v2, v3, v5}, Ld/a;->b(La/ac;La/ac;II)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public rcShowOffer(La/p;La/ac;I)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Ki:La/p;

    iput-object p2, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kj:La/ac;

    iput p3, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kk:I

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->qY()V

    return-void
.end method

.method public rd()V
    .locals 5

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAutoSalvar()I

    move-result v0

    if-lez v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAutoSalvar()I

    move-result v0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v3, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    iget v0, v0, La/b;->nG:I

    if-lt v0, v1, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    iput v2, v0, La/b;->nG:I

    :goto_0
    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    iget v1, v0, La/b;->nG:I

    add-int/2addr v1, v3

    iput v1, v0, La/b;->nG:I

    goto :goto_1

    :cond_1
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAutoSalvar()I

    move-result v0

    const/4 v4, 0x2

    if-ne v0, v4, :cond_2

    goto :goto_0

    :cond_2
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAutoSalvar()I

    move-result v0

    if-ne v0, v1, :cond_3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eR()Z

    move-result v0

    if-eqz v0, :cond_3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v2}, La/b;->q(Z)V

    goto :goto_0

    :cond_3
    :goto_1
    if-eqz v2, :cond_4

    sput-boolean v3, Lcom/brasfoot/v2028/ActivitySave;->LT:Z

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivitySave;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    :cond_4
    return-void
.end method

.method public re()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isAutoRenovaContrato()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityMainTeam;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->iT()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public rv()V
    .locals 1

    const v0, 0x7f0b0025

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->D(Ljava/lang/String;)V

    return-void
.end method

.method public rw()V
    .locals 2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityMainTeam;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityMainTeam;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
