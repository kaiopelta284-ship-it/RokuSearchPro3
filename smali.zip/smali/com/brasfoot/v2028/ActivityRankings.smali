.class public Lcom/brasfoot/v2028/ActivityRankings;
.super Landroid/app/Activity;


# static fields
.field public static Lt:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/cc;",
            ">;"
        }
    .end annotation
.end field

.field public static Lu:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/cc;",
            ">;"
        }
    .end annotation
.end field

.field public static selMode:Z


# instance fields
.field GA:Landroid/widget/Button;

.field GB:Landroid/widget/Button;

.field Gz:Landroid/widget/Button;

.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Hc:Landroid/widget/ListView;

.field Hj:Landroid/widget/Spinner;

.field private Ln:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private Lo:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cc;",
            ">;"
        }
    .end annotation
.end field

.field Lp:Lcomponents/d;

.field private Lq:I

.field private Lr:I

.field Ls:Landroid/widget/TextView;

.field lU:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$6;

    invoke-direct {v0}, Lcom/brasfoot/v2028/ActivityRankings$6;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/ActivityRankings;->Lt:Ljava/util/Comparator;

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$7;

    invoke-direct {v0}, Lcom/brasfoot/v2028/ActivityRankings$7;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/ActivityRankings;->Lu:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ha:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hb:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lq:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lr:I

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityRankings;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityRankings;->rI()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityRankings;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->cK(I)V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityRankings;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityRankings;->rJ()V

    return-void
.end method

.method private cK(I)V
    .locals 4

    const v0, 0x7f030010

    const v1, 0x7f030013

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    const/4 p1, 0x0

    iput p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    goto :goto_1

    :cond_0
    const/4 v2, 0x1

    if-ne p1, v2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GB:Landroid/widget/Button;

    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iput v2, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    goto :goto_1

    :cond_1
    const/4 v2, 0x2

    if-ne p1, v2, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityRankings;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GA:Landroid/widget/Button;

    goto :goto_0

    :cond_2
    :goto_1
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityRankings;->rJ()V

    return-void
.end method

.method private rI()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lp:Lcomponents/d;

    invoke-virtual {v0}, Lcomponents/d;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lp:Lcomponents/d;

    invoke-virtual {v1}, Lcomponents/d;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cc;

    invoke-virtual {v0}, Lcomponents/cc;->hE()La/ac;

    move-result-object v0

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityTeamHistory;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityRankings;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method private rJ()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    sget-boolean v0, Lcom/brasfoot/v2028/ActivityRankings;->selMode:Z

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->selFor(La/y;)La/ac;

    move-result-object v2

    if-eqz v2, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v2, 0x1

    goto/16 :goto_3

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lez v0, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    sub-int/2addr v0, v2

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    invoke-virtual {v0}, La/y;->kK()I

    move-result v0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lr:I

    const/4 v0, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_5

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    iget v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lr:I

    if-ne v3, v4, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_4
    const/4 v0, 0x0

    :goto_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_5

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_5
    :goto_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x2

    if-ge v1, v0, :cond_b

    new-instance v0, Lcomponents/cc;

    invoke-direct {v0}, Lcomponents/cc;-><init>()V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v0, v4}, Lcomponents/cc;->i(La/ac;)V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    invoke-virtual {v0, v4}, Lcomponents/cc;->W(I)V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-nez v4, :cond_7

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    sget-boolean v4, Lcom/brasfoot/v2028/ActivityRankings;->selMode:Z

    if-eqz v4, :cond_6

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->selecaoPoints(La/ac;)I

    move-result v3

    goto :goto_4

    :cond_6
    invoke-virtual {v3}, La/ac;->mr()I

    move-result v3

    :goto_4
    invoke-virtual {v0, v3}, Lcomponents/cc;->dO(I)V

    goto :goto_6

    :cond_7
    iget v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-ne v4, v2, :cond_9

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    sget-boolean v4, Lcom/brasfoot/v2028/ActivityRankings;->selMode:Z

    if-eqz v4, :cond_8

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->selVED(La/ac;)[I

    move-result-object v3

    goto :goto_5

    :cond_8
    invoke-virtual {v3}, La/ac;->mu()[I

    move-result-object v3

    :goto_5
    invoke-virtual {v0, v3}, Lcomponents/cc;->m([I)V

    goto :goto_6

    :cond_9
    iget v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-ne v4, v3, :cond_a

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ln:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->getReputacao()I

    move-result v3

    goto :goto_4

    :cond_a
    :goto_6
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_b
    iget v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-ne v0, v2, :cond_c

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    sget-object v1, Lcom/brasfoot/v2028/ActivityRankings;->Lu:Ljava/util/Comparator;

    :goto_7
    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    goto :goto_8

    :cond_c
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    sget-object v1, Lcom/brasfoot/v2028/ActivityRankings;->Lt:Ljava/util/Comparator;

    goto :goto_7

    :goto_8
    iget v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-nez v0, :cond_d

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ls:Landroid/widget/TextView;

    const v1, 0x7f0b0176

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityRankings;->getString(I)Ljava/lang/String;

    move-result-object v1

    :goto_9
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_a

    :cond_d
    iget v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-ne v0, v2, :cond_e

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ls:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v2, 0x7f0b0016

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityRankings;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v2, 0x7f0b0013

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityRankings;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v2, 0x7f0b0012

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityRankings;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_9

    :cond_e
    iget v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->lU:I

    if-ne v0, v3, :cond_f

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ls:Landroid/widget/TextView;

    const v1, 0x7f0b0250

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    :cond_f
    :goto_a
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lp:Lcomponents/d;

    invoke-virtual {v0}, Lcomponents/d;->notifyDataSetChanged()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07001f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->setContentView(I)V

    const p1, 0x7f060254

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hj:Landroid/widget/Spinner;

    const p1, 0x7f060215

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ls:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hb:Ljava/util/ArrayList;

    const v0, 0x7f0b00d9

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityRankings;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ha:Ljava/util/ArrayList;

    const/4 v0, -0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    :goto_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hb:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kX()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ha:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1, p0}, La/y;->f(Landroid/content/Context;)I

    move-result v1

    invoke-static {p0, v1}, Lcom/brasfoot/v2028/Recopa;->crest(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hj:Landroid/widget/Spinner;

    new-instance v6, Lcomponents/aw;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hb:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityRankings;->Ha:Ljava/util/ArrayList;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {p1, v6}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    const p1, 0x7f060053

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Gz:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Gz:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityRankings$1;-><init>(Lcom/brasfoot/v2028/ActivityRankings;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060054

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GA:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GA:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityRankings$2;-><init>(Lcom/brasfoot/v2028/ActivityRankings;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060055

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GB:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->GB:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityRankings$3;-><init>(Lcom/brasfoot/v2028/ActivityRankings;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0601a5

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hc:Landroid/widget/ListView;

    new-instance p1, Lcomponents/d;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lo:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/d;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lp:Lcomponents/d;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hc:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Lp:Lcomponents/d;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hc:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityRankings$4;-><init>(Lcom/brasfoot/v2028/ActivityRankings;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityRankings;->cK(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hj:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityRankings$5;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityRankings$5;-><init>(Lcom/brasfoot/v2028/ActivityRankings;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    sget-boolean v0, Lcom/brasfoot/v2028/ActivityRankings;->selMode:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityRankings;->Hj:Landroid/widget/Spinner;

    const/16 p1, 0x8

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    return-void
.end method
