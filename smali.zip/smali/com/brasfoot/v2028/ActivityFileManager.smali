.class public Lcom/brasfoot/v2028/ActivityFileManager;
.super Landroid/app/Activity;


# instance fields
.field IM:I

.field IN:I

.field IO:Landroid/widget/TextView;

.field IP:Landroid/widget/TextView;

.field IQ:Landroid/widget/TextView;

.field IR:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IN:I

    return-void
.end method

.method private a(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .locals 3

    const/16 v0, 0x400

    new-array v0, v0, [B

    :goto_0
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_0

    const/4 v2, 0x0

    invoke-virtual {p2, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private ai(II)I
    .locals 8

    const-string v0, "/TeamsAndroid"

    const-string v1, "TeamsAndroid"

    const-string v2, ""

    const/4 v3, 0x1

    if-ne p2, v3, :cond_0

    const-string v0, "/Escudos"

    const-string v1, "Escudos"

    const-string v2, ".png"

    :cond_0
    const/4 p2, 0x0

    iput p2, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFileManager;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    if-ne p1, v3, :cond_2

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object p1

    const-string v4, "mounted"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    :cond_2
    :goto_0
    array-length p1, v0

    const/4 v1, 0x0

    :goto_1
    if-ge v1, p1, :cond_4

    aget-object v4, v0, v1

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3

    const/4 v5, 0x0

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    :try_start_0
    new-instance v7, Ljava/io/FileInputStream;

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v7, v4}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v5, v7

    goto :goto_2

    :catch_0
    move-exception v4

    invoke-virtual {v4}, Ljava/io/IOException;->printStackTrace()V

    :goto_2
    if-eqz v5, :cond_3

    :try_start_1
    invoke-virtual {p0, v6, p2}, Lcom/brasfoot/v2028/ActivityFileManager;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v4

    invoke-direct {p0, v5, v4}, Lcom/brasfoot/v2028/ActivityFileManager;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    invoke-virtual {v4}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    add-int/2addr v4, v3

    iput v4, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    move-exception v4

    invoke-virtual {v4}, Ljava/io/IOException;->printStackTrace()V

    :cond_3
    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_4
    iget p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    return p1
.end method

.method private cR(I)I
    .locals 9

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IN:I

    const-string v1, ""

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IR:Ljava/lang/String;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFileManager;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IR:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v1

    const/4 v2, 0x1

    if-ne p1, v2, :cond_1

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object p1

    const-string v3, "mounted"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "TeamsAndroid"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v1

    :cond_1
    :goto_0
    array-length p1, v1

    :goto_1
    if-ge v0, p1, :cond_3

    aget-object v3, v1, v0

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, ""

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    :try_start_0
    new-instance v6, Ljava/io/FileInputStream;

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v6, v3}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v3

    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    move-object v6, v5

    :goto_2
    if-eqz v6, :cond_2

    :try_start_1
    new-instance v3, Ljava/io/File;

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityFileManager;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "TeamsAndroid/"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v5, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-direct {p0, v6, v4}, Lcom/brasfoot/v2028/ActivityFileManager;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    invoke-virtual {v4}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    iget v3, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IN:I

    add-int/2addr v3, v2

    iput v3, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IN:I
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    move-exception v3

    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    :cond_2
    :goto_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    iget p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    return p1
.end method


# virtual methods
.method public onClickCopy(Landroid/view/View;)V
    .locals 4

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityFileManager;->cR(I)I

    const v0, 0x7f0602fe

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFileManager;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IP:Landroid/widget/TextView;

    iget v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IN:I

    if-lez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFileManager;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0b023c

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    iget v3, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IN:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, p1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IP:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0602ff

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFileManager;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IQ:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IQ:Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IR:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/AndroidTeams"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IP:Landroid/widget/TextView;

    const v0, 0x7f0b00be

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    return-void
.end method

.method public onClickSelEscudos(Landroid/view/View;)V
    .locals 5

    const p1, 0x7f060300

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFileManager;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IO:Landroid/widget/TextView;

    const/4 p1, 0x0

    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityFileManager;->ai(II)I

    iget v1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    if-lez v1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFileManager;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0b023d

    new-array v3, v0, [Ljava/lang/Object;

    iget v4, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, p1

    invoke-virtual {v1, v2, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IO:Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IO:Landroid/widget/TextView;

    const v0, 0x7f0b00bf

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    return-void
.end method

.method public onClickSelFolder(Landroid/view/View;)V
    .locals 5

    const p1, 0x7f0602fd

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFileManager;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IO:Landroid/widget/TextView;

    const/4 p1, 0x0

    invoke-direct {p0, p1, p1}, Lcom/brasfoot/v2028/ActivityFileManager;->ai(II)I

    iget v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    if-lez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFileManager;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0b023b

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Object;

    iget v4, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IM:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, p1

    invoke-virtual {v0, v1, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IO:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sput-boolean v2, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFileManager;->IO:Landroid/widget/TextView;

    const v0, 0x7f0b00bd

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070011

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFileManager;->setContentView(I)V

    new-instance p1, Ljava/io/File;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFileManager;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const-string v1, "TeamsAndroid"

    invoke-direct {p1, v0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Ljava/io/File;->mkdir()Z

    :cond_0
    return-void
.end method
