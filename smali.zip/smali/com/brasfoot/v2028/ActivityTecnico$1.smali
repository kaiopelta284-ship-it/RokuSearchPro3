.class Lcom/brasfoot/v2028/ActivityTecnico$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityTecnico;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic MC:Lcom/brasfoot/v2028/ActivityTecnico;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityTecnico;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico$1;->MC:Lcom/brasfoot/v2028/ActivityTecnico;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico$1;->MC:Lcom/brasfoot/v2028/ActivityTecnico;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->a(Lcom/brasfoot/v2028/ActivityTecnico;I)V

    return-void
.end method
