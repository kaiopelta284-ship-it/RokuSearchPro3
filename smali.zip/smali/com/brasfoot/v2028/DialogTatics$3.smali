.class Lcom/brasfoot/v2028/DialogTatics$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogTatics;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic NJ:Lcom/brasfoot/v2028/DialogTatics;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogTatics;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics$3;->NJ:Lcom/brasfoot/v2028/DialogTatics;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics$3;->NJ:Lcom/brasfoot/v2028/DialogTatics;

    const-string v0, "bEscanteios"

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTatics$3;->NJ:Lcom/brasfoot/v2028/DialogTatics;

    iget-object v1, v1, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v1}, La/ac;->mF()La/p;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/brasfoot/v2028/DialogTatics;->a(Lcom/brasfoot/v2028/DialogTatics;Ljava/lang/String;La/p;)V

    return-void
.end method
