.class Lcom/brasfoot/v2028/ActivityPenalty$4;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityPenalty;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Lb:Lcom/brasfoot/v2028/ActivityPenalty;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityPenalty;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$4;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$4;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityPenalty;->b(Lcom/brasfoot/v2028/ActivityPenalty;)V

    return-void
.end method
