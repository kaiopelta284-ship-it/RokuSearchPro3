.class public Lcom/brasfoot/v2028/ActivityPref;
.super Landroid/app/Activity;


# instance fields
.field private Lc:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public af(Z)V
    .locals 4

    const v0, 0x7f060071

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const v1, 0x7f060072

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/RadioButton;

    const v2, 0x7f060073

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RadioButton;

    invoke-virtual {v0, p1}, Landroid/widget/RadioButton;->setEnabled(Z)V

    invoke-virtual {v1, p1}, Landroid/widget/RadioButton;->setEnabled(Z)V

    invoke-virtual {v2, p1}, Landroid/widget/RadioButton;->setEnabled(Z)V

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v3, 0x7f030010

    :goto_0
    invoke-virtual {p1, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/RadioButton;->setTextColor(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    invoke-virtual {v1, p1}, Landroid/widget/RadioButton;->setTextColor(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    invoke-virtual {v2, p1}, Landroid/widget/RadioButton;->setTextColor(I)V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v3, 0x7f030013

    goto :goto_0

    return-void
.end method

.method public onBackPressed()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->rE()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->finish()V

    return-void
.end method

.method public onClickFechar(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07001c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->setContentView(I)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->addTransferbanPref(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->addExtCompPref(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->addFinRealistaPref(Landroid/app/Activity;)V

    const p1, 0x7f060225

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/SeekBar;

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->getVelocidade()I

    move-result v0

    rsub-int v0, v0, 0x76d

    invoke-virtual {p1, v0}, Landroid/widget/SeekBar;->setProgress(I)V

    const p1, 0x7f060266

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVerJanelaSubs()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    invoke-virtual {p1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {p1, v1}, Landroid/widget/Switch;->setChecked(Z)V

    :goto_0
    const p1, 0x7f060267

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getVerMudancaTecnicos()I

    move-result v0

    if-ne v0, v2, :cond_1

    invoke-virtual {p1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    goto :goto_1

    :cond_1
    invoke-virtual {p1, v1}, Landroid/widget/Switch;->setChecked(Z)V

    :goto_1
    const p1, 0x7f060264

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isAutoRenovaContrato()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    const p1, 0x7f060269

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isUsaSons()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    const p1, 0x7f060414

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isEnergiaReal()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    const p1, 0x7f060265

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    const-string v0, "indCorLista"

    invoke-static {p0, v0}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityPref;->Lc:I

    const-string v0, "indCorLista"

    invoke-static {p0, v0}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const/4 v3, -0x1

    if-ne v0, v3, :cond_2

    invoke-virtual {p1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    goto :goto_2

    :cond_2
    invoke-virtual {p1, v1}, Landroid/widget/Switch;->setChecked(Z)V

    :goto_2
    const p1, 0x7f060268

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    new-instance v0, Lcom/brasfoot/v2028/ActivityPref$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityPref$1;-><init>(Lcom/brasfoot/v2028/ActivityPref;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->getAutoSalvar()I

    move-result v0

    if-lez v0, :cond_6

    invoke-virtual {p1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object p1

    invoke-virtual {p1}, Lest/Options;->getAutoSalvar()I

    move-result p1

    if-ne p1, v2, :cond_3

    const p1, 0x7f060071

    :goto_3
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    invoke-virtual {p1, v2}, Landroid/widget/RadioButton;->setChecked(Z)V

    goto :goto_4

    :cond_3
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object p1

    invoke-virtual {p1}, Lest/Options;->getAutoSalvar()I

    move-result p1

    const/4 v0, 0x2

    if-ne p1, v0, :cond_4

    const p1, 0x7f060072

    goto :goto_3

    :cond_4
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object p1

    invoke-virtual {p1}, Lest/Options;->getAutoSalvar()I

    move-result p1

    const/4 v0, 0x3

    if-ne p1, v0, :cond_5

    const p1, 0x7f060073

    goto :goto_3

    :cond_5
    :goto_4
    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityPref;->af(Z)V

    goto :goto_5

    :goto_5
    const p1, 0x7f060347

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isDonoDoTime()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    const p1, 0x7f060348

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isModoBilionario()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v0, Lcom/brasfoot/v2028/ActivityPref$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityPref$2;-><init>(Lcom/brasfoot/v2028/ActivityPref;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    return-void

    :cond_6
    invoke-virtual {p1, v1}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityPref;->af(Z)V

    goto :goto_5
.end method

.method public rE()V
    .locals 6

    const v0, 0x7f060225

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/SeekBar;

    invoke-virtual {v0}, Landroid/widget/SeekBar;->getProgress()I

    move-result v0

    if-ltz v0, :cond_0

    const/16 v1, 0x76c

    if-gt v0, v1, :cond_0

    sub-int/2addr v1, v0

    add-int/lit8 v1, v1, 0x1

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v1}, Lest/Options;->setVelocidade(I)V

    :cond_0
    const v0, 0x7f060266

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v2}, Lest/Options;->setVerJanelaSubs(I)V

    goto :goto_0

    :cond_1
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v1}, Lest/Options;->setVerJanelaSubs(I)V

    :goto_0
    const v0, 0x7f060267

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v2}, Lest/Options;->setVerMudancaTecnicos(I)V

    goto :goto_1

    :cond_2
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v1}, Lest/Options;->setVerMudancaTecnicos(I)V

    :goto_1
    const v0, 0x7f060264

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v3

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    invoke-virtual {v3, v0}, Lest/Options;->setAutoRenovaContrato(Z)V

    const v0, 0x7f060269

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v3

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    invoke-virtual {v3, v0}, Lest/Options;->setUsaSons(Z)V

    const v0, 0x7f060414

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v3

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    invoke-virtual {v3, v0}, Lest/Options;->setEnergiaReal(Z)V

    const v0, 0x7f060265

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const-string v0, "indCorLista"

    const/4 v4, -0x1

    invoke-static {p0, v0, v4}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    goto :goto_2

    :cond_3
    const-string v0, "indCorLista"

    invoke-static {p0, v0, v3}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    :goto_2
    const-string v0, "indCorLista"

    invoke-static {p0, v0}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    iget v4, p0, Lcom/brasfoot/v2028/ActivityPref;->Lc:I

    if-eq v0, v4, :cond_4

    sput-boolean v2, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    :cond_4
    const v0, 0x7f060268

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_7

    const v0, 0x7f060071

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const v4, 0x7f060072

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/RadioButton;

    const v5, 0x7f060073

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v2}, Lest/Options;->setAutoSalvar(I)V

    goto :goto_4

    :cond_5
    invoke-virtual {v4}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, v3}, Lest/Options;->setAutoSalvar(I)V

    goto :goto_4

    :cond_6
    invoke-virtual {v5}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    const/4 v1, 0x3

    goto :goto_3

    :cond_7
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    :goto_3
    invoke-virtual {v0, v1}, Lest/Options;->setAutoSalvar(I)V

    :goto_4
    const v0, 0x7f060347

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v3

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    invoke-virtual {v3, v0}, Lest/Options;->setDonoDoTime(Z)V

    const v0, 0x7f060348

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPref;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v2

    invoke-virtual {v0}, Landroid/widget/Switch;->isChecked()Z

    move-result v0

    invoke-virtual {v2, v0}, Lest/Options;->setModoBilionario(Z)V

    if-eqz v0, :cond_8

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object v2

    if-nez v2, :cond_8

    const-wide/32 v0, 0x3b9aca00

    invoke-virtual {v2, v0, v1}, La/ac;->d(J)V

    :cond_8
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->rF()Z

    return-void
.end method

.method public rF()Z
    .locals 3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPref;->getFilesDir()Ljava/io/File;

    const-string v0, "options.bcf"

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityPref;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v0

    new-instance v1, Ljava/io/ObjectOutputStream;

    invoke-direct {v1, v0}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    :goto_0
    const/4 v0, 0x1

    return v0
.end method
