.class public Lcom/brasfoot/v2028/ActivityCampeoes;
.super Landroid/app/Activity;


# instance fields
.field private Cc:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private FH:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/c;",
            ">;"
        }
    .end annotation
.end field

.field FI:Lcomponents/g;

.field Fo:Landroid/widget/Spinner;

.field Fp:Landroid/widget/Spinner;

.field private Fq:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field private Fr:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field Fs:Landroid/widget/ListView;

.field Fv:Landroid/widget/Spinner;

.field Fw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fx:Lcomponents/ai;

.field Fy:Z

.field Fz:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Cc:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FH:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fw:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fz:I

    return-void
.end method

.method private d(La/y;)V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b007d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b0075

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0077

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b0079

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const v1, 0x7f0b007b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fw:Ljava/util/ArrayList;

    add-int/lit8 v1, v1, 0x1

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    new-instance p1, Lcomponents/ai;

    const v0, 0x7f070066

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fw:Ljava/util/ArrayList;

    invoke-direct {p1, p0, v0, v1}, Lcomponents/ai;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fx:Lcomponents/ai;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fx:Lcomponents/ai;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityCampeoes$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityCampeoes$4;-><init>(Lcom/brasfoot/v2028/ActivityCampeoes;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fz:I

    const/4 v0, -0x1

    if-le p1, v0, :cond_1

    iget p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fz:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    if-gt p1, v1, :cond_1

    iget v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fz:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fz:I

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pj()V
    .locals 8

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v0

    if-eqz v0, :cond_a

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v0

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->jb()La/al;

    move-result-object v1

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_0
    if-eqz v1, :cond_1

    invoke-virtual {v1}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_1
    const/4 v3, -0x1

    :goto_0
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v4, :cond_4

    const/4 v4, 0x3

    if-ne v3, v4, :cond_4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v4, v5}, Landroid/widget/Spinner;->setSelection(I)V

    const/4 v4, 0x0

    :goto_1
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_4

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/bu;

    invoke-virtual {v7}, Lcomponents/bu;->uR()La/al;

    move-result-object v7

    if-eq v7, v0, :cond_3

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/bu;

    invoke-virtual {v7}, Lcomponents/bu;->uR()La/al;

    move-result-object v7

    if-ne v7, v1, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v7, v4}, Landroid/widget/Spinner;->setSelection(I)V

    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    :cond_4
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    if-nez v4, :cond_7

    if-ne v3, v6, :cond_7

    const/4 v3, 0x0

    :goto_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_7

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    if-eqz v4, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    invoke-virtual {v4}, La/y;->kC()I

    move-result v4

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v7

    if-ne v4, v7, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v4, v3}, Landroid/widget/Spinner;->setSelection(I)V

    if-eqz v2, :cond_5

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v3

    if-lez v3, :cond_5

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v2

    sub-int/2addr v2, v6

    iput v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fz:I

    :cond_5
    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    goto :goto_4

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_7
    :goto_4
    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    if-nez v2, :cond_a

    :goto_5
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v5, v2, :cond_a

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    if-eq v2, v0, :cond_9

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    if-ne v2, v1, :cond_8

    goto :goto_6

    :cond_8
    add-int/lit8 v5, v5, 0x1

    goto :goto_5

    :cond_9
    :goto_6
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v0, v5}, Landroid/widget/Spinner;->setSelection(I)V

    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    :cond_a
    return-void
.end method


# virtual methods
.method public ac(Z)V
    .locals 9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->uR()La/al;

    move-result-object v0

    move-object v8, v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v4, 0x8

    if-ne v1, v3, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v1, v4}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setVisibility(I)V

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uS()La/y;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityCampeoes;->d(La/y;)V

    goto :goto_1

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    const/4 v1, -0x1

    if-le p1, v1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uS()La/y;

    move-result-object p1

    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/al;

    move-object v8, v0

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, La/al;->cG()I

    move-result p1

    const/4 v1, 0x3

    if-ne p1, v1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uR()La/al;

    move-result-object v0

    move-object v8, v0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    invoke-virtual {p1, v2}, Landroid/widget/Spinner;->setVisibility(I)V

    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1, v4}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_1

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    invoke-virtual {p1, v4}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_0

    :cond_3
    :goto_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FH:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Cc:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v3

    :goto_2
    if-ltz p1, :cond_5

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FH:Ljava/util/ArrayList;

    invoke-virtual {v0}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, La/al;->oc()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_4

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Cc:Ljava/util/ArrayList;

    invoke-virtual {v0}, La/al;->oc()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 p1, p1, -0x1

    goto :goto_2

    :cond_5
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FI:Lcomponents/g;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Cc:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Lcomponents/g;->V(Ljava/util/ArrayList;)V

    invoke-virtual {p1}, Lcomponents/g;->notifyDataSetChanged()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070004

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityCampeoes;->setContentView(I)V

    new-instance p1, Lcomponents/bu;

    invoke-direct {p1}, Lcomponents/bu;-><init>()V

    const/4 v0, 0x1

    invoke-virtual {p1, p0, v0, v0}, Lcomponents/bu;->a(Landroid/content/Context;IZ)Ljava/util/ArrayList;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    const v1, 0x7f06022a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fv:Landroid/widget/Spinner;

    const v1, 0x7f060252

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCampeoes;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    new-instance v2, Lcomponents/k;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fq:Ljava/util/ArrayList;

    const/4 v4, 0x0

    invoke-direct {v2, p0, v4, v3}, Lcomponents/k;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fo:Landroid/widget/Spinner;

    new-instance v2, Lcom/brasfoot/v2028/ActivityCampeoes$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivityCampeoes$1;-><init>(Lcom/brasfoot/v2028/ActivityCampeoes;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-virtual {p1, p0}, Lcomponents/bu;->k(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->Rq:Ljava/util/Comparator;

    invoke-static {p1, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const p1, 0x7f060230

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityCampeoes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/k;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fr:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v0, v2}, Lcomponents/k;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fp:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityCampeoes$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityCampeoes$2;-><init>(Lcom/brasfoot/v2028/ActivityCampeoes;)V

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const p1, 0x7f060179

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityCampeoes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fs:Landroid/widget/ListView;

    new-instance p1, Lcomponents/g;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FH:Ljava/util/ArrayList;

    invoke-direct {p1, v1, p0, p0}, Lcomponents/g;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FI:Lcomponents/g;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fs:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->FI:Lcomponents/g;

    invoke-virtual {p1, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fs:Landroid/widget/ListView;

    new-instance v1, Lcom/brasfoot/v2028/ActivityCampeoes$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityCampeoes$3;-><init>(Lcom/brasfoot/v2028/ActivityCampeoes;)V

    invoke-virtual {p1, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityCampeoes;->pj()V

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityCampeoes;->Fy:Z

    if-nez p1, :cond_0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityCampeoes;->ac(Z)V

    :cond_0
    return-void
.end method
