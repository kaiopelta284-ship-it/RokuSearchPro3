.class public Lcom/brasfoot/v2028/ActivityEditorTeam;
.super Landroid/app/Activity;


# instance fields
.field HA:Landroid/widget/EditText;

.field HB:Landroid/widget/EditText;

.field HC:Landroid/widget/EditText;

.field HD:Landroid/widget/Spinner;

.field HE:Landroid/widget/Spinner;

.field HF:Landroid/widget/Spinner;

.field HG:Landroid/widget/Spinner;

.field HH:Landroid/widget/Spinner;

.field HI:Landroid/widget/TextView;

.field HJ:Landroid/widget/TextView;

.field HK:Le/t;

.field HL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field HM:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field HN:I

.field HO:I

.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Ht:Z

.field Hy:Landroid/widget/EditText;

.field Hz:Landroid/widget/EditText;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ht:Z

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HN:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HO:I

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityEditorTeam;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->pV()V

    return-void
.end method

.method private pS()Z
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/16 v1, 0x63

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const v0, 0x7f0b0096

    :goto_0
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ge v0, v2, :cond_1

    const v0, 0x7f0b0098

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v1, :cond_2

    const v0, 0x7f0b0097

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, ""

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    const v0, 0x7f0b0087

    goto :goto_0

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ge v0, v2, :cond_4

    const v0, 0x7f0b0089

    goto :goto_0

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v1, :cond_5

    const v0, 0x7f0b0088

    goto :goto_0

    :cond_5
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, ""

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    const v0, 0x7f0b0093

    goto/16 :goto_0

    :cond_6
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ge v0, v2, :cond_7

    const v0, 0x7f0b0095

    goto/16 :goto_0

    :cond_7
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v1, :cond_8

    const v0, 0x7f0b0094

    goto/16 :goto_0

    :cond_8
    const/4 v0, 0x0

    :goto_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HB:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const v5, 0x7f0b0092

    const/4 v6, 0x0

    if-nez v4, :cond_9

    const-string v4, "\\d+"

    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_9

    :try_start_0
    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    const/4 v3, 0x0

    :goto_2
    const/16 v4, 0x3e8

    if-lt v3, v4, :cond_9

    const v4, 0x1d4c0

    if-le v3, v4, :cond_a

    :cond_9
    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v0

    :cond_a
    iget-boolean v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ht:Z

    if-eqz v3, :cond_d

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HC:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_b

    const v0, 0x7f0b008a

    :goto_3
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_4

    :cond_b
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HC:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v3, v2, :cond_c

    const v0, 0x7f0b008c

    goto :goto_3

    :cond_c
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HC:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-le v2, v1, :cond_d

    const v0, 0x7f0b008b

    goto :goto_3

    :cond_d
    :goto_4
    const/4 v1, 0x1

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return v1

    :cond_e
    const/4 v1, 0x0

    return v1
.end method

.method private pV()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-static {v0}, La/g;->aB(I)I

    move-result v0

    const v1, 0x7f06022f

    const/16 v2, 0x1d

    if-eq v0, v2, :cond_0

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const/16 v1, 0x8

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    return-void

    :cond_0
    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const/4 v1, 0x0

    goto :goto_0

    return-void
.end method

.method private pW()V
    .locals 4

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    const/4 v2, 0x1

    :goto_0
    const/16 v3, 0x1a

    if-ge v2, v3, :cond_0

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance v2, Landroid/widget/ArrayAdapter;

    const v3, 0x1090008

    invoke-direct {v2, p0, v3, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v2, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HF:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HF:Landroid/widget/Spinner;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v2}, Le/t;->getNivel()I

    move-result v2

    sub-int/2addr v2, v1

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pX()V
    .locals 34

    move-object/from16 v6, p0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v7, "AC"

    const-string v8, "AL"

    const-string v9, "AM"

    const-string v10, "AP"

    const-string v11, "BA"

    const-string v12, "CE"

    const-string v13, "DF"

    const-string v14, "ES"

    const-string v15, "GO"

    const-string v16, "MA"

    const-string v17, "MG"

    const-string v18, "MS"

    const-string v19, "MT"

    const-string v20, "PA"

    const-string v21, "PB"

    const-string v22, "PE"

    const-string v23, "PI"

    const-string v24, "PR"

    const-string v25, "RJ"

    const-string v26, "RN"

    const-string v27, "RO"

    const-string v28, "RR"

    const-string v29, "RS"

    const-string v30, "SC"

    const-string v31, "SE"

    const-string v32, "SP"

    const-string v33, "TO"

    filled-new-array/range {v7 .. v33}, [Ljava/lang/String;

    move-result-object v7

    const/4 v1, 0x0

    :goto_0
    array-length v2, v7

    if-ge v1, v2, :cond_0

    aget-object v2, v7, v1

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HM:Ljava/util/ArrayList;

    aget-object v3, v7, v1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HL:Ljava/util/ArrayList;

    invoke-virtual {v6, v6, v1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->c(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v8, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    new-instance v9, Lcomponents/aw;

    const v2, 0x7f070066

    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HM:Ljava/util/ArrayList;

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HL:Ljava/util/ArrayList;

    const/4 v5, 0x0

    move-object v0, v9

    move-object v1, v6

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {v8, v9}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getEstado()I

    move-result v0

    if-ltz v0, :cond_1

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getEstado()I

    move-result v0

    array-length v1, v7

    if-ge v0, v1, :cond_1

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v1}, Le/t;->getEstado()I

    move-result v1

    goto :goto_1

    :cond_1
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    const/16 v1, 0x19

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pY()V
    .locals 4

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x6

    new-array v1, v1, [Ljava/lang/String;

    const v2, 0x7f0b019f

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const v2, 0x7f0b01a0

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    aput-object v2, v1, v3

    const v2, 0x7f0b01a1

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    aput-object v2, v1, v3

    const v2, 0x7f0b01a2

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x3

    aput-object v2, v1, v3

    const v2, 0x7f0b01a3

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x4

    aput-object v2, v1, v3

    const v2, 0x7f0b01a4

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditorTeam;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x5

    aput-object v2, v1, v3

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HG:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HG:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v1}, Le/t;->getReputacao()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method


# virtual methods
.method public ad(II)V
    .locals 1

    const/4 v0, 0x1

    if-ne p2, v0, :cond_0

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HN:I

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HI:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HI:Landroid/widget/TextView;

    :goto_0
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-void

    :cond_0
    iput p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HO:I

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HJ:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HJ:Landroid/widget/TextView;

    goto :goto_0

    return-void
.end method

.method public ae(II)V
    .locals 2

    new-instance v0, Lcomponents/bg;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEditorTeam$2;

    invoke-direct {v1, p0, p2}, Lcom/brasfoot/v2028/ActivityEditorTeam$2;-><init>(Lcom/brasfoot/v2028/ActivityEditorTeam;I)V

    invoke-direct {v0, p0, p1, v1}, Lcomponents/bg;-><init>(Landroid/content/Context;ILcomponents/bg$a;)V

    invoke-virtual {v0}, Lcomponents/bg;->show()V

    return-void
.end method

.method public c(Landroid/content/Context;I)I
    .locals 3

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "flage_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string v1, "drawable"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p2, v1, p1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public clickCancel(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->finish()V

    return-void
.end method

.method public onClickCorF(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1}, Le/t;->getCorF()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v0, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->ae(II)V

    return-void
.end method

.method public onClickCorT(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1}, Le/t;->getCorT()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->ae(II)V

    return-void
.end method

.method public onClickSave(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->pS()Z

    move-result p1

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->pT()Z

    move-result p1

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Hr:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->finish()V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070031

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->setContentView(I)V

    sget-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    iput-boolean p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ht:Z

    sget-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1}, Le/t;->getReputacao()I

    move-result p1

    const/4 v0, 0x5

    if-le p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1, v0}, Le/t;->setReputacao(I)V

    :cond_0
    const p1, 0x7f0600b8

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HC:Landroid/widget/EditText;

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ht:Z

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HC:Landroid/widget/EditText;

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setVisibility(I)V

    const p1, 0x7f06031a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getFileRef()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_0
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ha:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hb:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HL:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HM:Ljava/util/ArrayList;

    const p1, 0x7f0600bd

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0600bf

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getTecnico()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0600c0

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getEstadio()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0600bc

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HB:Landroid/widget/EditText;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HB:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getCapacidade()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    :goto_1
    invoke-static {}, La/z;->lj()I

    move-result v0

    if-ge p1, v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hb:Ljava/util/ArrayList;

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bz;

    invoke-virtual {v1}, Lcomponents/bz;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ha:Ljava/util/ArrayList;

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bz;

    invoke-virtual {v1, p0}, Lcomponents/bz;->f(Landroid/content/Context;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_2
    const p1, 0x7f060250

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    new-instance v6, Lcomponents/aw;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hb:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ha:Ljava/util/ArrayList;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {p1, v6}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getPais()I

    move-result v0

    invoke-static {v0}, La/g;->aA(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityEditorTeam$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityEditorTeam$1;-><init>(Lcom/brasfoot/v2028/ActivityEditorTeam;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const p1, 0x7f060251

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HE:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HE:Landroid/widget/Spinner;

    new-instance v6, Lcomponents/aw;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hb:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ha:Ljava/util/ArrayList;

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {p1, v6}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HE:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getTecNac()I

    move-result v0

    invoke-static {v0}, La/g;->aA(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    const p1, 0x7f060243

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HF:Landroid/widget/Spinner;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->pW()V

    const p1, 0x7f06024f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HG:Landroid/widget/Spinner;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->pY()V

    const p1, 0x7f06022e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->pX()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1}, Le/t;->getPais()I

    move-result p1

    const/16 v0, 0x1d

    if-eq p1, v0, :cond_3

    const p1, 0x7f06022f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setVisibility(I)V

    :cond_3
    const p1, 0x7f0602f9

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HI:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HI:Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getCorT()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackgroundColor(I)V

    const p1, 0x7f0602f8

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditorTeam;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HJ:Landroid/widget/TextView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HJ:Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0}, Le/t;->getCorF()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1}, Le/t;->getCorT()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HN:I

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {p1}, Le/t;->getCorF()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HO:I

    return-void
.end method

.method public pT()Z
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v1}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hy:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Le/t;->setNome(Ljava/lang/String;)V

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getTecnico()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Hz:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Le/t;->setTecnico(Ljava/lang/String;)V

    const/4 v0, 0x1

    :cond_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getEstadio()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HA:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Le/t;->setEstadio(Ljava/lang/String;)V

    const/4 v0, 0x1

    :cond_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HB:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3

    const-string v4, "\\d+"

    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/16 v4, 0x3e8

    if-lt v3, v4, :cond_3

    const v4, 0x1d4c0

    if-gt v3, v4, :cond_3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getCapacidade()I

    move-result v4

    if-eq v3, v4, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v0, v3}, Le/t;->setCapacidade(I)V

    const/4 v0, 0x1

    :cond_3
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getPais()I

    move-result v4

    invoke-static {v4}, La/g;->aA(I)I

    move-result v4

    if-eq v3, v4, :cond_4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-static {v3}, La/g;->aB(I)I

    move-result v3

    if-ltz v3, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HD:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-static {v3}, La/g;->aB(I)I

    move-result v3

    invoke-virtual {v0, v3}, Le/t;->setPais(I)V

    const/4 v0, 0x1

    :cond_4
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HE:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getTecNac()I

    move-result v4

    invoke-static {v4}, La/g;->aA(I)I

    move-result v4

    if-eq v3, v4, :cond_5

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HE:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-static {v3}, La/g;->aB(I)I

    move-result v3

    if-ltz v3, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HE:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-static {v3}, La/g;->aB(I)I

    move-result v3

    invoke-virtual {v0, v3}, Le/t;->setTecNac(I)V

    const/4 v0, 0x1

    :cond_5
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HF:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getNivel()I

    move-result v4

    add-int/2addr v4, v2

    if-eq v3, v4, :cond_6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HF:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/2addr v3, v2

    invoke-virtual {v0, v3}, Le/t;->setNivel(I)V

    const/4 v0, 0x1

    :cond_6
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HG:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getReputacao()I

    move-result v4

    if-eq v3, v4, :cond_7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HG:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v0, v3}, Le/t;->setReputacao(I)V

    const/4 v0, 0x1

    :cond_7
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v3}, Le/t;->getPais()I

    move-result v3

    const/16 v4, 0x1d

    if-ne v3, v4, :cond_8

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v4}, Le/t;->getEstado()I

    move-result v4

    if-eq v3, v4, :cond_8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HH:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v0, v3}, Le/t;->setEstado(I)V

    const/4 v0, 0x1

    :cond_8
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v3}, Le/t;->getCorT()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    iget v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HN:I

    const v5, 0xffffff

    if-eq v3, v4, :cond_9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    const-string v3, "#%06X"

    new-array v4, v2, [Ljava/lang/Object;

    iget v6, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HN:I

    and-int/2addr v6, v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Le/t;->setCor2(Ljava/lang/String;)V

    const/4 v0, 0x1

    :cond_9
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    invoke-virtual {v3}, Le/t;->getCorF()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    iget v4, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HO:I

    if-eq v3, v4, :cond_a

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HK:Le/t;

    const-string v3, "#%06X"

    new-array v4, v2, [Ljava/lang/Object;

    iget v6, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HO:I

    and-int/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Le/t;->setCor1(Ljava/lang/String;)V

    const/4 v0, 0x1

    :cond_a
    iget-boolean v1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->Ht:Z

    if-eqz v1, :cond_b

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam;->HC:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hu:Ljava/lang/String;

    const/4 v0, 0x1

    :cond_b
    return v0
.end method
