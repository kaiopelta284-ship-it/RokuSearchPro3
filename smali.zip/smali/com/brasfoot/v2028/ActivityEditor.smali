.class public Lcom/brasfoot/v2028/ActivityEditor;
.super Landroid/app/Activity;


# static fields
.field public static Hq:Le/t; = null

.field public static Hr:Z = false

.field public static Hs:Z = false

.field public static Ht:Z = false

.field public static Hu:Ljava/lang/String; = ""

.field public static Hv:[[I

.field public static Hw:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Le/g;",
            ">;"
        }
    .end annotation
.end field

.field public static Hz:I


# instance fields
.field FD:Landroid/widget/ListView;

.field GH:Landroid/widget/Spinner;

.field GI:Landroid/widget/Spinner;

.field GY:Lcomponents/p;

.field GZ:Lcomponents/o;

.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Hc:Landroid/widget/ListView;

.field Hd:Le/t;

.field He:Le/g;

.field Hf:Z

.field Hg:Landroid/widget/ViewFlipper;

.field Hh:Landroid/widget/EditText;

.field Hi:Landroid/widget/Spinner;

.field Hj:Landroid/widget/Spinner;

.field Hk:Landroid/widget/Spinner;

.field Hl:Landroid/widget/Spinner;

.field Hm:Landroid/widget/CheckBox;

.field Hn:Landroid/widget/CheckBox;

.field Ho:Landroid/widget/CheckBox;

.field Hp:Lcomponents/cg;

.field oN:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cg;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/16 v0, 0xdd

    const/4 v1, 0x1

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const-class v1, I

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[I

    sput-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    new-instance v0, Lcom/brasfoot/v2028/ActivityEditor$4;

    invoke-direct {v0}, Lcom/brasfoot/v2028/ActivityEditor$4;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hw:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hf:Z

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityEditor;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pQ()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityEditor;IZ)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/brasfoot/v2028/ActivityEditor;->e(IZ)V

    return-void
.end method

.method public static ac(II)V
    .locals 2

    sget-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    array-length v0, v0

    if-le v0, p0, :cond_0

    sget-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    aget-object v0, v0, p0

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    aget-object p0, v1, p0

    const/4 v1, 0x0

    aget p0, p0, v1

    add-int/2addr p0, p1

    aput p0, v0, v1

    :cond_0
    return-void
.end method

.method private b(Le/t;)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_1

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Le/g;

    invoke-virtual {v4}, Le/g;->getPosicao()I

    move-result v4

    if-nez v4, :cond_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    if-lt v2, v1, :cond_2

    const/16 v2, 0xb

    if-lt v3, v2, :cond_2

    invoke-virtual {p1, v1}, Le/t;->setValid(Z)V

    return-void

    :cond_2
    invoke-virtual {p1, v0}, Le/t;->setValid(Z)V

    return-void
.end method

.method private e(IZ)V
    .locals 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f010006

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_1

    aget-object v5, v1, v4

    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    :goto_1
    array-length v5, v1

    if-ge v4, v5, :cond_1

    aget-object v5, v1, v4

    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    new-instance v1, Landroid/widget/ArrayAdapter;

    const v4, 0x1090008

    invoke-direct {v1, p0, v4, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v5, 0x1090009

    invoke-virtual {v1, v5}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {v6, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    new-instance v1, Landroid/widget/ArrayAdapter;

    invoke-direct {v1, p0, v4, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    invoke-virtual {v1, v5}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    if-eqz p2, :cond_6

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    if-eqz p2, :cond_6

    const/4 p2, 0x2

    if-nez p1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {p1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {p1, p2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void

    :cond_2
    const/4 v0, 0x1

    const/4 v1, 0x3

    if-ne p1, v0, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    :goto_2
    invoke-virtual {p1, p2}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void

    :cond_3
    const/16 v0, 0x9

    if-ne p1, p2, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setSelection(I)V

    :goto_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    return-void

    :cond_4
    if-ne p1, v1, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    const/4 p2, 0x7

    goto :goto_2

    :cond_5
    if-ne p1, v3, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    const/4 p2, 0x5

    invoke-virtual {p1, p2}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_3

    :cond_6
    return-void
.end method

.method private pC()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x5

    new-array v1, v1, [Ljava/lang/String;

    const v2, 0x7f0b0183

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const v2, 0x7f0b0188

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const v2, 0x7f0b0181

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    aput-object v2, v1, v4

    const v2, 0x7f0b0185

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    aput-object v2, v1, v4

    const v2, 0x7f0b0180

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    aput-object v2, v1, v4

    :goto_0
    array-length v2, v1

    if-ge v3, v2, :cond_0

    aget-object v2, v1, v3

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GH:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method private pD()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01c5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b01c3

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GI:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method private pN()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v1, 0x10

    :goto_0
    const/16 v2, 0x2a

    if-ge v1, v2, :cond_0

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hi:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method private pO()V
    .locals 8

    const/4 v0, 0x1

    const/16 v1, 0xdd

    filled-new-array {v1, v0}, [I

    move-result-object v1

    const-class v2, I

    invoke-static {v2, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [[I

    sput-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    move-result v0

    :cond_0
    if-eqz v1, :cond_2

    if-eqz v0, :cond_2

    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, ".ban"

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    const/4 v4, 0x0

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    :try_start_0
    new-instance v7, Ljava/io/FileInputStream;

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v7, v3}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v4, v7

    goto :goto_1

    :catch_0
    move-exception v3

    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    :goto_1
    invoke-virtual {p0, v4, v6, v5}, Lcom/brasfoot/v2028/ActivityEditor;->a(Ljava/io/InputStream;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->Ro:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0}, Lcomponents/p;->notifyDataSetChanged()V

    return-void
.end method

.method private pQ()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0}, Lcomponents/p;->th()I

    move-result v0

    if-ltz v0, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/cg;

    invoke-virtual {v1}, Lcomponents/cg;->vt()Le/t;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    sput-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cg;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {v1}, Lcomponents/cg;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0}, Lcomponents/p;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0, v2}, Lcomponents/p;->dm(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hc:Landroid/widget/ListView;

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hc:Landroid/widget/ListView;

    invoke-virtual {v0, v2, v2}, Landroid/widget/ListView;->scrollTo(II)V

    :cond_1
    return-void
.end method

.method private pR()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1}, Le/g;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1}, Le/g;->getPais()I

    move-result v1

    invoke-static {v1}, La/g;->aA(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0}, Le/g;->getIdade()I

    move-result v0

    const/16 v1, 0x2b

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hi:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1}, Le/g;->getIdade()I

    move-result v1

    add-int/lit8 v1, v1, -0x10

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GH:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1}, Le/g;->getPosicao()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GI:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1}, Le/g;->getLado()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0}, Le/g;->getPosicao()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_1

    invoke-direct {p0, v2, v2}, Lcom/brasfoot/v2028/ActivityEditor;->e(IZ)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getCr1()I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getCr2()I

    move-result v3

    :goto_0
    invoke-virtual {v0, v3}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_1

    :cond_1
    invoke-direct {p0, v1, v2}, Lcom/brasfoot/v2028/ActivityEditor;->e(IZ)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getCr1()I

    move-result v3

    add-int/lit8 v3, v3, -0x4

    invoke-virtual {v0, v3}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getCr2()I

    move-result v3

    add-int/lit8 v3, v3, -0x4

    goto :goto_0

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0}, Le/g;->isEstrela()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hm:Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_2

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hm:Landroid/widget/CheckBox;

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :goto_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0}, Le/g;->isTopMundial()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hn:Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_3

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hn:Landroid/widget/CheckBox;

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :goto_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0}, Le/g;->getStatus()I

    move-result v0

    if-nez v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ho:Landroid/widget/CheckBox;

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_4

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ho:Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    :goto_4
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void
.end method

.method private pS()Z
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, 0x7f0b008d

    :goto_0
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    if-ge v0, v1, :cond_1

    const v0, 0x7f0b008f

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x63

    if-le v0, v1, :cond_2

    const v0, 0x7f0b008e

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_1
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hn:Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isSelected()Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v1}, Le/t;->getReputacao()I

    move-result v1

    const/4 v2, 0x4

    if-ge v1, v2, :cond_3

    const v0, 0x7f0b0090

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v0

    :cond_3
    const/4 v1, 0x1

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return v1

    :cond_4
    const/4 v1, 0x0

    return v1
.end method

.method private pU()V
    .locals 4

    const v0, 0x7f0b0175

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    const v0, 0x7f0b0148

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const v1, 0x7f0602fa

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v3}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v3}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getCorT()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getCorF()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-void
.end method


# virtual methods
.method public D(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEditor$5;

    invoke-direct {v1, p0, v0}, Lcom/brasfoot/v2028/ActivityEditor$5;-><init>(Lcom/brasfoot/v2028/ActivityEditor;Landroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEditor$6;

    invoke-direct {v1, p0, v0}, Lcom/brasfoot/v2028/ActivityEditor$6;-><init>(Lcom/brasfoot/v2028/ActivityEditor;Landroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public a(Ljava/io/InputStream;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    new-instance v0, Le/t;

    invoke-direct {v0}, Le/t;-><init>()V

    :try_start_0
    new-instance v0, Ljava/io/ObjectInputStream;

    invoke-direct {v0, p1}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le/t;

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {p1}, Le/t;->getVid()I

    move-result v0

    const/16 v1, 0xb9

    if-ne v0, v1, :cond_0

    new-instance v0, Lcomponents/cg;

    invoke-direct {v0}, Lcomponents/cg;-><init>()V

    invoke-virtual {p1}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcomponents/cg;->setNome(Ljava/lang/String;)V

    invoke-virtual {p1}, Le/t;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, Lcomponents/cg;->setPais(I)V

    invoke-virtual {p1}, Le/t;->getNivel()I

    move-result v1

    invoke-virtual {v0, v1}, Lcomponents/cg;->setNivel(I)V

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    invoke-virtual {p1}, Le/t;->getPais()I

    move-result v2

    aget-object v1, v1, v2

    const/4 v2, 0x0

    aget v3, v1, v2

    add-int/lit8 v3, v3, 0x1

    aput v3, v1, v2

    invoke-virtual {v0, p2}, Lcomponents/cg;->ak(Ljava/lang/String;)V

    invoke-virtual {v0, p3}, Lcomponents/cg;->setPath(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Lcomponents/cg;->c(Le/t;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    return-void

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    return-void
.end method

.method public clickCanceleJ(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void
.end method

.method public onBackPressed()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    invoke-virtual {v0}, Landroid/widget/ViewFlipper;->getDisplayedChild()I

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->startActivity(Landroid/content/Intent;)V

    return-void

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    invoke-virtual {v0}, Landroid/widget/ViewFlipper;->getDisplayedChild()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    invoke-virtual {v0}, Landroid/widget/ViewFlipper;->getDisplayedChild()I

    move-result v0

    const/4 v2, 0x2

    if-ne v0, v2, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    goto :goto_0

    :cond_2
    return-void
.end method

.method public onClickAddT(Landroid/view/View;)V
    .locals 2

    const/4 p1, 0x0

    sput-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/4 v0, 0x0

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityEditor;->Hr:Z

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    sput-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hu:Ljava/lang/String;

    new-instance p1, Le/t;

    invoke-direct {p1}, Le/t;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/4 v0, 0x3

    invoke-virtual {p1, v0}, Le/t;->setReputacao(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/16 v0, 0xf

    invoke-virtual {p1, v0}, Le/t;->setNivel(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const-string v0, "#ffffff"

    invoke-virtual {p1, v0}, Le/t;->setCor1(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const-string v0, "#00281f"

    invoke-virtual {p1, v0}, Le/t;->setCor2(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/16 v0, 0x4e20

    invoke-virtual {p1, v0}, Le/t;->setCapacidade(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/16 v0, 0x1d

    invoke-virtual {p1, v0}, Le/t;->setPais(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1, v0}, Le/t;->setTecNac(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/16 v1, 0xb9

    invoke-virtual {p1, v1}, Le/t;->setVid(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    sput-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    new-instance p1, Lcomponents/cg;

    invoke-direct {p1}, Lcomponents/cg;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {p1, v0}, Lcomponents/cg;->setPais(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1, v0}, Lcomponents/cg;->c(Le/t;)V

    sget-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    if-eqz p1, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityEditorTeam;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onClickCopy(Landroid/view/View;)V
    .locals 1

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityFileManager;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickDelJog(Landroid/view/View;)V
    .locals 1

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {p1}, Lcomponents/o;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {p1}, Lcomponents/o;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {v0}, Lcomponents/o;->th()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le/g;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    invoke-virtual {p1}, Landroid/widget/ListView;->clearChoices()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {p1}, Lcomponents/o;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    invoke-virtual {p1}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pP()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pU()V

    :cond_0
    return-void
.end method

.method public onClickDelT(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {p1}, Lcomponents/p;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cg;

    invoke-virtual {v0}, Lcomponents/cg;->vt()Le/t;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/cg;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0b0071

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v2}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->D(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public onClickEJog(Landroid/view/View;)V
    .locals 1

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hf:Z

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {p1}, Lcomponents/o;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {p1}, Lcomponents/o;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {v0}, Lcomponents/o;->th()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le/g;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pR()V

    :cond_0
    return-void
.end method

.method public onClickEdit(Landroid/view/View;)V
    .locals 1

    const/4 p1, 0x0

    sput-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Hr:Z

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {p1}, Lcomponents/p;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cg;

    invoke-virtual {v0}, Lcomponents/cg;->vt()Le/t;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    sput-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/cg;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    :cond_0
    sget-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    if-eqz p1, :cond_1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityEditorTeam;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->startActivity(Landroid/content/Intent;)V

    :cond_1
    return-void
.end method

.method public onClickEditListaJog(Landroid/view/View;)V
    .locals 2

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    sput-object p1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Hr:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0}, Lcomponents/p;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/cg;

    invoke-virtual {v1}, Lcomponents/cg;->vt()Le/t;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    sput-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cg;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hw:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    new-instance v0, Lcomponents/o;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v1

    invoke-direct {v0, v1, p0, p0}, Lcomponents/o;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pU()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {v0}, Lcomponents/o;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {v0, p1}, Lcomponents/o;->dm(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    invoke-virtual {v0, p1}, Landroid/widget/ListView;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v0}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le/g;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    :cond_1
    return-void
.end method

.method public onClickInstall(Landroid/view/View;)V
    .locals 1

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityInstall;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickSaveJ(Landroid/view/View;)V
    .locals 1

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pS()Z

    move-result p1

    if-nez p1, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pT()Z

    move-result p1

    if-eqz p1, :cond_1

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hf:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/16 v0, 0x34

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hw:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GZ:Lcomponents/o;

    invoke-virtual {p1}, Lcomponents/o;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    invoke-virtual {p1}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pP()V

    :cond_1
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pU()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    :cond_2
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07000c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->setContentView(I)V

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ha:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hb:Ljava/util/ArrayList;

    const v0, 0x7f0600e3

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ViewFlipper;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hg:Landroid/widget/ViewFlipper;

    const v0, 0x7f0601a0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hc:Landroid/widget/ListView;

    const v0, 0x7f06019f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->FD:Landroid/widget/ListView;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEditor$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEditor$1;-><init>(Lcom/brasfoot/v2028/ActivityEditor;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const v0, 0x7f0600bb

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    const v0, 0x7f06024e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GH:Landroid/widget/Spinner;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pC()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GH:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEditor$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEditor$2;-><init>(Lcom/brasfoot/v2028/ActivityEditor;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const v0, 0x7f06024d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    :goto_0
    invoke-static {}, La/z;->lj()I

    move-result v1

    if-ge p1, v1, :cond_1

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hb:Ljava/util/ArrayList;

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bz;

    invoke-virtual {v2}, Lcomponents/bz;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ha:Ljava/util/ArrayList;

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bz;

    invoke-virtual {v2, p0}, Lcomponents/bz;->f(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    new-instance v6, Lcomponents/aw;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hb:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ha:Ljava/util/ArrayList;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {p1, v6}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    const p1, 0x7f060255

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GI:Landroid/widget/Spinner;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pD()V

    const p1, 0x7f06023f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hi:Landroid/widget/Spinner;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pN()V

    const p1, 0x7f060240

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    const p1, 0x7f060241

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    const p1, 0x7f060075

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hm:Landroid/widget/CheckBox;

    const p1, 0x7f060076

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hn:Landroid/widget/CheckBox;

    const p1, 0x7f06007c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditor;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ho:Landroid/widget/CheckBox;

    new-instance p1, Ljava/io/File;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const-string v2, "TeamsAndroid"

    invoke-direct {p1, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_2

    :try_start_0
    invoke-virtual {p1}, Ljava/io/File;->mkdir()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    new-instance p1, Ljava/io/File;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditor;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const-string v1, "Escudos"

    invoke-direct {p1, v0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_3

    :try_start_1
    invoke-virtual {p1}, Ljava/io/File;->mkdir()Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pM()V

    return-void
.end method

.method protected onStart()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    check-cast v0, Lcom/brasfoot/v2028/MainActivity;

    iget-object v0, v0, Lcom/brasfoot/v2028/MainActivity;->JP:Lcom/brasfoot/v2028/b;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    check-cast v0, Lcom/brasfoot/v2028/MainActivity;

    iget-object v0, v0, Lcom/brasfoot/v2028/MainActivity;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/brasfoot/v2028/MainActivity;->Cy:Landroid/app/Activity;

    check-cast v0, Lcom/brasfoot/v2028/MainActivity;

    iget-object v0, v0, Lcom/brasfoot/v2028/MainActivity;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->dismiss()V

    :cond_0
    sget-boolean v0, Lcom/brasfoot/v2028/ActivityEditor;->Hr:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityEditor;->Hr:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pP()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0}, Lcomponents/p;->notifyDataSetChanged()V

    :cond_1
    sget-boolean v0, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    if-eqz v0, :cond_2

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityEditor;->Hs:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->finish()V

    :cond_2
    return-void
.end method

.method public oncliCkaddJog(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {p1}, Le/t;->getJogadores()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v0, 0x1

    const/16 v1, 0x34

    if-lt p1, v1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b0156

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditor;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hf:Z

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    new-instance v1, Le/g;

    invoke-direct {v1}, Le/g;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v2}, Le/t;->getPais()I

    move-result v2

    invoke-virtual {v1, v2}, Le/g;->setPais(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    const/16 v2, 0x14

    invoke-virtual {v1, v2}, Le/g;->setIdade(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1, p1}, Le/g;->setPosicao(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1, p1}, Le/g;->setCr1(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1, v0}, Le/g;->setCr2(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0, p1}, Le/g;->setLado(I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pR()V

    return-void
.end method

.method public pM()V
    .locals 2

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    new-instance v0, Lcomponents/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/p;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hc:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hc:Landroid/widget/ListView;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEditor$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEditor$3;-><init>(Lcom/brasfoot/v2028/ActivityEditor;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEditor;->pO()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hc:Landroid/widget/ListView;

    sget v1, Lcom/brasfoot/v2028/ActivityEditor;->Hz:I

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0, v1}, Lcomponents/p;->dm(I)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->GY:Lcomponents/p;

    invoke-virtual {v0}, Lcomponents/p;->notifyDataSetChanged()V

    return-void
.end method

.method public pP()V
    .locals 6

    sget-object v0, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    if-eqz v0, :cond_2

    :try_start_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    invoke-virtual {v1}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcomponents/cg;->setNome(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    invoke-virtual {v1}, Le/t;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, Lcomponents/cg;->setPais(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hq:Le/t;

    invoke-virtual {v1}, Le/t;->getNivel()I

    move-result v1

    invoke-virtual {v0, v1}, Lcomponents/cg;->setNivel(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {v0}, Lcomponents/cg;->vu()Ljava/lang/String;

    move-result-object v0

    sget-boolean v1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hu:Ljava/lang/String;

    if-eqz v1, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lcom/brasfoot/v2028/ActivityEditor;->Hu:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".ban"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v3}, Le/t;->getPais()I

    move-result v3

    invoke-virtual {v1, v3}, Lcomponents/cg;->setPais(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {v1, v0}, Lcomponents/cg;->ak(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v3}, Le/t;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcomponents/cg;->setNome(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->oN:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {v1, v2, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityEditor;->b(Le/t;)V

    invoke-virtual {p0, v0, v2}, Lcom/brasfoot/v2028/ActivityEditor;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v1

    new-instance v3, Ljava/io/ObjectOutputStream;

    invoke-direct {v3, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hd:Le/t;

    invoke-virtual {v3, v4}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {v3}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V

    sget-boolean v1, Lcom/brasfoot/v2028/ActivityEditor;->Ht:Z

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditor;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v1

    array-length v3, v1

    :goto_0
    if-ge v2, v3, :cond_2

    aget-object v4, v1, v2

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hp:Lcomponents/cg;

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcomponents/cg;->setPath(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    :cond_2
    return-void
.end method

.method public pT()Z
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v1}, Le/g;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hh:Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Le/g;->setNome(Ljava/lang/String;)V

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hi:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/lit8 v3, v3, 0x10

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getIdade()I

    move-result v4

    if-eq v3, v4, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hi:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/lit8 v3, v3, 0x10

    invoke-virtual {v0, v3}, Le/g;->setIdade(I)V

    const/4 v0, 0x1

    :cond_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->GI:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getLado()I

    move-result v4

    if-eq v3, v4, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->GI:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v0, v3}, Le/g;->setLado(I)V

    const/4 v0, 0x1

    :cond_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->GH:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getPosicao()I

    move-result v4

    if-eq v3, v4, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->GH:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v0, v3}, Le/g;->setPosicao(I)V

    const/4 v0, 0x1

    :cond_3
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getPosicao()I

    move-result v3

    if-nez v3, :cond_5

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getCr1()I

    move-result v4

    if-eq v3, v4, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v0, v3}, Le/g;->setCr1(I)V

    const/4 v0, 0x1

    :cond_4
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getCr2()I

    move-result v4

    if-eq v3, v4, :cond_7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    :goto_1
    invoke-virtual {v0, v3}, Le/g;->setCr2(I)V

    const/4 v0, 0x1

    goto :goto_2

    :cond_5
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getPosicao()I

    move-result v3

    if-eqz v3, :cond_7

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/lit8 v3, v3, 0x4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getCr1()I

    move-result v4

    if-eq v3, v4, :cond_6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hk:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/lit8 v3, v3, 0x4

    invoke-virtual {v0, v3}, Le/g;->setCr1(I)V

    const/4 v0, 0x1

    :cond_6
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/lit8 v3, v3, 0x4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getCr2()I

    move-result v4

    if-eq v3, v4, :cond_7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hl:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    add-int/lit8 v3, v3, 0x4

    goto :goto_1

    :cond_7
    :goto_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->getPais()I

    move-result v4

    invoke-static {v4}, La/g;->aA(I)I

    move-result v4

    if-eq v3, v4, :cond_8

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-static {v3}, La/g;->aB(I)I

    move-result v3

    if-ltz v3, :cond_8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-static {v3}, La/g;->aB(I)I

    move-result v3

    invoke-virtual {v0, v3}, Le/g;->setPais(I)V

    const/4 v0, 0x1

    :cond_8
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hn:Landroid/widget/CheckBox;

    invoke-virtual {v3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->isTopMundial()Z

    move-result v4

    if-eq v3, v4, :cond_9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hn:Landroid/widget/CheckBox;

    invoke-virtual {v3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    invoke-virtual {v0, v3}, Le/g;->setTopMundial(Z)V

    const/4 v0, 0x1

    :cond_9
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hm:Landroid/widget/CheckBox;

    invoke-virtual {v3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v4}, Le/g;->isEstrela()Z

    move-result v4

    if-eq v3, v4, :cond_a

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Hm:Landroid/widget/CheckBox;

    invoke-virtual {v3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    invoke-virtual {v0, v3}, Le/g;->setEstrela(Z)V

    const/4 v0, 0x1

    :cond_a
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ho:Landroid/widget/CheckBox;

    invoke-virtual {v3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    if-eqz v3, :cond_b

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getStatus()I

    move-result v3

    if-nez v3, :cond_b

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0, v2}, Le/g;->setStatus(I)V

    return v2

    :cond_b
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->Ho:Landroid/widget/CheckBox;

    invoke-virtual {v3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    if-nez v3, :cond_c

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v3}, Le/g;->getStatus()I

    move-result v3

    if-ne v3, v2, :cond_c

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEditor;->He:Le/g;

    invoke-virtual {v0, v1}, Le/g;->setStatus(I)V

    return v2

    :cond_c
    move v2, v0

    return v2
.end method
