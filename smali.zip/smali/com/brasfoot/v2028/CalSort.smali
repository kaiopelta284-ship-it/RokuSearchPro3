.class public Lcom/brasfoot/v2028/CalSort;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# static fields
.field public static INST:Ljava/util/Comparator;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/CalSort;

    invoke-direct {v0}, Lcom/brasfoot/v2028/CalSort;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/CalSort;->INST:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    check-cast p1, La/t;

    check-cast p2, La/t;

    invoke-virtual {p1}, La/t;->jY()I

    move-result v0

    invoke-virtual {p2}, La/t;->jY()I

    move-result v1

    sub-int/2addr v0, v1

    return v0
.end method
