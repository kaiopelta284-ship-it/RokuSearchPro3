.class Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivtyRankingTecnicos;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;->MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;->MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MN:Lcomponents/ad;

    invoke-virtual {p1, p3}, Lcomponents/ad;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;->MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->a(Lcom/brasfoot/v2028/ActivtyRankingTecnicos;)V

    :try_start_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;->MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/af;

    if-eqz p1, :cond_0

    sput-object p1, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    new-instance p1, Landroid/content/Intent;

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;->MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    const-class p3, Lcom/brasfoot/v2028/ActivityTecnico;

    invoke-direct {p1, p2, p3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;->MP:Lcom/brasfoot/v2028/ActivtyRankingTecnicos;

    invoke-virtual {p2, p1}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-void

    :catch_0
    move-exception p1

    return-void
.end method
