.class Lcom/brasfoot/v2028/ActivityRankings$5;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityRankings;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Lv:Lcom/brasfoot/v2028/ActivityRankings;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityRankings;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings$5;->Lv:Lcom/brasfoot/v2028/ActivityRankings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityRankings$5;->Lv:Lcom/brasfoot/v2028/ActivityRankings;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityRankings;->b(Lcom/brasfoot/v2028/ActivityRankings;)V

    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
