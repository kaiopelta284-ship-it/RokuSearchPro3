.class public Lcom/brasfoot/v2028/ActivityHist;
.super Landroid/app/Activity;


# static fields
.field public static fixedClub:La/ac;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private appendLines(Ljava/lang/StringBuilder;Ljava/lang/String;IZ)V
    .locals 6

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, La/b;->getTransHist()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_2

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lest/TransRec;

    iget v3, v2, Lest/TransRec;->ano:I

    if-ne v3, p3, :cond_1

    if-eqz p4, :cond_0

    iget-object v3, v2, Lest/TransRec;->para:Ljava/lang/String;

    invoke-static {v3, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_1

    const-string v3, "\u2022 "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v2, Lest/TransRec;->jog:Ljava/lang/String;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v2, Lest/TransRec;->de:Ljava/lang/String;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ") "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Lcom/brasfoot/v2028/ActivityHist;->vstr(Lest/TransRec;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\n"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_0
    iget-object v3, v2, Lest/TransRec;->de:Ljava/lang/String;

    invoke-static {v3, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_1

    const-string v3, "\u2022 "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v2, Lest/TransRec;->jog:Ljava/lang/String;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " (-> "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v2, Lest/TransRec;->para:Ljava/lang/String;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ") "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Lcom/brasfoot/v2028/ActivityHist;->vstr(Lest/TransRec;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\n"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method private clubNames()[Ljava/lang/String;
    .locals 6

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_1

    new-array v2, v1, [Ljava/lang/String;

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-object v2

    :cond_1
    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    return-object v0
.end method

.method private fill(I[Ljava/lang/String;)V
    .locals 3

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityHist;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, p2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    const v2, 0x1090009

    invoke-virtual {v1, v2}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    :cond_0
    return-void
.end method

.method private selByName(ILjava/lang/String;)V
    .locals 5

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityHist;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private selStr(I)Ljava/lang/String;
    .locals 2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityHist;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItem()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const-string v0, ""

    return-object v0
.end method

.method private static vstr(Lest/TransRec;)Ljava/lang/String;
    .locals 4

    iget v0, p0, Lest/TransRec;->tipo:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const-string v0, "(emprestimo)"

    return-object v0

    :cond_0
    iget v0, p0, Lest/TransRec;->valor:I

    if-gtz v0, :cond_1

    const-string v0, "(livre)"

    return-object v0

    :cond_1
    iget v0, p0, Lest/TransRec;->valor:I

    int-to-long v2, v0

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private yearList()[Ljava/lang/String;
    .locals 8

    sget-object v0, Lc/a;->TF:La/b;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "0"

    aput-object v2, v0, v1

    return-object v0

    :cond_0
    invoke-virtual {v0}, La/b;->getTransHist()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-nez v2, :cond_1

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    invoke-virtual {v0}, La/b;->dd()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v2, v3

    return-object v2

    :cond_1
    const v3, 0x7fffffff

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v2, :cond_4

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lest/TransRec;

    iget v6, v6, Lest/TransRec;->ano:I

    if-ge v6, v3, :cond_2

    move v3, v6

    :cond_2
    if-le v6, v4, :cond_3

    move v4, v6

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    sub-int v0, v4, v3

    add-int/lit8 v0, v0, 0x1

    if-gtz v0, :cond_5

    const/4 v0, 0x1

    :cond_5
    new-array v1, v0, [Ljava/lang/String;

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v0, :cond_6

    sub-int v6, v4, v5

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v1, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_6
    return-object v1
.end method


# virtual methods
.method public onClickMostrar(Landroid/view/View;)V
    .locals 9

    const v0, 0x7f060427

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityHist;->selStr(I)Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f060428

    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityHist;->selStr(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    :try_start_0
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v3

    const/4 v2, 0x0

    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "== ENTRADAS "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " ==\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-direct {p0, v3, v0, v2, v4}, Lcom/brasfoot/v2028/ActivityHist;->appendLines(Ljava/lang/StringBuilder;Ljava/lang/String;IZ)V

    const-string v4, "\n== SAIDAS "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " ==\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    invoke-direct {p0, v3, v0, v2, v4}, Lcom/brasfoot/v2028/ActivityHist;->appendLines(Ljava/lang/StringBuilder;Ljava/lang/String;IZ)V

    const v0, 0x7f060429

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityHist;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07007a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityHist;->setContentView(I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityHist;->clubNames()[Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f060427

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityHist;->fill(I[Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityHist;->yearList()[Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f060428

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityHist;->fill(I[Ljava/lang/String;)V

    sget-object v0, Lcom/brasfoot/v2028/ActivityHist;->fixedClub:La/ac;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f060427

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityHist;->selByName(ILjava/lang/String;)V

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/ActivityHist;->fixedClub:La/ac;

    :cond_0
    return-void
.end method
