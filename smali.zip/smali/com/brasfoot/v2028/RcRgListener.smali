.class public Lcom/brasfoot/v2028/RcRgListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field private mode:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/brasfoot/v2028/RcRgListener;->mode:I

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 5

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_1

    const/4 v1, 0x0

    iput v1, v0, La/b;->rcSpRenegY:I

    iget v1, p0, Lcom/brasfoot/v2028/RcRgListener;->mode:I

    if-eqz v1, :cond_1

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-virtual {v1}, La/ac;->getSponsorValue()I

    move-result v2

    if-lez v2, :cond_1

    div-int/lit8 v2, v2, 0x64

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->spPct()I

    move-result v3

    mul-int v3, v3, v2

    div-int/lit8 v3, v3, 0xa

    if-lez v3, :cond_0

    const/4 v4, 0x6

    invoke-virtual {v1, v3, v4}, La/ac;->V(II)V

    :cond_0
    invoke-virtual {v1}, La/ac;->getNivel()I

    move-result v2

    invoke-static {v2}, Lcom/brasfoot/v2028/Recopa;->spPctFor(I)I

    move-result v2

    iput v2, v0, La/b;->rcSpPct:I

    invoke-virtual {v0}, La/b;->db()I

    move-result v2

    add-int/lit8 v2, v2, 0x2

    iput v2, v0, La/b;->rcSpUntil:I

    const-string v1, "Contrato de patrocinio renegociado: nova cota vigente por 3 temporadas."

    sput-object v1, Lcom/brasfoot/v2028/Recopa;->pendingConv:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method
