.class public Lcom/brasfoot/v2028/RcShop;
.super Ljava/lang/Object;


# static fields
.field public static dlg:Landroid/app/AlertDialog;

.field public static minQd:I

.field public static paisList:Ljava/util/ArrayList;

.field public static paisSel:I

.field public static stock:Ljava/util/ArrayList;

.field public static stockPais:I

.field public static stockSrc:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, -0x1

    sput v0, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    sput v0, Lcom/brasfoot/v2028/RcShop;->stockPais:I

    const/4 v0, 0x0

    sput v0, Lcom/brasfoot/v2028/RcShop;->minQd:I

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static basesView(Landroid/app/Activity;)V
    .locals 0

    invoke-static {}, Lcom/brasfoot/v2028/RcShop;->buildBaseStock()V

    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->refresh(Landroid/app/Activity;)V

    return-void
.end method

.method public static buildBaseStock()V
    .locals 12

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    sput-object v1, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    sget v2, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    sput v2, Lcom/brasfoot/v2028/RcShop;->stockPais:I

    :try_start_0
    sget-object v3, Lc/a;->TF:La/b;

    if-eqz v3, :cond_6

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    if-eqz v3, :cond_6

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v4

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x0

    :goto_0
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_1

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/ac;

    invoke-virtual {v8}, La/ac;->getPais()I

    move-result v9

    if-ne v9, v2, :cond_0

    if-eq v8, v4, :cond_0

    invoke-virtual {v8}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v9

    if-eqz v9, :cond_0

    const/4 v10, 0x0

    :goto_1
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v10, v11, :cond_0

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_1
    :goto_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v3, 0x64

    if-lt v2, v3, :cond_2

    return-void

    :cond_2
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-gtz v2, :cond_3

    return-void

    :cond_3
    const/4 v3, -0x1

    const/4 v4, -0x1

    const/4 v7, 0x0

    :goto_3
    if-ge v7, v2, :cond_5

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/q;

    invoke-virtual {v8}, La/q;->ic()I

    move-result v8

    if-le v8, v4, :cond_4

    move v4, v8

    move v3, v7

    :cond_4
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_5
    if-ltz v3, :cond_6

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_6
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static buildPaisList()V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_1

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    sput-object v0, Lcom/brasfoot/v2028/RcShop;->paisList:Ljava/util/ArrayList;

    return-void
.end method

.method public static buy(Landroid/app/Activity;I)V
    .locals 10

    :try_start_0
    sget-object v0, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    if-eqz v0, :cond_6

    if-ltz p1, :cond_6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/q;

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v2

    if-eqz v2, :cond_6

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v3

    if-eqz v3, :cond_6

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/16 v5, 0x12

    if-lt v4, v5, :cond_0

    const-string v1, "Base de juniores cheia (maximo 18)"

    invoke-static {p0, v1}, Lcom/brasfoot/v2028/RcShop;->toast(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :cond_0
    const/4 v9, 0x0

    sget-object v5, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    if-eqz v5, :cond_1

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge p1, v6, :cond_1

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/ac;

    :cond_1
    invoke-static {v1}, Lcom/brasfoot/v2028/RcShop;->price(La/q;)I

    move-result v4

    if-eqz v9, :cond_2

    mul-int/lit8 v4, v4, 0x2

    :cond_2
    invoke-virtual {v2}, La/ac;->lA()J

    move-result-wide v5

    int-to-long v7, v4

    cmp-long v8, v5, v7

    if-gez v8, :cond_3

    const-string v1, "Dinheiro insuficiente"

    invoke-static {p0, v1}, Lcom/brasfoot/v2028/RcShop;->toast(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :cond_3
    const/4 v5, 0x1

    invoke-virtual {v2, v4, v5}, La/ac;->V(II)V

    if-eqz v9, :cond_4

    invoke-virtual {v9}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v5

    if-eqz v5, :cond_4

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_4
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    sget-object v5, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    if-eqz v5, :cond_5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge p1, v6, :cond_5

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, La/q;->gN()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " contratado para a base!"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/RcShop;->toast(Landroid/app/Activity;Ljava/lang/String;)V

    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->refresh(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_6
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static genStock()V
    .locals 12

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    sget v1, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    sput v1, Lcom/brasfoot/v2028/RcShop;->stockPais:I

    :try_start_0
    sget-object v2, Lc/a;->TF:La/b;

    if-eqz v2, :cond_4

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    if-eqz v2, :cond_4

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    :goto_0
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_2

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    invoke-virtual {v5}, La/ac;->getPais()I

    move-result v6

    const/4 v7, -0x2

    if-eq v1, v7, :cond_0

    if-ne v6, v1, :cond_1

    :cond_0
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_4

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/4 v5, 0x0

    :goto_1
    const/16 v6, 0xc

    if-ge v5, v6, :cond_4

    invoke-virtual {v4, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ac;

    const/4 v7, -0x1

    invoke-static {}, La/b;->newJunior()La/q;

    move-result-object v8

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v11, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static/range {v6 .. v11}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    move-result-object v6

    if-nez v5, :cond_3

    const/16 v7, 0xa

    goto :goto_2

    :cond_3
    const/4 v7, 0x4

    invoke-virtual {v4, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    add-int/lit8 v7, v7, 0x6

    :goto_2
    invoke-virtual {v6, v7}, La/q;->forceQd(I)V

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v7, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_4
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static genStockElite()V
    .locals 12

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    sget v1, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    sput v1, Lcom/brasfoot/v2028/RcShop;->stockPais:I

    :try_start_0
    sget-object v2, Lc/a;->TF:La/b;

    if-eqz v2, :cond_5

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    if-eqz v2, :cond_5

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    :goto_0
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_2

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ac;

    invoke-virtual {v5}, La/ac;->getPais()I

    move-result v6

    const/4 v7, -0x2

    if-eq v1, v7, :cond_0

    if-ne v6, v1, :cond_1

    :cond_0
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_5

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const/4 v5, 0x0

    :goto_1
    const/16 v6, 0xc

    if-ge v5, v6, :cond_5

    invoke-virtual {v4, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ac;

    const/4 v7, -0x1

    invoke-static {}, La/b;->newJunior()La/q;

    move-result-object v8

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v11, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static/range {v6 .. v11}, La/q;->a(La/ac;ILa/q;ILjava/lang/String;Ljava/lang/Boolean;)La/q;

    move-result-object v6

    const/4 v7, 0x2

    if-ge v5, v7, :cond_3

    const/16 v7, 0xa

    goto :goto_2

    :cond_3
    const/4 v7, 0x5

    if-ge v5, v7, :cond_4

    const/16 v7, 0x9

    goto :goto_2

    :cond_4
    const/16 v7, 0x8

    :goto_2
    invoke-virtual {v6, v7}, La/q;->forceQd(I)V

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v7, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_5
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static paisName(Landroid/app/Activity;I)Ljava/lang/String;
    .locals 4

    const/4 v0, -0x2

    if-ne p1, v0, :cond_0

    const-string v0, "Todos os paises"

    return-object v0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "country_names"

    const-string v2, "array"

    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    if-ltz p1, :cond_1

    array-length v1, v0

    if-ge p1, v1, :cond_1

    aget-object v0, v0, p1

    return-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :catch_0
    move-exception v0

    const-string v0, "?"

    return-object v0
.end method

.method public static peneira(Landroid/app/Activity;)V
    .locals 6

    :try_start_0
    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v0

    if-eqz v0, :cond_1

    const v1, 0x7a120

    invoke-virtual {v0}, La/ac;->lA()J

    move-result-wide v2

    int-to-long v4, v1

    cmp-long v4, v2, v4

    if-gez v4, :cond_0

    const-string v1, "Dinheiro insuficiente para a peneira (R$ 500 mil)"

    invoke-static {p0, v1}, Lcom/brasfoot/v2028/RcShop;->toast(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :cond_0
    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, La/ac;->V(II)V

    invoke-static {}, Lcom/brasfoot/v2028/RcShop;->genStock()V

    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->refresh(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static peneiraElite(Landroid/app/Activity;)V
    .locals 6

    :try_start_0
    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v0

    if-eqz v0, :cond_1

    const v1, 0x989680

    invoke-virtual {v0}, La/ac;->lA()J

    move-result-wide v2

    int-to-long v4, v1

    cmp-long v4, v2, v4

    if-gez v4, :cond_0

    const-string v1, "Dinheiro insuficiente para a Peneira Elite (R$ 10M)"

    invoke-static {p0, v1}, Lcom/brasfoot/v2028/RcShop;->toast(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :cond_0
    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, La/ac;->V(II)V

    invoke-static {}, Lcom/brasfoot/v2028/RcShop;->genStockElite()V

    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->refresh(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static pickPais(Landroid/app/Activity;)V
    .locals 7

    :try_start_0
    sget-object v0, Lcom/brasfoot/v2028/RcShop;->paisList:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_1

    add-int/lit8 v2, v1, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "Todos os paises"

    aput-object v4, v2, v3

    :goto_0
    if-ge v3, v1, :cond_0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-static {p0, v4}, Lcom/brasfoot/v2028/RcShop;->paisName(Landroid/app/Activity;I)Ljava/lang/String;

    move-result-object v4

    add-int/lit8 v5, v3, 0x1

    aput-object v4, v2, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v4, "Pais da base"

    invoke-virtual {v3, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    new-instance v4, Lcom/brasfoot/v2028/RcShopClick;

    const/16 v5, 0xa

    const/4 v6, 0x0

    invoke-direct {v4, p0, v5, v6}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v3, v2, v4}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static pickStars(Landroid/app/Activity;)V
    .locals 7

    :try_start_0
    const/4 v0, 0x4

    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "Todas"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "3+ estrelas"

    const/4 v3, 0x1

    aput-object v2, v1, v3

    const-string v2, "4+ estrelas"

    const/4 v3, 0x2

    aput-object v2, v1, v3

    const-string v2, "5 estrelas"

    const/4 v3, 0x3

    aput-object v2, v1, v3

    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v4, "Filtro de estrelas"

    invoke-virtual {v3, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    new-instance v4, Lcom/brasfoot/v2028/RcShopClick;

    const/16 v5, 0xb

    const/4 v6, 0x0

    invoke-direct {v4, p0, v5, v6}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v3, v1, v4}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static posName(I)Ljava/lang/String;
    .locals 1

    if-nez p0, :cond_0

    const-string v0, "GOL"

    return-object v0

    :cond_0
    const/4 v0, 0x1

    if-ne p0, v0, :cond_1

    const-string v0, "LAT"

    return-object v0

    :cond_1
    const/4 v0, 0x2

    if-ne p0, v0, :cond_2

    const-string v0, "ZAG"

    return-object v0

    :cond_2
    const/4 v0, 0x3

    if-ne p0, v0, :cond_3

    const-string v0, "MEI"

    return-object v0

    :cond_3
    const-string v0, "ATA"

    return-object v0
.end method

.method public static price(La/q;)I
    .locals 2

    invoke-virtual {p0}, La/q;->ic()I

    move-result v0

    mul-int v1, v0, v0

    const v0, 0x186a0

    mul-int v1, v1, v0

    return v1
.end method

.method public static refresh(Landroid/app/Activity;)V
    .locals 2

    :try_start_0
    sget-object v0, Lcom/brasfoot/v2028/RcShop;->dlg:Landroid/app/AlertDialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    const/4 v1, 0x0

    sput-object v1, Lcom/brasfoot/v2028/RcShop;->dlg:Landroid/app/AlertDialog;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->show(Landroid/app/Activity;)V

    return-void
.end method

.method public static setPais(Landroid/app/Activity;I)V
    .locals 2

    :try_start_0
    if-nez p1, :cond_0

    const/4 v0, -0x2

    sput v0, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    goto :goto_0

    :cond_0
    sget-object v0, Lcom/brasfoot/v2028/RcShop;->paisList:Ljava/util/ArrayList;

    if-eqz v0, :cond_1

    add-int/lit8 p1, p1, -0x1

    if-ltz p1, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    sput v0, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    :goto_0
    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->refresh(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method public static setStars(Landroid/app/Activity;I)V
    .locals 1

    if-nez p1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    const/4 v0, 0x6

    goto :goto_0

    :cond_1
    const/4 v0, 0x2

    if-ne p1, v0, :cond_2

    const/16 v0, 0x8

    goto :goto_0

    :cond_2
    const/16 v0, 0xa

    :goto_0
    sput v0, Lcom/brasfoot/v2028/RcShop;->minQd:I

    invoke-static {p0}, Lcom/brasfoot/v2028/RcShop;->refresh(Landroid/app/Activity;)V

    return-void
.end method

.method public static show(Landroid/app/Activity;)V
    .locals 14

    :try_start_0
    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v0

    if-eqz v0, :cond_9

    sget v1, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_0

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v1

    sput v1, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    :cond_0
    sget-object v1, Lcom/brasfoot/v2028/RcShop;->paisList:Ljava/util/ArrayList;

    if-nez v1, :cond_1

    invoke-static {}, Lcom/brasfoot/v2028/RcShop;->buildPaisList()V

    :cond_1
    sget-object v1, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    if-eqz v1, :cond_2

    sget v1, Lcom/brasfoot/v2028/RcShop;->stockPais:I

    sget v2, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    if-eq v1, v2, :cond_3

    :cond_2
    invoke-static {}, Lcom/brasfoot/v2028/RcShop;->genStock()V

    :cond_3
    new-instance v1, Landroid/widget/ScrollView;

    invoke-direct {v1, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const v2, -0xf2eee9

    invoke-virtual {v1, v2}, Landroid/widget/ScrollView;->setBackgroundColor(I)V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->cardBox(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v4, Landroid/widget/Button;

    invoke-direct {v4, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Pais: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v6, Lcom/brasfoot/v2028/RcShop;->paisSel:I

    invoke-static {p0, v6}, Lcom/brasfoot/v2028/RcShop;->paisName(Landroid/app/Activity;I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v4}, Lcom/brasfoot/v2028/RcShop;->styleBtn(Landroid/widget/Button;)V

    new-instance v5, Lcom/brasfoot/v2028/RcShopClick;

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v5, p0, v6, v7}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x0

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v6, 0x3f800000    # 1.0f

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v3, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/Button;

    invoke-direct {v4, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Filtro: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/brasfoot/v2028/RcShop;->starsLabel()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v4}, Lcom/brasfoot/v2028/RcShop;->styleBtn(Landroid/widget/Button;)V

    new-instance v5, Lcom/brasfoot/v2028/RcShopClick;

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v5, p0, v6, v7}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x0

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v6, 0x3f800000    # 1.0f

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v3, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v4, Landroid/widget/Button;

    invoke-direct {v4, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Peneira (500 mil)"

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v4}, Lcom/brasfoot/v2028/RcShop;->styleBtn(Landroid/widget/Button;)V

    new-instance v5, Lcom/brasfoot/v2028/RcShopClick;

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {v5, p0, v6, v7}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x0

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v6, 0x3f800000    # 1.0f

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v3, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/Button;

    invoke-direct {v4, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v5, "Elite 10M (4-5 estrelas)"

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v4}, Lcom/brasfoot/v2028/RcShop;->styleBtn(Landroid/widget/Button;)V

    new-instance v5, Lcom/brasfoot/v2028/RcShopClick;

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v5, p0, v6, v7}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x0

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v6, 0x3f800000    # 1.0f

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v3, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    sget-object v3, Lcom/brasfoot/v2028/RcShop;->stock:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v3, :cond_7

    :goto_0
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/q;

    invoke-virtual {v6}, La/q;->ic()I

    move-result v7

    sget v8, Lcom/brasfoot/v2028/RcShop;->minQd:I

    if-lt v7, v8, :cond_6

    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v8, 0x10

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v9, Landroid/widget/ImageView;

    invoke-direct {v9, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, p0}, La/q;->f(Landroid/content/Context;)I

    move-result v10

    if-lez v10, :cond_4

    invoke-virtual {v9, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_4
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v11, 0x36

    const/16 v12, 0x24

    invoke-direct {v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v11, 0x10

    const/4 v12, 0x0

    invoke-virtual {v9, v12, v12, v11, v12}, Landroid/widget/ImageView;->setPadding(IIII)V

    invoke-virtual {v7, v9, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x0

    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6}, La/q;->gN()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, "  ("

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, La/q;->getPosicao()I

    move-result v11

    invoke-static {v11}, Lcom/brasfoot/v2028/RcShop;->posName(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, ", "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, La/q;->getIdade()I

    move-result v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, " anos)"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v10, 0x41700000    # 15.0f

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v10, -0x1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v9, v10, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v6}, Lcom/brasfoot/v2028/RcShop;->starsText(La/q;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    sget-object v11, Lcom/brasfoot/v2028/RcShop;->stockSrc:Ljava/util/ArrayList;

    if-eqz v11, :cond_5

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v13

    if-ge v4, v13, :cond_5

    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/ac;

    if-eqz v11, :cond_5

    const/4 v12, 0x2

    const-string v13, "  -  "

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    const-string v11, "  -  "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v6}, Lcom/brasfoot/v2028/RcShop;->price(La/q;)I

    move-result v11

    mul-int v11, v11, v12

    int-to-long v12, v11

    invoke-static {v12, v13}, La/n;->b(J)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v10, 0x41500000    # 13.0f

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    const v10, -0x163885

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v9, v10, v10, v10, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x0

    const/4 v11, -0x2

    invoke-direct {v9, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v10, 0x3f800000    # 1.0f

    iput v10, v9, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v7, v8, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Landroid/widget/Button;

    invoke-direct {v8, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v9, "Contratar"

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v8}, Lcom/brasfoot/v2028/RcShop;->styleBtn(Landroid/widget/Button;)V

    new-instance v9, Lcom/brasfoot/v2028/RcShopClick;

    const/4 v10, 0x3

    invoke-direct {v9, p0, v10, v4}, Lcom/brasfoot/v2028/RcShopClick;-><init>(Landroid/app/Activity;II)V

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v5, v5, 0x1

    :cond_6
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_0

    :cond_7
    if-nez v5, :cond_8

    const-string v3, "Nenhum junior com esse filtro. Toque em Filtro e escolha Todas, ou faca uma nova peneira."

    const/4 v4, 0x0

    invoke-static {p0, v2, v3, v4}, Lcom/brasfoot/v2028/Recopa;->cardRow(Landroid/app/Activity;Landroid/widget/LinearLayout;Ljava/lang/String;I)V

    :cond_8
    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v4, "Loja de Juniores"

    invoke-virtual {v3, v4}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    const-string v4, "Fechar"

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v3

    sput-object v3, Lcom/brasfoot/v2028/RcShop;->dlg:Landroid/app/AlertDialog;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_9
    return-void

    :catch_0
    move-exception v0

    const-string v1, "BRASDBG"

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static starsLabel()Ljava/lang/String;
    .locals 2

    sget v0, Lcom/brasfoot/v2028/RcShop;->minQd:I

    const/4 v1, 0x6

    if-ge v0, v1, :cond_2

    const/16 v1, 0x8

    if-ge v0, v1, :cond_1

    const/16 v1, 0xa

    if-ge v0, v1, :cond_0

    const-string v0, "5 estrelas"

    return-object v0

    :cond_0
    const-string v0, "4+ estrelas"

    return-object v0

    :cond_1
    const-string v0, "3+ estrelas"

    return-object v0

    :cond_2
    const-string v0, "Todas"

    return-object v0
.end method

.method public static starsText(La/q;)Ljava/lang/String;
    .locals 3

    invoke-virtual {p0}, La/q;->ic()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    div-int/lit8 v2, v0, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    rem-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const-string v0, ".5"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const-string v0, " estrelas"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static styleBtn(Landroid/widget/Button;)V
    .locals 1

    const v0, -0xe4ddd0

    invoke-virtual {p0, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    const v0, -0x163885

    invoke-virtual {p0, v0}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v0, 0x41500000    # 13.0f

    invoke-virtual {p0, v0}, Landroid/widget/Button;->setTextSize(F)V

    return-void
.end method

.method public static toast(Landroid/app/Activity;Ljava/lang/String;)V
    .locals 1

    :try_start_0
    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    return-void
.end method
