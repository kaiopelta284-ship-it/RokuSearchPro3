.class public Lcom/brasfoot/v2028/ActivityJogo;
.super Landroid/app/Activity;


# static fields
.field private static Jf:I = -0x1

.field private static Jo:La/t;

.field private static Jp:Z

.field public static Jq:I

.field public static Jr:I

.field public static Js:La/p;

.field public static Jt:Z

.field private static Jv:Lcomponents/bo;

.field public static yn:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bo;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field JA:Lcomponents/z;

.field JB:[Landroid/media/MediaPlayer;

.field private Jg:La/t;

.field private Jh:Landroid/widget/TextView;

.field private Ji:Landroid/widget/TextView;

.field private Jj:Landroid/widget/ProgressBar;

.field private Jk:Landroid/widget/TextView;

.field private Jl:Landroid/widget/TextView;

.field private Jm:Landroid/widget/ImageView;

.field private Jn:Landroid/widget/ImageView;

.field private Ju:Ljava/lang/String;

.field private Jw:I

.field Jx:Landroid/os/Handler;

.field public Jy:Ljava/lang/Runnable;

.field private Jz:I

.field private d:I

.field private oW:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private pw:I

.field private yo:I

.field private yq:Z

.field private yr:I

.field private yt:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private yu:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private yv:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation
.end field

.field private yy:La/al;

.field private yz:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    const/4 v1, 0x1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    iput v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    const/4 v2, -0x1

    iput v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->yr:I

    const/4 v3, 0x0

    iput-object v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    const-string v4, "pt_BR"

    iput-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->Ju:Ljava/lang/String;

    iput v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jw:I

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->yt:Ljava/util/ArrayList;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->yu:Ljava/util/ArrayList;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->yv:Ljava/util/ArrayList;

    iput-object v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->yy:La/al;

    iput v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->yz:I

    iput-object v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->oW:Ljava/util/ArrayList;

    new-instance v2, Landroid/os/Handler;

    invoke-direct {v2}, Landroid/os/Handler;-><init>()V

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    new-instance v2, Lcom/brasfoot/v2028/ActivityJogo$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivityJogo$1;-><init>(Lcom/brasfoot/v2028/ActivityJogo;)V

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jy:Ljava/lang/Runnable;

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jz:I

    const/4 v2, 0x7

    new-array v2, v2, [Landroid/media/MediaPlayer;

    aput-object v3, v2, v0

    aput-object v3, v2, v1

    const/4 v0, 0x2

    aput-object v3, v2, v0

    const/4 v0, 0x3

    aput-object v3, v2, v0

    const/4 v0, 0x4

    aput-object v3, v2, v0

    const/4 v0, 0x5

    aput-object v3, v2, v0

    const/4 v0, 0x6

    aput-object v3, v2, v0

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->JB:[Landroid/media/MediaPlayer;

    return-void
.end method

.method private a(Lcomponents/bo;La/m;)V
    .locals 0

    return-void
.end method

.method public static ad(Z)V
    .locals 0

    sput-boolean p0, Lcom/brasfoot/v2028/ActivityJogo;->Jp:Z

    return-void
.end method

.method private b(Lcomponents/bo;La/m;)V
    .locals 0

    return-void
.end method

.method public static cT(I)V
    .locals 0

    sput p0, Lcom/brasfoot/v2028/ActivityJogo;->Jq:I

    return-void
.end method

.method public static cU(I)V
    .locals 0

    sput p0, Lcom/brasfoot/v2028/ActivityJogo;->Jr:I

    return-void
.end method

.method public static cV(I)V
    .locals 0

    sput p0, Lcom/brasfoot/v2028/ActivityJogo;->Jf:I

    return-void
.end method

.method private d(IZ)V
    .locals 2

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jy:Ljava/lang/Runnable;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jy:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v0, -0x1

    if-ne p1, v0, :cond_3

    const/4 p1, 0x0

    :goto_0
    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_2

    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bo;

    invoke-virtual {v0}, Lcomponents/bo;->le()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_2
    const/4 p1, 0x1

    :cond_3
    :goto_1
    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bo;

    sput-object v0, Lcom/brasfoot/v2028/ActivityJogo;->Jv:Lcomponents/bo;

    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bo;

    invoke-virtual {p1}, Lcomponents/bo;->uE()La/t;

    move-result-object p1

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJogo;->j(La/t;)V

    invoke-static {p2}, Lcom/brasfoot/v2028/ActivityJogo;->ad(Z)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJogo;->cU(I)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJogo;->cT(I)V

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityJogo;->Jt:Z

    new-instance p1, Landroid/content/Intent;

    const-class p2, Lcom/brasfoot/v2028/DialogFieldInfo;

    invoke-direct {p1, p0, p2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V

    :cond_4
    return-void
.end method

.method public static j(La/t;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/ActivityJogo;->Jo:La/t;

    return-void
.end method

.method private nl()V
    .locals 3

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    if-nez v0, :cond_1

    sget-boolean v0, Lcom/brasfoot/v2028/ActivityJogo;->Jt:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jh:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0b00eb

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityJogo;->Jt:Z

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->cs(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->nn()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->nm()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yv:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yv:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yv:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJogo;->h(La/t;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->finish()V

    invoke-static {}, La/o;->gG()V

    :cond_1
    return-void
.end method

.method private pM()V
    .locals 13

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->oW:Ljava/util/ArrayList;

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->filterRecopaDayLive(Ljava/util/ArrayList;)V

    const-string v0, ""

    const-string v1, ""

    const/4 v2, 0x0

    const/4 v3, 0x1

    move-object v4, v0

    move-object v5, v1

    const/4 v0, 0x0

    const/4 v1, 0x1

    :goto_0
    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityJogo;->oW:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v0, v6, :cond_b

    const-string v6, ""

    const-string v7, ""

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-object v6, v4

    move-object v7, v5

    const/4 v4, 0x1

    move v5, v1

    const/4 v1, 0x0

    :goto_1
    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v1, v8, :cond_a

    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v8}, La/t;->jH()La/al;

    move-result-object v8

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityJogo;->oW:Ljava/util/ArrayList;

    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    if-ne v8, v9, :cond_9

    if-eqz v4, :cond_6

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->jQ()Ljava/lang/String;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->jH()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nT()Ljava/lang/String;

    move-result-object v4

    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v8}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v8, v2}, La/t;->J(Z)[Ljava/lang/String;

    move-result-object v8

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/t;

    invoke-virtual {v9}, La/t;->jH()La/al;

    move-result-object v9

    invoke-virtual {v9}, La/al;->cG()I

    move-result v9

    const/4 v10, 0x3

    if-ne v9, v10, :cond_0

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v4}, La/t;->jb()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->getNome()Ljava/lang/String;

    move-result-object v4

    :cond_0
    new-instance v9, Lcomponents/bo;

    invoke-direct {v9}, Lcomponents/bo;-><init>()V

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v12, v8, v2

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v12, " "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v12, v8, v3

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcomponents/bo;->Y(Ljava/lang/String;)V

    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/t;

    invoke-virtual {v11}, La/t;->jH()La/al;

    move-result-object v11

    invoke-virtual {v11}, La/al;->cG()I

    move-result v11

    if-ne v11, v3, :cond_1

    invoke-static {v5, p0, v2}, La/ak;->a(ILandroid/content/Context;Z)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcomponents/bo;->Y(Ljava/lang/String;)V

    add-int/lit8 v5, v5, 0x1

    :cond_1
    sget-object v11, Lc/a;->TF:La/b;

    invoke-virtual {v11}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La/t;

    invoke-virtual {v11}, La/t;->jH()La/al;

    move-result-object v11

    invoke-virtual {v11}, La/al;->cG()I

    move-result v11

    if-ne v11, v10, :cond_2

    invoke-static {v5, p0, v2}, La/ak;->a(ILandroid/content/Context;Z)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcomponents/bo;->Y(Ljava/lang/String;)V

    add-int/lit8 v5, v5, 0x1

    :cond_2
    sget-object v10, Lc/a;->TF:La/b;

    invoke-virtual {v10}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/t;

    invoke-virtual {v10}, La/t;->jH()La/al;

    move-result-object v10

    invoke-virtual {v10}, La/al;->cG()I

    move-result v10

    const/4 v11, 0x5

    if-ne v10, v11, :cond_3

    const-string v10, ""

    invoke-virtual {v9, v10}, Lcomponents/bo;->Y(Ljava/lang/String;)V

    :cond_3
    sget-object v10, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-nez v0, :cond_4

    aget-object v7, v8, v3

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    invoke-virtual {v6}, La/al;->cG()I

    move-result v6

    if-ne v6, v11, :cond_5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->ee()Ld/y;

    move-result-object v6

    if-eqz v6, :cond_5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->ee()Ld/y;

    move-result-object v6

    invoke-virtual {v6, p0, v2}, Ld/y;->b(Landroid/content/Context;Z)Ljava/lang/String;

    move-result-object v7

    goto :goto_2

    :cond_4
    move-object v4, v6

    :cond_5
    :goto_2
    move-object v6, v4

    const/4 v4, 0x0

    :cond_6
    new-instance v8, Lcomponents/bo;

    invoke-direct {v8}, Lcomponents/bo;-><init>()V

    sget-object v9, Lc/a;->TF:La/b;

    invoke-virtual {v9}, La/b;->dm()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/t;

    invoke-virtual {v8, v9}, Lcomponents/bo;->o(La/t;)V

    invoke-virtual {v8}, Lcomponents/bo;->uJ()V

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v9

    invoke-virtual {v9}, La/t;->ji()La/ac;

    move-result-object v9

    if-eqz v9, :cond_7

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v9

    invoke-virtual {v9}, La/t;->ji()La/ac;

    move-result-object v9

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v10

    invoke-virtual {v10}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v9, v10}, La/ac;->O(Ljava/util/ArrayList;)V

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v9

    invoke-virtual {v9}, La/t;->ji()La/ac;

    move-result-object v9

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v10

    invoke-virtual {v10}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v9, v10}, La/ac;->M(Ljava/util/ArrayList;)V

    :cond_7
    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v9

    invoke-virtual {v9}, La/t;->jj()La/ac;

    move-result-object v9

    if-eqz v9, :cond_8

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v9

    invoke-virtual {v9}, La/t;->jj()La/ac;

    move-result-object v9

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v10

    invoke-virtual {v10}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v9, v10}, La/ac;->O(Ljava/util/ArrayList;)V

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v9

    invoke-virtual {v9}, La/t;->jj()La/ac;

    move-result-object v9

    invoke-virtual {v8}, Lcomponents/bo;->uE()La/t;

    move-result-object v10

    invoke-virtual {v10}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v9, v10}, La/ac;->M(Ljava/util/ArrayList;)V

    :cond_8
    sget-object v9, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_1

    :cond_a
    add-int/lit8 v0, v0, 0x1

    move v1, v5

    move-object v4, v6

    move-object v5, v7

    goto/16 :goto_0

    :cond_b
    const/4 v0, 0x0

    :goto_3
    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_d

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->le()Z

    move-result v1

    if-eqz v1, :cond_c

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jw:I

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bo;

    invoke-virtual {v0}, Lcomponents/bo;->uE()La/t;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    const/4 v2, 0x1

    goto :goto_4

    :cond_c
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_d
    :goto_4
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->qw()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->getVelocidade()I

    move-result v0

    if-nez v2, :cond_e

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->getVelocidadeNH()I

    move-result v0

    :cond_e
    const/4 v1, 0x1

    if-eqz v2, :cond_11

    const/16 v2, 0x7d0

    if-gt v0, v2, :cond_f

    if-ge v0, v1, :cond_10

    :cond_f
    const/16 v0, 0x3e8

    :cond_10
    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    goto :goto_5

    :cond_11
    iput v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    :goto_5
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_12

    iput v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    :cond_12
    const v0, 0x7f060126

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f060127

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->nj()V

    return-void
.end method

.method public static qA()Z
    .locals 1

    sget-boolean v0, Lcom/brasfoot/v2028/ActivityJogo;->Jp:Z

    return v0
.end method

.method public static qB()I
    .locals 1

    sget v0, Lcom/brasfoot/v2028/ActivityJogo;->Jq:I

    return v0
.end method

.method public static qC()I
    .locals 1

    sget v0, Lcom/brasfoot/v2028/ActivityJogo;->Jr:I

    return v0
.end method

.method public static qD()I
    .locals 1

    sget v0, Lcom/brasfoot/v2028/ActivityJogo;->Jf:I

    return v0
.end method

.method public static qu()Lcomponents/bo;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->Jv:Lcomponents/bo;

    return-object v0
.end method

.method public static qz()La/t;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->Jo:La/t;

    return-object v0
.end method


# virtual methods
.method public V(Z)V
    .locals 6

    const/4 v0, -0x1

    sput v0, Lcom/brasfoot/v2028/ActivityJogo;->Jf:I

    const/4 v1, 0x0

    if-nez p1, :cond_1

    const/4 p1, 0x0

    :goto_0
    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p1, v2, :cond_1

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->le()Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->kn()[I

    move-result-object v2

    iget v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    aget v2, v2, v3

    iget v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    if-gt v2, v3, :cond_0

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    iget v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    iget v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    invoke-virtual {v2, v3, v4}, La/t;->P(II)V

    :cond_0
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_1
    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p1, v2, :cond_4

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    if-eqz v2, :cond_3

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityJogo;->doAutoSubs(La/t;)V

    const/4 v2, 0x0

    :goto_2
    sget-object v3, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uE()La/t;

    move-result-object v3

    invoke-virtual {v3}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    sget-object v3, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uE()La/t;

    move-result-object v3

    invoke-virtual {v3}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/m;

    invoke-virtual {v3}, La/m;->isDone()Z

    move-result v3

    if-nez v3, :cond_2

    sget-object v3, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uE()La/t;

    move-result-object v3

    invoke-virtual {v3}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/m;

    invoke-virtual {v3}, La/m;->gV()I

    move-result v3

    iget v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    if-ne v3, v4, :cond_2

    sget-object v3, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uE()La/t;

    move-result-object v3

    invoke-virtual {v3}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/m;

    invoke-virtual {v3}, La/m;->gU()I

    move-result v3

    iget v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    if-gt v3, v4, :cond_2

    sget-object v3, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    sget-object v4, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bo;

    invoke-virtual {v4}, Lcomponents/bo;->uE()La/t;

    move-result-object v4

    sget-object v5, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcomponents/bo;

    invoke-virtual {v5}, Lcomponents/bo;->uE()La/t;

    move-result-object v5

    invoke-virtual {v5}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/m;

    invoke-virtual {p0, v3, v4, v5, p1}, Lcom/brasfoot/v2028/ActivityJogo;->a(Lcomponents/bo;La/t;La/m;I)V

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_2

    :cond_3
    add-int/lit8 p1, p1, 0x1

    goto/16 :goto_1

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    if-eqz p1, :cond_5

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->qx()V

    :cond_5
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->JA:Lcomponents/z;

    invoke-virtual {p1}, Lcomponents/z;->notifyDataSetChanged()V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yr:I

    if-ltz p1, :cond_6

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yr:I

    invoke-direct {p0, p1, v1}, Lcom/brasfoot/v2028/ActivityJogo;->d(IZ)V

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yr:I

    return-void

    :cond_6
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->nj()V

    return-void
.end method

.method public a(Lcomponents/bo;La/t;La/m;I)V
    .locals 5

    invoke-virtual {p3}, La/m;->cG()I

    move-result v0

    const/16 v1, 0x14

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p3, v0}, La/m;->F(Z)V

    return-void

    :cond_0
    invoke-virtual {p3}, La/m;->isDone()Z

    move-result v0

    if-nez v0, :cond_d

    const/4 v0, 0x1

    invoke-virtual {p3, v0}, La/m;->F(Z)V

    const/4 v1, 0x0

    invoke-virtual {p3}, La/m;->gS()La/ac;

    move-result-object v2

    invoke-virtual {p2}, La/t;->ji()La/ac;

    move-result-object v3

    const/4 v4, 0x2

    if-ne v2, v3, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {p3}, La/m;->gS()La/ac;

    move-result-object v2

    invoke-virtual {p2}, La/t;->jj()La/ac;

    move-result-object p2

    if-ne v2, p2, :cond_2

    const/4 v1, 0x2

    :cond_2
    :goto_0
    if-lez v1, :cond_d

    invoke-virtual {p1, p3}, Lcomponents/bo;->a(La/m;)V

    invoke-virtual {p3}, La/m;->cG()I

    move-result p2

    const/4 v2, 0x3

    if-ne p2, v0, :cond_5

    invoke-virtual {p3}, La/m;->gT()I

    move-result p2

    if-ne p2, v2, :cond_3

    invoke-virtual {p1}, Lcomponents/bo;->le()Z

    move-result p2

    if-eqz p2, :cond_3

    invoke-virtual {p3, v0}, La/m;->G(Z)V

    :cond_3
    invoke-virtual {p1, v1}, Lcomponents/bo;->dC(I)V

    invoke-virtual {p1}, Lcomponents/bo;->le()Z

    move-result p2

    if-eqz p2, :cond_a

    invoke-virtual {p3}, La/m;->gS()La/ac;

    move-result-object p2

    invoke-virtual {p2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_4

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityJogo;->cs(I)V

    goto :goto_3

    :cond_4
    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityJogo;->cs(I)V

    goto :goto_3

    :cond_5
    invoke-virtual {p3}, La/m;->cG()I

    move-result p2

    const/4 v3, 0x5

    if-eq p2, v2, :cond_8

    invoke-virtual {p3}, La/m;->cG()I

    move-result p2

    const/4 v4, 0x4

    if-ne p2, v4, :cond_6

    goto :goto_1

    :cond_6
    invoke-virtual {p3}, La/m;->cG()I

    move-result p2

    if-ne p2, v3, :cond_a

    invoke-virtual {p1}, Lcomponents/bo;->le()Z

    move-result p2

    const/4 v3, 0x6

    if-eqz p2, :cond_7

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityJogo;->cs(I)V

    :cond_7
    invoke-virtual {p3}, La/m;->gS()La/ac;

    move-result-object p2

    invoke-virtual {p2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_a

    goto :goto_2

    :cond_8
    :goto_1
    invoke-virtual {p1}, Lcomponents/bo;->le()Z

    move-result p2

    if-eqz p2, :cond_9

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityJogo;->cs(I)V

    :cond_9
    invoke-virtual {p3}, La/m;->gS()La/ac;

    move-result-object p2

    invoke-virtual {p2}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_a

    invoke-virtual {p3}, La/m;->gW()La/p;

    move-result-object p2

    sput-object p2, Lcom/brasfoot/v2028/ActivityJogo;->Js:La/p;

    :goto_2
    iput p4, p0, Lcom/brasfoot/v2028/ActivityJogo;->yr:I

    sput v3, Lcom/brasfoot/v2028/ActivityJogo;->Jf:I

    :cond_a
    :goto_3
    invoke-virtual {p1}, Lcomponents/bo;->le()Z

    move-result p1

    if-eqz p1, :cond_d

    invoke-virtual {p3}, La/m;->cG()I

    move-result p1

    if-ne p1, v0, :cond_b

    invoke-virtual {p3}, La/m;->gT()I

    move-result p1

    if-ne p1, v2, :cond_b

    invoke-virtual {p3}, La/m;->gZ()Z

    move-result p1

    goto :goto_4

    :cond_b
    const/4 p1, 0x1

    :goto_4
    if-eqz p1, :cond_d

    if-ne v1, v0, :cond_c

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jk:Landroid/widget/TextView;

    invoke-virtual {p3, p0}, La/m;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jm:Landroid/widget/ImageView;

    :goto_5
    invoke-virtual {p3, p0}, La/m;->d(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_c
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jl:Landroid/widget/TextView;

    invoke-virtual {p3, p0}, La/m;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jn:Landroid/widget/ImageView;

    goto :goto_5

    :cond_d
    return-void
.end method

.method public cs(I)V
    .locals 1

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0}, Lest/Options;->isUsaSons()Z

    move-result v0

    if-eqz v0, :cond_6

    if-nez p1, :cond_0

    const/4 p1, 0x0

    const-string v0, "intervalo"

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityJogo;->d(ILjava/lang/String;)V

    return-void

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    const-string p1, "fimjogo"

    :goto_0
    invoke-virtual {p0, v0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->d(ILjava/lang/String;)V

    return-void

    :cond_1
    const/4 v0, 0x2

    if-ne p1, v0, :cond_2

    const-string p1, "gol1"

    goto :goto_0

    :cond_2
    const/4 v0, 0x3

    if-ne p1, v0, :cond_3

    const-string p1, "goladv"

    goto :goto_0

    :cond_3
    const/4 v0, 0x4

    if-ne p1, v0, :cond_4

    const-string p1, "penalty"

    goto :goto_0

    :cond_4
    const/4 v0, 0x5

    if-ne p1, v0, :cond_5

    const-string p1, "expulsao"

    goto :goto_0

    :cond_5
    const/4 v0, 0x6

    if-ne p1, v0, :cond_6

    const-string p1, "contusao"

    goto :goto_0

    :cond_6
    return-void
.end method

.method public d(ILjava/lang/String;)V
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->JB:[Landroid/media/MediaPlayer;

    aget-object v0, v0, p1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_2

    if-eqz v0, :cond_0

    :try_start_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->JB:[Landroid/media/MediaPlayer;

    aget-object v0, v0, p1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :try_start_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->JB:[Landroid/media/MediaPlayer;

    aget-object v0, v0, p1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_2

    :cond_0
    :try_start_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->JB:[Landroid/media/MediaPlayer;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const-string v2, "raw"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, p2, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p2

    invoke-static {p0, p2}, Landroid/media/MediaPlayer;->create(Landroid/content/Context;I)Landroid/media/MediaPlayer;

    move-result-object p2

    aput-object p2, v0, p1
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_2

    :catch_1
    :try_start_4
    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityJogo;->JB:[Landroid/media/MediaPlayer;

    aget-object p1, p2, p1

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->start()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_4} :catch_2

    :catch_2
    return-void
.end method

.method public doAutoSubs(La/t;)V
    .locals 3

    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    iget v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    invoke-static {p1, v0, v1}, Lcom/brasfoot/v2028/Recopa;->autoSubs(La/t;II)V

    return-void
.end method

.method public h(La/t;)V
    .locals 1

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/ActivityJogo;->Jv:Lcomponents/bo;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJogo;->j(La/t;)V

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V

    :cond_1
    return-void
.end method

.method public nj()V
    .locals 4

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    if-nez v0, :cond_1

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jy:Ljava/lang/Runnable;

    if-nez v0, :cond_2

    new-instance v0, Lcom/brasfoot/v2028/ActivityJogo$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityJogo$3;-><init>(Lcom/brasfoot/v2028/ActivityJogo;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jy:Ljava/lang/Runnable;

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jy:Ljava/lang/Runnable;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public nm()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yv:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    if-eqz v1, :cond_1

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ke()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ju()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_0

    sget-object v1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bo;

    invoke-virtual {v1}, Lcomponents/bo;->uE()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yv:Ljava/util/ArrayList;

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_2
    return-void
.end method

.method public nn()V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    if-eqz v2, :cond_0

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jD()I

    move-result v2

    sget-object v3, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uG()I

    move-result v3

    if-eq v2, v3, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    :goto_1
    if-eqz v2, :cond_1

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bo;

    invoke-virtual {v2}, Lcomponents/bo;->uE()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->jP()V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public no()V
    .locals 4

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    const/4 v1, 0x2

    iput v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v2, v1, v0}, La/t;->M(II)V

    :cond_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->getVerJanelaSubs()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->cs(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jh:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v3, 0x7f0b00d6

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v0, -0x1

    invoke-direct {p0, v0, v2}, Lcom/brasfoot/v2028/ActivityJogo;->d(IZ)V

    return-void

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->qy()Z

    return-void
.end method

.method public onBackPressed()V
    .locals 0

    return-void
.end method

.method public onClickFieldInfo(Landroid/view/View;)V
    .locals 1

    const/4 p1, -0x1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityJogo;->d(IZ)V

    return-void
.end method

.method public onClickSettings(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJogo;->cU(I)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJogo;->cT(I)V

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityJogo;->Jt:Z

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityPref;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070015

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->finish()V

    :cond_0
    :goto_0
    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    iget-object p1, p1, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Ju:Ljava/lang/String;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_1

    const-string v0, "index"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jz:I

    :cond_1
    iget p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jz:I

    invoke-static {}, La/i;->gw()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_2

    invoke-static {}, La/i;->gw()Ljava/util/ArrayList;

    move-result-object p1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jz:I

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bt;

    invoke-virtual {p1}, Lcomponents/bt;->uO()Ljava/util/ArrayList;

    move-result-object p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->filterRecopaDayLive(Ljava/util/ArrayList;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->oW:Ljava/util/ArrayList;

    :cond_2
    const p1, 0x7f0601c7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jh:Landroid/widget/TextView;

    const p1, 0x7f060278

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Ji:Landroid/widget/TextView;

    const p1, 0x7f0601c0

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ProgressBar;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jj:Landroid/widget/ProgressBar;

    const p1, 0x7f0600d5

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jk:Landroid/widget/TextView;

    const p1, 0x7f0600d6

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jl:Landroid/widget/TextView;

    const p1, 0x7f06010c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jm:Landroid/widget/ImageView;

    const p1, 0x7f06010d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jn:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jm:Landroid/widget/ImageView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jn:Landroid/widget/ImageView;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget-object p1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    if-nez p1, :cond_3

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    sput-object p1, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    :cond_3
    sget p1, Lcom/brasfoot/v2028/ActivityJogo;->Jq:I

    iput p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    sget p1, Lcom/brasfoot/v2028/ActivityJogo;->Jr:I

    iput p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Ji:Landroid/widget/TextView;

    const v0, 0x7f0b000c

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo;->oW:Ljava/util/ArrayList;

    if-eqz p1, :cond_4

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJogo;->pM()V

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/Recopa;->applyMatchBg(Landroid/app/Activity;La/t;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->qv()V

    return-void
.end method

.method protected onResume()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    sget-object v0, Lc/a;->TF:La/b;

    if-nez v0, :cond_0

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->finish()V

    :cond_0
    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yq:Z

    if-nez v0, :cond_3

    sget-boolean v0, Lcom/brasfoot/v2028/ActivityJogo;->Jt:Z

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    if-nez v0, :cond_2

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jx:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->getVelocidade()I

    move-result v0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->d:I

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->V(Z)V

    return-void

    :cond_3
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->finish()V

    invoke-static {}, La/o;->gG()V

    return-void
.end method

.method public qv()V
    .locals 3

    const v0, 0x7f06018a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/z;

    sget-object v2, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/z;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->JA:Lcomponents/z;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->JA:Lcomponents/z;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityJogo$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityJogo$2;-><init>(Lcom/brasfoot/v2028/ActivityJogo;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public qw()V
    .locals 9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    if-eqz v0, :cond_8

    const v0, 0x7f0601cc

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const v2, 0x3f59999a    # 0.85f

    const/16 v3, 0x10

    const v4, 0x3f4ccccd    # 0.8f

    const/16 v5, 0x19

    const v6, 0x3f333333    # 0.7f

    const/16 v7, 0x20

    if-le v1, v7, :cond_0

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setTextScaleX(F)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-le v1, v5, :cond_1

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextScaleX(F)V

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-le v1, v3, :cond_2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextScaleX(F)V

    :cond_2
    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->ma()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const v1, 0x7f0601cd

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v8, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v8}, La/t;->jj()La/ac;

    move-result-object v8

    invoke-virtual {v8}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v8

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-le v8, v7, :cond_3

    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setTextScaleX(F)V

    goto :goto_1

    :cond_3
    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-le v6, v5, :cond_4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextScaleX(F)V

    goto :goto_1

    :cond_4
    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-le v4, v3, :cond_5

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextScaleX(F)V

    :cond_5
    :goto_1
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ma()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :try_start_0
    const v0, 0x7f06034a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-eqz v0, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1, p0}, La/ac;->f(Landroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->lx()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_6

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getFilesDir()Ljava/io/File;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".png"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v2, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_6

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_6
    const v0, 0x7f06034b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-eqz v0, :cond_7

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1, p0}, La/ac;->f(Landroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->lx()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_7

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getFilesDir()Ljava/io/File;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".png"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v2, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_7

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_7
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->qx()V

    :cond_8
    return-void
.end method

.method public qx()V
    .locals 2

    const v0, 0x7f0601e1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->jD()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601e2

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-virtual {v1}, La/t;->jF()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->upPosse()V

    return-void
.end method

.method public qy()Z
    .locals 8

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->upPosse()V

    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->yn:Ljava/util/ArrayList;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJogo;->nl()V

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-ne v0, v1, :cond_1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    const/16 v4, 0x30

    if-le v0, v4, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->no()V

    return v3

    :cond_1
    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    if-ne v0, v2, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Ji:Landroid/widget/TextView;

    const v4, 0x7f0b000d

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(I)V

    iget v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    const/16 v4, 0x33

    if-lt v0, v4, :cond_2

    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    iget v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    const/16 v5, 0x2d

    if-ge v4, v5, :cond_3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jh:Landroid/widget/TextView;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    iget v7, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, "\'"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jj:Landroid/widget/ProgressBar;

    iget v6, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    invoke-virtual {v4, v6}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->pw:I

    if-ne v4, v2, :cond_4

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Ju:Ljava/lang/String;

    const-string v4, "pt_BR"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jh:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget v6, p0, Lcom/brasfoot/v2028/ActivityJogo;->yo:I

    add-int/2addr v6, v5

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "\'"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_3
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jh:Landroid/widget/TextView;

    const v4, 0x7f0b0010

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(I)V

    :cond_4
    :goto_1
    if-eqz v0, :cond_5

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJogo;->nl()V

    return v1

    :cond_5
    :try_start_0
    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityJogo;->V(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->finish()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJogo;->getBaseContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v2, 0x4000000

    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJogo;->startActivity(Landroid/content/Intent;)V

    return v1
.end method

.method public upPosse()V
    .locals 6

    :try_start_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    if-eqz v0, :cond_1

    const v1, 0x7f06040f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJogo;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    if-eqz v1, :cond_1

    invoke-virtual {v0}, La/t;->jI()[I

    move-result-object v0

    if-eqz v0, :cond_1

    array-length v2, v0

    const/4 v3, 0x2

    if-lt v2, v3, :cond_1

    new-instance v2, Landroid/text/SpannableStringBuilder;

    invoke-direct {v2}, Landroid/text/SpannableStringBuilder;-><init>()V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->aggLine(La/t;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_0

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const-string v3, "\n"

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    :cond_0
    const/4 v3, 0x0

    aget v3, v0, v3

    const/4 v4, 0x1

    aget v4, v0, v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    invoke-static {p0, v5, v3, v4}, Lcom/brasfoot/v2028/Recopa;->posseBarSpan(Landroid/content/Context;La/t;II)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityJogo;->Jg:La/t;

    const-string v3, "\nFinalizacoes: "

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, La/t;->bu(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const-string v3, "  -  "

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, La/t;->bu(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-void

    :catch_0
    move-exception v0

    return-void
.end method
