.class Lcom/brasfoot/v2028/ActivityTeamHistory$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityTeamHistory;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Mx:Lcom/brasfoot/v2028/ActivityTeamHistory;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityTeamHistory;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory$1;->Mx:Lcom/brasfoot/v2028/ActivityTeamHistory;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTeamHistory$1;->Mx:Lcom/brasfoot/v2028/ActivityTeamHistory;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/brasfoot/v2028/ActivityTeamHistory;->a(Lcom/brasfoot/v2028/ActivityTeamHistory;I)V

    return-void
.end method
