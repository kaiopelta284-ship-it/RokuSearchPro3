.class public Lcom/brasfoot/v2028/ActivityClass;
.super Landroid/app/Activity;


# instance fields
.field FD:Landroid/widget/ListView;

.field private FK:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private FL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private FM:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bc;",
            ">;"
        }
    .end annotation
.end field

.field private FN:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bw;",
            ">;"
        }
    .end annotation
.end field

.field private FO:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bp;",
            ">;"
        }
    .end annotation
.end field

.field private FP:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/a;",
            ">;"
        }
    .end annotation
.end field

.field private FQ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private FR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private FS:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private FT:Ld/q;

.field private FU:La/al;

.field private FV:I

.field private FW:Ld/x;

.field private FX:Ld/x;

.field private FY:I

.field private FZ:I

.field Fo:Landroid/widget/Spinner;

.field Fp:Landroid/widget/Spinner;

.field private Fq:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field private Fr:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field Fs:Landroid/widget/ListView;

.field Fv:Landroid/widget/Spinner;

.field Fw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fx:Lcomponents/ai;

.field Fy:Z

.field Fz:I

.field private Ga:La/al;

.field private Gb:I

.field private Gc:I

.field Gd:Z

.field Ge:Z

.field Gf:Z

.field Gg:Z

.field private Gh:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private Gi:I

.field private Gj:I

.field Gk:Landroid/widget/Spinner;

.field Gl:Landroid/widget/Spinner;

.field Gm:Lcomponents/l;

.field Gn:Lcomponents/i;

.field Go:Lcomponents/m;

.field Gp:Lcomponents/am;

.field Gq:Lcomponents/ai;

.field Gr:Landroid/widget/ListView;

.field Gs:Landroid/widget/ViewFlipper;

.field private lU:I


# direct methods
.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fw:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FL:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FO:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FQ:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FR:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FS:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    const/4 v1, 0x0

    iput v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    const/4 v2, -0x1

    iput v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FY:I

    iput v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Ga:La/al;

    iput v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Gb:I

    iput v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Gc:I

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gd:Z

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Ge:Z

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gf:Z

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gg:Z

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    iput v1, p0, Lcom/brasfoot/v2028/ActivityClass;->lU:I

    iput v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fz:I

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityClass;)Ld/q;
    .locals 0

    iget-object p0, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    return-object p0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityClass;ZI)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/brasfoot/v2028/ActivityClass;->a(ZI)V

    return-void
.end method

.method private a(Ld/q;Ld/x;Ld/x;ZZ)V
    .locals 2

    iput-object p2, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    iput-boolean p4, p0, Lcom/brasfoot/v2028/ActivityClass;->Ge:Z

    iput-boolean p5, p0, Lcom/brasfoot/v2028/ActivityClass;->Gd:Z

    const/4 p2, 0x1

    iput-boolean p2, p0, Lcom/brasfoot/v2028/ActivityClass;->Gf:Z

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz p3, :cond_0

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {p3}, Ld/q;->xL()Ld/x;

    move-result-object p3

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_0
    iput p2, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    const/4 v0, 0x0

    if-eqz p3, :cond_1

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {p3}, Ld/q;->cG()I

    move-result p3

    const/4 v1, 0x3

    if-ne p3, v1, :cond_1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :cond_1
    iput v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gc:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gb:I

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ld/q;->xO()I

    move-result p3

    sub-int/2addr p3, p2

    iput p3, p0, Lcom/brasfoot/v2028/ActivityClass;->Gb:I

    :cond_2
    const/4 p3, 0x2

    if-eqz p5, :cond_3

    iget-object p5, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-nez p5, :cond_4

    iput v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto :goto_0

    :cond_3
    if-nez p1, :cond_4

    iput p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :cond_4
    :goto_0
    iget-object p5, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of p5, p5, Ld/y;

    if-eqz p5, :cond_6

    iget-object p5, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-nez p5, :cond_5

    iput v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto :goto_1

    :cond_5
    iget-object p5, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    invoke-virtual {p5}, Ld/x;->yo()Ljava/util/List;

    move-result-object p5

    invoke-interface {p5}, Ljava/util/List;->size()I

    move-result p5

    iput p5, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :cond_6
    :goto_1
    if-eqz p4, :cond_9

    iget-object p4, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz p4, :cond_7

    invoke-virtual {p1}, Ld/q;->xN()Z

    move-result p1

    if-eqz p1, :cond_7

    iput p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    sub-int/2addr p1, p2

    iput p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gc:I

    goto :goto_3

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz p1, :cond_8

    goto :goto_2

    :cond_8
    :goto_3
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityClass;->pq()V

    :cond_9
    return-void
.end method

.method private a(Ld/q;Ljava/lang/String;ZI)V
    .locals 6

    const/16 v0, 0x8

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    const-string v0, ""

    new-instance v1, Lcomponents/bc;

    invoke-direct {v1}, Lcomponents/bc;-><init>()V

    if-nez p3, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Grupo "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v1, p2}, Lcomponents/bc;->setInfo(Ljava/lang/String;)V

    :cond_0
    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    if-eqz p3, :cond_1

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object p2

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/r;

    invoke-virtual {p2}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object p2

    :goto_0
    const/4 p4, 0x0

    move-object v1, v0

    const/4 v0, 0x0

    :goto_1
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_6

    new-instance v2, Lcomponents/bc;

    invoke-direct {v2}, Lcomponents/bc;-><init>()V

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v2, v3}, Lcomponents/bc;->i(La/ac;)V

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3, p1}, La/ac;->d(Ld/q;)[I

    move-result-object v3

    invoke-virtual {v2, v3}, Lcomponents/bc;->k([I)V

    if-nez v0, :cond_2

    const-string v1, "1"

    goto :goto_3

    :cond_2
    if-lez v0, :cond_5

    add-int/lit8 v1, v0, -0x1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1, p1}, La/ac;->d(Ld/q;)[I

    move-result-object v1

    aget v4, v3, p4

    aget v5, v1, p4

    if-ne v4, v5, :cond_4

    const/4 v4, 0x2

    aget v5, v3, v4

    aget v4, v1, v4

    if-ne v5, v4, :cond_4

    const/4 v4, 0x5

    aget v5, v3, v4

    aget v4, v1, v4

    if-ne v5, v4, :cond_4

    const/4 v4, 0x7

    aget v3, v3, v4

    aget v1, v1, v4

    if-eq v3, v1, :cond_3

    goto :goto_2

    :cond_3
    const-string v1, ""

    goto :goto_3

    :cond_4
    :goto_2
    add-int/lit8 v1, v0, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    :cond_5
    :goto_3
    invoke-virtual {v2, v1}, Lcomponents/bc;->P(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_6
    if-nez p3, :cond_7

    new-instance p1, Lcomponents/bc;

    invoke-direct {p1}, Lcomponents/bc;-><init>()V

    const-string p2, ""

    invoke-virtual {p1, p2}, Lcomponents/bc;->setInfo(Ljava/lang/String;)V

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Lcomponents/bc;->ak(Z)V

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method private a(Ld/x;[Ljava/lang/String;Z)V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const v0, 0x7f0b0119

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez p3, :cond_4

    if-eqz p1, :cond_3

    const/4 p3, 0x0

    :goto_0
    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p3, v0, :cond_b

    const/4 v0, 0x0

    :goto_1
    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/ac;

    invoke-virtual {v3}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_1

    new-instance v3, Lcomponents/bw;

    invoke-direct {v3}, Lcomponents/bw;-><init>()V

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/ac;

    invoke-virtual {v4}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v3, v4}, Lcomponents/bw;->m(La/t;)V

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/ac;

    invoke-virtual {v4}, Ld/ac;->ka()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/ac;

    invoke-virtual {v4}, Ld/ac;->yJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v3, v4}, Lcomponents/bw;->n(La/t;)V

    :cond_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1
    new-instance v0, Lcomponents/bw;

    invoke-direct {v0}, Lcomponents/bw;-><init>()V

    array-length v3, p2

    if-ge p3, v3, :cond_2

    aget-object v3, p2, p3

    invoke-virtual {v0, v3}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    :cond_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p3, p3, 0x1

    goto :goto_0

    :cond_3
    new-instance p1, Lcomponents/bw;

    invoke-direct {p1}, Lcomponents/bw;-><init>()V

    :goto_2
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_5

    :cond_4
    if-eqz p1, :cond_a

    const/4 p3, 0x0

    :goto_3
    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p3, v0, :cond_b

    const/4 v0, 0x0

    :goto_4
    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/ac;

    invoke-virtual {v3}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_6

    new-instance v3, Lcomponents/bw;

    invoke-direct {v3}, Lcomponents/bw;-><init>()V

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/ac;

    invoke-virtual {v4}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v3, v4}, Lcomponents/bw;->m(La/t;)V

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/ac;

    invoke-virtual {v4}, Ld/ac;->ka()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/ac;

    invoke-virtual {v4}, Ld/ac;->yJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/t;

    invoke-virtual {v3, v4}, Lcomponents/bw;->n(La/t;)V

    :cond_5
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_6
    new-instance v0, Lcomponents/bw;

    invoke-direct {v0}, Lcomponents/bw;-><init>()V

    array-length v3, p2

    if-ge p3, v3, :cond_7

    aget-object v3, p2, p3

    invoke-virtual {v0, v3}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    :cond_7
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    array-length v0, p2

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ne v0, v3, :cond_9

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/cpaulista;

    if-nez v4, :cond_9

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/sm;

    if-nez v4, :cond_9

    invoke-virtual {p1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    sub-int/2addr v0, v2

    if-ne p3, v0, :cond_9

    new-instance v0, Lcomponents/bw;

    invoke-direct {v0}, Lcomponents/bw;-><init>()V

    const v3, 0x7f0b020c

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x2

    if-lt v3, v4, :cond_8

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    sub-int/2addr v5, v4

    invoke-virtual {v3, v5, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_8
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x4

    if-lt v0, v3, :cond_9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    sub-int/2addr v5, v4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    sub-int/2addr v4, v3

    invoke-static {v0, v5, v4}, Ljava/util/Collections;->swap(Ljava/util/List;II)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x3

    invoke-static {v0, v3, v4}, Ljava/util/Collections;->swap(Ljava/util/List;II)V

    :cond_9
    add-int/lit8 p3, p3, 0x1

    goto/16 :goto_3

    :cond_a
    new-instance p1, Lcomponents/bw;

    invoke-direct {p1}, Lcomponents/bw;-><init>()V

    goto/16 :goto_2

    :cond_b
    :goto_5
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-static {p1}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Go:Lcomponents/m;

    invoke-virtual {p1}, Lcomponents/m;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {p1, v2}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void
.end method

.method private a(ZI)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/brasfoot/v2028/ActivityClass;->b(ZI)V

    return-void
.end method

.method private a(ILd/q;La/al;)Z
    .locals 4

    const/4 v0, 0x0

    if-nez p2, :cond_0

    return v0

    :cond_0
    invoke-virtual {p2}, Ld/q;->xu()I

    move-result v1

    if-lt p1, v1, :cond_1

    return v0

    :cond_1
    iput p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gb:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    const/4 v2, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cY()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, p3, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_4
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FO:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p2}, Ld/q;->cG()I

    move-result v1

    const/4 v2, 0x4

    if-ne v1, v2, :cond_5

    invoke-virtual {p3}, La/al;->iw()I

    move-result p3

    const/4 v1, 0x2

    if-ge p3, v1, :cond_5

    add-int/lit8 p1, p1, 0x4

    :cond_5
    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-lez p3, :cond_7

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-ge p1, p3, :cond_7

    :goto_3
    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/a;

    invoke-virtual {p3}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-ge v0, p3, :cond_7

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/a;

    invoke-virtual {p3}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/t;

    invoke-virtual {p3}, La/t;->jb()La/al;

    move-result-object p3

    if-eqz p3, :cond_6

    invoke-virtual {p3, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_6

    new-instance p3, Lcomponents/bp;

    invoke-direct {p3}, Lcomponents/bp;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FP:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a;

    invoke-virtual {v1}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/t;

    invoke-virtual {p3, v1}, Lcomponents/bp;->o(La/t;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FO:Ljava/util/ArrayList;

    invoke-virtual {v1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gn:Lcomponents/i;

    invoke-virtual {p1}, Lcomponents/i;->notifyDataSetChanged()V

    const/4 p1, 0x1

    return p1
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityClass;ILd/q;La/al;)Z
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lcom/brasfoot/v2028/ActivityClass;->a(ILd/q;La/al;)Z

    move-result p0

    return p0
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityClass;)La/al;
    .locals 0

    iget-object p0, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    return-object p0
.end method

.method private b(ZI)V
    .locals 19

    move-object/from16 v6, p0

    move/from16 v1, p2

    iput v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    const v2, 0x7f060131

    invoke-virtual {v6, v2}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/16 v7, 0x8

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-static {v6, v4}, Lcom/brasfoot/v2028/Recopa;->showSupercopa(Landroid/app/Activity;La/al;)Z

    move-result v4

    if-eqz v4, :cond_0

    return-void

    :cond_0
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gs:Landroid/widget/ViewFlipper;

    const/4 v8, 0x0

    invoke-virtual {v4, v8}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    iput v4, v6, Lcom/brasfoot/v2028/ActivityClass;->lU:I

    const/4 v9, 0x1

    if-eqz p1, :cond_1

    iget v4, v6, Lcom/brasfoot/v2028/ActivityClass;->lU:I

    if-ne v4, v9, :cond_1

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->uS()La/y;

    move-result-object v0

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->d(La/y;)V

    return-void

    :cond_1
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    iget v5, v6, Lcom/brasfoot/v2028/ActivityClass;->lU:I

    invoke-virtual {v4, v5}, Lcomponents/l;->do(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Go:Lcomponents/m;

    iget-object v5, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v5}, La/al;->cG()I

    move-result v5

    invoke-virtual {v4, v5}, Lcomponents/m;->do(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const v5, 0x7f06014a

    const/4 v10, 0x3

    const/4 v11, 0x4

    if-eq v4, v11, :cond_3

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    if-ne v4, v10, :cond_2

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v4, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v4, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_0

    :cond_2
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    :cond_3
    :goto_0
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const/4 v12, 0x6

    if-eq v4, v11, :cond_7

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const/4 v13, 0x7

    if-eq v4, v13, :cond_7

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const/16 v13, 0x9

    if-ne v4, v13, :cond_4

    goto :goto_1

    :cond_4
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    const/16 v13, 0xc

    if-ne v4, v13, :cond_5

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v4, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_2

    :cond_5
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    if-ne v4, v12, :cond_6

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->iw()I

    move-result v4

    if-nez v4, :cond_6

    goto :goto_1

    :cond_6
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    if-ne v4, v12, :cond_8

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->iw()I

    move-result v4

    if-ne v4, v9, :cond_8

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v4, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_2

    :cond_7
    :goto_1
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v4, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    :cond_8
    :goto_2
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    if-ne v4, v9, :cond_9

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v4, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_3

    :cond_9
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v4, v7}, Landroid/widget/Spinner;->setVisibility(I)V

    :goto_3
    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v4}, La/al;->cG()I

    move-result v4

    if-ne v4, v9, :cond_10

    if-eqz p1, :cond_a

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->uS()La/y;

    move-result-object v0

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->d(La/y;)V

    :cond_a
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->uS()La/y;

    move-result-object v0

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    iput-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Ld/q;->xN()Z

    move-result v0

    if-eqz v0, :cond_d

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    iput-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz p1, :cond_b

    const/4 v0, 0x3

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    :cond_b
    const v0, 0x7f06014a

    invoke-virtual {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-eqz v0, :cond_c

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->bracketNames(Ld/x;)[Ljava/lang/String;

    move-result-object v1

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    const/4 v2, 0x0

    invoke-direct {v6, v0, v1, v2}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    return-void

    :cond_c
    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x4

    const v12, 0x7f0b020a

    const v13, 0x7f0b0208

    const v14, 0x7f0b01f6

    const v15, 0x7f0b0206

    const v3, 0x7f0b0204

    const v4, 0x7f0b01f6

    const v5, 0x7f0b020a

    goto/16 :goto_9

    :cond_d
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_f

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_f

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xO()I

    move-result v0

    sub-int/2addr v0, v9

    iput v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->h(Ld/q;)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    invoke-virtual {v0}, Lcomponents/l;->notifyDataSetChanged()V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget-object v0, v0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "pt_BR"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->pp()V

    goto :goto_4

    :cond_e
    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->po()V

    :goto_4
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    invoke-virtual {v0}, Lcomponents/am;->notifyDataSetChanged()V

    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    :goto_5
    invoke-direct {v6, v0, v1, v2}, Lcom/brasfoot/v2028/ActivityClass;->a(ILd/q;La/al;)Z

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void

    :cond_f
    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->pm()V

    const v0, 0x7f0b00ce

    invoke-virtual {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_10
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/16 v3, 0x8

    if-eq v2, v3, :cond_11

    :goto_6
    const v3, 0x7f0b0204

    const v13, 0x7f0b0208

    const/4 v14, 0x5

    const v15, 0x7f0b0206

    const v5, 0x7f0b020a

    const v4, 0x7f0b01f6

    const/4 v7, 0x2

    if-ne v2, v7, :cond_18

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    check-cast v0, La/y;

    invoke-virtual {v0}, La/y;->kZ()Ld/x;

    move-result-object v1

    if-eqz v1, :cond_75

    invoke-virtual {v0}, La/y;->kZ()Ld/x;

    move-result-object v1

    invoke-virtual {v1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/String;

    const v12, 0x7f0b01fe

    invoke-virtual {v6, v12}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v2, v8

    const v12, 0x7f0b01fa

    invoke-virtual {v6, v12}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v2, v9

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v2, v7

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v2, v10

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v2, v11

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v2, v14

    invoke-virtual {v6, v4}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v12

    const/4 v4, 0x6

    aput-object v12, v2, v4

    if-ne v1, v14, :cond_14

    new-array v2, v4, [Ljava/lang/String;

    const v1, 0x7f0b01fa

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v8

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v9

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v7

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v10

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v11

    const v1, 0x7f0b01f6

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v14

    goto/16 :goto_8

    :cond_11
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v3, Ld/z;

    if-nez v4, :cond_12

    instance-of v4, v3, Ld/aa;

    if-nez v4, :cond_13

    goto/16 :goto_6

    :cond_12
    check-cast v3, Ld/z;

    invoke-virtual {v3}, Ld/z;->yE()Ld/x;

    move-result-object v3

    goto :goto_7

    :cond_13
    check-cast v3, Ld/aa;

    invoke-virtual {v3}, Ld/aa;->yE()Ld/x;

    move-result-object v3

    :goto_7
    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/String;

    iget-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    const/4 v5, 0x0

    invoke-direct {v6, v4, v3, v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    return-void

    :cond_14
    if-ne v1, v11, :cond_15

    new-array v2, v14, [Ljava/lang/String;

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v8

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v9

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v7

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v10

    const v4, 0x7f0b01f6

    invoke-virtual {v6, v4}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v11

    goto :goto_8

    :cond_15
    const v4, 0x7f0b01f6

    if-ne v1, v11, :cond_16

    new-array v2, v14, [Ljava/lang/String;

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v8

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v9

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v7

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v10

    invoke-virtual {v6, v4}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v11

    goto :goto_8

    :cond_16
    if-ne v1, v10, :cond_17

    new-array v2, v11, [Ljava/lang/String;

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v8

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v9

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v7

    invoke-virtual {v6, v4}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v10

    :cond_17
    :goto_8
    invoke-virtual {v0}, La/y;->kZ()Ld/x;

    move-result-object v0

    invoke-direct {v6, v0, v2, v8}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    return-void

    :cond_18
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    if-ne v2, v10, :cond_1e

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v2, v8}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v2}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v2

    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    check-cast v2, Ld/q;

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz p1, :cond_19

    invoke-direct {v6, v10}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    move-object v0, v6

    const v14, 0x7f0b01f6

    move v4, v12

    const v12, 0x7f0b020a

    move v5, v13

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    sub-int/2addr v1, v9

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_9

    :cond_19
    const v12, 0x7f0b020a

    const v14, 0x7f0b01f6

    iput v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_9
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-nez v0, :cond_1b

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->h(Ld/q;)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    invoke-virtual {v0}, Lcomponents/l;->notifyDataSetChanged()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    invoke-virtual {v0}, Lcomponents/am;->notifyDataSetChanged()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xO()I

    move-result v0

    sub-int/2addr v0, v9

    iput v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xO()I

    move-result v0

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v1}, Ld/q;->xu()I

    move-result v1

    if-le v0, v1, :cond_1a

    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    sub-int/2addr v0, v9

    iput v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    :cond_1a
    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->po()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    invoke-virtual {v0}, Lcomponents/am;->notifyDataSetChanged()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-direct {v6, v0, v1, v2}, Lcom/brasfoot/v2028/ActivityClass;->a(ILd/q;La/al;)Z

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gn:Lcomponents/i;

    invoke-virtual {v0}, Lcomponents/i;->notifyDataSetChanged()V

    return-void

    :cond_1b
    new-array v0, v11, [Ljava/lang/String;

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v12}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v7

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v10

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v1}, Ld/q;->xK()I

    move-result v1

    if-ge v1, v11, :cond_1c

    new-array v0, v7, [Ljava/lang/String;

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    goto :goto_a

    :cond_1c
    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v1}, Ld/q;->xK()I

    move-result v1

    const/16 v2, 0x8

    if-ge v1, v2, :cond_1d

    new-array v0, v7, [Ljava/lang/String;

    invoke-virtual {v6, v12}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    :cond_1d
    :goto_a
    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :goto_b
    invoke-direct {v6, v1, v0, v8}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    return-void

    :cond_1e
    const v5, 0x7f0b01f6

    const v12, 0x7f0b020a

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/4 v4, 0x0

    if-eq v2, v11, :cond_1f

    const/4 v3, 0x6

    if-eq v2, v3, :cond_1f

    const/16 v3, 0xc

    if-eq v2, v3, :cond_1f

    goto/16 :goto_14

    :cond_1f
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/t;

    if-eqz v2, :cond_20

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dV()Ld/t;

    move-result-object v2

    invoke-virtual {v2}, Ld/t;->getFaseGrupos()Ld/q;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dV()Ld/t;

    move-result-object v2

    invoke-virtual {v2}, Ld/t;->xr()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dV()Ld/t;

    move-result-object v2

    invoke-virtual {v2}, Ld/t;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_33

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dV()Ld/t;

    move-result-object v2

    invoke-virtual {v2}, Ld/t;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    goto/16 :goto_c

    :cond_20
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/cpaulista;

    if-eqz v2, :cond_22

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v2, v2, La/b;->cpaulistaCopa:Ld/cpaulista;

    invoke-virtual {v2}, Ld/cpaulista;->getFaseGrupos()Ld/q;

    move-result-object v3

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v3, :cond_21

    invoke-virtual {v3}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_21
    const/4 v4, 0x1

    goto/16 :goto_d

    :cond_22
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/p;

    if-eqz v2, :cond_24

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dR()Ld/p;

    move-result-object v2

    invoke-virtual {v2}, Ld/p;->getFaseGrupos()Ld/q;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dR()Ld/p;

    move-result-object v2

    invoke-virtual {v2}, Ld/p;->xr()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dR()Ld/p;

    move-result-object v2

    invoke-virtual {v2}, Ld/p;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_23

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dR()Ld/p;

    move-result-object v2

    invoke-virtual {v2}, Ld/p;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_23
    const/4 v4, 0x1

    goto/16 :goto_d

    :cond_24
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/ad;

    if-eqz v2, :cond_26

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dU()Ld/ad;

    move-result-object v2

    invoke-virtual {v2}, Ld/ad;->getFaseGrupos()Ld/q;

    move-result-object v3

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dU()Ld/ad;

    move-result-object v2

    invoke-virtual {v2}, Ld/ad;->yE()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dU()Ld/ad;

    move-result-object v2

    invoke-virtual {v2}, Ld/ad;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_25

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dU()Ld/ad;

    move-result-object v2

    invoke-virtual {v2}, Ld/ad;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_25
    const/4 v4, 0x1

    goto/16 :goto_d

    :cond_26
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/ag;

    if-eqz v2, :cond_29

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->d0()Ld/ag;

    move-result-object v2

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v3

    if-nez v3, :cond_27

    invoke-virtual {v2}, Ld/ag;->xi()V

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v3

    :cond_27
    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->d0()Ld/ag;

    move-result-object v2

    const/4 v3, 0x0

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->d0()Ld/ag;

    move-result-object v2

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_28

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_28
    const/4 v4, 0x1

    goto/16 :goto_d

    :cond_29
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/v;

    if-eqz v2, :cond_2b

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dX()Ld/v;

    move-result-object v2

    invoke-virtual {v2}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v3

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dX()Ld/v;

    move-result-object v2

    const/4 v3, 0x0

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dX()Ld/v;

    move-result-object v2

    invoke-virtual {v2}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_2a

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_2a
    const/4 v4, 0x1

    goto/16 :goto_d

    :cond_2b
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/u;

    if-eqz v2, :cond_2d

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dZ()Ld/u;

    move-result-object v2

    invoke-virtual {v2}, Ld/u;->getFaseGrupos()Ld/q;

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dZ()Ld/u;

    move-result-object v2

    invoke-virtual {v2}, Ld/u;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_2c

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dZ()Ld/u;

    move-result-object v2

    invoke-virtual {v2}, Ld/u;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_2c
    const/4 v4, 0x4

    goto/16 :goto_d

    :cond_2d
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/s;

    if-eqz v2, :cond_2f

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eb()Ld/s;

    move-result-object v2

    invoke-virtual {v2}, Ld/s;->getFaseGrupos()Ld/q;

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eb()Ld/s;

    move-result-object v2

    invoke-virtual {v2}, Ld/s;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_2e

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eb()Ld/s;

    move-result-object v2

    invoke-virtual {v2}, Ld/s;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_2e
    const/4 v4, 0x3

    goto :goto_d

    :cond_2f
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/r;

    if-eqz v2, :cond_31

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ea()Ld/r;

    move-result-object v2

    invoke-virtual {v2}, Ld/r;->getFaseGrupos()Ld/q;

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ea()Ld/r;

    move-result-object v2

    invoke-virtual {v2}, Ld/r;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_30

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ea()Ld/r;

    move-result-object v2

    invoke-virtual {v2}, Ld/r;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_30
    const/4 v4, 0x2

    goto :goto_d

    :cond_31
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/w;

    if-eqz v2, :cond_33

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dY()Ld/w;

    move-result-object v2

    invoke-virtual {v2}, Ld/w;->getFaseGrupos()Ld/q;

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dY()Ld/w;

    move-result-object v2

    invoke-virtual {v2}, Ld/w;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_32

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dY()Ld/w;

    move-result-object v2

    invoke-virtual {v2}, Ld/w;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_32
    const/4 v4, 0x5

    goto :goto_d

    :cond_33
    :goto_c
    const/4 v4, 0x0

    :goto_d
    if-eqz p1, :cond_42

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/cpaulista;

    if-eqz v0, :cond_34

    const/4 v0, 0x3

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    goto :goto_f

    :cond_34
    if-eqz v4, :cond_36

    if-ne v4, v9, :cond_35

    goto :goto_e

    :cond_35
    const/16 v0, 0x2c

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    goto :goto_f

    :cond_36
    :goto_e
    invoke-direct {v6, v11}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    :goto_f
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/t;

    if-eqz v0, :cond_37

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v0

    invoke-virtual {v0}, Ld/t;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v0

    invoke-virtual {v0}, Ld/t;->xr()Ld/x;

    move-result-object v3

    const/16 v16, 0x1

    const/16 v17, 0x1

    move-object v0, v6

    move v12, v4

    move/from16 v4, v16

    move/from16 v5, v17

    :goto_10
    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    goto/16 :goto_12

    :cond_37
    move v12, v4

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/cpaulista;

    if-eqz v0, :cond_38

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->cpaulistaCopa:Ld/cpaulista;

    invoke-virtual {v0}, Ld/cpaulista;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->cpaulistaCopa:Ld/cpaulista;

    invoke-virtual {v0}, Ld/cpaulista;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v3

    const/16 v16, 0x1

    const/16 v17, 0x1

    move-object v0, v6

    move/from16 v4, v16

    move/from16 v5, v17

    goto/16 :goto_10

    :cond_38
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/p;

    if-eqz v0, :cond_39

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dR()Ld/p;

    move-result-object v0

    invoke-virtual {v0}, Ld/p;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dR()Ld/p;

    move-result-object v0

    invoke-virtual {v0}, Ld/p;->xr()Ld/x;

    move-result-object v3

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object v0, v6

    goto :goto_10

    :cond_39
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/ad;

    if-eqz v0, :cond_3c

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->yE()Ld/x;

    move-result-object v3

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object v0, v6

    goto :goto_10

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/ag;

    if-eqz v0, :cond_3b

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v1

    if-nez v1, :cond_3a

    invoke-virtual {v0}, Ld/ag;->xi()V

    invoke-virtual {v0}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v1

    :cond_3a
    iput-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object v0, v6

    goto/16 :goto_10

    :cond_3b
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/v;

    if-eqz v0, :cond_3c

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object v0, v6

    goto/16 :goto_10

    :cond_3c
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/u;

    if-eqz v0, :cond_3e

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dZ()Ld/u;

    move-result-object v0

    invoke-virtual {v0}, Ld/u;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dZ()Ld/u;

    move-result-object v0

    invoke-virtual {v0}, Ld/u;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    if-nez v0, :cond_3d

    :goto_11
    iput v8, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto/16 :goto_12

    :cond_3d
    iput v9, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto/16 :goto_12

    :cond_3e
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/s;

    if-eqz v0, :cond_3f

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eb()Ld/s;

    move-result-object v0

    invoke-virtual {v0}, Ld/s;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eb()Ld/s;

    move-result-object v0

    invoke-virtual {v0}, Ld/s;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    if-nez v0, :cond_3d

    goto :goto_11

    :cond_3f
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/r;

    if-eqz v0, :cond_40

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ea()Ld/r;

    move-result-object v0

    invoke-virtual {v0}, Ld/r;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ea()Ld/r;

    move-result-object v0

    invoke-virtual {v0}, Ld/r;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    if-nez v0, :cond_3d

    goto :goto_11

    :cond_40
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/w;

    if-eqz v0, :cond_41

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dY()Ld/w;

    move-result-object v0

    invoke-virtual {v0}, Ld/w;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dY()Ld/w;

    move-result-object v0

    invoke-virtual {v0}, Ld/w;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    if-nez v0, :cond_3d

    goto/16 :goto_11

    :cond_41
    :goto_12
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_13

    :cond_42
    move v12, v4

    iput v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_13
    if-eq v12, v11, :cond_43

    if-eq v12, v10, :cond_43

    if-eq v12, v7, :cond_43

    if-ne v12, v14, :cond_44

    :cond_43
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    add-int/2addr v0, v9

    iput v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :cond_44
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-ne v0, v9, :cond_45

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_75

    goto/16 :goto_25

    :cond_45
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-nez v0, :cond_46

    new-array v0, v7, [Ljava/lang/String;

    const v1, 0x7f0b01ff

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    const v1, 0x7f0b0201

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    goto/16 :goto_b

    :cond_46
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-ne v0, v7, :cond_7b

    new-array v0, v11, [Ljava/lang/String;

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    const v1, 0x7f0b020a

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v7

    const v5, 0x7f0b01f6

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v10

    if-ne v12, v11, :cond_47

    new-array v0, v10, [Ljava/lang/String;

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v8

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v7

    goto/16 :goto_a

    :cond_47
    if-ne v12, v14, :cond_1d

    new-array v0, v7, [Ljava/lang/String;

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    goto/16 :goto_a

    :goto_14
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    if-ne v2, v14, :cond_48

    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->pn()V

    return-void

    :cond_48
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/4 v12, 0x6

    if-ne v2, v12, :cond_50

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->iw()I

    move-result v2

    if-ne v2, v9, :cond_50

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->getFaseGrupos()Ld/q;

    move-result-object v1

    if-eqz v1, :cond_49

    invoke-virtual {v0}, Ld/ad;->yE()Ld/x;

    move-result-object v2

    if-nez v2, :cond_4d

    move-object v0, v2

    goto :goto_15

    :cond_49
    invoke-virtual {v0}, Ld/ad;->yE()Ld/x;

    move-result-object v0

    if-nez v0, :cond_4d

    :goto_15
    invoke-virtual {v0}, Ld/x;->yp()I

    move-result v0

    const/4 v1, 0x7

    new-array v1, v1, [Ljava/lang/String;

    const v2, 0x7f0b01fe

    invoke-virtual {v6, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v8

    const v2, 0x7f0b01fa

    invoke-virtual {v6, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v9

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v10

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v11

    const v2, 0x7f0b020a

    invoke-virtual {v6, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v14

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    aput-object v2, v1, v4

    if-ne v0, v14, :cond_4a

    new-array v1, v4, [Ljava/lang/String;

    const v0, 0x7f0b01fa

    invoke-virtual {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v8

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v9

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v7

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v10

    const v0, 0x7f0b020a

    invoke-virtual {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v11

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v14

    goto :goto_16

    :cond_4a
    if-ne v0, v11, :cond_4b

    new-array v1, v14, [Ljava/lang/String;

    invoke-virtual {v6, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v8

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v9

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v7

    const v2, 0x7f0b020a

    invoke-virtual {v6, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v10

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v11

    goto :goto_16

    :cond_4b
    const v2, 0x7f0b020a

    if-ne v0, v10, :cond_4c

    new-array v1, v11, [Ljava/lang/String;

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v8

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v9

    invoke-virtual {v6, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v7

    invoke-virtual {v6, v5}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v10

    :cond_4c
    :goto_16
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->yE()Ld/x;

    move-result-object v0

    if-nez v0, :cond_4d

    invoke-direct {v6, v0, v1, v8}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    return-void

    :cond_4d
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v0

    invoke-virtual {v0}, Ld/ad;->getFaseGrupos()Ld/q;

    move-result-object v1

    iput-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v1}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    const/4 v2, 0x0

    invoke-virtual {v0}, Ld/ad;->yE()Ld/x;

    move-result-object v3

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    iget v10, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v10, v9, :cond_4e

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    goto :goto_17

    :cond_4e
    if-eqz v3, :cond_4f

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/String;

    invoke-direct {v6, v3, v0, v8}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    :cond_4f
    :goto_17
    const/16 v0, 0x5a

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void

    :cond_50
    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/16 v3, 0xc

    if-eq v2, v3, :cond_56

    const/4 v3, 0x6

    if-ne v2, v3, :cond_5b

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->iw()I

    move-result v2

    if-nez v2, :cond_5b

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dX()Ld/v;

    move-result-object v2

    invoke-virtual {v2}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dX()Ld/v;

    move-result-object v2

    invoke-virtual {v2}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_51

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dX()Ld/v;

    move-result-object v2

    invoke-virtual {v2}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_51
    if-eqz p1, :cond_53

    const/4 v0, 0x6

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v12, 0x0

    move-object v0, v6

    const v14, 0x7f0b01f6

    move v5, v12

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v0

    invoke-virtual {v0}, Ld/v;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    if-nez v0, :cond_52

    iput v8, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto :goto_18

    :cond_52
    iput v9, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_18
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_19

    :cond_53
    const v14, 0x7f0b01f6

    iput v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_19
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-nez v0, :cond_55

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_54

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->h(Ld/q;)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    invoke-virtual {v0}, Lcomponents/l;->notifyDataSetChanged()V

    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->po()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    invoke-virtual {v0}, Lcomponents/am;->notifyDataSetChanged()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xO()I

    move-result v0

    sub-int/2addr v0, v9

    iput v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-direct {v6, v0, v1, v2}, Lcom/brasfoot/v2028/ActivityClass;->a(ILd/q;La/al;)Z

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_1a

    :cond_54
    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->pm()V

    :cond_55
    :goto_1a
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-ne v0, v9, :cond_7b

    new-array v0, v11, [Ljava/lang/String;

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    const v1, 0x7f0b020a

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v7

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v10

    goto/16 :goto_a

    :cond_56
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->d0()Ld/ag;

    move-result-object v2

    if-eqz v2, :cond_5b

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v0

    if-nez v0, :cond_57

    invoke-virtual {v2}, Ld/ag;->xi()V

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v2

    goto :goto_1b

    :cond_57
    move-object v2, v0

    :goto_1b
    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->d0()Ld/ag;

    move-result-object v2

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v2

    if-eqz v2, :cond_58

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->d0()Ld/ag;

    move-result-object v2

    invoke-virtual {v2}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v2

    invoke-virtual {v2}, Ld/q;->xL()Ld/x;

    move-result-object v2

    iput-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_58
    if-eqz p1, :cond_5a

    const/4 v0, 0x6

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v12, 0x0

    move-object v0, v6

    const v14, 0x7f0b01f6

    move v5, v12

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    invoke-virtual {v0}, Ld/ag;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v0

    if-nez v0, :cond_59

    iput v8, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto :goto_1c

    :cond_59
    iput v9, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_1c
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto/16 :goto_19

    :cond_5a
    const v14, 0x7f0b01f6

    iput v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto/16 :goto_19

    :cond_5b
    const v14, 0x7f0b01f6

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/4 v3, 0x7

    if-eq v2, v3, :cond_5c

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    invoke-virtual {v2}, La/al;->cG()I

    move-result v2

    const/16 v3, 0x9

    if-eq v2, v3, :cond_5c

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/sm;

    if-nez v2, :cond_5c

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/css;

    if-nez v2, :cond_5c

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/cne;

    if-nez v2, :cond_5c

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/cv;

    if-nez v2, :cond_5c

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, Ld/cpaulista;

    if-eqz v2, :cond_7b

    :cond_5c
    iput-object v4, v6, Lcom/brasfoot/v2028/ActivityClass;->FX:Ld/x;

    const/4 v2, -0x1

    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/sm;

    if-eqz v3, :cond_5d

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, v3, La/b;->superMundial:Ld/sm;

    goto :goto_1d

    :cond_5d
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/css;

    if-eqz v3, :cond_5e

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, v3, La/b;->cssCopa:Ld/css;

    goto :goto_1d

    :cond_5e
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/cne;

    if-eqz v3, :cond_5f

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, v3, La/b;->cneCopa:Ld/cne;

    goto :goto_1d

    :cond_5f
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/cv;

    if-eqz v3, :cond_60

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, v3, La/b;->cvCopa:Ld/cv;

    goto :goto_1d

    :cond_60
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/cpaulista;

    if-eqz v3, :cond_61

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, v3, La/b;->cpaulistaCopa:Ld/cpaulista;

    goto :goto_1d

    :cond_61
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/o;

    if-eqz v3, :cond_63

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->fe()Ld/o;

    move-result-object v4

    :cond_62
    :goto_1d
    const/4 v2, 0x0

    const/4 v12, -0x1

    goto/16 :goto_20

    :cond_63
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/n;

    if-eqz v3, :cond_64

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->fg()Ld/n;

    move-result-object v4

    const/4 v2, 0x0

    :goto_1e
    const/4 v12, 0x0

    goto/16 :goto_20

    :cond_64
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/ouro;

    if-eqz v3, :cond_65

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->ouroCopa:Ld/ouro;

    const/4 v2, 0x0

    goto :goto_1f

    :cond_65
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/africa;

    if-eqz v3, :cond_66

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->africaCopa:Ld/africa;

    const/4 v2, 0x0

    goto :goto_1f

    :cond_66
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/asia;

    if-eqz v3, :cond_67

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->asiaCopa:Ld/asia;

    const/4 v2, 0x0

    goto :goto_1f

    :cond_67
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/ofc;

    if-eqz v3, :cond_68

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->ofcCopa:Ld/ofc;

    const/4 v2, 0x0

    goto :goto_1f

    :cond_68
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/c;

    if-eqz v3, :cond_69

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ff()Ld/c;

    move-result-object v4

    const/4 v2, 0x0

    :goto_1f
    const/4 v12, 0x1

    goto :goto_20

    :cond_69
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/j;

    if-eqz v3, :cond_6a

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->fp()Ld/j;

    move-result-object v4

    const/4 v2, 0x1

    goto :goto_1e

    :cond_6a
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/elimcc;

    if-eqz v3, :cond_6b

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->elimccCopa:Ld/elimcc;

    const/4 v2, 0x1

    goto :goto_1f

    :cond_6b
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/elimaf;

    if-eqz v3, :cond_6c

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->africaElimCopa:Ld/elimaf;

    const/4 v2, 0x1

    goto :goto_1f

    :cond_6c
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/elimas;

    if-eqz v3, :cond_6d

    sget-object v2, Lc/a;->TF:La/b;

    iget-object v4, v2, La/b;->asiaElimCopa:Ld/elimas;

    const/4 v2, 0x1

    goto :goto_1f

    :cond_6d
    iget-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/l;

    if-eqz v3, :cond_62

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->fo()Ld/l;

    move-result-object v4

    const/4 v2, 0x1

    goto :goto_1f

    :goto_20
    if-eqz v4, :cond_7b

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v0, v0, Ld/cpaulista;

    if-eqz v0, :cond_70

    invoke-interface {v4}, Lest/CopasNacionaisINT;->getFaseGrupos()Ld/q;

    move-result-object v0

    iput-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_70

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v1

    iput-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    const v0, 0x7f06014a

    invoke-virtual {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setVisibility(I)V

    if-eqz p1, :cond_6e

    const/16 v0, 0x4d

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    :cond_6e
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-eqz v0, :cond_6f

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz v0, :cond_6f

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->cupBracketNames(Ld/x;)[Ljava/lang/String;

    move-result-object v1

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    const/4 v2, 0x0

    invoke-direct {v6, v0, v1, v2}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    return-void

    :cond_6f
    goto/16 :goto_25

    :cond_70
    invoke-interface {v4}, Lest/CopasNacionaisINT;->getFaseGrupos()Ld/q;

    move-result-object v3

    if-eqz v3, :cond_71

    invoke-interface {v4}, Lest/CopasNacionaisINT;->getFaseGrupos()Ld/q;

    move-result-object v3

    invoke-virtual {v3}, Ld/q;->xL()Ld/x;

    move-result-object v3

    iput-object v3, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    :cond_71
    if-eqz p1, :cond_74

    if-nez v2, :cond_72

    const/16 v0, 0x4d

    :goto_21
    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->cJ(I)V

    goto :goto_22

    :cond_72
    const/16 v0, 0x5a

    goto :goto_21

    :goto_22
    iput-boolean v9, v6, Lcom/brasfoot/v2028/ActivityClass;->Gg:Z

    invoke-interface {v4}, Lest/CopasNacionaisINT;->getFaseGrupos()Ld/q;

    move-result-object v0

    invoke-virtual {v0}, Ld/q;->xL()Ld/x;

    move-result-object v16

    invoke-interface {v4}, Lest/CopasNacionaisINT;->getFaseGrupos()Ld/q;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ld/x;Ld/x;ZZ)V

    if-nez v16, :cond_73

    iput v8, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    goto :goto_23

    :cond_73
    iput v9, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_23
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_24

    :cond_74
    iput v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    :goto_24
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-nez v0, :cond_76

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_75

    :goto_25
    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-direct {v6, v0}, Lcom/brasfoot/v2028/ActivityClass;->h(Ld/q;)V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    invoke-virtual {v0}, Lcomponents/l;->notifyDataSetChanged()V

    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->po()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    invoke-virtual {v0}, Lcomponents/am;->notifyDataSetChanged()V

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v0}, Ld/q;->xO()I

    move-result v0

    sub-int/2addr v0, v9

    iput v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FV:I

    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v2, v6, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    goto/16 :goto_5

    :cond_75
    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivityClass;->pm()V

    return-void

    :cond_76
    iget v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FZ:I

    if-ne v0, v9, :cond_7b

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz v0, :cond_78

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v0, :cond_77

    iget-object v0, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    invoke-virtual {v0}, Ld/x;->yp()I

    move-result v0

    goto :goto_26

    :cond_77
    if-eqz v0, :cond_7b

    invoke-virtual {v0}, Ld/q;->xD()I

    move-result v0

    goto :goto_26

    :cond_78
    if-eqz v0, :cond_7b

    invoke-virtual {v0}, Ld/x;->yp()I

    move-result v0

    :goto_26
    if-lt v0, v11, :cond_79

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b0204

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v7

    const v1, 0x7f0b020a

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v10

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v11

    goto :goto_27

    :cond_79
    new-array v0, v11, [Ljava/lang/String;

    invoke-virtual {v6, v13}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v8

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    const v1, 0x7f0b020a

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v7

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v10

    :goto_27
    if-ne v12, v9, :cond_7a

    new-array v0, v10, [Ljava/lang/String;

    invoke-virtual {v6, v15}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v8

    invoke-virtual {v6, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v9

    invoke-virtual {v6, v14}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v7

    :cond_7a
    iget-object v1, v6, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    invoke-direct {v6, v1, v0, v9}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/x;[Ljava/lang/String;Z)V

    :cond_7b
    return-void
.end method

.method private cJ(I)V
    .locals 4

    const v0, 0x7f0b01fb

    const v1, 0x7f0b01fc

    const/4 v2, 0x3

    if-ne p1, v2, :cond_0

    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    :goto_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_2
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_3
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_0
    const/4 v2, 0x6

    const v3, 0x7f0b01fe

    if-ne p1, v2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_1
    const/16 v2, 0x2c

    if-ne p1, v2, :cond_2

    goto :goto_0

    :cond_2
    const/4 v2, 0x4

    if-ne p1, v2, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    const/16 v0, 0x4d

    const v1, 0x7f0b01f4

    if-ne p1, v0, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    const v0, 0x7f0b01f9

    :goto_4
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_4
    const/16 v0, 0x5a

    if-ne p1, v0, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    const v0, 0x7f0b01fd

    goto :goto_4

    :cond_5
    :goto_5
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityClass;->pl()V

    return-void
.end method

.method private d(La/y;)V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b007d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b0075

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0077

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b0079

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const v1, 0x7f0b007b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->Fw:Ljava/util/ArrayList;

    add-int/lit8 v1, v1, 0x1

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    new-instance p1, Lcomponents/ai;

    const v0, 0x7f070066

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fw:Ljava/util/ArrayList;

    invoke-direct {p1, p0, v0, v1}, Lcomponents/ai;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fx:Lcomponents/ai;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fx:Lcomponents/ai;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityClass$7;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityClass$7;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fz:I

    const/4 v0, -0x1

    if-le p1, v0, :cond_1

    iget p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fz:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    if-gt p1, v1, :cond_1

    iget v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fz:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fz:I

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private h(Ld/q;)V
    .locals 12

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    if-nez p1, :cond_0

    new-instance p1, Lcomponents/bc;

    invoke-direct {p1}, Lcomponents/bc;-><init>()V

    const v0, 0x7f0b0119

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcomponents/bc;->setInfo(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_0
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_1

    const-string v0, ""

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0, v2, v1}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ljava/lang/String;ZI)V

    goto :goto_1

    :cond_1
    invoke-virtual {p1}, Ld/q;->yd()Z

    move-result v2

    if-nez v2, :cond_4

    const/16 v0, 0xc

    new-array v0, v0, [Ljava/lang/String;

    const-string v3, "A"

    const/4 v4, 0x0

    aput-object v3, v0, v4

    const-string v3, "B"

    const/4 v4, 0x1

    aput-object v3, v0, v4

    const-string v3, "C"

    const/4 v4, 0x2

    aput-object v3, v0, v4

    const-string v3, "D"

    const/4 v4, 0x3

    aput-object v3, v0, v4

    const-string v3, "E"

    const/4 v4, 0x4

    aput-object v3, v0, v4

    const-string v3, "F"

    const/4 v4, 0x5

    aput-object v3, v0, v4

    const-string v3, "G"

    const/4 v4, 0x6

    aput-object v3, v0, v4

    const-string v3, "H"

    const/4 v4, 0x7

    aput-object v3, v0, v4

    const-string v3, "I"

    const/16 v4, 0x8

    aput-object v3, v0, v4

    const-string v3, "J"

    const/16 v4, 0x9

    aput-object v3, v0, v4

    const-string v3, "K"

    const/16 v4, 0xa

    aput-object v3, v0, v4

    const-string v3, "L"

    const/16 v4, 0xb

    aput-object v3, v0, v4

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    add-int/lit8 v3, v2, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    iget-boolean v5, p0, Lcom/brasfoot/v2028/ActivityClass;->Gg:Z

    if-eqz v5, :cond_2

    array-length v6, v0

    if-ge v2, v6, :cond_2

    aget-object v4, v0, v2

    :cond_2
    invoke-direct {p0, p1, v4, v1, v2}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ljava/lang/String;ZI)V

    move v2, v3

    goto :goto_0

    :cond_3
    goto :goto_1

    :cond_4
    const-string v0, ""

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0, p1, v0, v2, v3}, Lcom/brasfoot/v2028/ActivityClass;->a(Ld/q;Ljava/lang/String;ZI)V

    :goto_1
    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->i(Ld/q;)V

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->j(Ld/q;)Z

    return-void
.end method

.method private i(Ld/q;)V
    .locals 14

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Ld/q;->xK()I

    move-result v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/j;

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/l;

    if-eqz v4, :cond_1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/elimcc;

    if-eqz v4, :cond_2

    const/4 v3, 0x6

    :cond_2
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/elimaf;

    if-eqz v4, :cond_3

    const/4 v3, 0x1

    :cond_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v4, v4, Ld/elimas;

    if-eqz v4, :cond_4

    const/4 v3, 0x2

    :cond_4
    :goto_0
    const/16 v4, 0x8

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-nez v3, :cond_5

    invoke-virtual {p1}, Ld/q;->getDivisao()I

    move-result v3

    if-le v3, v6, :cond_d

    invoke-virtual {p1}, Ld/q;->xZ()I

    move-result v3

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-lez v9, :cond_d

    const/4 v9, 0x0

    :goto_1
    if-ge v9, v3, :cond_d

    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_1

    :cond_5
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-eqz v9, :cond_c

    invoke-virtual {p1}, Ld/q;->yd()Z

    move-result v9

    if-eqz v9, :cond_6

    goto/16 :goto_8

    :cond_6
    const/4 v9, 0x0

    :goto_2
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_8

    const/4 v10, 0x0

    :goto_3
    if-ge v10, v3, :cond_7

    iget-object v11, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v12

    invoke-virtual {v12, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/r;

    invoke-virtual {v12}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v12

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    goto :goto_3

    :cond_7
    add-int/lit8 v9, v9, 0x1

    goto :goto_2

    :cond_8
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v9, 0xc

    if-ne v3, v9, :cond_a

    iget-boolean v3, p1, Ld/q;->melhoresTerceiros:Z

    if-eqz v3, :cond_a

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x0

    :goto_4
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_9

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/r;

    invoke-virtual {v10}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_4

    :cond_9
    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-static {v9}, Ld/q;->m(Ld/q;)V

    sget-object v9, Ld/q;->Wu:Ljava/util/Comparator;

    invoke-static {v3, v9}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v9, 0x0

    :goto_5
    if-ge v9, v4, :cond_d

    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_5

    :cond_a
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v9, 0x11

    if-ne v3, v9, :cond_d

    iget-boolean v3, p1, Ld/q;->melhoresTerceiros:Z

    if-eqz v3, :cond_d

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x0

    :goto_6
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_b

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/r;

    invoke-virtual {v10}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_6

    :cond_b
    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-static {v9}, Ld/q;->m(Ld/q;)V

    sget-object v9, Ld/q;->Wu:Ljava/util/Comparator;

    invoke-static {v3, v9}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v9, 0x0

    :goto_7
    const/16 v10, 0xf

    if-ge v9, v10, :cond_d

    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_7

    :cond_c
    :goto_8
    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-lez v9, :cond_d

    const/4 v9, 0x0

    :goto_9
    if-ge v9, v3, :cond_d

    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_9

    :cond_d
    invoke-virtual {p1}, Ld/q;->cG()I

    move-result v3

    if-ne v3, v6, :cond_12

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->isJogaIntClubes()Z

    move-result v3

    if-eqz v3, :cond_12

    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v3

    invoke-virtual {v3}, La/y;->iw()I

    move-result v3

    if-ne v3, v6, :cond_f

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dR()Ld/p;

    move-result-object v3

    invoke-virtual {v3, v8}, Ld/p;->cz(I)La/ac;

    move-result-object v3

    if-eqz v3, :cond_e

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_e
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dU()Ld/ad;

    move-result-object v3

    if-eqz v3, :cond_12

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dU()Ld/ad;

    move-result-object v3

    invoke-virtual {v3, v8}, Ld/ad;->cz(I)La/ac;

    move-result-object v3

    if-eqz v3, :cond_12

    goto :goto_a

    :cond_f
    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v3

    invoke-virtual {v3}, La/y;->iw()I

    move-result v3

    if-nez v3, :cond_12

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dV()Ld/t;

    move-result-object v3

    invoke-virtual {v3, v8}, Ld/t;->cz(I)La/ac;

    move-result-object v3

    if-eqz v3, :cond_10

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_10
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dX()Ld/v;

    move-result-object v3

    if-eqz v3, :cond_12

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dX()Ld/v;

    move-result-object v3

    invoke-virtual {v3, v8}, Ld/v;->cz(I)La/ac;

    move-result-object v3

    if-eqz v3, :cond_11

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_11
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->d0()Ld/ag;

    move-result-object v3

    if-eqz v3, :cond_12

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->d0()Ld/ag;

    move-result-object v3

    invoke-virtual {v3, v8}, Ld/ag;->cz(I)La/ac;

    move-result-object v3

    if-eqz v3, :cond_12

    :goto_a
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_12
    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v3

    if-eqz v3, :cond_13

    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v3

    invoke-virtual {v3}, La/y;->iw()I

    move-result v3

    if-eqz v3, :cond_13

    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v3

    invoke-virtual {v3, v8}, La/y;->cz(I)La/ac;

    move-result-object v3

    if-eqz v3, :cond_13

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_13
    invoke-virtual {p1}, Ld/q;->getDivisao()I

    move-result v3

    if-ne v3, v6, :cond_1a

    invoke-virtual {p1}, Ld/q;->cG()I

    move-result v3

    if-ne v3, v6, :cond_1a

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->isJogaIntClubes()Z

    move-result v3

    if-eqz v3, :cond_1a

    invoke-virtual {p1}, Ld/q;->ya()[I

    move-result-object v3

    const/4 v9, 0x0

    :goto_b
    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_15

    aget v10, v3, v8

    if-lez v10, :cond_14

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_14

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v10, v3, v8

    sub-int/2addr v10, v6

    aput v10, v3, v8

    :cond_14
    add-int/lit8 v9, v9, 0x1

    goto :goto_b

    :cond_15
    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v9

    invoke-virtual {v9}, La/y;->iw()I

    move-result v9

    if-eq v9, v6, :cond_16

    invoke-virtual {p1}, Ld/q;->uS()La/y;

    move-result-object v9

    invoke-virtual {v9}, La/y;->iw()I

    move-result v9

    if-nez v9, :cond_18

    :cond_16
    const/4 v9, 0x0

    :goto_c
    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_18

    aget v10, v3, v7

    if-lez v10, :cond_17

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_17

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v10, v3, v7

    sub-int/2addr v10, v6

    aput v10, v3, v7

    :cond_17
    add-int/lit8 v9, v9, 0x1

    goto :goto_c

    :cond_18
    aget v9, v3, v6

    if-lez v9, :cond_1a

    const/4 v9, 0x0

    :goto_d
    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_1a

    aget v10, v3, v6

    if-lez v10, :cond_19

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_19

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_19

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_19

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v10, v3, v6

    sub-int/2addr v10, v6

    aput v10, v3, v6

    :cond_19
    add-int/lit8 v9, v9, 0x1

    goto :goto_d

    :cond_1a
    invoke-virtual {p1}, Ld/q;->ya()[I

    move-result-object v3

    if-eqz v3, :cond_1c

    const/4 v10, 0x3

    aget v10, v3, v10

    if-lez v10, :cond_1c

    const/4 v9, 0x0

    :goto_e
    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_1c

    const/4 v10, 0x3

    aget v11, v3, v10

    if-lez v11, :cond_1b

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_1b

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_1b

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_1b

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v13, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aget v11, v3, v10

    sub-int/2addr v11, v6

    aput v11, v3, v10

    :cond_1b
    add-int/lit8 v9, v9, 0x1

    goto :goto_e

    :cond_1c
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/j;

    if-eqz v3, :cond_1e

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x0

    :goto_f
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_1d

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/r;

    invoke-virtual {v10}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_f

    :cond_1d
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-static {p1}, Ld/q;->m(Ld/q;)V

    sget-object p1, Ld/q;->Wu:Ljava/util/Comparator;

    invoke-static {v3, p1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 p1, 0x0

    :goto_10
    if-ge p1, v4, :cond_1f

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_10

    :cond_1e
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v3, v3, Ld/l;

    if-eqz v3, :cond_1f

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1f
    const/4 p1, 0x0

    :goto_11
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p1, v3, :cond_21

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bc;

    invoke-virtual {v4}, Lcomponents/bc;->hE()La/ac;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_20

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bc;

    invoke-virtual {v3, v6}, Lcomponents/bc;->du(I)V

    :cond_20
    add-int/lit8 p1, p1, 0x1

    goto :goto_11

    :cond_21
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_23

    const/4 p1, 0x0

    :goto_12
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge p1, v3, :cond_23

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bc;

    invoke-virtual {v3}, Lcomponents/bc;->hE()La/ac;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_22

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bc;

    invoke-virtual {v3, v7}, Lcomponents/bc;->du(I)V

    :cond_22
    add-int/lit8 p1, p1, 0x1

    goto :goto_12

    :cond_23
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_25

    const/4 p1, 0x0

    :goto_13
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_25

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bc;

    invoke-virtual {v0}, Lcomponents/bc;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bc;

    invoke-virtual {v0, v5}, Lcomponents/bc;->du(I)V

    :cond_24
    add-int/lit8 p1, p1, 0x1

    goto :goto_13

    :cond_25
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_27

    :goto_14
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v8, p1, :cond_27

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bc;

    invoke-virtual {p1}, Lcomponents/bc;->hE()La/ac;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_26

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bc;

    const/4 v0, 0x5

    invoke-virtual {p1, v0}, Lcomponents/bc;->du(I)V

    :cond_26
    add-int/lit8 v8, v8, 0x1

    goto :goto_14

    :cond_27
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_29

    const/4 p1, 0x0

    :goto_15
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_29

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bc;

    invoke-virtual {v0}, Lcomponents/bc;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_28

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bc;

    const/4 v1, 0x6

    invoke-virtual {v0, v1}, Lcomponents/bc;->du(I)V

    :cond_28
    add-int/lit8 p1, p1, 0x1

    goto :goto_15

    :cond_29
    return-void
.end method

.method private j(Ld/q;)Z
    .locals 8

    invoke-virtual {p1}, Ld/q;->cG()I

    move-result v0

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eq v0, v2, :cond_0

    invoke-virtual {p1}, Ld/q;->cG()I

    move-result v0

    if-ne v0, v1, :cond_9

    :cond_0
    invoke-virtual {p1}, Ld/q;->cG()I

    move-result v0

    const/4 v3, 0x0

    if-ne v0, v2, :cond_1

    invoke-virtual {p1}, Ld/q;->nR()La/y;

    move-result-object v0

    invoke-virtual {v0}, La/y;->kK()I

    move-result v0

    const/16 v4, 0x1d

    if-ne v0, v4, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eA()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Ld/q;->getDivisao()I

    move-result v0

    const/4 v4, 0x4

    if-ne v0, v4, :cond_1

    return v3

    :cond_1
    invoke-virtual {p1}, Ld/q;->getnRebaixados()I

    move-result v0

    invoke-virtual {p1}, Ld/q;->xP()Z

    move-result v4

    invoke-virtual {p1}, Ld/q;->xP()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_2

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    div-int/2addr v0, v5

    int-to-float v0, v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    :cond_2
    invoke-virtual {p1}, Ld/q;->xX()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {p1}, Ld/q;->xY()I

    move-result v5

    if-ge v5, v0, :cond_3

    invoke-virtual {p1}, Ld/q;->xY()I

    move-result v0

    :cond_3
    if-lez v0, :cond_9

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    if-eqz v4, :cond_5

    const/4 v4, 0x0

    :goto_0
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v4, v6, :cond_7

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/r;

    invoke-virtual {v6}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    sub-int/2addr v6, v2

    :goto_1
    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/r;

    invoke-virtual {v7}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    sub-int/2addr v7, v0

    if-lt v6, v7, :cond_4

    invoke-virtual {p1}, Ld/q;->xC()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/r;

    invoke-virtual {v7}, La/r;->ja()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, -0x1

    goto :goto_1

    :cond_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_5
    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    sub-int/2addr v4, v2

    :goto_2
    if-ltz v4, :cond_7

    if-lez v0, :cond_6

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityClass;->Gh:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_6

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    :cond_6
    add-int/lit8 v4, v4, -0x1

    goto :goto_2

    :cond_7
    :goto_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v3, p1, :cond_9

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bc;

    invoke-virtual {p1}, Lcomponents/bc;->hE()La/ac;

    move-result-object p1

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_8

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bc;

    invoke-virtual {p1, v1}, Lcomponents/bc;->du(I)V

    :cond_8
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_9
    return v2
.end method

.method private pj()V
    .locals 8

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v0

    if-eqz v0, :cond_a

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v0

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->jb()La/al;

    move-result-object v1

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_0
    if-eqz v1, :cond_1

    invoke-virtual {v1}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_1
    const/4 v3, -0x1

    :goto_0
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v4, :cond_4

    const/4 v4, 0x3

    if-ne v3, v4, :cond_4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v4, v5}, Landroid/widget/Spinner;->setSelection(I)V

    const/4 v4, 0x0

    :goto_1
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_4

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/bu;

    invoke-virtual {v7}, Lcomponents/bu;->uR()La/al;

    move-result-object v7

    if-eq v7, v0, :cond_3

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/bu;

    invoke-virtual {v7}, Lcomponents/bu;->uR()La/al;

    move-result-object v7

    if-ne v7, v1, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v7, v4}, Landroid/widget/Spinner;->setSelection(I)V

    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    :cond_4
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    if-nez v4, :cond_7

    if-ne v3, v6, :cond_7

    const/4 v3, 0x0

    :goto_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_7

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    if-eqz v4, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    invoke-virtual {v4}, La/y;->kC()I

    move-result v4

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v7

    if-ne v4, v7, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v4, v3}, Landroid/widget/Spinner;->setSelection(I)V

    if-eqz v2, :cond_5

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v3

    if-lez v3, :cond_5

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v2

    sub-int/2addr v2, v6

    iput v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fz:I

    :cond_5
    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    goto :goto_4

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_7
    :goto_4
    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    if-nez v2, :cond_a

    :goto_5
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v5, v2, :cond_a

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    if-eq v2, v0, :cond_9

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    if-ne v2, v1, :cond_8

    goto :goto_6

    :cond_8
    add-int/lit8 v5, v5, 0x1

    goto :goto_5

    :cond_9
    :goto_6
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v0, v5}, Landroid/widget/Spinner;->setSelection(I)V

    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityClass;->Fy:Z

    :cond_a
    return-void
.end method

.method private pl()V
    .locals 3

    new-instance v0, Lcomponents/ai;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FK:Ljava/util/ArrayList;

    const v2, 0x7f070066

    invoke-direct {v0, p0, v2, v1}, Lcomponents/ai;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gq:Lcomponents/ai;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gq:Lcomponents/ai;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityClass$8;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityClass$8;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    return-void
.end method

.method private pm()V
    .locals 3

    const v0, 0x7f060131

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    invoke-virtual {v1}, Lcomponents/l;->notifyDataSetChanged()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Go:Lcomponents/m;

    invoke-virtual {v1}, Lcomponents/m;->notifyDataSetChanged()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gs:Landroid/widget/ViewFlipper;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    const v1, 0x7f0b0119

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private pn()V
    .locals 11

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b01fe

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b020a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b01f6

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    aput-object v1, v0, v4

    const v1, 0x7f0b020c

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    aput-object v1, v0, v5

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->ee()Ld/y;

    move-result-object v1

    invoke-virtual {v1}, Ld/y;->yB()Ld/x;

    move-result-object v1

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->ee()Ld/y;

    move-result-object v6

    invoke-virtual {v6}, Ld/y;->yC()Ld/x;

    move-result-object v6

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    if-eqz v1, :cond_3

    const/4 v7, 0x0

    :goto_0
    invoke-virtual {v1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-ge v7, v8, :cond_4

    const/4 v8, 0x0

    :goto_1
    invoke-virtual {v1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v9

    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ld/ac;

    invoke-virtual {v9}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v8, v9, :cond_1

    new-instance v9, Lcomponents/bw;

    invoke-direct {v9}, Lcomponents/bw;-><init>()V

    invoke-virtual {v1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ld/ac;

    invoke-virtual {v10}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/t;

    invoke-virtual {v9, v10}, Lcomponents/bw;->m(La/t;)V

    invoke-virtual {v1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ld/ac;

    invoke-virtual {v10}, Ld/ac;->ka()Z

    move-result v10

    if-eqz v10, :cond_0

    invoke-virtual {v1}, Ld/x;->yo()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ld/ac;

    invoke-virtual {v10}, Ld/ac;->yJ()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/t;

    invoke-virtual {v9, v10}, Lcomponents/bw;->n(La/t;)V

    :cond_0
    iget-object v10, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_1
    new-instance v8, Lcomponents/bw;

    invoke-direct {v8}, Lcomponents/bw;-><init>()V

    array-length v9, v0

    if-ge v7, v9, :cond_2

    aget-object v9, v0, v2

    invoke-virtual {v8, v9}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    :cond_2
    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_3
    new-instance v1, Lcomponents/bw;

    invoke-direct {v1}, Lcomponents/bw;-><init>()V

    const v7, 0x7f0b0119

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    if-eqz v6, :cond_c

    :goto_2
    invoke-virtual {v6}, Ld/x;->yo()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v2, v1, :cond_c

    invoke-virtual {v6}, Ld/x;->yo()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld/ac;

    invoke-virtual {v1}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v3

    :goto_3
    if-ltz v1, :cond_9

    new-instance v7, Lcomponents/bw;

    invoke-direct {v7}, Lcomponents/bw;-><init>()V

    invoke-virtual {v6}, Ld/x;->yo()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/ac;

    invoke-virtual {v8}, Ld/ac;->yI()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v7, v8}, Lcomponents/bw;->m(La/t;)V

    invoke-virtual {v6}, Ld/x;->yo()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/ac;

    invoke-virtual {v8}, Ld/ac;->ka()Z

    move-result v8

    if-eqz v8, :cond_5

    invoke-virtual {v6}, Ld/x;->yo()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld/ac;

    invoke-virtual {v8}, Ld/ac;->yJ()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/t;

    invoke-virtual {v7, v8}, Lcomponents/bw;->n(La/t;)V

    :cond_5
    iget-object v8, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-ne v2, v3, :cond_7

    if-nez v1, :cond_7

    new-instance v7, Lcomponents/bw;

    invoke-direct {v7}, Lcomponents/bw;-><init>()V

    array-length v8, v0

    if-ge v2, v8, :cond_6

    aget-object v8, v0, v4

    :goto_4
    invoke-virtual {v7, v8}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    :cond_6
    iget-object v8, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_7
    if-ne v2, v3, :cond_8

    if-ne v1, v3, :cond_8

    new-instance v7, Lcomponents/bw;

    invoke-direct {v7}, Lcomponents/bw;-><init>()V

    array-length v8, v0

    if-ge v2, v8, :cond_6

    aget-object v8, v0, v5

    goto :goto_4

    :cond_8
    :goto_5
    add-int/lit8 v1, v1, -0x1

    goto :goto_3

    :cond_9
    if-nez v2, :cond_b

    new-instance v1, Lcomponents/bw;

    invoke-direct {v1}, Lcomponents/bw;-><init>()V

    array-length v7, v0

    if-ge v2, v7, :cond_a

    aget-object v7, v0, v3

    invoke-virtual {v1, v7}, Lcomponents/bw;->Q(Ljava/lang/String;)V

    :cond_a
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_2

    :cond_c
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Go:Lcomponents/m;

    invoke-virtual {v0}, Lcomponents/m;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {v0, v3}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void
.end method

.method private po()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v1}, Ld/q;->xu()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->FL:Ljava/util/ArrayList;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "\u00aa rodada"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-void
.end method

.method private pp()V
    .locals 7

    const-string v0, ""

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f010003

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    :try_start_0
    aget-object v3, v1, v2

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v3, 0x0

    :goto_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FL:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    :goto_1
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v4}, Ld/q;->xu()I

    move-result v4

    if-ge v2, v4, :cond_3

    add-int/lit8 v2, v2, 0x1

    array-length v4, v1

    if-ge v2, v4, :cond_0

    aget-object v4, v1, v2

    goto :goto_2

    :cond_0
    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    :goto_2
    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v5

    const v6, 0x7f0b01a8

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    if-nez v3, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_3
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_4

    :cond_1
    const/4 v6, 0x1

    if-ne v3, v6, :cond_2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_3

    :cond_2
    :goto_4
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityClass;->FL:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    return-void
.end method

.method private pq()V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FQ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FR:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x7

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    new-array v0, v0, [Ljava/lang/String;

    const v2, 0x7f0b01fe

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v0, v3

    const v2, 0x7f0b01fa

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    aput-object v2, v0, v4

    const v2, 0x7f0b0204

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    aput-object v2, v0, v5

    const v2, 0x7f0b0208

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    aput-object v2, v0, v5

    const v2, 0x7f0b0206

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    aput-object v2, v0, v6

    const v2, 0x7f0b020a

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    aput-object v2, v0, v6

    const v2, 0x7f0b01f6

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityClass;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    aput-object v2, v0, v6

    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Gd:Z

    if-eqz v2, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ld/x;->yo()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v2, 0x7

    sub-int/2addr v2, v3

    move v3, v2

    goto :goto_1

    :cond_0
    const/4 v3, 0x3

    goto :goto_1

    :cond_1
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    if-eqz v2, :cond_2

    array-length v2, v0

    sub-int/2addr v2, v4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FW:Ld/x;

    invoke-virtual {v3}, Ld/x;->yp()I

    move-result v3

    :goto_0
    sub-int v3, v2, v3

    goto :goto_1

    :cond_2
    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Gf:Z

    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    if-eqz v2, :cond_3

    array-length v2, v0

    sub-int/2addr v2, v4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    invoke-virtual {v3}, Ld/q;->xD()I

    move-result v3

    goto :goto_0

    :cond_3
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    instance-of v2, v2, La/y;

    if-eqz v2, :cond_4

    array-length v2, v0

    sub-int/2addr v2, v4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->FU:La/al;

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kG()I

    move-result v3

    goto :goto_0

    :cond_4
    :goto_1
    array-length v2, v0

    if-ge v3, v2, :cond_5

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FQ:Ljava/util/ArrayList;

    aget-object v4, v0, v3

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FR:Ljava/util/ArrayList;

    aget v4, v1, v3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FS:Ljava/util/ArrayList;

    const-string v4, ""

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_5
    return-void

    :array_0
    .array-data 4
        0x40
        0x20
        0x10
        0x8
        0x4
        0x2
        0x1
    .end array-data
.end method


# virtual methods
.method public onClickL(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    if-lez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_0
    return-void
.end method

.method public onClickR(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getCount()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_0
    return-void
.end method

.method public onClickShowJogos(Landroid/view/View;)V
    .locals 2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FT:Ld/q;

    const/4 v1, 0x0

    invoke-direct {p0, v1, p1, v0}, Lcom/brasfoot/v2028/ActivityClass;->a(ILd/q;La/al;)Z

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070005

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityClass;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityClass;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityClass;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityClass;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityClass;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityClass;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityClass;->finish()V

    :cond_0
    :goto_0
    const p1, 0x7f06022b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fv:Landroid/widget/Spinner;

    const p1, 0x7f060233

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    new-instance p1, Lcomponents/bu;

    invoke-direct {p1}, Lcomponents/bu;-><init>()V

    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0, v0}, Lcomponents/bu;->a(Landroid/content/Context;IZ)Ljava/util/ArrayList;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    new-instance v2, Lcomponents/k;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityClass;->Fq:Ljava/util/ArrayList;

    invoke-direct {v2, p0, v0, v3}, Lcomponents/k;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fo:Landroid/widget/Spinner;

    new-instance v2, Lcom/brasfoot/v2028/ActivityClass$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivityClass$1;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-virtual {p1, p0}, Lcomponents/bu;->k(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->Rq:Ljava/util/Comparator;

    invoke-static {p1, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const p1, 0x7f060231

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gl:Landroid/widget/Spinner;

    const p1, 0x7f0600e7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ViewFlipper;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gs:Landroid/widget/ViewFlipper;

    const p1, 0x7f060236

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    new-instance p1, Lcomponents/am;

    const v1, 0x7f070066

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->FL:Ljava/util/ArrayList;

    invoke-direct {p1, p0, v1, v2, v0}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gp:Lcomponents/am;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gk:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityClass$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityClass$2;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const p1, 0x7f060230

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    new-instance v0, Lcomponents/k;

    const/4 v1, 0x1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityClass;->Fr:Ljava/util/ArrayList;

    invoke-direct {v0, p0, v1, v2}, Lcomponents/k;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fp:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityClass$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityClass$3;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const p1, 0x7f06017a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fs:Landroid/widget/ListView;

    new-instance p1, Lcomponents/l;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FM:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/l;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fs:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gm:Lcomponents/l;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Fs:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityClass$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityClass$4;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const p1, 0x7f06017d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FD:Landroid/widget/ListView;

    new-instance p1, Lcomponents/i;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FO:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/i;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gn:Lcomponents/i;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FD:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Gn:Lcomponents/i;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->FD:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityClass$5;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityClass$5;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const p1, 0x7f06017e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityClass;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gr:Landroid/widget/ListView;

    new-instance p1, Lcomponents/m;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->FN:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/m;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Go:Lcomponents/m;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gr:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityClass;->Go:Lcomponents/m;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass;->Gr:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityClass$6;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityClass$6;-><init>(Lcom/brasfoot/v2028/ActivityClass;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityClass;->pj()V

    return-void
.end method
