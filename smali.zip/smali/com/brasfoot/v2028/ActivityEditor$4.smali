.class final Lcom/brasfoot/v2028/ActivityEditor$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityEditor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Le/g;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Le/g;Le/g;)I
    .locals 0

    invoke-virtual {p2}, Le/g;->getPosicao()I

    move-result p2

    invoke-virtual {p1}, Le/g;->getPosicao()I

    move-result p1

    if-eq p2, p1, :cond_0

    sub-int/2addr p1, p2

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Le/g;

    check-cast p2, Le/g;

    invoke-virtual {p0, p1, p2}, Lcom/brasfoot/v2028/ActivityEditor$4;->a(Le/g;Le/g;)I

    move-result p1

    return p1
.end method
