.class Lcom/brasfoot/v2028/ActivitySub$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivitySub;->pw()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Mq:Lcom/brasfoot/v2028/ActivitySub;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivitySub;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub$1;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub$1;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivitySub;->a(Lcom/brasfoot/v2028/ActivitySub;)V

    return-void
.end method
