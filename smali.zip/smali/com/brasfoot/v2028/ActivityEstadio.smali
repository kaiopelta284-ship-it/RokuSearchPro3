.class public Lcom/brasfoot/v2028/ActivityEstadio;
.super Landroid/app/Activity;


# instance fields
.field private IA:Z

.field private IB:Ljava/util/Calendar;

.field IC:Landroid/widget/Button;

.field ID:Landroid/widget/Button;

.field IE:Landroid/widget/TextView;

.field IF:Landroid/widget/TextView;

.field private IG:I

.field private Iv:La/ac;

.field private Iw:[I

.field private Ix:[I

.field private Iy:[I

.field private Iz:[I

.field private qX:La/l;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iy:[I

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IA:Z

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    return-void

    nop

    :array_0
    .array-data 4
        0x4650
        0x13880
        0x2328
        0x2bc
    .end array-data
.end method

.method public static G(Ljava/lang/String;)Z
    .locals 1

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    return v0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityEstadio;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->qi()V

    return-void
.end method

.method private ah(II)I
    .locals 9

    const/4 v0, 0x4

    new-array v1, v0, [[I

    const/4 v2, 0x5

    new-array v3, v2, [I

    fill-array-data v3, :array_0

    const/4 v4, 0x0

    aput-object v3, v1, v4

    new-array v3, v2, [I

    fill-array-data v3, :array_1

    const/4 v5, 0x1

    aput-object v3, v1, v5

    new-array v3, v2, [I

    fill-array-data v3, :array_2

    const/4 v6, 0x2

    aput-object v3, v1, v6

    new-array v3, v2, [I

    fill-array-data v3, :array_3

    const/4 v7, 0x3

    aput-object v3, v1, v7

    new-array v3, v0, [[I

    new-array v8, v2, [I

    fill-array-data v8, :array_4

    aput-object v8, v3, v4

    new-array v8, v2, [I

    fill-array-data v8, :array_5

    aput-object v8, v3, v5

    new-array v5, v2, [I

    fill-array-data v5, :array_6

    aput-object v5, v3, v6

    new-array v2, v2, [I

    fill-array-data v2, :array_7

    aput-object v2, v3, v7

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iy:[I

    aget v2, v2, p1

    add-int/2addr v2, p2

    :goto_0
    aget-object v5, v3, p1

    array-length v5, v5

    if-ge v4, v5, :cond_1

    aget-object v5, v3, p1

    aget v5, v5, v4

    if-gt v2, v5, :cond_0

    move v0, v4

    goto :goto_1

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    aget-object p1, v1, p1

    aget p1, p1, v0

    mul-int p1, p1, p2

    mul-int/lit8 p1, p1, 0x5

    return p1

    :array_0
    .array-data 4
        0x50
        0xa0
        0xf0
        0x1f4
        0x2bc
    .end array-data

    :array_1
    .array-data 4
        0x78
        0x17c
        0x280
        0x2bc
        0x578
    .end array-data

    :array_2
    .array-data 4
        0x12c
        0x258
        0x2ee
        0x320
        0x4b0
    .end array-data

    :array_3
    .array-data 4
        0x5dc
        0xdac
        0xfa0
        0x1770
        0x1900
    .end array-data

    :array_4
    .array-data 4
        0x3e8
        0x9c4
        0xdac
        0x2710
        0x4650
    .end array-data

    :array_5
    .array-data 4
        0x1388
        0x3a98
        0x7530
        0xea60
        0x13880
    .end array-data

    :array_6
    .array-data 4
        0x3e8
        0x7d0
        0xbb8
        0x1388
        0x2328
    .end array-data

    :array_7
    .array-data 4
        0x64
        0xc8
        0x1f4
        0x258
        0x2bc
    .end array-data
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityEstadio;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->qk()V

    return-void
.end method

.method private cP(I)I
    .locals 1

    const/16 v0, 0x3e8

    if-ge p1, v0, :cond_0

    const/16 p1, 0xf

    return p1

    :cond_0
    const/16 v0, 0x2710

    if-ge p1, v0, :cond_1

    const/16 p1, 0x14

    return p1

    :cond_1
    const/16 v0, 0x7530

    if-ge p1, v0, :cond_2

    const/16 p1, 0x1e

    return p1

    :cond_2
    const/16 p1, 0x28

    return p1
.end method

.method private loadPrecos()V
    .locals 3

    const v0, 0x7f060433

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    check-cast v0, Landroid/widget/TextView;

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->sociosText()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    if-eqz v0, :cond_1

    const v1, 0x7f060410

    iget v2, v0, La/ac;->precoGeral:I

    invoke-direct {p0, v1, v2}, Lcom/brasfoot/v2028/ActivityEstadio;->pf(II)V

    const v1, 0x7f060411

    iget v2, v0, La/ac;->precoArq:I

    invoke-direct {p0, v1, v2}, Lcom/brasfoot/v2028/ActivityEstadio;->pf(II)V

    const v1, 0x7f060412

    iget v2, v0, La/ac;->precoCad:I

    invoke-direct {p0, v1, v2}, Lcom/brasfoot/v2028/ActivityEstadio;->pf(II)V

    const v1, 0x7f060413

    iget v2, v0, La/ac;->precoCam:I

    invoke-direct {p0, v1, v2}, Lcom/brasfoot/v2028/ActivityEstadio;->pf(II)V

    :cond_1
    return-void
.end method

.method private static parsePreco(Landroid/widget/EditText;)I
    .locals 2

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    :try_start_0
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v0, 0x0

    :cond_0
    :goto_0
    return v0
.end method

.method private pf(II)V
    .locals 2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    if-eqz v0, :cond_1

    if-gtz p2, :cond_0

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_0
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    return-void
.end method

.method private qi()V
    .locals 10

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IE:Landroid/widget/TextView;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IF:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->ID:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    const v2, 0x7f0600b3

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f0600b0

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/EditText;

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f0600b1

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/EditText;

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const v5, 0x7f0600b2

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, ""

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_0

    const-string v6, "\\d+"

    invoke-virtual {v2, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-static {v2}, Lcom/brasfoot/v2028/ActivityEstadio;->G(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    if-lez v6, :cond_0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    const-string v6, ""

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    const-string v6, "\\d+"

    invoke-virtual {v3, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-static {v3}, Lcom/brasfoot/v2028/ActivityEstadio;->G(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    if-lez v6, :cond_1

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    :goto_1
    const-string v6, ""

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2

    const-string v6, "\\d+"

    invoke-virtual {v4, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-static {v4}, Lcom/brasfoot/v2028/ActivityEstadio;->G(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    if-lez v6, :cond_2

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    goto :goto_2

    :cond_2
    const/4 v4, 0x0

    :goto_2
    const-string v6, ""

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3

    const-string v6, "\\d+"

    invoke-virtual {v5, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-static {v5}, Lcom/brasfoot/v2028/ActivityEstadio;->G(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    if-lez v6, :cond_3

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    goto :goto_3

    :cond_3
    const/4 v5, 0x0

    :goto_3
    new-array v1, v1, [I

    aput v2, v1, v0

    const/4 v6, 0x1

    aput v3, v1, v6

    const/4 v7, 0x2

    aput v4, v1, v7

    const/4 v8, 0x3

    aput v5, v1, v8

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    aget v1, v1, v0

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    aget v9, v9, v6

    add-int/2addr v1, v9

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    aget v9, v9, v7

    add-int/2addr v1, v9

    iget-object v9, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    aget v9, v9, v8

    add-int/2addr v1, v9

    if-nez v1, :cond_4

    :goto_4
    const/4 v1, 0x0

    goto :goto_6

    :cond_4
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v0

    if-gt v2, v1, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v6

    if-gt v3, v1, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v7

    if-gt v4, v1, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v8

    if-le v5, v1, :cond_5

    goto :goto_5

    :cond_5
    const/4 v1, 0x1

    goto :goto_6

    :cond_6
    :goto_5
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b01eb

    invoke-static {v1, v2, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_4

    :goto_6
    if-eqz v1, :cond_8

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_7
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    array-length v3, v3

    if-ge v1, v3, :cond_7

    iget v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    aget v4, v4, v1

    invoke-direct {p0, v1, v4}, Lcom/brasfoot/v2028/ActivityEstadio;->ah(II)I

    move-result v4

    add-int/2addr v3, v4

    iput v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    aget v3, v3, v1

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_7
    iget v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    const v3, 0x7a120

    add-int/2addr v1, v3

    iput v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    invoke-direct {p0, v2}, Lcom/brasfoot/v2028/ActivityEstadio;->cP(I)I

    move-result v1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dd()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cF()Ljava/util/Calendar;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    invoke-virtual {v2, v6}, Ljava/util/Calendar;->get(I)I

    move-result v4

    invoke-virtual {v2, v7}, Ljava/util/Calendar;->get(I)I

    move-result v5

    const/4 v6, 0x5

    invoke-virtual {v2, v6}, Ljava/util/Calendar;->get(I)I

    move-result v2

    invoke-virtual {v3, v4, v5, v2}, Ljava/util/Calendar;->set(III)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    invoke-virtual {v2, v6, v1}, Ljava/util/Calendar;->add(II)V

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "dd/MM/yyyy"

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    invoke-virtual {v2}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IE:Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IF:Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->ID:Landroid/widget/Button;

    invoke-virtual {v2, v0}, Landroid/widget/Button;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IE:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b01e5

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    int-to-long v3, v3

    invoke-static {v3, v4}, La/n;->b(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IF:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b01e6

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_8
    return-void
.end method

.method private qk()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    invoke-virtual {v0}, La/ac;->lA()J

    move-result-wide v0

    iget v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    int-to-long v2, v2

    cmp-long v4, v0, v2

    const/4 v0, 0x1

    if-gez v4, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b01f0

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    new-instance v1, Lcomponents/bi;

    invoke-direct {v1}, Lcomponents/bi;-><init>()V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    invoke-virtual {v1, v2}, Lcomponents/bi;->a(La/l;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    invoke-virtual {v1, v2}, Lcomponents/bi;->c(Ljava/util/Calendar;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iz:[I

    invoke-virtual {v1, v2}, Lcomponents/bi;->l([I)V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IG:I

    const/4 v3, 0x7

    invoke-virtual {v1, v2, v3}, La/ac;->V(II)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b01e7

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->ql()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IF:Landroid/widget/TextView;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->ID:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    return-void
.end method

.method private ql()V
    .locals 4

    const v0, 0x7f06013e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IC:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    const v0, 0x7f06032a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-static {}, Ljava/text/DateFormat;->getDateInstance()Ljava/text/DateFormat;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "dd/MM/yyyy"

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IE:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IE:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b01e9

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private savePrecos()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    if-eqz v0, :cond_3

    const v1, 0x7f060410

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-static {v1}, Lcom/brasfoot/v2028/ActivityEstadio;->parsePreco(Landroid/widget/EditText;)I

    move-result v2

    if-lez v2, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    invoke-virtual {v3, v2}, La/ac;->setPrecoGeral(I)V

    :cond_0
    const v1, 0x7f060411

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-static {v1}, Lcom/brasfoot/v2028/ActivityEstadio;->parsePreco(Landroid/widget/EditText;)I

    move-result v2

    if-lez v2, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    invoke-virtual {v3, v2}, La/ac;->setPrecoArq(I)V

    :cond_1
    const v1, 0x7f060412

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-static {v1}, Lcom/brasfoot/v2028/ActivityEstadio;->parsePreco(Landroid/widget/EditText;)I

    move-result v2

    if-lez v2, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    invoke-virtual {v3, v2}, La/ac;->setPrecoCad(I)V

    :cond_2
    const v1, 0x7f060413

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-static {v1}, Lcom/brasfoot/v2028/ActivityEstadio;->parsePreco(Landroid/widget/EditText;)I

    move-result v2

    if-lez v2, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    invoke-virtual {v3, v2}, La/ac;->setPrecoCam(I)V

    :cond_3
    return-void
.end method


# virtual methods
.method public onClickSalvarPrecos(Landroid/view/View;)V
    .locals 2

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->savePrecos()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->loadPrecos()V

    const-string v0, "Precos salvos!"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07000f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iv:La/ac;

    invoke-virtual {p1}, La/ac;->jO()La/l;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    const p1, 0x7f0601c9

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    invoke-virtual {v0}, La/l;->gN()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    invoke-virtual {p1}, La/l;->gO()[I

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    invoke-virtual {v0}, La/l;->gR()I

    move-result v0

    const/4 v1, 0x0

    aget v2, p1, v1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v3, v3, v1

    if-le v2, v3, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v3, p1, v1

    aput v3, v2, v1

    :cond_0
    const/4 v2, 0x1

    aget v3, p1, v2

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v4, v4, v2

    if-le v3, v4, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v4, p1, v2

    aput v4, v3, v2

    :cond_1
    const/4 v3, 0x2

    aget v4, p1, v3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v5, v5, v3

    if-le v4, v5, :cond_2

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v5, p1, v3

    aput v5, v4, v3

    :cond_2
    const/4 v4, 0x3

    aget v5, p1, v4

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v6, v6, v4

    if-le v5, v6, :cond_3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v6, p1, v4

    aput v6, v5, v4

    :cond_3
    const v5, 0x7f0602c0

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v0, 0x7f0b01f1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602f5

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const v6, 0x7f0b000b

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ": "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v6, p1, v1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602f2

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const v6, 0x7f0b01ee

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ": "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v6, p1, v2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602f3

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const v6, 0x7f0b01ec

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ": "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v6, p1, v3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602f4

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const v6, 0x7f0b01f3

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ": "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget p1, p1, v4

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    if-lt p1, v3, :cond_4

    sget-object p1, La/ak;->yX:[[I

    aget-object p1, p1, v2

    :goto_0
    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    goto :goto_1

    :cond_4
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    const/4 v0, 0x6

    if-lt p1, v0, :cond_5

    sget-object p1, La/ak;->yX:[[I

    aget-object p1, p1, v3

    goto :goto_0

    :cond_5
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    const/16 v0, 0xa

    if-lt p1, v0, :cond_6

    sget-object p1, La/ak;->yX:[[I

    aget-object p1, p1, v4

    goto :goto_0

    :cond_6
    :goto_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    invoke-virtual {p1}, La/l;->gO()[I

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iy:[I

    const/4 p1, 0x0

    :goto_2
    const/4 v0, 0x4

    if-ge p1, v0, :cond_7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iw:[I

    aget v5, v5, p1

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Iy:[I

    aget v6, v6, p1

    sub-int/2addr v5, v6

    aput v5, v0, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    :cond_7
    const p1, 0x7f0602c9

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v5, 0x7f0b01ed

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " "

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v6, v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0602aa

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0602b6

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0602b8

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityEstadio;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->Ix:[I

    aget v1, v1, v4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060017

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IC:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IC:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityEstadio$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityEstadio$1;-><init>(Lcom/brasfoot/v2028/ActivityEstadio;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060018

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->ID:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->ID:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityEstadio$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityEstadio$2;-><init>(Lcom/brasfoot/v2028/ActivityEstadio;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0602d0

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IE:Landroid/widget/TextView;

    const p1, 0x7f0602d1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEstadio;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IF:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->qj()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->loadPrecos()V

    return-void
.end method

.method protected onPause()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->savePrecos()V

    return-void
.end method

.method public qj()V
    .locals 3

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bi;

    invoke-virtual {v1}, Lcomponents/bi;->jO()La/l;

    move-result-object v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEstadio;->qX:La/l;

    if-ne v1, v2, :cond_0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->eK()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bi;

    invoke-virtual {v0}, Lcomponents/bi;->ub()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IB:Ljava/util/Calendar;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEstadio;->IC:Landroid/widget/Button;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEstadio;->ql()V

    return-void

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
