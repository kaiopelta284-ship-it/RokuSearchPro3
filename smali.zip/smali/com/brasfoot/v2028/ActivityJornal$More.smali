.class public Lcom/brasfoot/v2028/ActivityJornal$More;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final act:Lcom/brasfoot/v2028/ActivityJornal;


# direct methods
.method public constructor <init>(Lcom/brasfoot/v2028/ActivityJornal;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJornal$More;->act:Lcom/brasfoot/v2028/ActivityJornal;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    sget v0, Lcom/brasfoot/v2028/ActivityJornal;->limite:I

    add-int/lit8 v0, v0, 0x32

    sput v0, Lcom/brasfoot/v2028/ActivityJornal;->limite:I

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJornal$More;->act:Lcom/brasfoot/v2028/ActivityJornal;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityJornal;->onClickMostrarJor(Landroid/view/View;)V

    :cond_0
    return-void
.end method
