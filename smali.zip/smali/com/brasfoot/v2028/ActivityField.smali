.class public Lcom/brasfoot/v2028/ActivityField;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityField$1;,
        Lcom/brasfoot/v2028/ActivityField$2;,
        Lcom/brasfoot/v2028/ActivityField$3;
    }
.end annotation


# static fields
.field public static sInst:Lcom/brasfoot/v2028/ActivityField;

.field public static selFormation:I

.field public static selSubIdx:I

.field public static selTitIdx:I

.field static tmpForm:[I

.field static tmpOrder:[I


# instance fields
.field II:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lfield/d;",
            ">;"
        }
    .end annotation
.end field

.field IJ:Landroid/widget/LinearLayout;

.field IK:Landroid/widget/TextView;

.field IL:Landroid/widget/TextView;

.field private llFormationBar:Landroid/widget/LinearLayout;

.field private llSubsContainer:Landroid/widget/LinearLayout;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, -0x1

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    const/4 v0, 0x0

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selFormation:I

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private H(Ljava/lang/String;)V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityField;->J(Ljava/lang/String;)I

    move-result v2

    if-gt v1, v2, :cond_0

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v4, 0x3f800000    # 1.0f

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v3, 0x11

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setId(I)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityField;->IJ:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private I(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->IL:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private J(Ljava/lang/String;)I
    .locals 1

    const-string v0, "-"

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityField;->c([Ljava/lang/String;)[I

    move-result-object p1

    array-length p1, p1

    return p1
.end method

.method private a(Lfield/d;)Landroid/widget/LinearLayout;
    .locals 4

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f070061

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-direct {p0, v0, p1}, Lcom/brasfoot/v2028/ActivityField;->a(Landroid/widget/LinearLayout;Lfield/d;)V

    return-object v0
.end method

.method private a(Landroid/widget/LinearLayout;Lfield/d;)V
    .locals 5

    const v0, 0x7f060113

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const-string v2, "camisa"

    const-string v3, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    const v0, 0x7f0602db

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p2, Lfield/d;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602e4

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget p2, p2, Lfield/d;->number:I

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private a(Lfield/b;)V
    .locals 2

    iget-object v0, p1, Lfield/b;->Us:Ljava/lang/String;

    iget-object v1, p1, Lfield/b;->Uu:Ljava/lang/String;

    invoke-direct {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityField;->f(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p1, Lfield/b;->Ut:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityField;->I(Ljava/lang/String;)V

    iget-object v0, p1, Lfield/b;->Uu:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityField;->H(Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityField;->b(Lfield/b;)V

    return-void
.end method

.method private static addCell(Landroid/content/Context;Landroid/widget/LinearLayout;I)V
    .locals 9

    sget-object v0, Lcom/brasfoot/v2028/ActivityField;->tmpForm:[I

    sget-object v1, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    if-ltz p2, :cond_2

    array-length v2, v1

    if-ge p2, v2, :cond_2

    aget v2, v1, p2

    if-ltz v2, :cond_2

    sget-object v3, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v3, :cond_2

    iget-object v3, v3, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    if-eqz v3, :cond_2

    sget v4, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    const/4 v5, 0x0

    if-ne p2, v4, :cond_0

    const/4 v5, 0x1

    :cond_0
    const/4 v6, 0x0

    invoke-static {p0, v3, v5, p2, v6}, Lcom/brasfoot/v2028/ActivityField;->makePlayerCard(Landroid/content/Context;La/p;ZIZ)Landroid/view/View;

    move-result-object v6

    if-nez v5, :cond_1

    invoke-virtual {v3}, La/p;->getPosicao()I

    move-result v7

    invoke-static {v7}, Lcom/brasfoot/v2028/ActivityField;->roleCat(I)I

    move-result v7

    aget v8, v0, p2

    rem-int/lit8 v8, v8, 0xa

    invoke-static {v8}, Lcom/brasfoot/v2028/ActivityField;->roleCat(I)I

    move-result v8

    if-eq v7, v8, :cond_1

    const v7, -0x10000

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_1
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/4 v0, -0x2

    invoke-direct {v7, v8, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void

    :cond_2
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/4 v3, -0x1

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-direct {v1, v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private static assignSlots(Ljava/util/ArrayList;[I)[I
    .locals 11

    const/16 v0, 0xb

    new-array v0, v0, [I

    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0xb

    if-ge v1, v2, :cond_0

    const/4 v2, -0x1

    aput v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-array v1, v1, [I

    const/4 v2, 0x1

    :goto_1
    const/4 v3, 0x5

    if-ge v2, v3, :cond_8

    const/4 v3, 0x0

    :goto_2
    const/16 v4, 0xb

    if-ge v3, v4, :cond_7

    aget v4, v0, v3

    const/4 v5, -0x1

    if-ne v4, v5, :cond_6

    aget v4, p1, v3

    rem-int/lit8 v5, v4, 0xa

    div-int/lit8 v4, v4, 0xa

    rem-int/lit8 v4, v4, 0x64

    const/4 v6, 0x5

    if-ge v4, v6, :cond_1

    const/4 v6, 0x1

    goto :goto_3

    :cond_1
    const/4 v6, 0x6

    if-le v4, v6, :cond_2

    const/4 v6, 0x0

    goto :goto_3

    :cond_2
    const/4 v6, -0x1

    :goto_3
    invoke-static {v5}, Lcom/brasfoot/v2028/ActivityField;->roleCat(I)I

    move-result v4

    const/4 v7, 0x0

    :goto_4
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_6

    aget v8, v1, v7

    if-nez v8, :cond_5

    invoke-virtual {p0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcomponents/bb;

    invoke-virtual {v8}, Lcomponents/bb;->ts()I

    move-result v9

    const/4 v10, -0x1

    if-eq v9, v10, :cond_5

    invoke-virtual {v8}, Lcomponents/bb;->tt()La/p;

    move-result-object v8

    if-eqz v8, :cond_5

    invoke-virtual {v8}, La/p;->getPosicao()I

    move-result v9

    const/4 v10, 0x4

    if-eq v2, v10, :cond_4

    const/4 v10, 0x3

    if-ne v2, v10, :cond_3

    invoke-static {v9}, Lcom/brasfoot/v2028/ActivityField;->roleCat(I)I

    move-result v10

    if-ne v10, v4, :cond_5

    goto :goto_5

    :cond_3
    if-ne v9, v5, :cond_5

    const/4 v10, 0x1

    if-ne v2, v10, :cond_4

    if-ltz v6, :cond_4

    invoke-virtual {v8}, La/p;->getLado()I

    move-result v10

    if-ne v10, v6, :cond_5

    :cond_4
    :goto_5
    aput v7, v0, v3

    const/4 v8, 0x1

    aput v8, v1, v7

    goto :goto_6

    :cond_5
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_6
    :goto_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_7
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_8
    return-object v0
.end method

.method private b(Lfield/b;)V
    .locals 7

    iget-object v0, p1, Lfield/b;->Uu:Ljava/lang/String;

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityField;->c([Ljava/lang/String;)[I

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    array-length v1, v0

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x0

    :goto_0
    if-ltz v1, :cond_1

    aget v3, v0, v1

    add-int/2addr v3, v2

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityField;->IJ:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    :goto_1
    if-ge v2, v3, :cond_0

    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityField;->cQ(I)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    iget-object v6, p1, Lfield/b;->II:Ljava/util/List;

    invoke-interface {v6, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lfield/d;

    invoke-direct {p0, v6}, Lcom/brasfoot/v2028/ActivityField;->a(Lfield/d;)Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, -0x1

    move v2, v3

    goto :goto_0

    :cond_1
    return-void

    :array_0
    .array-data 4
        0x2
        0x4
        0x2
        0x2
        0x1
    .end array-data
.end method

.method private c([Ljava/lang/String;)[I
    .locals 3

    array-length v0, p1

    const/4 v1, 0x1

    add-int/2addr v0, v1

    new-array v0, v0, [I

    const/4 v2, 0x0

    aput v1, v0, v2

    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    add-int/lit8 v2, v1, -0x1

    aget-object v2, p1, v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    aput v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method private cQ(I)Landroid/widget/LinearLayout;
    .locals 4

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/4 v3, -0x1

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x3f800000    # 1.0f

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->setId(I)V

    return-object v0
.end method

.method private f(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->IK:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " ("

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ")"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private static fCount()I
    .locals 1

    const/4 v0, 0x7

    return v0
.end method

.method private static fGet(I)[I
    .locals 1

    const/16 v0, 0xb

    new-array v0, v0, [I

    packed-switch p0, :pswitch_data_0

    fill-array-data v0, :array_0

    return-object v0

    :pswitch_0
    fill-array-data v0, :array_1

    return-object v0

    :pswitch_1
    fill-array-data v0, :array_2

    return-object v0

    :pswitch_2
    fill-array-data v0, :array_3

    return-object v0

    :pswitch_3
    fill-array-data v0, :array_4

    return-object v0

    :pswitch_4
    fill-array-data v0, :array_5

    return-object v0

    :pswitch_5
    fill-array-data v0, :array_6

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch

    :pswitch_6
    fill-array-data v0, :array_0

    return-object v0

    :array_0
    .array-data 4
        0x13c4
        0xfab
        0xfca
        0xfe8
        0x1005
        0x7dd
        0x7fb
        0x819
        0x837
        0x22
        0x54
    .end array-data

    :array_1
    .array-data 4
        0x13c4
        0xfab
        0xfca
        0xfe8
        0x1005
        0x7f1
        0x80f
        0x82d
        0x18
        0x40
        0x68
    .end array-data

    :array_2
    .array-data 4
        0x13c4
        0xfb6
        0xfde
        0x1006
        0x7d1
        0x7f1
        0x80f
        0x82d
        0x83f
        0x22
        0x54
    .end array-data

    :array_3
    .array-data 4
        0x13c4
        0xfab
        0xfca
        0xfe8
        0x1005
        0xbe3
        0xc01
        0x3ff
        0x427
        0x44f
        0x40
    .end array-data

    :array_4
    .array-data 4
        0x13c4
        0xfa1
        0xfc0
        0xfde
        0xffc
        0x100f
        0x7f1
        0x80f
        0x82d
        0x22
        0x54
    .end array-data

    :array_5
    .array-data 4
        0x13c4
        0xfab
        0xfca
        0xfe8
        0x1005
        0x7d3
        0x7f1
        0x80f
        0x82d
        0x841
        0x40
    .end array-data

    :array_6
    .array-data 4
        0x13c4
        0xfb6
        0xfde
        0x1006
        0x7db
        0x7fb
        0x819
        0x835
        0x18
        0x40
        0x68
    .end array-data
.end method

.method private static fName(I)Ljava/lang/String;
    .locals 1

    packed-switch p0, :pswitch_data_0

    const-string v0, "4-4-2"

    return-object v0

    :pswitch_0
    const-string v0, "4-3-3"

    return-object v0

    :pswitch_1
    const-string v0, "3-5-2"

    return-object v0

    :pswitch_2
    const-string v0, "4-2-3-1"

    return-object v0

    :pswitch_3
    const-string v0, "5-3-2"

    return-object v0

    :pswitch_4
    const-string v0, "4-5-1"

    return-object v0

    :pswitch_5
    const-string v0, "3-4-3"

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch

    :pswitch_6
    const-string v0, "4-4-2"

    return-object v0
.end method

.method private static fSlotAt([III)I
    .locals 5

    const/4 v0, 0x0

    :goto_0
    array-length v1, p0

    if-ge v0, v1, :cond_1

    aget v1, p0, v0

    div-int/lit16 v2, v1, 0x3e8

    if-ne v2, p1, :cond_0

    div-int/lit8 v3, v1, 0xa

    rem-int/lit8 v3, v3, 0x64

    if-ne v3, p2, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    return v0
.end method

.method public static formCampToGame(I)I
    .locals 1

    packed-switch p0, :pswitch_data_0

    const/4 v0, 0x4

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
    .end packed-switch

    :pswitch_0
    const/4 v0, 0x4

    return v0

    :pswitch_1
    const/4 v0, 0x7

    return v0

    :pswitch_2
    const/16 v0, 0x9

    return v0

    :pswitch_3
    const/4 v0, 0x0

    return v0

    :pswitch_4
    const/4 v0, 0x2

    return v0

    :pswitch_5
    const/4 v0, 0x3

    return v0

    :pswitch_6
    const/16 v0, 0xa

    return v0
.end method

.method public static formGameToCamp(I)I
    .locals 1

    packed-switch p0, :pswitch_data_0

    const/4 v0, 0x0

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
    .end packed-switch

    :pswitch_0
    const/4 v0, 0x3

    return v0

    :pswitch_1
    const/4 v0, 0x4

    return v0

    :pswitch_2
    const/4 v0, 0x4

    return v0

    :pswitch_3
    const/4 v0, 0x5

    return v0

    :pswitch_4
    const/4 v0, 0x0

    return v0

    :pswitch_5
    const/4 v0, 0x0

    return v0

    :pswitch_6
    const/4 v0, 0x0

    return v0

    :pswitch_7
    const/4 v0, 0x1

    return v0

    :pswitch_8
    const/4 v0, 0x1

    return v0

    :pswitch_9
    const/4 v0, 0x2

    return v0

    :pswitch_a
    const/4 v0, 0x6

    return v0
.end method

.method private static makePlayerCard(Landroid/content/Context;La/p;ZIZ)Landroid/view/View;
    .locals 4

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f070061

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const v1, 0x7f060113

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const v2, 0x7f050006

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    const/high16 v3, 0x41d00000    # 26.0f

    mul-float/2addr v2, v3

    float-to-int v2, v2

    invoke-virtual {v1}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    iput v2, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v2, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v1, 0x7f0602db

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p1}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_1

    :cond_0
    const-string v3, "\u2605 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    invoke-virtual {p1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/brasfoot/v2028/ActivityField;->shortName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityField;->posCode(La/p;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v2, 0x41100000    # 9.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    const v1, 0x7f0602e4

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const/high16 v2, 0x41100000    # 9.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {p1}, La/p;->hG()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_2

    const v2, -0x10000

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_3

    const v2, -0x2900

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_3
    :goto_0
    if-eqz p2, :cond_4

    const-string v1, "#FF00B0FF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_4
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    if-nez p4, :cond_5

    new-instance v1, Lcom/brasfoot/v2028/ActivityField$1;

    invoke-direct {v1, p3}, Lcom/brasfoot/v2028/ActivityField$1;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_1

    :cond_5
    new-instance v1, Lcom/brasfoot/v2028/ActivityField$2;

    invoke-direct {v1, p3}, Lcom/brasfoot/v2028/ActivityField$2;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :goto_1
    return-object v0
.end method

.method private static posCode(La/p;)Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "GOL"

    return-object v0

    :cond_0
    invoke-virtual {p0}, La/p;->getLado()I

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "D"

    goto :goto_0

    :cond_1
    const-string v1, "E"

    :goto_0
    const/4 v2, 0x1

    if-ne v0, v2, :cond_2

    const-string v2, "L"

    goto :goto_1

    :cond_2
    const/4 v2, 0x2

    if-ne v0, v2, :cond_3

    const-string v2, "Z"

    goto :goto_1

    :cond_3
    const/4 v2, 0x3

    if-ne v0, v2, :cond_4

    const-string v2, "M"

    goto :goto_1

    :cond_4
    const-string v2, "AT"

    :goto_1
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private qm()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lfield/d;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

.method private qn()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->IJ:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    return-void
.end method

.method public static rcRender(Landroid/content/Context;Landroid/widget/LinearLayout;Ljava/util/ArrayList;)V
    .locals 13

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v2, v1, -0x1

    :goto_0
    if-ltz v2, :cond_1

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/ArrayList;

    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v7, 0x0

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v6, 0x3f800000    # 1.0f

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x0

    :goto_1
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_0

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/p;

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v9

    const v10, 0x7f070061

    const/4 v11, 0x0

    invoke-virtual {v9, v10, v11, v11}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v9

    const v10, 0x7f060113

    invoke-virtual {v9, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/ImageView;

    const v11, 0x7f050006

    invoke-virtual {v10, v11}, Landroid/widget/ImageView;->setImageResource(I)V

    const v10, 0x7f0602db

    invoke-virtual {v9, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    invoke-virtual {v8}, La/p;->getNome()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v10, 0x7f0602e4

    invoke-virtual {v9, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    invoke-virtual {v8}, La/p;->ia()I

    move-result v11

    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, 0x0

    const/4 v12, -0x2

    invoke-direct {v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v11, 0x3f800000    # 1.0f

    iput v11, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v9, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_0
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v2, v2, -0x1

    goto/16 :goto_0

    :cond_1
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private static rcRenderSubs(Landroid/content/Context;Landroid/widget/LinearLayout;Ljava/util/ArrayList;I)V
    .locals 8

    invoke-virtual {p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->ts()I

    move-result v2

    const/4 v3, -0x1

    if-ne v2, v3, :cond_1

    invoke-virtual {v1}, Lcomponents/bb;->tt()La/p;

    move-result-object v1

    if-eqz v1, :cond_1

    const/4 v2, 0x0

    if-ne v0, p3, :cond_0

    const/4 v2, 0x1

    :cond_0
    const/4 v3, 0x1

    invoke-static {p0, v1, v2, v0, v3}, Lcom/brasfoot/v2028/ActivityField;->makePlayerCard(Landroid/content/Context;La/p;ZIZ)Landroid/view/View;

    move-result-object v4

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/4 v7, -0x1

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v6, 0x4

    iput v6, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    invoke-virtual {v4, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method private static rcRenderTitulars(Landroid/content/Context;Landroid/widget/LinearLayout;Ljava/util/ArrayList;II)V
    .locals 8

    invoke-virtual {p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    invoke-static {p4}, Lcom/brasfoot/v2028/ActivityField;->fGet(I)[I

    move-result-object v0

    sput-object v0, Lcom/brasfoot/v2028/ActivityField;->tmpForm:[I

    sget-object v1, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    if-nez v1, :cond_0

    invoke-static {p2, v0}, Lcom/brasfoot/v2028/ActivityField;->assignSlots(Ljava/util/ArrayList;[I)[I

    move-result-object v0

    sput-object v0, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    :cond_0
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x6

    if-ge v1, v2, :cond_2

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v3, 0x10

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v3, v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x0

    :goto_1
    const/16 v4, 0xc

    if-ge v3, v4, :cond_1

    sget-object v4, Lcom/brasfoot/v2028/ActivityField;->tmpForm:[I

    invoke-static {v4, v1, v3}, Lcom/brasfoot/v2028/ActivityField;->fSlotAt([III)I

    move-result v4

    invoke-static {p0, v2, v4}, Lcom/brasfoot/v2028/ActivityField;->addCell(Landroid/content/Context;Landroid/widget/LinearLayout;I)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method public static rcRows(Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .locals 8

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, -0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/16 v5, 0xb

    if-le v4, v5, :cond_0

    move v4, v5

    :cond_0
    :goto_0
    if-ge v3, v4, :cond_2

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->getPosicao()I

    move-result v7

    if-eqz v3, :cond_1

    if-eq v7, v2, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v2, v7

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    return-object v0
.end method

.method private static roleCat(I)I
    .locals 1

    if-nez p0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    const/4 v0, 0x1

    if-eq p0, v0, :cond_1

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1

    const/4 v0, 0x3

    if-ne p0, v0, :cond_2

    const/4 v0, 0x2

    return v0

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x3

    return v0
.end method

.method private static shortName(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    if-nez p0, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    const-string v0, " "

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x2

    if-ge v1, v2, :cond_1

    return-object p0

    :cond_1
    const/4 v2, 0x0

    aget-object v2, v0, v2

    add-int/lit8 v3, v1, -0x1

    aget-object v3, v0, v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-virtual {v2, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "."

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public onClickStartGame(Landroid/view/View;)V
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityEscala;->qg()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->finish()V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070010

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityField;->setContentView(I)V

    sput-object p0, Lcom/brasfoot/v2028/ActivityField;->sInst:Lcom/brasfoot/v2028/ActivityField;

    const/4 v0, -0x1

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityEscala;->qf()I

    move-result v0

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivityField;->formGameToCamp(I)I

    move-result v0

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selFormation:I

    :cond_0
    const v0, 0x7f06018b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityField;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->IJ:Landroid/widget/LinearLayout;

    const v0, 0x7f060403

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityField;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->llSubsContainer:Landroid/widget/LinearLayout;

    const v0, 0x7f060404

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityField;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->llFormationBar:Landroid/widget/LinearLayout;

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v0

    if-eqz v0, :cond_1

    const v1, 0x7f0602c2

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityField;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->renderFormationBar()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const/high16 v1, 0x7f080000

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 p1, 0x1

    return p1
.end method

.method protected onDestroy()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    sget-object v0, Lcom/brasfoot/v2028/ActivityField;->sInst:Lcom/brasfoot/v2028/ActivityField;

    if-ne v0, p0, :cond_0

    const/4 v0, 0x0

    sput-object v0, Lcom/brasfoot/v2028/ActivityField;->sInst:Lcom/brasfoot/v2028/ActivityField;

    sput-object v0, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    :cond_0
    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    const/4 v0, 0x1

    return v0
.end method

.method public onSubClick(I)V
    .locals 6

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_2

    sget-object v1, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    if-eqz v1, :cond_2

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    sget v3, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    const/4 v4, -0x1

    if-eq v3, v4, :cond_0

    array-length v4, v1

    if-ge v3, v4, :cond_2

    aget v3, v1, v3

    if-ltz v3, :cond_2

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v5

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v4, v5}, Lcomponents/bb;->u(La/p;)V

    const/4 v2, -0x1

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    goto :goto_0

    :cond_0
    sget v2, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    if-eq v2, p1, :cond_1

    sput p1, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    const/4 v2, -0x1

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    goto :goto_0

    :cond_1
    const/4 v2, -0x1

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    :cond_2
    :goto_0
    return-void
.end method

.method public onTitularClick(I)V
    .locals 6

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_3

    sget-object v1, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    if-eqz v1, :cond_3

    array-length v2, v1

    if-ge p1, v2, :cond_3

    sget v2, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    const/4 v3, -0x1

    if-eq v2, v3, :cond_0

    aget v3, v1, p1

    if-ltz v3, :cond_3

    iget-object v4, v0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v5

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v4, v5}, Lcomponents/bb;->u(La/p;)V

    const/4 v2, -0x1

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    goto :goto_0

    :cond_0
    sget v2, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    const/4 v3, -0x1

    if-ne v2, v3, :cond_1

    sput p1, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    sput v3, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    goto :goto_0

    :cond_1
    if-ne v2, p1, :cond_2

    const/4 v2, -0x1

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    goto :goto_0

    :cond_2
    aget v3, v1, v2

    aget v4, v1, p1

    aput v4, v1, v2

    aput v3, v1, p1

    const/4 v2, -0x1

    sput v2, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    :cond_3
    :goto_0
    return-void
.end method

.method public rebuildSlotMap()V
    .locals 3

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    sget v1, Lcom/brasfoot/v2028/ActivityField;->selFormation:I

    invoke-static {v1}, Lcom/brasfoot/v2028/ActivityField;->fGet(I)[I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/brasfoot/v2028/ActivityField;->assignSlots(Ljava/util/ArrayList;[I)[I

    move-result-object v0

    sput-object v0, Lcom/brasfoot/v2028/ActivityField;->tmpOrder:[I

    :cond_0
    return-void
.end method

.method public refreshField()V
    .locals 7

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_0

    iget-object v1, v0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    iget-object v2, v0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityField;->IJ:Landroid/widget/LinearLayout;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityField;->llSubsContainer:Landroid/widget/LinearLayout;

    sget v5, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    sget v6, Lcom/brasfoot/v2028/ActivityField;->selFormation:I

    invoke-static {p0, v3, v1, v5, v6}, Lcom/brasfoot/v2028/ActivityField;->rcRenderTitulars(Landroid/content/Context;Landroid/widget/LinearLayout;Ljava/util/ArrayList;II)V

    sget v5, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    invoke-static {p0, v4, v1, v5}, Lcom/brasfoot/v2028/ActivityField;->rcRenderSubs(Landroid/content/Context;Landroid/widget/LinearLayout;Ljava/util/ArrayList;I)V

    :cond_0
    return-void
.end method

.method public renderFormationBar()V
    .locals 9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityField;->llFormationBar:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityField;->fCount()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v2}, Lcom/brasfoot/v2028/ActivityField;->fName(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v4, 0x12

    invoke-virtual {v3, v4, v4, v4, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v4, -0x1

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextColor(I)V

    sget v4, Lcom/brasfoot/v2028/ActivityField;->selFormation:I

    if-ne v2, v4, :cond_0

    const-string v4, "#FFE9C46A"

    goto :goto_1

    :cond_0
    const-string v4, "#33FFFFFF"

    :goto_1
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setBackgroundColor(I)V

    new-instance v4, Lcom/brasfoot/v2028/ActivityField$3;

    invoke-direct {v4, v2}, Lcom/brasfoot/v2028/ActivityField$3;-><init>(I)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/4 v6, -0x1

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v5, 0x8

    iput v5, v4, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
