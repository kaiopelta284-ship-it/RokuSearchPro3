.class Lcom/brasfoot/v2028/ActivitySave$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivitySave;->qQ()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic LY:Lcom/brasfoot/v2028/ActivitySave;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivitySave;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivitySave;->a(Lcom/brasfoot/v2028/ActivitySave;)Lcom/brasfoot/v2028/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivitySave;->a(Lcom/brasfoot/v2028/ActivitySave;)Lcom/brasfoot/v2028/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->dismiss()V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    iget-boolean v0, v0, Lcom/brasfoot/v2028/ActivitySave;->LS:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivitySave;->qL()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivitySave;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave$3;->LY:Lcom/brasfoot/v2028/ActivitySave;

    const v2, 0x7f0b01b1

    invoke-virtual {v1, v2}, Lcom/brasfoot/v2028/ActivitySave;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method
