.class Lcom/brasfoot/v2028/ActivityEditorTeam$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcomponents/bg$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityEditorTeam;->ae(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic HP:Lcom/brasfoot/v2028/ActivityEditorTeam;

.field final synthetic HQ:I


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityEditorTeam;I)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam$2;->HP:Lcom/brasfoot/v2028/ActivityEditorTeam;

    iput p2, p0, Lcom/brasfoot/v2028/ActivityEditorTeam$2;->HQ:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcomponents/bg;)V
    .locals 0

    return-void
.end method

.method public a(Lcomponents/bg;I)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditorTeam$2;->HP:Lcom/brasfoot/v2028/ActivityEditorTeam;

    iget v0, p0, Lcom/brasfoot/v2028/ActivityEditorTeam$2;->HQ:I

    invoke-virtual {p1, p2, v0}, Lcom/brasfoot/v2028/ActivityEditorTeam;->ad(II)V

    return-void
.end method
