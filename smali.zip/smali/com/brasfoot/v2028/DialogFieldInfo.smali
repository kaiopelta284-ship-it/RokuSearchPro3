.class public Lcom/brasfoot/v2028/DialogFieldInfo;
.super Landroid/app/Activity;


# instance fields
.field GA:Landroid/widget/Button;

.field GB:Landroid/widget/Button;

.field private Gi:I

.field Gs:Landroid/widget/ViewFlipper;

.field Gz:Landroid/widget/Button;

.field HR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field HU:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bb;",
            ">;"
        }
    .end annotation
.end field

.field HV:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field HW:Z

.field HX:Landroid/widget/ListView;

.field private HY:I

.field HZ:Lcomponents/r;

.field Ia:Lcomponents/s;

.field Ic:Landroid/widget/Spinner;

.field Id:Z

.field private Jp:Z

.field private Js:La/p;

.field Jv:Lcomponents/bo;

.field LI:Lcomponents/u;

.field private Lw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/m;",
            ">;"
        }
    .end annotation
.end field

.field private MT:[La/ac;

.field private MU:I

.field MV:Z

.field MW:Landroid/widget/ImageButton;

.field MX:Landroid/widget/ImageButton;

.field MY:Landroid/widget/TextView;

.field MZ:Landroid/widget/TextView;

.field Na:Landroid/widget/TextView;

.field Nb:Landroid/widget/TextView;

.field private nx:La/t;


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HV:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HW:Z

    const/4 v1, 0x2

    new-array v1, v1, [La/ac;

    const/4 v2, 0x0

    aput-object v2, v1, v0

    const/4 v3, 0x1

    aput-object v2, v1, v3

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iput v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    const/4 v1, 0x4

    iput v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HY:I

    iput-boolean v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Id:Z

    iput-boolean v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MV:Z

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogFieldInfo;)I
    .locals 1

    iget v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gi:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gi:I

    return v0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogFieldInfo;I)I
    .locals 0

    iput p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HY:I

    return p1
.end method

.method static synthetic b(Lcom/brasfoot/v2028/DialogFieldInfo;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->sx()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/DialogFieldInfo;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->di(I)V

    return-void
.end method

.method private di(I)V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-static {p0, v0}, Lcom/brasfoot/v2028/Recopa;->showH2HInfo(Landroid/app/Activity;La/t;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030038

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextColor(I)V

    const/4 v0, 0x3

    const/4 v1, 0x0

    const v3, 0x7f030013

    const/4 v4, 0x1

    if-ne p1, v4, :cond_0

    iput v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    aget-object v5, v5, v6

    iget v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    invoke-virtual {p0, v5, v6}, Lcom/brasfoot/v2028/DialogFieldInfo;->d(La/ac;I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object v6, v6, v1

    invoke-virtual {v6}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object v6, v6, v1

    invoke-virtual {v6}, La/ac;->ma()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setTextColor(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    :goto_0
    invoke-virtual {v5, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {v5, v3}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v3, v2}, Landroid/widget/Button;->setTextColor(I)V

    goto/16 :goto_1

    :cond_0
    if-ne p1, v0, :cond_1

    iput v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    aget-object v5, v5, v6

    iget v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    invoke-virtual {p0, v5, v6}, Lcom/brasfoot/v2028/DialogFieldInfo;->d(La/ac;I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v5, v2}, Landroid/widget/Button;->setTextColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object v3, v3, v4

    invoke-virtual {v3}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object v3, v3, v4

    invoke-virtual {v3}, La/ac;->ma()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTextColor(I)V

    goto :goto_1

    :cond_1
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->sy()V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setTextColor(I)V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const v7, 0x7f030010

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    goto/16 :goto_0

    :goto_1
    if-eq p1, v4, :cond_3

    if-ne p1, v0, :cond_2

    goto :goto_2

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {p1, v4}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void

    :cond_3
    :goto_2
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {p1, v1}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void
.end method

.method private sx()V
    .locals 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    aget-object v1, v1, v2

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_3

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    if-nez v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v2}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v2

    :goto_0
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_1

    :cond_0
    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v2}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v2

    goto :goto_0

    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_2
    const/16 v4, 0xb

    if-ge v3, v4, :cond_2

    sget-object v4, La/ak;->AX:[[I

    iget v5, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HY:I

    aget-object v4, v4, v5

    aget v4, v4, v3

    invoke-static {v1, v4, v2, v2}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v5

    if-eqz v5, :cond_1

    invoke-virtual {v5, v4}, La/p;->bd(I)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v6, Lcomponents/bb;

    invoke-direct {v6}, Lcomponents/bb;-><init>()V

    invoke-virtual {v6, v5}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v6, v4}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v6, v2}, Lcomponents/bb;->aj(Z)V

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    aget-object v0, v0, v1

    iget v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HY:I

    invoke-virtual {v0, v2, v1}, La/ac;->T(II)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->LM:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {v0}, Lcomponents/r;->notifyDataSetChanged()V

    :cond_3
    return-void
.end method

.method private sy()V
    .locals 13

    const v0, 0x7f060104

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f060133

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0600a1

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const v3, 0x7f0600a0

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f0600a2

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    const/4 v5, 0x0

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jO()La/l;

    move-result-object v6

    const/16 v7, 0x8

    if-eqz v6, :cond_0

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jO()La/l;

    move-result-object v6

    invoke-virtual {v6}, La/l;->gN()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jZ()I

    move-result v6

    int-to-long v8, v6

    invoke-static {v8, v9}, La/n;->b(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->kg()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setVisibility(I)V

    :goto_0
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/t;

    if-nez v6, :cond_5

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/p;

    if-eqz v6, :cond_1

    goto/16 :goto_3

    :cond_1
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/ad;

    if-nez v6, :cond_2

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/v;

    if-eqz v6, :cond_7

    :cond_2
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    if-eqz v6, :cond_7

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/x;

    if-eqz v6, :cond_7

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    check-cast v6, Ld/x;

    invoke-virtual {v6}, Ld/x;->yp()I

    move-result v8

    invoke-virtual {v6}, Ld/x;->xO()I

    move-result v6

    if-ne v6, v8, :cond_7

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/ad;

    if-eqz v6, :cond_3

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    check-cast v6, Ld/ad;

    invoke-static {}, Ld/ad;->xs()Ljava/lang/String;

    move-result-object v6

    :goto_1
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    :cond_3
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/v;

    if-eqz v6, :cond_4

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    check-cast v6, Ld/v;

    invoke-static {}, Ld/v;->xs()Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_4
    :goto_2
    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_4

    :cond_5
    :goto_3
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    if-eqz v6, :cond_7

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/x;

    if-eqz v6, :cond_7

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jb()La/al;

    move-result-object v6

    check-cast v6, Ld/x;

    invoke-virtual {v6}, Ld/x;->yp()I

    move-result v8

    invoke-virtual {v6}, Ld/x;->xO()I

    move-result v6

    const/4 v9, 0x3

    if-ne v6, v9, :cond_7

    if-ne v6, v8, :cond_7

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/t;

    if-eqz v6, :cond_6

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    check-cast v6, Ld/t;

    invoke-static {}, Ld/t;->xs()Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_6
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    instance-of v6, v6, Ld/p;

    if-eqz v6, :cond_4

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jH()La/al;

    move-result-object v6

    check-cast v6, Ld/p;

    invoke-static {}, Ld/p;->xs()Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_7
    :goto_4
    const/4 v2, 0x2

    new-array v3, v2, [I

    fill-array-data v3, :array_0

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v4}, La/t;->jb()La/al;

    move-result-object v4

    instance-of v4, v4, Ld/x;

    if-eqz v4, :cond_8

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v4}, La/t;->jb()La/al;

    move-result-object v4

    check-cast v4, Ld/x;

    invoke-virtual {v4}, Ld/x;->yq()I

    move-result v4

    if-ne v4, v2, :cond_8

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v3}, La/t;->jb()La/al;

    move-result-object v3

    check-cast v3, Ld/x;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v3, v4}, Ld/x;->p(La/t;)[I

    move-result-object v3

    :cond_8
    const-string v4, ""

    const-string v6, ""

    filled-new-array {v4, v6}, [Ljava/lang/String;

    move-result-object v4

    aget v6, v3, v5

    const/4 v8, 0x1

    if-ltz v6, :cond_9

    aget v6, v3, v8

    if-ltz v6, :cond_9

    aget v6, v3, v5

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v5

    aget v3, v3, v8

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v4, v8

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "("

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v6, v4, v5

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " x "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v4, v4, v8

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_5

    :cond_9
    const-string v3, ""

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setVisibility(I)V

    :goto_5
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Jv:Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uG()I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " x "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Jv:Lcomponents/bo;

    invoke-virtual {v3}, Lcomponents/bo;->uH()I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060258

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f060259

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v3, 0x7f06025a

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const v4, 0x7f06025b

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    const v6, 0x7f06025c

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    const v7, 0x7f06025d

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    const v9, 0x7f06025e

    invoke-virtual {p0, v9}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/TextView;

    const v10, 0x7f06025f

    invoke-virtual {p0, v10}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v12, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v12}, La/t;->jI()[I

    move-result-object v12

    aget v12, v12, v5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v12, "%"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v11}, La/t;->jI()[I

    move-result-object v11

    aget v11, v11, v8

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, "%"

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v0, v5}, La/t;->bu(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v0, v8}, La/t;->bu(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v0, v5}, La/t;->bB(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v0, v8}, La/t;->bB(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v0, v5}, La/t;->bv(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v0, v8}, La/t;->bv(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    move-object v1, v0

    move-object v3, v1

    move-object v4, v3

    :goto_6
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_12

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->cG()I

    move-result v6

    if-ne v6, v8, :cond_b

    if-nez v0, :cond_a

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :cond_a
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7

    :cond_b
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->cG()I

    move-result v6

    const/4 v7, 0x6

    if-ne v6, v7, :cond_d

    if-nez v3, :cond_c

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    :cond_c
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_d
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->cG()I

    move-result v6

    if-lt v6, v2, :cond_f

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->cG()I

    move-result v6

    const/4 v7, 0x4

    if-gt v6, v7, :cond_f

    if-nez v1, :cond_e

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :cond_e
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_f
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6}, La/m;->cG()I

    move-result v6

    const/4 v7, 0x5

    if-ne v6, v7, :cond_11

    if-nez v4, :cond_10

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :cond_10
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_11
    :goto_7
    iget-object v6, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v6}, La/t;->jN()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/m;

    invoke-virtual {v6, v8}, La/m;->F(Z)V

    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_6

    :cond_12
    if-eqz v0, :cond_13

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    new-instance v5, La/m;

    const/16 v6, 0x5b

    invoke-direct {v5, v6, v8}, La/m;-><init>(IZ)V

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_13
    if-eqz v1, :cond_14

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    new-instance v2, La/m;

    const/16 v5, 0x5c

    invoke-direct {v2, v5, v8}, La/m;-><init>(IZ)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_14
    if-eqz v4, :cond_15

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    new-instance v1, La/m;

    const/16 v2, 0x5f

    invoke-direct {v1, v2, v8}, La/m;-><init>(IZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_15
    if-eqz v3, :cond_16

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    new-instance v1, La/m;

    const/16 v2, 0x60

    invoke-direct {v1, v2, v8}, La/m;-><init>(IZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_16
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->LI:Lcomponents/u;

    invoke-virtual {v0}, Lcomponents/u;->notifyDataSetChanged()V

    return-void

    nop

    :array_0
    .array-data 4
        -0x1
        -0x1
    .end array-data
.end method

.method private sz()V
    .locals 9

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    aget-object v0, v0, v1

    const/4 v1, 0x3

    new-array v2, v1, [Ljava/lang/String;

    const v3, 0x7f0b0248

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const v3, 0x7f0b0249

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    aput-object v3, v2, v5

    const v3, 0x7f0b024a

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    aput-object v3, v2, v6

    new-array v3, v1, [Ljava/lang/String;

    const v7, 0x7f0b0244

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v3, v4

    const v7, 0x7f0b0245

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v3, v5

    const v7, 0x7f0b0246

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v3, v6

    new-array v7, v6, [Ljava/lang/String;

    const v8, 0x7f0b0241

    invoke-virtual {p0, v8}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v7, v4

    const v4, 0x7f0b0242

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v7, v5

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MY:Landroid/widget/TextView;

    invoke-virtual {v0, v5}, La/ac;->bX(I)I

    move-result v5

    aget-object v2, v2, v5

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MZ:Landroid/widget/TextView;

    invoke-virtual {v0, v6}, La/ac;->bX(I)I

    move-result v4

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Na:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, La/ac;->bX(I)I

    move-result v0

    aget-object v0, v7, v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public af(II)V
    .locals 10

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bb;

    invoke-virtual {v0}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bb;

    invoke-virtual {v0}, Lcomponents/bb;->ts()I

    move-result v7

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    iget v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    invoke-virtual {v0, v1}, La/t;->bs(I)I

    move-result v0

    const/4 v1, 0x0

    const/4 v9, 0x1

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b0239

    invoke-static {v0, v2, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bb;

    invoke-virtual {v2}, Lcomponents/bb;->tp()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b004f

    invoke-static {v0, v2, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const/4 v0, 0x0

    :cond_1
    if-eqz v0, :cond_5

    if-eqz v3, :cond_5

    if-eqz p2, :cond_5

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qB()I

    move-result v0

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qC()I

    move-result v5

    iget-boolean v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Jp:Z

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    goto :goto_1

    :cond_2
    move v6, v0

    :goto_1
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    iget v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    const/4 v8, -0x1

    move-object v4, p2

    invoke-virtual/range {v1 .. v8}, La/t;->a(ILa/p;La/p;IIII)La/m;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0, v9}, La/m;->F(Z)V

    :cond_3
    if-eqz p2, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bb;

    invoke-virtual {p1, p2}, Lcomponents/bb;->u(La/p;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Lcomponents/s;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1, p2}, Lcomponents/r;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->notifyDataSetChanged()V

    :cond_5
    return-void
.end method

.method public ag(II)V
    .locals 5

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    if-nez p2, :cond_2

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->tp()Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->tp()Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->tp()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    aget-object v1, v1, v2

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_3

    if-eqz v0, :cond_3

    if-ltz p1, :cond_3

    if-ltz p2, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bb;

    invoke-virtual {v0}, Lcomponents/bb;->tp()Z

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->tp()Z

    move-result v1

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bb;

    invoke-virtual {v2}, Lcomponents/bb;->tt()La/p;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4, v3}, Lcomponents/bb;->u(La/p;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4, v2}, Lcomponents/bb;->u(La/p;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->ts()I

    move-result v4

    invoke-virtual {v2, v4}, La/p;->bd(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bb;

    invoke-virtual {v2}, Lcomponents/bb;->ts()I

    move-result v2

    invoke-virtual {v3, v2}, La/p;->bd(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bb;

    invoke-virtual {p1, v1}, Lcomponents/bb;->ai(Z)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bb;

    invoke-virtual {p1, v0}, Lcomponents/bb;->ai(Z)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HX:Landroid/widget/ListView;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->setSelection(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1, p2}, Lcomponents/r;->dm(I)V

    :cond_3
    return-void
.end method

.method public cM(I)V
    .locals 0

    iput p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HY:I

    return-void
.end method

.method public d(La/ac;I)V
    .locals 6

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->sz()V

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MW:Landroid/widget/ImageButton;

    const/16 v3, 0x8

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MX:Landroid/widget/ImageButton;

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setEnabled(Z)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MW:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MX:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setEnabled(Z)V

    :goto_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    if-eqz p2, :cond_1

    if-ne p2, v1, :cond_2

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Nb:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b023a

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v4, p2}, La/t;->bs(I)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    const v0, 0x7f0602f1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v3, 0x7f0b01df

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1, v2}, La/ac;->bX(I)I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->cM(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    invoke-virtual {p1, v2}, La/ac;->bX(I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/Spinner;->setSelection(I)V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    if-nez p2, :cond_3

    iget-object p2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {p2}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {p2}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v3}, La/t;->ji()La/ac;

    move-result-object v3

    if-ne v0, v3, :cond_4

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    iget-object p2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {p2}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {p2}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object p2

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v3}, La/t;->jj()La/ac;

    move-result-object v3

    if-ne v0, v3, :cond_4

    goto :goto_1

    :cond_4
    :goto_2
    const/4 v0, 0x0

    :goto_3
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->io()I

    move-result v3

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    new-instance v5, Lcomponents/bb;

    invoke-direct {v5}, Lcomponents/bb;-><init>()V

    invoke-virtual {v5, v4}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v5, v3}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v5, v2}, Lcomponents/bb;->aj(Z)V

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    if-ne v4, v3, :cond_5

    invoke-virtual {v5, v1}, Lcomponents/bb;->ai(Z)V

    :cond_5
    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_6
    :goto_4
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v2, p1, :cond_7

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    sget-object p2, Lcomponents/ce;->LM:Ljava/util/Comparator;

    invoke-static {p1, p2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    sget-object p2, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {p1, p2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->notifyDataSetChanged()V

    return-void
.end method

.method public onBackPressed()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V

    return-void
.end method

.method public onClickAgenda(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityAgenda;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickChange(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->th()I

    move-result p1

    const/4 v0, 0x1

    const/4 v1, -0x1

    if-eq p1, v1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->th()I

    move-result p1

    if-ne p1, v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->th()I

    move-result p1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->th()I

    move-result p1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->th()I

    move-result p1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {v1}, Lcomponents/s;->th()I

    move-result v1

    invoke-virtual {p0, p1, v1}, Lcom/brasfoot/v2028/DialogFieldInfo;->af(II)V

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b0232

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_1
    iget p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    if-eqz p1, :cond_3

    iget p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    if-ne p1, v0, :cond_4

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Nb:Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b023a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    iget v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    invoke-virtual {v1, v2}, La/t;->bs(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_4
    return-void
.end method

.method public onClickJogar(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V

    return-void
.end method

.method public onClickTaticaField(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/DialogTatics;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070033

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V

    :cond_0
    :goto_0
    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Id:Z

    const v0, 0x7f0600e6

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ViewFlipper;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gs:Landroid/widget/ViewFlipper;

    const v0, 0x7f06032b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MY:Landroid/widget/TextView;

    const v0, 0x7f06032c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MZ:Landroid/widget/TextView;

    const v0, 0x7f06032d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Na:Landroid/widget/TextView;

    const v0, 0x7f06006c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HX:Landroid/widget/ListView;

    const v0, 0x7f06031b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Nb:Landroid/widget/TextView;

    const v0, 0x7f060237

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HV:Ljava/util/ArrayList;

    sget-object v1, La/ak;->AY:[Ljava/lang/String;

    invoke-static {v0, v1}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/am;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HV:Ljava/util/ArrayList;

    const/4 v4, 0x1

    invoke-direct {v1, p0, v2, v3, v4}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    iget v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HY:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ic:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/DialogFieldInfo$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogFieldInfo$1;-><init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qz()La/t;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qu()Lcomponents/bo;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Jv:Lcomponents/bo;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    aput-object v1, v0, p1

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->nx:La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    aput-object v1, v0, v4

    const v0, 0x7f0600a4

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qA()Z

    move-result v1

    iput-boolean v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Jp:Z

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qD()I

    move-result v1

    iget-boolean v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Jp:Z

    if-eqz v2, :cond_1

    const v1, 0x7f0b00d5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogFieldInfo;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    :cond_1
    const/4 v2, 0x5

    if-ne v1, v2, :cond_2

    const v1, 0x7f0b014f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    sget-object v0, Lcom/brasfoot/v2028/ActivityJogo;->Js:La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Js:La/p;

    goto :goto_2

    :cond_2
    const/4 v2, 0x6

    if-ne v1, v2, :cond_3

    const v1, 0x7f0b0153

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    goto :goto_2

    :cond_3
    const v1, 0x7f0b0143

    goto :goto_1

    :goto_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object v0, v0, p1

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    iput p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    goto :goto_3

    :cond_4
    iput v4, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    :goto_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->qc()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->sA()V

    const v0, 0x7f0600a3

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/u;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Lw:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/u;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->LI:Lcomponents/u;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->LI:Lcomponents/u;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    const v0, 0x7f06005d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MX:Landroid/widget/ImageButton;

    const v0, 0x7f060036

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MW:Landroid/widget/ImageButton;

    const v0, 0x7f06005e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    const v0, 0x7f060047

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GA:Landroid/widget/Button;

    const v0, 0x7f06005f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/DialogFieldInfo$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogFieldInfo$2;-><init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GA:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/DialogFieldInfo$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogFieldInfo$3;-><init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/DialogFieldInfo$4;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogFieldInfo$4;-><init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Gz:Landroid/widget/Button;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object p1, v1, p1

    invoke-virtual {p1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->GB:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MT:[La/ac;

    aget-object v0, v0, v4

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    iget p1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->MU:I

    if-nez p1, :cond_5

    invoke-direct {p0, v4}, Lcom/brasfoot/v2028/DialogFieldInfo;->di(I)V

    return-void

    :cond_5
    const/4 p1, 0x3

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/DialogFieldInfo;->di(I)V

    return-void
.end method

.method protected onResume()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    sget-object v0, Lc/a;->TF:La/b;

    if-nez v0, :cond_0

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V

    :cond_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->sz()V

    return-void
.end method

.method public onStart()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lc/a;->TF:La/b;

    if-nez v0, :cond_0

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogFieldInfo;->finish()V

    :cond_1
    return-void
.end method

.method public qc()V
    .locals 2

    new-instance v0, Lcomponents/r;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HU:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/r;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HX:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HZ:Lcomponents/r;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HX:Landroid/widget/ListView;

    new-instance v1, Lcom/brasfoot/v2028/DialogFieldInfo$5;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogFieldInfo$5;-><init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public sA()V
    .locals 4

    const v0, 0x7f0600cf

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogFieldInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/s;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->HR:Ljava/util/ArrayList;

    const/4 v3, 0x0

    invoke-direct {v1, v2, p0, p0, v3}, Lcomponents/s;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;Z)V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogFieldInfo;->Ia:Lcomponents/s;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/DialogFieldInfo$6;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogFieldInfo$6;-><init>(Lcom/brasfoot/v2028/DialogFieldInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method
