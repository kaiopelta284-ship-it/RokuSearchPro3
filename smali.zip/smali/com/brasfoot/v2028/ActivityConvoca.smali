.class public Lcom/brasfoot/v2028/ActivityConvoca;
.super Landroid/app/Activity;


# instance fields
.field private EZ:La/ac;

.field GA:Landroid/widget/Button;

.field GB:Landroid/widget/Button;

.field GC:Landroid/widget/Button;

.field GD:Landroid/widget/Button;

.field GE:Landroid/widget/Button;

.field GF:Landroid/widget/Button;

.field GG:Lcomponents/b;

.field GH:Landroid/widget/Spinner;

.field GI:Landroid/widget/Spinner;

.field GJ:Landroid/widget/Spinner;

.field GK:Landroid/widget/Spinner;

.field GL:Landroid/widget/Spinner;

.field GM:Lcomponents/a;

.field GN:Landroid/widget/TextView;

.field GO:Landroid/widget/TextView;

.field GP:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field GQ:Landroid/widget/ListView;

.field GR:Lfield/RangeSeekBar;

.field private GS:La/p;

.field private GT:I

.field private GU:I

.field private GV:I

.field private GW:I

.field Gs:Landroid/widget/ViewFlipper;

.field Gz:Landroid/widget/Button;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GS:La/p;

    const/4 v0, 0x2

    iput v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GT:I

    const/16 v0, 0xf

    iput v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GU:I

    const/4 v0, 0x3

    iput v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GV:I

    const/16 v0, 0x1b

    iput v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GW:I

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityConvoca;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pA()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityConvoca;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->cK(I)V

    return-void
.end method

.method private ab(II)V
    .locals 4

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0b01c1

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    if-ne p1, v1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f0b01c0

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    const/16 v3, 0xc8

    if-le p1, v1, :cond_1

    if-ge p1, v3, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0b01be

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v1, v2

    :goto_0
    invoke-virtual {p1, v0, v1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_1
    if-lt p1, v3, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f0b01bf

    new-array v1, v1, [Ljava/lang/Object;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v1, v2

    goto :goto_0

    :cond_2
    :goto_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GN:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityConvoca;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pz()V

    return-void
.end method

.method private cK(I)V
    .locals 4

    const v0, 0x7f030010

    const v1, 0x7f030013

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gs:Landroid/widget/ViewFlipper;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void

    :cond_0
    const/4 v2, 0x1

    if-ne p1, v2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {p1, v2}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GB:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gs:Landroid/widget/ViewFlipper;

    const/4 v0, 0x2

    goto :goto_0

    return-void
.end method

.method private pA()V
    .locals 6

    new-instance v0, La/aa;

    invoke-direct {v0}, La/aa;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v1}, La/ac;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->bT(I)V

    const v1, 0x7f0600b9

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, La/aa;->setNome(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GH:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, La/aa;->bN(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GI:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, La/aa;->bO(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GK:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, La/aa;->bP(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, La/aa;->bR(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GL:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, La/aa;->bU(I)V

    const v1, 0x7f060078

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->O(Z)V

    const v1, 0x7f060079

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->P(Z)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v1}, Lfield/RangeSeekBar;->getSelectedMinValue()Ljava/lang/Number;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->bV(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v1}, Lfield/RangeSeekBar;->getSelectedMaxValue()Ljava/lang/Number;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->bW(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, La/aa;->ln()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_1

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    const/16 v4, 0x96

    if-lt v3, v4, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    :goto_2
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_2
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    sget-object v2, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {v1, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->ab(II)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v0}, Lcomponents/a;->notifyDataSetChanged()V

    return-void
.end method

.method private pB()V
    .locals 4

    const v0, 0x7f060244

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GL:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kX()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance v2, Landroid/widget/ArrayAdapter;

    const v3, 0x1090008

    invoke-direct {v2, p0, v3, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v2, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GL:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GL:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pC()V
    .locals 3

    const v0, 0x7f060248

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GH:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0183

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0188

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0181

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0185

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0180

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GH:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GH:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pD()V
    .locals 3

    const v0, 0x7f060247

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GI:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b01c5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b01c3

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GI:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GI:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pE()V
    .locals 3

    const v0, 0x7f060246

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GK:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "1..10"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "11..30"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "31..50"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "51..70"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "71..100"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GK:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GK:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pF()V
    .locals 4

    const/16 v0, 0xe

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b015f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b015e

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0160

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b015a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const v1, 0x7f0b0163

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const v1, 0x7f0b0159

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    aput-object v1, v0, v3

    const v1, 0x7f0b015b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    aput-object v1, v0, v3

    const v1, 0x7f0b0165

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    aput-object v1, v0, v3

    const v1, 0x7f0b015c

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x8

    aput-object v1, v0, v3

    const v1, 0x7f0b0164

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x9

    aput-object v1, v0, v3

    const v1, 0x7f0b0161

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xa

    aput-object v1, v0, v3

    const v1, 0x7f0b0162

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xb

    aput-object v1, v0, v3

    const v1, 0x7f0b0166

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xc

    aput-object v1, v0, v3

    const v1, 0x7f0b015d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xd

    aput-object v1, v0, v3

    const v1, 0x7f060245

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GJ:Landroid/widget/Spinner;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const v3, 0x7f0b01b4

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    new-instance v0, Landroid/widget/ArrayAdapter;

    const v3, 0x1090008

    invoke-direct {v0, p0, v3, v1}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v1, 0x1090009

    invoke-virtual {v0, v1}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pK()[I
    .locals 9

    const/4 v0, 0x2

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v4}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v5, 0x1

    if-ge v3, v4, :cond_1

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v4}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getPosicao()I

    move-result v4

    if-nez v4, :cond_0

    aget v4, v1, v2

    add-int/2addr v4, v5

    aput v4, v1, v2

    goto :goto_1

    :cond_0
    aget v4, v1, v5

    add-int/2addr v4, v5

    aput v4, v1, v5

    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    aget v3, v1, v2

    aget v4, v1, v5

    add-int/2addr v3, v4

    const/4 v4, 0x3

    if-ne v3, v5, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const v7, 0x7f0b0122

    new-array v4, v4, [Ljava/lang/Object;

    aget v8, v1, v2

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v2

    aget v2, v1, v5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v4, v5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v4, v0

    :goto_2
    invoke-virtual {v6, v7, v4}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const v7, 0x7f0b0123

    new-array v4, v4, [Ljava/lang/Object;

    aget v8, v1, v2

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v4, v2

    aget v2, v1, v5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v4, v5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v4, v0

    goto :goto_2

    :goto_3
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GO:Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-object v1

    nop

    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data
.end method

.method private px()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const v0, 0x7f060194

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/b;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-direct {v1, v2, p0, p0}, Lcomponents/b;-><init>(Ljava/util/ArrayList;Lcom/brasfoot/v2028/ActivityConvoca;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GG:Lcomponents/b;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GG:Lcomponents/b;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-static {v1}, Lcom/brasfoot/v2028/MainActivity;->s(La/p;)V

    :cond_0
    new-instance v1, Lcom/brasfoot/v2028/ActivityConvoca$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityConvoca$3;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pK()[I

    return-void
.end method

.method private pz()V
    .locals 3

    const v0, 0x7f0600b9

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GH:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GI:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GK:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GL:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v2}, Lfield/RangeSeekBar;->getAbsoluteMinValue()Ljava/lang/Number;

    move-result-object v2

    invoke-virtual {v0, v2}, Lfield/RangeSeekBar;->setSelectedMinValue(Ljava/lang/Number;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v2}, Lfield/RangeSeekBar;->getAbsoluteMaxValue()Ljava/lang/Number;

    move-result-object v2

    invoke-virtual {v0, v2}, Lfield/RangeSeekBar;->setSelectedMaxValue(Ljava/lang/Number;)V

    const v0, 0x7f060078

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    const v0, 0x7f060079

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GN:Landroid/widget/TextView;

    const v1, 0x7f0b01b7

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v0}, Lcomponents/a;->notifyDataSetChanged()V

    return-void
.end method


# virtual methods
.method public cL(I)V
    .locals 2

    const/4 v0, 0x1

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b012d

    :goto_0
    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    if-ne p1, v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b012e

    goto :goto_0

    :cond_1
    return-void
.end method

.method public onBackPressed()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {v0}, Landroid/widget/ViewFlipper;->getDisplayedChild()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pL()V

    return-void

    :cond_0
    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->cK(I)V

    return-void
.end method

.method public onClickContinuarConv(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pL()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070008

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    const p1, 0x7f060329

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b0120

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f06010f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v0, p0}, La/ac;->f(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const p1, 0x7f0600e4

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ViewFlipper;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gs:Landroid/widget/ViewFlipper;

    const p1, 0x7f060224

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lfield/RangeSeekBar;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GR:Lfield/RangeSeekBar;

    const p1, 0x7f060050

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gz:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->Gz:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityConvoca$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConvoca$1;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060051

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GA:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GA:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityConvoca$8;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConvoca$8;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06003a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GB:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GB:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityConvoca$9;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConvoca$9;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06001e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GC:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GC:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityConvoca$10;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityConvoca$10;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f060021

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GD:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GD:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityConvoca$11;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityConvoca$11;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f060020

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GE:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GE:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityConvoca$12;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityConvoca$12;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f060014

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GF:Landroid/widget/Button;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GF:Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityConvoca$13;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityConvoca$13;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GC:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GC:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityConvoca$14;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConvoca$14;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pC()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pD()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pF()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pE()V

    :try_start_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pB()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const p1, 0x7f060198

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    new-instance p1, Lcomponents/a;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/a;-><init>(Ljava/util/ArrayList;Lcom/brasfoot/v2028/ActivityConvoca;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityConvoca$15;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConvoca$15;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityConvoca$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConvoca$2;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemLongClickListener(Landroid/widget/AdapterView$OnItemLongClickListener;)V

    const p1, 0x7f06031d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GN:Landroid/widget/TextView;

    const p1, 0x7f06030d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GO:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->px()V

    const/4 p1, 0x3

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityConvoca;->cK(I)V

    return-void
.end method

.method public pG()V
    .locals 3

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0b0127

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityConvoca$4;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca$4;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityConvoca$5;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca$5;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public pH()V
    .locals 3

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v0}, Lcomponents/a;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GG:Lcomponents/b;

    invoke-virtual {v0}, Lcomponents/b;->notifyDataSetChanged()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pK()[I

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->ab(II)V

    return-void
.end method

.method public pI()V
    .locals 3

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0b011e

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityConvoca$6;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca$6;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityConvoca$7;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca$7;-><init>(Lcom/brasfoot/v2028/ActivityConvoca;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public pJ()V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v1}, La/ac;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, La/b;->al(I)La/y;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/y;->N(Z)V

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->px()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityConvoca;->ab(II)V

    return-void
.end method

.method public pL()V
    .locals 4

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pK()[I

    move-result-object v0

    const/4 v1, 0x0

    aget v1, v0, v1

    iget v2, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GT:I

    const/4 v3, 0x1

    if-lt v1, v2, :cond_1

    aget v0, v0, v3

    iget v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GU:I

    if-ge v0, v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->finish()V

    return-void

    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b012c

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public py()V
    .locals 2

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v0}, Lcomponents/a;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v0}, Lcomponents/a;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v1}, Lcomponents/a;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GS:La/p;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GS:La/p;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->s(La/p;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GS:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public q(La/p;)V
    .locals 4

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pK()[I

    move-result-object v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_0

    aget v0, v0, v2

    iget v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GV:I

    if-lt v0, v1, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    aget v0, v0, v3

    iget v1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GW:I

    if-lt v0, v1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, -0x1

    const/4 v0, -0x1

    const/4 v2, 0x1

    :goto_0
    if-eqz v2, :cond_2

    sput-boolean v3, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {p1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v0, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    invoke-virtual {p1}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {p1}, Lcomponents/a;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GG:Lcomponents/b;

    invoke-virtual {p1}, Lcomponents/b;->notifyDataSetChanged()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pK()[I

    return-void

    :cond_2
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->cL(I)V

    :cond_3
    return-void
.end method

.method public r(La/p;)V
    .locals 2

    if-eqz p1, :cond_0

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GQ:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {v0}, Lcomponents/a;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GG:Lcomponents/b;

    invoke-virtual {p1}, Lcomponents/b;->notifyDataSetChanged()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConvoca;->pK()[I

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityConvoca;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityConvoca;->ab(II)V

    :cond_0
    return-void
.end method
