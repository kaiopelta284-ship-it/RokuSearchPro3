.class Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityEscolhaTimes;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    iget-object v0, v0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    if-gez p3, :cond_1

    :cond_0
    return-void

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    iget-object v0, v0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt p3, v0, :cond_2

    return-void

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    iget-object v0, v0, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v0, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-virtual {v0}, La/ac;->lx()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_4

    :cond_3
    return-void

    :cond_4
    :try_start_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    const v2, 0x7f06034c

    invoke-virtual {v1, v2}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    if-eqz v1, :cond_5

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$3;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    invoke-virtual {v2}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->getFilesDir()Ljava/io/File;

    move-result-object v2

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".png"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v2, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_5

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_5
    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
