.class Lcom/brasfoot/v2028/ActivityTimes$10;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityTimes;->rH()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic Lm:Landroid/widget/EditText;

.field final synthetic MK:Lcom/brasfoot/v2028/ActivityTimes;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityTimes;Landroid/widget/EditText;Landroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    iput-object p2, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->Lm:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->Lm:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "\\d+"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivityTimes;->G(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, -0x1

    :goto_0
    const/4 v1, 0x1

    if-ltz v0, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-static {v2}, Lcom/brasfoot/v2028/ActivityTimes;->d(Lcom/brasfoot/v2028/ActivityTimes;)La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lA()J

    move-result-wide v2

    int-to-long v4, v0

    cmp-long v0, v2, v4

    if-lez v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-virtual {v0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->M(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b0131

    goto :goto_1

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$10;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b00d7

    :goto_1
    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method
