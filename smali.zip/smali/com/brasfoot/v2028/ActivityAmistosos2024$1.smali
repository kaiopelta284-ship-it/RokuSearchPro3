.class Lcom/brasfoot/v2028/ActivityAmistosos2024$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/ExpandableListView$OnChildClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityAmistosos2024;->pe()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityAmistosos2024;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onChildClick(Landroid/widget/ExpandableListView;Landroid/view/View;IIJ)Z
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fe:Lcomponents/ar;

    invoke-virtual {p1, p3, p4}, Lcomponents/ar;->al(II)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    const p2, 0x7f0602ce

    invoke-virtual {p1, p2}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    iget-object p2, p2, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fe:Lcomponents/ar;

    invoke-virtual {p2, p3, p4}, Lcomponents/ar;->getChild(II)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/ac;

    if-eqz p2, :cond_0

    invoke-virtual {p2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p3, 0x0

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    invoke-static {p1, p2}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->a(Lcom/brasfoot/v2028/ActivityAmistosos2024;La/ac;)La/ac;

    :cond_0
    const/4 p1, 0x1

    return p1
.end method
