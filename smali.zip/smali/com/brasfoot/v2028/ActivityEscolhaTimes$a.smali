.class Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityEscolhaTimes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;


# direct methods
.method private constructor <init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;Lcom/brasfoot/v2028/ActivityEscolhaTimes$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;-><init>(Lcom/brasfoot/v2028/ActivityEscolhaTimes;)V

    return-void
.end method


# virtual methods
.method protected varargs b([Ljava/lang/String;)Ljava/lang/Boolean;
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->qh()V

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;->b([Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected l(Ljava/lang/Boolean;)V
    .locals 0

    return-void
.end method

.method protected synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;->l(Ljava/lang/Boolean;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscolhaTimes$a;->Iu:Lcom/brasfoot/v2028/ActivityEscolhaTimes;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityEscolhaTimes;->pv()V

    return-void
.end method
