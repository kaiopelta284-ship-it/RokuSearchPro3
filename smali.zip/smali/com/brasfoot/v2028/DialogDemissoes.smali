.class public Lcom/brasfoot/v2028/DialogDemissoes;
.super Landroid/app/Activity;


# instance fields
.field private MQ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/be;",
            ">;"
        }
    .end annotation
.end field

.field MR:Lcomponents/n;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MQ:Ljava/util/ArrayList;

    return-void
.end method

.method private pw()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/DialogDemissoes$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogDemissoes$1;-><init>(Lcom/brasfoot/v2028/DialogDemissoes;)V

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private sw()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->sv()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->finish()V

    return-void
.end method


# virtual methods
.method public onBackPressed()V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->sw()V

    return-void
.end method

.method public onClickCD(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->sw()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070030

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogDemissoes;->setContentView(I)V

    invoke-static {}, La/o;->ht()Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MQ:Ljava/util/ArrayList;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MQ:Ljava/util/ArrayList;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MQ:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_0

    const p1, 0x7f06019e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogDemissoes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v0, Lcomponents/n;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MQ:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/n;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MR:Lcomponents/n;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogDemissoes;->MR:Lcomponents/n;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    return-void

    :cond_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->sw()V

    return-void
.end method

.method public onStart()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->sw()V

    :cond_0
    return-void
.end method

.method public pv()V
    .locals 2

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogDemissoes;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method

.method public sv()V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogDemissoes;->pw()V

    invoke-static {}, La/o;->hz()V

    return-void
.end method
