.class Lcom/brasfoot/v2028/ActivityJogo$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityJogo;->qv()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic JC:Lcom/brasfoot/v2028/ActivityJogo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityJogo;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo$2;->JC:Lcom/brasfoot/v2028/ActivityJogo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJogo$2;->JC:Lcom/brasfoot/v2028/ActivityJogo;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityJogo;->JA:Lcomponents/z;

    invoke-virtual {p1, p3}, Lcomponents/z;->dm(I)V

    return-void
.end method
