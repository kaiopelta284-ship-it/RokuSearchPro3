.class Lcom/brasfoot/v2028/DialogIgrokInfo$TitInd;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/DialogIgrokInfo;
.end annotation


# instance fields
.field final synthetic this$0:Lcom/brasfoot/v2028/DialogIgrokInfo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$TitInd;->this$0:Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$TitInd;->this$0:Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->showTitulosInd()V

    return-void
.end method
