.class public Lcom/brasfoot/v2028/ActivityAgenda;
.super Landroid/app/Activity;


# static fields
.field public static saiMap:[I


# instance fields
.field private Iv:La/ac;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private fill(I[Ljava/lang/String;)V
    .locals 3

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, p2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    const v2, 0x1090009

    invoke-virtual {v1, v2}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    :cond_0
    return-void
.end method

.method private getSel(I)I
    .locals 2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    return v1

    :cond_0
    const/4 v1, 0x0

    return v1
.end method

.method private loadAg()V
    .locals 10

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    if-eqz v0, :cond_3

    iget v1, v0, La/ac;->agCond:I

    const v2, 0x7f060416

    invoke-direct {p0, v2, v1}, Lcom/brasfoot/v2028/ActivityAgenda;->setSel(II)V

    const v1, 0x7f06042d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Switch;

    if-eqz v1, :cond_1

    iget-boolean v2, v0, La/ac;->agOff:Z

    if-nez v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    :cond_1
    iget-object v1, v0, La/ac;->agMin:[I

    if-eqz v1, :cond_3

    iget-object v2, v0, La/ac;->agOut:[I

    if-eqz v2, :cond_3

    iget-object v3, v0, La/ac;->agIn:[I

    if-eqz v3, :cond_3

    const/4 v4, 0x5

    new-array v5, v4, [I

    fill-array-data v5, :array_0

    new-array v6, v4, [I

    fill-array-data v6, :array_1

    new-array v7, v4, [I

    fill-array-data v7, :array_2

    const/4 v8, 0x0

    :goto_1
    if-ge v8, v4, :cond_3

    aget v9, v1, v8

    if-lez v9, :cond_2

    aget v0, v5, v8

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    if-eqz v0, :cond_2

    invoke-static {v9}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    aget v0, v6, v8

    aget v9, v2, v8

    add-int/lit8 v9, v9, 0x1

    invoke-direct {p0, v0, v9}, Lcom/brasfoot/v2028/ActivityAgenda;->setSel(II)V

    aget v0, v7, v8

    aget v9, v3, v8

    add-int/lit8 v9, v9, 0x1

    invoke-direct {p0, v0, v9}, Lcom/brasfoot/v2028/ActivityAgenda;->setSel(II)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_3
    return-void

    nop

    :array_0
    .array-data 4
        0x7f060417
        0x7f060418
        0x7f060419
        0x7f06041a
        0x7f06041b
    .end array-data

    :array_1
    .array-data 4
        0x7f06041c
        0x7f06041d
        0x7f06041e
        0x7f06041f
        0x7f060420
    .end array-data

    :array_2
    .array-data 4
        0x7f060421
        0x7f060422
        0x7f060423
        0x7f060424
        0x7f060425
    .end array-data
.end method

.method private static mapOut(I)I
    .locals 2

    const/4 v0, -0x1

    if-gtz p0, :cond_0

    return v0

    :cond_0
    sget-object v1, Lcom/brasfoot/v2028/ActivityAgenda;->saiMap:[I

    if-eqz v1, :cond_2

    add-int/lit8 p0, p0, -0x1

    array-length v0, v1

    if-lt p0, v0, :cond_1

    const/4 v0, -0x1

    return v0

    :cond_1
    aget v0, v1, p0

    :cond_2
    return v0
.end method

.method private nomeDoIdx(I)Ljava/lang/String;
    .locals 3

    const-string v0, ""

    if-ltz p1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p1, v2, :cond_0

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    invoke-virtual {v1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method private nomes()[Ljava/lang/String;
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v2, v1, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "\u2014"

    aput-object v4, v2, v3

    :goto_0
    if-ge v3, v1, :cond_0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v4}, Lcom/brasfoot/v2028/ActivityAgenda;->posAbbr(La/p;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, La/p;->getNome()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    add-int/lit8 v6, v3, 0x1

    aput-object v5, v2, v6

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-object v2

    :cond_1
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "\u2014"

    aput-object v2, v0, v1

    return-object v0
.end method

.method private nomesSai()[Ljava/lang/String;
    .locals 9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_5

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    invoke-static {v1}, Lcom/brasfoot/v2028/Recopa;->startersIdx(La/ac;)[I

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    array-length v4, v1

    if-ge v3, v4, :cond_1

    aget v4, v1, v3

    if-ltz v4, :cond_0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    add-int/lit8 v2, v2, 0x1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    if-gtz v2, :cond_2

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAgenda;->nomesSaiFallback()[Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_2
    new-array v5, v2, [I

    sput-object v5, Lcom/brasfoot/v2028/ActivityAgenda;->saiMap:[I

    add-int/lit8 v6, v2, 0x1

    new-array v6, v6, [Ljava/lang/String;

    const/4 v7, 0x0

    const-string v8, "\u2014"

    aput-object v8, v6, v7

    const/4 v3, 0x0

    const/4 v7, 0x0

    :goto_1
    array-length v4, v1

    if-ge v3, v4, :cond_4

    aget v4, v1, v3

    if-ltz v4, :cond_3

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v4, v8, :cond_3

    aput v4, v5, v7

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/p;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v8}, Lcom/brasfoot/v2028/ActivityAgenda;->posAbbr(La/p;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, " "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v8, v5, v7

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/p;

    invoke-virtual {v8}, La/p;->getNome()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    add-int/lit8 v8, v7, 0x1

    aput-object v4, v6, v8

    add-int/lit8 v7, v7, 0x1

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_4
    return-object v6

    :cond_5
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "\u2014"

    aput-object v2, v0, v1

    return-object v0
.end method

.method private nomesSaiFallback()[Ljava/lang/String;
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v2, 0xb

    if-le v1, v2, :cond_0

    const/16 v1, 0xb

    :cond_0
    new-array v2, v1, [I

    sput-object v2, Lcom/brasfoot/v2028/ActivityAgenda;->saiMap:[I

    add-int/lit8 v3, v1, 0x1

    new-array v3, v3, [Ljava/lang/String;

    const/4 v4, 0x0

    const-string v5, "\u2014"

    aput-object v5, v3, v4

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v1, :cond_1

    aput v4, v2, v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v5}, Lcom/brasfoot/v2028/ActivityAgenda;->posAbbr(La/p;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, La/p;->getNome()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    add-int/lit8 v7, v4, 0x1

    aput-object v6, v3, v7

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    return-object v3
.end method

.method private parseEd(Landroid/widget/EditText;)I
    .locals 2

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    :try_start_0
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v0, 0x0

    :cond_0
    :goto_0
    return v0
.end method

.method private static posAbbr(La/p;)Ljava/lang/String;
    .locals 3

    invoke-virtual {p0}, La/p;->getPosicao()I

    move-result v0

    if-eqz v0, :cond_5

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const-string v2, "L"

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    if-ne v0, v1, :cond_1

    const-string v2, "Z"

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    const-string v2, "M"

    goto :goto_0

    :cond_2
    const-string v2, "AT"

    :goto_0
    invoke-virtual {p0}, La/p;->getLado()I

    move-result v0

    if-nez v0, :cond_3

    const-string v0, "D"

    goto :goto_1

    :cond_3
    const/4 v1, 0x1

    if-ne v0, v1, :cond_4

    const-string v0, "E"

    goto :goto_1

    :cond_4
    const-string v0, ""

    :goto_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_5
    const-string v0, "GOL"

    return-object v0
.end method

.method private static revOut(I)I
    .locals 3

    const/4 v0, 0x0

    if-gez p0, :cond_0

    return v0

    :cond_0
    sget-object v1, Lcom/brasfoot/v2028/ActivityAgenda;->saiMap:[I

    if-eqz v1, :cond_3

    const/4 v2, 0x0

    :goto_0
    array-length v0, v1

    if-ge v2, v0, :cond_2

    aget v0, v1, v2

    if-ne v0, p0, :cond_1

    add-int/lit8 v0, v2, 0x1

    return v0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :cond_3
    return v0
.end method

.method private setSel(II)V
    .locals 2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_2

    if-gez p2, :cond_0

    const/4 p2, 0x0

    :cond_0
    invoke-virtual {v0}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    if-lt p2, v1, :cond_1

    add-int/lit8 p2, v1, -0x1

    :cond_1
    if-ltz p2, :cond_2

    invoke-virtual {v0, p2}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_2
    return-void
.end method


# virtual methods
.method public onClickSalvarAgenda(Landroid/view/View;)V
    .locals 10

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    new-array v1, v4, [I

    new-array v2, v4, [I

    new-array v3, v4, [I

    new-array v5, v4, [I

    fill-array-data v5, :array_0

    new-array v6, v4, [I

    fill-array-data v6, :array_1

    new-array v7, v4, [I

    fill-array-data v7, :array_2

    const/4 v8, 0x0

    :goto_0
    if-ge v8, v4, :cond_0

    aget v9, v5, v8

    invoke-virtual {p0, v9}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/EditText;

    invoke-direct {p0, v9}, Lcom/brasfoot/v2028/ActivityAgenda;->parseEd(Landroid/widget/EditText;)I

    move-result v9

    aput v9, v1, v8

    aget v9, v6, v8

    invoke-direct {p0, v9}, Lcom/brasfoot/v2028/ActivityAgenda;->getSel(I)I

    move-result v9

    add-int/lit8 v9, v9, -0x1

    aput v9, v2, v8

    aget v9, v7, v8

    invoke-direct {p0, v9}, Lcom/brasfoot/v2028/ActivityAgenda;->getSel(I)I

    move-result v9

    add-int/lit8 v9, v9, -0x1

    aput v9, v3, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_0
    iput-object v1, v0, La/ac;->agMin:[I

    iput-object v2, v0, La/ac;->agOut:[I

    iput-object v3, v0, La/ac;->agIn:[I

    const/4 v4, 0x5

    new-array v5, v4, [Ljava/lang/String;

    new-array v6, v4, [Ljava/lang/String;

    const/4 v7, 0x0

    :goto_1
    if-ge v7, v4, :cond_1

    aget v8, v2, v7

    invoke-direct {p0, v8}, Lcom/brasfoot/v2028/ActivityAgenda;->nomeDoIdx(I)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v5, v7

    aget v8, v3, v7

    invoke-direct {p0, v8}, Lcom/brasfoot/v2028/ActivityAgenda;->nomeDoIdx(I)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_1
    iput-object v5, v0, La/ac;->agOutNome:[Ljava/lang/String;

    iput-object v6, v0, La/ac;->agInNome:[Ljava/lang/String;

    const v1, 0x7f060416

    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityAgenda;->getSel(I)I

    move-result v1

    iput v1, v0, La/ac;->agCond:I

    const v1, 0x7f06042d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAgenda;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Switch;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/widget/Switch;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, 0x0

    goto :goto_2

    :cond_2
    const/4 v1, 0x1

    :goto_2
    iput-boolean v1, v0, La/ac;->agOff:Z

    :cond_3
    const-string v0, "Agendamento salvo!"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAgenda;->finish()V

    return-void

    :array_0
    .array-data 4
        0x7f060417
        0x7f060418
        0x7f060419
        0x7f06041a
        0x7f06041b
    .end array-data

    :array_1
    .array-data 4
        0x7f06041c
        0x7f06041d
        0x7f06041e
        0x7f06041f
        0x7f060420
    .end array-data

    :array_2
    .array-data 4
        0x7f060421
        0x7f060422
        0x7f060423
        0x7f060424
        0x7f060425
    .end array-data
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070079

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityAgenda;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAgenda;->Iv:La/ac;

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "Sempre"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "So vencendo"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "So perdendo"

    aput-object v2, v0, v1

    const v1, 0x7f060416

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityAgenda;->fill(I[Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAgenda;->nomes()[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x5

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    new-array v3, v1, [I

    fill-array-data v3, :array_1

    const/4 v1, 0x0

    :goto_0
    const/4 p1, 0x5

    if-ge v1, p1, :cond_0

    aget p1, v2, v1

    invoke-direct {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityAgenda;->fill(I[Ljava/lang/String;)V

    aget p1, v3, v1

    invoke-direct {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityAgenda;->fill(I[Ljava/lang/String;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAgenda;->loadAg()V

    return-void

    nop

    :array_0
    .array-data 4
        0x7f06041c
        0x7f06041d
        0x7f06041e
        0x7f06041f
        0x7f060420
    .end array-data

    :array_1
    .array-data 4
        0x7f060421
        0x7f060422
        0x7f060423
        0x7f060424
        0x7f060425
    .end array-data
.end method
