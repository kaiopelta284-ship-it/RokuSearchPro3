.class Lcom/brasfoot/v2028/ActivitySub$a;
.super Ljava/lang/Object;

# interfaces
.implements Lb/a/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivitySub;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic Mq:Lcom/brasfoot/v2028/ActivitySub;


# direct methods
.method private constructor <init>(Lcom/brasfoot/v2028/ActivitySub;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub$a;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/brasfoot/v2028/ActivitySub;Lcom/brasfoot/v2028/ActivitySub$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivitySub$a;-><init>(Lcom/brasfoot/v2028/ActivitySub;)V

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/Purchase;",
            ">;)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySub$a;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivitySub;->sf()V

    return-void
.end method

.method public d(Ljava/lang/String;I)V
    .locals 0

    return-void
.end method

.method public on()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub$a;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivitySub;->sf()V

    return-void
.end method
