.class public Lcom/brasfoot/v2028/ActivityLoad$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityLoad;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field final synthetic JW:Lcom/brasfoot/v2028/ActivityLoad;


# direct methods
.method public constructor <init>(Lcom/brasfoot/v2028/ActivityLoad;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad$b;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad$b;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityLoad;->qS()V

    return-void
.end method
