.class public Lcom/brasfoot/v2028/DialogIgrokInfo;
.super Landroid/app/Activity;


# static fields
.field public static Ng:Landroid/app/Activity;


# instance fields
.field IU:Landroid/widget/ImageView;

.field IV:Landroid/widget/ImageView;

.field IW:Landroid/widget/ImageView;

.field private MA:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/e;",
            ">;"
        }
    .end annotation
.end field

.field Mv:Landroid/widget/Button;

.field Nd:La/p;

.field Ne:Landroid/widget/ImageView;

.field private Nf:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bq;",
            ">;"
        }
    .end annotation
.end field

.field Nh:Lcomponents/y;

.field Ni:Lcomponents/x;

.field Nj:Landroid/widget/ListView;

.field Nk:Landroid/widget/ListView;

.field private Nl:I

.field private Nm:I

.field private Nn:I

.field private No:I

.field Np:Landroid/widget/Button;

.field po:La/ac;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nf:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nl:I

    iput v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nm:I

    iput v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nn:I

    iput v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->No:I

    return-void
.end method

.method public static G(Ljava/lang/String;)Z
    .locals 1

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    return v0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogIgrokInfo;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sD()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogIgrokInfo;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->cK(I)V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogIgrokInfo;ZLjava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->a(ZLjava/lang/String;)V

    return-void
.end method

.method private a(ZLjava/lang/String;)V
    .locals 1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "000"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    if-eqz p1, :cond_0

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->dj(I)V

    return-void

    :cond_0
    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->dk(I)V

    return-void
.end method

.method private aj(II)Z
    .locals 4

    iput p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nm:I

    const/4 v0, 0x4

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v2}, La/p;->hH()I

    move-result v2

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->hH()I

    move-result v3

    aget v1, v1, p2

    mul-int v3, v3, v1

    div-int/lit8 v3, v3, 0x64

    int-to-float v1, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    sub-int/2addr v2, v1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->hH()I

    move-result v1

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->hH()I

    move-result v3

    aget p2, v0, p2

    mul-int v3, v3, p2

    div-int/lit8 v3, v3, 0x64

    int-to-float p2, v3

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    add-int/2addr v1, p2

    iget-object p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p2}, La/p;->in()I

    move-result p2

    const/4 v0, 0x0

    const/16 v3, 0x3c

    if-ge p2, v3, :cond_0

    iput v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nl:I

    if-ge p1, v2, :cond_1

    return v0

    :cond_0
    iput v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nl:I

    if-ge p1, v1, :cond_1

    return v0

    :cond_1
    const/4 p1, 0x1

    return p1

    :array_0
    .array-data 4
        0x1
        0x3
        0x5
        0xc
    .end array-data

    :array_1
    .array-data 4
        0xa
        0xc
        0xf
        0x5
    .end array-data
.end method

.method private ak(II)V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v2}, La/p;->c(Ljava/lang/Boolean;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->hK()V

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    aget p2, v0, p2

    int-to-long v3, p2

    invoke-virtual {v2, v3, v4, v1}, La/p;->a(JZ)V

    iget-object p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p2, p1}, La/p;->aQ(I)V

    const/4 p1, 0x1

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    const p2, 0x7f0b0116

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p2, p1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->im()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_0

    const p1, 0x7f0b009f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const p2, 0x7f0b014c

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p2}, La/p;->im()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p2, 0x7f0602d3

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    nop

    :array_0
    .array-data 4
        0xb4
        0x16d
        0x2da
        0x447
    .end array-data
.end method

.method static synthetic b(Lcom/brasfoot/v2028/DialogIgrokInfo;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sC()V

    return-void
.end method

.method private cK(I)V
    .locals 10

    const v0, 0x7f06040b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    const/16 v9, 0x8

    invoke-virtual {v0, v9}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const v0, 0x7f06040a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    const v8, 0x7f030013

    invoke-virtual {v9, v8}, Landroid/content/res/Resources;->getColor(I)I

    move-result v8

    invoke-virtual {v0, v8}, Landroid/widget/Button;->setBackgroundColor(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    const v8, 0x7f030038

    invoke-virtual {v9, v8}, Landroid/content/res/Resources;->getColor(I)I

    move-result v8

    invoke-virtual {v0, v8}, Landroid/widget/Button;->setTextColor(I)V

    :cond_1
    const v0, 0x7f0601a3

    const v1, 0x7f060199

    const v2, 0x7f060157

    const v3, 0x7f030010

    const v4, 0x7f030007

    const v5, 0x7f030038

    const v6, 0x7f030013

    const/16 v7, 0x8

    const/4 v8, 0x0

    if-nez p1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v8}, Landroid/widget/ListView;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v7}, Landroid/widget/ListView;->setVisibility(I)V

    return-void

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v7}, Landroid/widget/ListView;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v8}, Landroid/widget/ListView;->setVisibility(I)V

    return-void
.end method

.method private dj(I)V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0, p1}, La/p;->aS(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->hI()I

    move-result v0

    if-ge p1, v0, :cond_2

    const-wide v0, 0x3fb999999999999aL    # 0.1

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const/16 v3, 0x64

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    const/16 v3, 0x32

    if-le v2, v3, :cond_0

    const-wide v0, 0x3fc3333333333333L    # 0.15

    :cond_0
    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v2}, La/p;->hI()I

    move-result v2

    int-to-double v2, v2

    mul-double v2, v2, v0

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->hI()I

    move-result v1

    sub-int v0, v1, v0

    if-ge v0, p1, :cond_1

    goto :goto_0

    :cond_1
    move p1, v0

    :cond_2
    :goto_0
    new-instance v0, Lcomponents/ck;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1, p1, v3, v2}, Lcomponents/ck;-><init>(La/p;IZZ)V

    invoke-virtual {v0}, Lcomponents/ck;->vG()La/ac;

    move-result-object p1

    if-eqz p1, :cond_3

    const p1, 0x7f0b00cc

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    invoke-virtual {v0}, Lcomponents/ck;->vF()I

    move-result v1

    int-to-long v4, v1

    invoke-static {v4, v5}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    invoke-virtual {v0}, Lcomponents/ck;->vG()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    aput-object v0, v5, v2

    aput-object v1, v5, v3

    invoke-virtual {v4, p1, v5}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->finish()V

    return-void

    :cond_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b00cb

    invoke-static {p1, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private dk(I)V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v2}, La/p;->c(Ljava/lang/Boolean;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0, p1}, La/p;->aS(I)V

    const p1, 0x7f0b0174

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "ic_moneybag_128_m"

    const-string v2, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$5;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$5;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private dl(I)Z
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->hH()I

    move-result v0

    mul-int/lit8 v0, v0, 0x5

    if-le p1, v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    const/4 p1, 0x1

    return p1
.end method

.method private sC()V
    .locals 7

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v2, 0x7f07002f

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setContentView(I)V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    const v3, 0x7f060316

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->getNome()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->im()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_0

    const v3, 0x7f0b009f

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b014c

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->im()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f0602f7

    invoke-virtual {v0, v4}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f0b006f

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->hH()I

    move-result v4

    int-to-long v4, v4

    invoke-static {v4, v5}, La/n;->b(J)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f060327

    invoke-virtual {v0, v4}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/String;

    const v4, 0x7f0b01dd

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v2

    const v4, 0x7f0b0132

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v1

    const/4 v1, 0x2

    const v4, 0x7f0b0265

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v1

    const/4 v1, 0x3

    const v4, 0x7f0b0259

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v1

    const v1, 0x7f0600b5

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/EditText;

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->hH()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f06022d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    const v4, 0x7f06001c

    invoke-virtual {v0, v4}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/Button;

    new-instance v5, Lcom/brasfoot/v2028/DialogIgrokInfo$19;

    invoke-direct {v5, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$19;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v4, 0x7f060011

    invoke-virtual {v0, v4}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/Button;

    new-instance v5, Lcom/brasfoot/v2028/DialogIgrokInfo$20;

    invoke-direct {v5, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$20;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    :goto_0
    array-length v6, v3

    if-ge v5, v6, :cond_1

    aget-object v6, v3, v5

    invoke-interface {v4, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_1
    new-instance v3, Landroid/widget/ArrayAdapter;

    const v5, 0x1090008

    invoke-direct {v3, p0, v5, v4}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v4, 0x1090009

    invoke-virtual {v3, v4}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {v1, v3}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private sD()V
    .locals 8

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->in()I

    move-result v1

    const/4 v2, 0x0

    if-gtz v1, :cond_0

    iput v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nn:I

    goto :goto_1

    :cond_0
    const/16 v3, 0x1e

    if-lez v1, :cond_1

    if-gt v1, v3, :cond_1

    const/16 v1, 0xc

    :goto_0
    iput v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nn:I

    goto :goto_1

    :cond_1
    const/16 v4, 0x3c

    if-gt v1, v4, :cond_2

    const/16 v1, 0x14

    goto :goto_0

    :cond_2
    const/16 v4, 0x5a

    if-gt v1, v4, :cond_3

    const/16 v1, 0x16

    goto :goto_0

    :cond_3
    const/16 v4, 0xb4

    if-gt v1, v4, :cond_4

    const/16 v1, 0x19

    goto :goto_0

    :cond_4
    const/16 v4, 0x2d2

    if-gt v1, v4, :cond_5

    iput v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nn:I

    goto :goto_1

    :cond_5
    const/16 v1, 0x23

    goto :goto_0

    :goto_1
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v3, 0x7f07003a

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->setContentView(I)V

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    const v3, 0x7f060319

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->getNome()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->getNome()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v3, 0x7f0600b7

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/EditText;

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->hI()I

    move-result v5

    iget v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nn:I

    mul-int v5, v5, v6

    div-int/lit8 v5, v5, 0x64

    int-to-float v5, v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iput v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->No:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f0b016e

    new-array v1, v1, [Ljava/lang/Object;

    iget v7, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nn:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v1, v2

    invoke-virtual {v5, v6, v1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f0602da

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->hI()I

    move-result v3

    div-int/lit16 v3, v3, 0x3e8

    int-to-float v3, v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    iget v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->No:I

    if-nez v1, :cond_6

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_6
    const v1, 0x7f060311

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->N(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v2, Lcom/brasfoot/v2028/DialogIgrokInfo$2;

    invoke-direct {v2, p0, v1, v4}, Lcom/brasfoot/v2028/DialogIgrokInfo$2;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/widget/TextView;Landroid/widget/EditText;)V

    invoke-virtual {v4, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const v1, 0x7f060023

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/DialogIgrokInfo$3;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$3;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f060035

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/DialogIgrokInfo$4;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$4;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private sF()V
    .locals 8

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    if-eqz v1, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    :goto_0
    if-ltz v1, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_1
    if-ltz v1, :cond_1

    aget v5, v0, v3

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v6}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/e;

    invoke-virtual {v6}, La/e;->fC()I

    move-result v6

    add-int/2addr v5, v6

    aput v5, v0, v3

    aget v5, v0, v2

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v6}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/e;

    invoke-virtual {v6}, La/e;->fy()I

    move-result v6

    add-int/2addr v5, v6

    aput v5, v0, v2

    const/4 v5, 0x2

    aget v6, v0, v5

    iget-object v7, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v7}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/e;

    invoke-virtual {v7}, La/e;->fN()I

    move-result v7

    add-int/2addr v6, v7

    aput v6, v0, v5

    const/4 v5, 0x3

    aget v6, v0, v5

    iget-object v7, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v7}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/e;

    invoke-virtual {v7}, La/e;->fO()I

    move-result v7

    add-int/2addr v6, v7

    aput v6, v0, v5

    const/4 v5, 0x4

    aget v6, v0, v5

    iget-object v7, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v7}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/e;

    invoke-virtual {v7}, La/e;->fP()I

    move-result v7

    add-int/2addr v6, v7

    aput v6, v0, v5

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->iE()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/e;

    invoke-virtual {v5}, La/e;->fW()I

    move-result v5

    add-int/2addr v4, v5

    add-int/lit8 v1, v1, -0x1

    goto/16 :goto_1

    :cond_1
    new-instance v1, La/e;

    invoke-direct {v1, v2, v0}, La/e;-><init>(Z[I)V

    invoke-virtual {v1, v4}, La/e;->ay(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->ig()I

    move-result v0

    if-lez v0, :cond_2

    new-instance v0, La/e;

    invoke-direct {v0}, La/e;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->ig()I

    move-result v1

    invoke-virtual {v0, v1}, La/e;->ax(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    new-instance v0, Lcomponents/y;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/y;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nh:Lcomponents/y;

    const v0, 0x7f060199

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nj:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nj:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nh:Lcomponents/y;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    :goto_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->MA:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/e;

    invoke-virtual {v0}, La/e;->db()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_3

    goto :goto_3

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    :goto_3
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nf:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->iF()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->iF()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    sub-int/2addr v0, v2

    :goto_4
    if-ltz v0, :cond_5

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nf:Ljava/util/ArrayList;

    new-instance v2, Lcomponents/bq;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->iF()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/br;

    invoke-direct {v2, v3}, Lcomponents/bq;-><init>(Lcomponents/br;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    goto :goto_4

    :cond_5
    new-instance v0, Lcomponents/x;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nf:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/x;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Ni:Lcomponents/x;

    const v0, 0x7f0601a3

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nk:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nk:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Ni:Lcomponents/x;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    :cond_6
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method private sJ()V
    .locals 5

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v1, 0x0

    const/4 v0, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v3

    if-ne v3, v4, :cond_0

    invoke-virtual {v2}, Lcomponents/bn;->uD()La/ac;

    move-result-object v1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz v1, :cond_2

    invoke-virtual {v4, v1}, La/p;->m(La/ac;)V

    :cond_2
    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->finish()V

    const v1, 0x7f0b016a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private selTitulosTab()V
    .locals 4

    const v0, 0x7f06040a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030007

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setBackgroundColor(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030010

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setTextColor(I)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030013

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setBackgroundColor(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030038

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setTextColor(I)V

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030013

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setBackgroundColor(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f030038

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setTextColor(I)V

    :cond_2
    return-void
.end method


# virtual methods
.method public N(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "000"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "\\d+"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->G(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-ltz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    int-to-long v0, p1

    invoke-static {v0, v1}, La/n;->b(J)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    const p1, 0x7f0b00d7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public dd(I)V
    .locals 3

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sJ()V

    return-void

    :cond_0
    const/4 v1, 0x2

    const v2, 0x7f0602d4

    if-ne p1, v1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p1, v0}, La/p;->g(Ljava/lang/Boolean;)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_1
    const/4 v1, 0x3

    if-ne p1, v1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p1, v0}, La/p;->g(Ljava/lang/Boolean;)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const v0, 0x7f0b0158

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    return-void

    :cond_2
    const/4 v0, 0x4

    if-ne p1, v0, :cond_3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sH()V

    :cond_3
    return-void
.end method

.method public e(ILjava/lang/String;)V
    .locals 4

    const-string v0, ""

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "\\d+"

    invoke-virtual {p2, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->G(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-lez v0, :cond_0

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p2

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    const/4 v0, 0x1

    if-nez p2, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f0b00d7

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    :goto_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_1
    invoke-direct {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->dl(I)Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-direct {p0, p2, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->aj(II)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0, p2, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->ak(II)V

    return-void

    :cond_2
    iget p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nl:I

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const p2, 0x7f0b01ac

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nl:I

    int-to-long v2, p2

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ". "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const p2, 0x7f0b001a

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->f(Ljava/lang/String;I)V

    return-void

    :cond_3
    invoke-direct {p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->dl(I)Z

    move-result p1

    if-nez p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->hH()I

    move-result p1

    mul-int/lit8 p1, p1, 0x5

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const v2, 0x7f0b01ad

    new-array v3, v0, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v3, v1

    invoke-virtual {p2, v2, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :cond_4
    return-void
.end method

.method public e(Ljava/lang/String;I)V
    .locals 2

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/DialogIgrokInfo$9;

    invoke-direct {v1, p0, p2, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$9;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;ILandroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance p2, Lcom/brasfoot/v2028/DialogIgrokInfo$10;

    invoke-direct {p2, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$10;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {p1, p2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public f(Ljava/lang/String;I)V
    .locals 1

    new-instance p2, Landroid/app/Dialog;

    invoke-direct {p2, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v0, 0x7f07002e

    invoke-virtual {p2, v0}, Landroid/app/Dialog;->setContentView(I)V

    const v0, 0x7f0600a6

    invoke-virtual {p2, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {p2, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$6;

    invoke-direct {v0, p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo$6;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {p2, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$7;

    invoke-direct {v0, p0, p2}, Lcom/brasfoot/v2028/DialogIgrokInfo$7;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p2}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public g(Ljava/lang/String;I)V
    .locals 3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v2, 0x23

    if-ge v0, v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    const/4 v0, 0x5

    if-ge p2, v0, :cond_1

    goto :goto_1

    :cond_1
    const/4 p2, -0x1

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2, v2}, La/p;->a(Ljava/lang/String;IZ)Z

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->finish()V

    return-void
.end method

.method public onClickEditarJogador(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    if-eqz v0, :cond_0

    sput-object v0, Lcom/brasfoot/v2028/ActivityEditJog;->target:La/p;

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityEditJog;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070034

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->setContentView(I)V

    sput-object p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Ng:Landroid/app/Activity;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->sU()La/p;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->po:La/ac;

    const p1, 0x7f060044

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Mv:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$1;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Np:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$12;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$12;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06040a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    if-eqz p1, :cond_0

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$TitInd;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$TitInd;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    if-eqz p1, :cond_f

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->po:La/ac;

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->po:La/ac;

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sB()V

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->po:La/ac;

    if-nez p1, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sB()V

    :cond_2
    const/4 p1, 0x5

    new-array p1, p1, [Ljava/lang/String;

    const v0, 0x7f0b0183

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    aput-object v0, p1, v1

    const v0, 0x7f0b0188

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    aput-object v0, p1, v2

    const/4 v0, 0x2

    const v3, 0x7f0b0181

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, p1, v0

    const/4 v0, 0x3

    const v3, 0x7f0b0185

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, p1, v0

    const/4 v0, 0x4

    const v3, 0x7f0b0180

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, p1, v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v3, 0x7f010006

    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->getCr1()I

    move-result v3

    aget-object v3, v0, v3

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v4}, La/p;->getCr2()I

    move-result v4

    aget-object v0, v0, v4

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v5, 0x7f0b01c5

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->getLado()I

    move-result v5

    if-ne v5, v2, :cond_3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v5, 0x7f0b01c3

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :cond_3
    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->getPosicao()I

    move-result v5

    if-nez v5, :cond_4

    const-string v4, ""

    :cond_4
    const v5, 0x7f0600fc

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f0b01c7

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f0600fe

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f0b0149

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f060102

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f0b0172

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f060100

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f0b016b

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f0600f8

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f0b0055

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f0600fa

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    const v6, 0x7f0b014d

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f0600fd

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v6}, La/p;->hG()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f0600ff

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v6}, La/p;->getIdade()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f060103

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v6}, La/p;->hI()I

    move-result v6

    int-to-long v6, v6

    invoke-static {v6, v7}, La/n;->b(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f060101

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v6}, La/p;->hH()I

    move-result v6

    int-to-long v6, v6

    invoke-static {v6, v7}, La/n;->b(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v5, 0x7f0600f9

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\n"

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0600fb

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->hN()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "%"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602df

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0602e0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v5}, La/p;->getPosicao()I

    move-result v5

    aget-object p1, p1, v5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060317

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->ii()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0601e6

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0, p0}, La/p;->f(Landroid/content/Context;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const p1, 0x7f060135

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    const p1, 0x7f060136

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IV:Landroid/widget/ImageView;

    const p1, 0x7f060137

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IW:Landroid/widget/ImageView;

    const p1, 0x7f060138

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Ne:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$14;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$14;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_1

    :cond_5
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$15;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$15;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v3, "ic_moneybag_128_m"

    goto :goto_0

    :cond_6
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v3, "ic_moneybag_128_disabled"

    :goto_0
    const-string v4, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_1
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_7

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IV:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$16;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$16;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_2

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IV:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v3, "ic_agree_disabled"

    const-string v4, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_2
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Ne:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$17;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$17;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->getIdade()I

    move-result p1

    const/16 v0, 0x22

    if-le p1, v0, :cond_8

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_8

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IW:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/DialogIgrokInfo$18;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$18;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_3

    :cond_8
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IW:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v3, "ic_retire_disabled"

    const-string v4, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_3
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->im()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_9

    const p1, 0x7f0b009f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    :cond_9
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v0, 0x7f0b014c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ": "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->im()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const v0, 0x7f0602d3

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_a

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0157

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/p;->im()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4

    :cond_a
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_b

    const p1, 0x7f0602d4

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const v0, 0x7f0b0158

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    :cond_b
    :goto_4
    const p1, 0x7f0602d6

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const v0, 0x7f0602d5

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eB()La/t;

    move-result-object v3

    if-eqz v3, :cond_d

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v3}, La/t;->jH()La/al;

    move-result-object v3

    invoke-virtual {v4, v3}, La/p;->g(La/al;)[I

    move-result-object v3

    aget v4, v3, v2

    if-le v4, v2, :cond_c

    aget v3, v3, v2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f0b023e

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v2, v1

    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    :goto_5
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_6

    :cond_c
    aget v1, v3, v2

    if-ne v1, v2, :cond_d

    aget v1, v3, v2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0b023f

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_5

    :cond_d
    :goto_6
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->il()Z

    move-result p1

    if-eqz p1, :cond_e

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {p1}, La/p;->hM()J

    move-result-wide v1

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object p1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dd()I

    move-result v3

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/a;

    invoke-virtual {p1}, La/a;->cF()Ljava/util/Calendar;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/Date;->getTime()J

    move-result-wide v3

    cmp-long p1, v1, v3

    if-lez p1, :cond_e

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b0154

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->hM()J

    move-result-wide v1

    invoke-static {v1, v2}, La/a;->a(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_e
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sF()V

    return-void

    :cond_f
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->finish()V

    return-void
.end method

.method public sB()V
    .locals 2

    const v0, 0x7f060166

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const v0, 0x7f06015b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void
.end method

.method public sE()V
    .locals 2

    iget v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nl:I

    iget v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nm:I

    invoke-direct {p0, v0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->ak(II)V

    return-void
.end method

.method public sG()V
    .locals 2

    const v0, 0x7f0b019e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->e(Ljava/lang/String;I)V

    return-void
.end method

.method public sH()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, La/p;->c(Ljava/lang/Boolean;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const-string v2, "ic_moneybag_128"

    const-string v3, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->IU:Landroid/widget/ImageView;

    new-instance v1, Lcom/brasfoot/v2028/DialogIgrokInfo$8;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogIgrokInfo$8;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public sI()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lQ()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lP()I

    move-result v1

    add-int/2addr v0, v1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    const v0, 0x7f0b004e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Lcom/brasfoot/v2028/DialogIgrokInfo;->e(Ljava/lang/String;I)V

    return-void

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v1}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    const v0, 0x7f0b0286

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    :goto_0
    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->e(Ljava/lang/String;I)V

    return-void

    :cond_1
    const/16 v1, 0xa

    if-lt v0, v1, :cond_2

    const v0, 0x7f0b00e5

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v0}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_3

    const v0, 0x7f0b0196

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x3

    goto :goto_0

    :cond_3
    return-void
.end method

.method public sK()V
    .locals 5

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002b

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f060326

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f06000f

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/DialogIgrokInfo$11;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$11;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f060010

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/DialogIgrokInfo$13;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo$13;-><init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f060242

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    const v2, 0x7f0600b6

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/EditText;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const v3, 0x7f0b0183

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v3, 0x7f0b0188

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v3, 0x7f0b0181

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v3, 0x7f0b0185

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v3, 0x7f0b0180

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v3, 0x7f0b0237

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v3, Landroid/widget/ArrayAdapter;

    const v4, 0x1090008

    invoke-direct {v3, p0, v4, v2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v2, 0x1090009

    invoke-virtual {v3, v2}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {v1, v3}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method showTitulosInd()V
    .locals 11

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->selTitulosTab()V

    const/16 v9, 0x8

    const v0, 0x7f060157

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, v9}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const v0, 0x7f060199

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0, v9}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    const v0, 0x7f0601a3

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0, v9}, Landroid/view/View;->setVisibility(I)V

    :cond_2
    const v0, 0x7f06040b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const v0, 0x7f06040c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo;->Nd:La/p;

    if-eqz v2, :cond_5

    const/4 v3, 0x5

    new-array v4, v3, [Ljava/lang/String;

    const-string v5, "ic_aw_bola"

    aput-object v5, v4, v1

    const/4 v5, 0x1

    const-string v6, "ic_aw_chut"

    aput-object v6, v4, v5

    const/4 v6, 0x2

    const-string v7, "ic_aw_assist"

    aput-object v7, v4, v6

    const/4 v7, 0x3

    const-string v9, "ic_aw_luva"

    aput-object v9, v4, v7

    const/4 v9, 0x4

    const-string v10, "ic_aw_time"

    aput-object v10, v4, v9

    new-array v8, v3, [Ljava/lang/String;

    const-string v3, "Bola de Ouro"

    aput-object v3, v8, v1

    const-string v3, "Artilheiro do Ano"

    aput-object v3, v8, v5

    const-string v3, "Chuteira de Prata (Assist.)"

    aput-object v3, v8, v6

    const-string v3, "Luva de Ouro"

    aput-object v3, v8, v7

    const-string v3, "Time do Ano"

    aput-object v3, v8, v9

    const/4 v3, 0x5

    new-array v3, v3, [I

    iget v10, v2, La/p;->awBola:I

    aput v10, v3, v1

    iget v10, v2, La/p;->awChut:I

    aput v10, v3, v5

    iget v10, v2, La/p;->awAssist:I

    aput v10, v3, v6

    iget v10, v2, La/p;->awLuva:I

    aput v10, v3, v7

    iget v2, v2, La/p;->awTeam:I

    aput v2, v3, v9

    const/4 v2, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x5

    if-ge v1, v5, :cond_4

    aget v5, v3, v1

    if-lez v5, :cond_3

    add-int/lit8 v2, v2, 0x1

    aget-object v6, v4, v1

    aget-object v7, v8, v1

    aget v5, v3, v1

    invoke-static {p0, v6, v7, v5}, Lcom/brasfoot/v2028/Recopa;->awardRow(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)Landroid/view/View;

    move-result-object v5

    if-eqz v5, :cond_3

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_4
    if-nez v2, :cond_5

    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v3, "Nenhum titulo individual."

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v3, -0x1000000

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41800000    # 16.0f

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_5
    return-void
.end method
