.class Lcom/brasfoot/v2028/DialogTimeRodada$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogTimeRodada;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic NR:Lcom/brasfoot/v2028/DialogTimeRodada;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogTimeRodada;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada$2;->NR:Lcom/brasfoot/v2028/DialogTimeRodada;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada$2;->NR:Lcom/brasfoot/v2028/DialogTimeRodada;

    invoke-static {p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->b(Lcom/brasfoot/v2028/DialogTimeRodada;)V

    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
