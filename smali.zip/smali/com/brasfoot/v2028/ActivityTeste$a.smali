.class public Lcom/brasfoot/v2028/ActivityTeste$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityTeste;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field final synthetic ME:Lcom/brasfoot/v2028/ActivityTeste;


# direct methods
.method public constructor <init>(Lcom/brasfoot/v2028/ActivityTeste;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTeste$a;->ME:Lcom/brasfoot/v2028/ActivityTeste;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTeste$a;->ME:Lcom/brasfoot/v2028/ActivityTeste;

    const/4 v1, 0x0

    invoke-virtual {v0, v1, v1}, Lcom/brasfoot/v2028/ActivityTeste;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method
