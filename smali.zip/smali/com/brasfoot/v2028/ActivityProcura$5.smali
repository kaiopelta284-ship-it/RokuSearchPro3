.class Lcom/brasfoot/v2028/ActivityProcura$5;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityProcura;->rH()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Lk:Lcom/brasfoot/v2028/ActivityProcura;

.field final synthetic Ll:Landroid/widget/TextView;

.field final synthetic Lm:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityProcura;Landroid/widget/TextView;Landroid/widget/EditText;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura$5;->Lk:Lcom/brasfoot/v2028/ActivityProcura;

    iput-object p2, p0, Lcom/brasfoot/v2028/ActivityProcura$5;->Ll:Landroid/widget/TextView;

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityProcura$5;->Lm:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 0

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura$5;->Ll:Landroid/widget/TextView;

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityProcura$5;->Lk:Lcom/brasfoot/v2028/ActivityProcura;

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityProcura$5;->Lm:Landroid/widget/EditText;

    invoke-virtual {p3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Lcom/brasfoot/v2028/ActivityProcura;->N(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
