.class Lcom/brasfoot/v2028/ActivityAmistosos2024$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityAmistosos2024;->pg()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

.field final synthetic Fm:Landroid/app/Dialog;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityAmistosos2024;Landroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$2;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    iput-object p2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$2;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$2;->Fl:Lcom/brasfoot/v2028/ActivityAmistosos2024;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->ph()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024$2;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
