.class Lcom/brasfoot/v2028/ActivityJuniores$4;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityJuniores;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic JJ:Lcom/brasfoot/v2028/ActivityJuniores;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityJuniores;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$4;->JJ:Lcom/brasfoot/v2028/ActivityJuniores;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$4;->JJ:Lcom/brasfoot/v2028/ActivityJuniores;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJuniores;->c(Lcom/brasfoot/v2028/ActivityJuniores;)V

    return-void
.end method
