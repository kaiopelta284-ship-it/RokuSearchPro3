.class Lcom/brasfoot/v2028/ActivityLoad$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityLoad;->qQ()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic JW:Lcom/brasfoot/v2028/ActivityLoad;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityLoad;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad$3;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad$3;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivityLoad;->b(Lcom/brasfoot/v2028/ActivityLoad;)Lcom/brasfoot/v2028/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad$3;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivityLoad;->b(Lcom/brasfoot/v2028/ActivityLoad;)Lcom/brasfoot/v2028/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->dismiss()V

    :cond_0
    return-void
.end method
