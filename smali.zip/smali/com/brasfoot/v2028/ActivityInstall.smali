.class public Lcom/brasfoot/v2028/ActivityInstall;
.super Landroid/app/Activity;


# instance fields
.field Ja:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bl;",
            ">;"
        }
    .end annotation
.end field

.field Jb:Lcomponents/w;

.field Jc:Landroid/widget/ListView;

.field Jd:[[I

.field Je:[Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 13

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Ja:Ljava/util/ArrayList;

    const/16 v0, 0xa

    new-array v0, v0, [[I

    const/4 v1, 0x2

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x0

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_1

    const/4 v3, 0x1

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_2

    aput-object v2, v0, v1

    new-array v2, v1, [I

    fill-array-data v2, :array_3

    const/4 v3, 0x3

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_4

    const/4 v3, 0x4

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_5

    const/4 v3, 0x5

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_6

    const/4 v3, 0x6

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_7

    const/4 v3, 0x7

    aput-object v2, v0, v3

    new-array v2, v1, [I

    fill-array-data v2, :array_8

    const/16 v3, 0x8

    aput-object v2, v0, v3

    new-array v1, v1, [I

    fill-array-data v1, :array_9

    const/16 v2, 0x9

    aput-object v1, v0, v2

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    const-string v3, "pack_arg"

    const-string v4, "pack_be"

    const-string v5, "pack_col"

    const-string v6, "pack_gre"

    const-string v7, "pack_nl"

    const-string v8, "pack_mx"

    const-string v9, "pack_ru"

    const-string v10, "pack_tu"

    const-string v11, "pack_ua"

    const-string v12, "pack_uy"

    filled-new-array/range {v3 .. v12}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Je:[Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 4
        0xb
        0x2b
    .end array-data

    :array_1
    .array-data 4
        0x15
        0x12
    .end array-data

    :array_2
    .array-data 4
        0x2e
        0x13
    .end array-data

    :array_3
    .array-data 4
        0x4e
        0x1a
    .end array-data

    :array_4
    .array-data 4
        0x55
        0x13
    .end array-data

    :array_5
    .array-data 4
        0x83
        0x22
    .end array-data

    :array_6
    .array-data 4
        0xa2
        0x28
    .end array-data

    :array_7
    .array-data 4
        0xc0
        0x27
    .end array-data

    :array_8
    .array-data 4
        0xc1
        0x1e
    .end array-data

    :array_9
    .array-data 4
        0xc3
        0x11
    .end array-data
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070014

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityInstall;->setContentView(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityInstall;->qt()V

    return-void
.end method

.method public qt()V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Ja:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityInstall;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    array-length v3, v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lcom/brasfoot/v2028/ActivityEditor;->Hv:[[I

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    aget-object v4, v4, v2

    aget v4, v4, v1

    aget-object v3, v3, v4

    aget v3, v3, v1

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    aget-object v4, v4, v2

    const/4 v5, 0x1

    aget v4, v4, v5

    if-ge v3, v4, :cond_0

    new-instance v3, Lcomponents/bl;

    invoke-direct {v3}, Lcomponents/bl;-><init>()V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityInstall;->Je:[Ljava/lang/String;

    aget-object v4, v4, v2

    invoke-virtual {v3, v4}, Lcomponents/bl;->X(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    aget-object v4, v4, v2

    aget v4, v4, v1

    aget-object v4, v0, v4

    invoke-virtual {v3, v4}, Lcomponents/bl;->setNome(Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    aget-object v6, v6, v2

    aget v5, v6, v5

    invoke-static {v5}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v5, 0x7f0b0236

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityInstall;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcomponents/bl;->W(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jd:[[I

    aget-object v4, v4, v2

    aget v4, v4, v1

    invoke-virtual {v3, v4}, Lcomponents/bl;->setPais(I)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityInstall;->Ja:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const v0, 0x7f060196

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityInstall;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jc:Landroid/widget/ListView;

    new-instance v0, Lcomponents/w;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityInstall;->Ja:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/w;-><init>(Ljava/util/ArrayList;Lcom/brasfoot/v2028/ActivityInstall;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jb:Lcomponents/w;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jc:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityInstall;->Jb:Lcomponents/w;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    return-void
.end method
