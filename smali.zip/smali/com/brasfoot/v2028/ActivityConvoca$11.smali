.class Lcom/brasfoot/v2028/ActivityConvoca$11;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityConvoca;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic GX:Lcom/brasfoot/v2028/ActivityConvoca;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityConvoca;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$11;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$11;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityConvoca;->b(Lcom/brasfoot/v2028/ActivityConvoca;)V

    return-void
.end method
