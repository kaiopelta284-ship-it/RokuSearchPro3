.class Lcom/brasfoot/v2028/ActivityTimes$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityTimes;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic MK:Lcom/brasfoot/v2028/ActivityTimes;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityTimes;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$1;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes$1;->MK:Lcom/brasfoot/v2028/ActivityTimes;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1, p3}, Lcomponents/ap;->dm(I)V

    return-void
.end method
