.class public Lcom/brasfoot/v2028/DialogTatics;
.super Landroid/app/Activity;


# instance fields
.field KL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field NA:Landroid/widget/RadioButton;

.field NB:Landroid/widget/RadioButton;

.field NC:Landroid/widget/RadioButton;

.field ND:Landroid/widget/RadioButton;

.field NE:Landroid/widget/Button;

.field NF:Landroid/widget/Button;

.field NG:Landroid/widget/Button;

.field NH:Landroid/widget/Button;

.field NI:Landroid/widget/CheckBox;

.field Nu:I

.field Nv:I

.field Nw:Landroid/widget/RadioButton;

.field Nx:Landroid/widget/RadioButton;

.field Ny:Landroid/widget/RadioButton;

.field Nz:Landroid/widget/RadioButton;

.field nx:La/t;

.field po:La/ac;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/DialogTatics;->Nu:I

    iput v0, p0, Lcom/brasfoot/v2028/DialogTatics;->Nv:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogTatics;Ljava/lang/String;La/p;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/brasfoot/v2028/DialogTatics;->a(Ljava/lang/String;La/p;)V

    return-void
.end method

.method private a(Ljava/lang/String;La/p;)V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const-string v0, "bEscanteios"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    :goto_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->getPosicao()I

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const-string v0, "fNove"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->getPosicao()I

    move-result v0

    const/4 v2, 0x4

    if-ne v0, v2, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->getPosicao()I

    move-result v0

    const/4 v2, 0x3

    if-ne v0, v2, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v0}, La/p;->ia()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_5
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    new-instance v0, Lcom/brasfoot/v2028/c;

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTatics;->KL:Ljava/util/ArrayList;

    move-object v2, v0

    move-object v3, p0

    move-object v4, p0

    move-object v6, p1

    move-object v7, p2

    invoke-direct/range {v2 .. v7}, Lcom/brasfoot/v2028/c;-><init>(Landroid/content/Context;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/lang/String;La/p;)V

    invoke-virtual {v0}, Lcom/brasfoot/v2028/c;->show()V

    return-void
.end method

.method private sM()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->Nw:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v3, v1}, La/ac;->T(II)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->Nx:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v3, v3}, La/ac;->T(II)V

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->Ny:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v3, v2}, La/ac;->T(II)V

    :cond_2
    :goto_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NB:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v2, v1}, La/ac;->T(II)V

    goto :goto_1

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NC:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v2, v3}, La/ac;->T(II)V

    goto :goto_1

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->ND:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v2, v2}, La/ac;->T(II)V

    :cond_5
    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->Nz:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x3

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v2, v1}, La/ac;->T(II)V

    goto :goto_2

    :cond_6
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NA:Landroid/widget/RadioButton;

    invoke-virtual {v0}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0, v2, v3}, La/ac;->T(II)V

    :cond_7
    :goto_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTatics;->NI:Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/ac;->U(Z)V

    return-void
.end method


# virtual methods
.method public b(Ljava/lang/String;La/p;)V
    .locals 1

    const-string v0, "cap"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, p2}, La/ac;->f(La/p;)V

    goto :goto_0

    :cond_0
    const-string v0, "bFaltas"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, p2}, La/ac;->g(La/p;)V

    goto :goto_0

    :cond_1
    const-string v0, "bEscanteios"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, p2}, La/ac;->i(La/p;)V

    goto :goto_0

    :cond_2
    const-string v0, "fNove"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, p2}, La/ac;->j(La/p;)V

    :cond_3
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogTatics;->sL()V

    return-void
.end method

.method public onBackPressed()V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTatics;->sM()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogTatics;->finish()V

    return-void
.end method

.method public onClickBack(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTatics;->sM()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogTatics;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070038

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->setContentView(I)V

    :try_start_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qz()La/t;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->nx:La/t;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->nx:La/t;

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->nx:La/t;

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    :goto_0
    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    goto :goto_1

    :cond_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->nx:La/t;

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object p1

    goto :goto_0

    :goto_1
    const p1, 0x7f060202

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Nw:Landroid/widget/RadioButton;

    const p1, 0x7f060203

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Nx:Landroid/widget/RadioButton;

    const p1, 0x7f060204

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Ny:Landroid/widget/RadioButton;

    const p1, 0x7f060205

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Nz:Landroid/widget/RadioButton;

    const p1, 0x7f060206

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NA:Landroid/widget/RadioButton;

    const p1, 0x7f060207

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NB:Landroid/widget/RadioButton;

    const p1, 0x7f060208

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NC:Landroid/widget/RadioButton;

    const p1, 0x7f060209

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/RadioButton;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->ND:Landroid/widget/RadioButton;

    const p1, 0x7f06006f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NI:Landroid/widget/CheckBox;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, La/ac;->bX(I)I

    move-result p1

    const/4 v1, 0x2

    if-nez p1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Nw:Landroid/widget/RadioButton;

    :goto_2
    invoke-virtual {p1, v0}, Landroid/widget/RadioButton;->setChecked(Z)V

    goto :goto_3

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, v0}, La/ac;->bX(I)I

    move-result p1

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Nx:Landroid/widget/RadioButton;

    goto :goto_2

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, v0}, La/ac;->bX(I)I

    move-result p1

    if-ne p1, v1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Ny:Landroid/widget/RadioButton;

    goto :goto_2

    :cond_3
    :goto_3
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    const/4 v2, 0x3

    invoke-virtual {p1, v2}, La/ac;->bX(I)I

    move-result p1

    if-nez p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->Nz:Landroid/widget/RadioButton;

    :goto_4
    invoke-virtual {p1, v0}, Landroid/widget/RadioButton;->setChecked(Z)V

    goto :goto_5

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, v2}, La/ac;->bX(I)I

    move-result p1

    if-ne p1, v0, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NA:Landroid/widget/RadioButton;

    goto :goto_4

    :cond_5
    :goto_5
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, v1}, La/ac;->bX(I)I

    move-result p1

    if-nez p1, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NB:Landroid/widget/RadioButton;

    :goto_6
    invoke-virtual {p1, v0}, Landroid/widget/RadioButton;->setChecked(Z)V

    goto :goto_7

    :cond_6
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, v1}, La/ac;->bX(I)I

    move-result p1

    if-ne p1, v0, :cond_7

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NC:Landroid/widget/RadioButton;

    goto :goto_6

    :cond_7
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {p1, v1}, La/ac;->bX(I)I

    move-result p1

    if-ne p1, v1, :cond_8

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->ND:Landroid/widget/RadioButton;

    goto :goto_6

    :cond_8
    :goto_7
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NI:Landroid/widget/CheckBox;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mH()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/CheckBox;->setChecked(Z)V

    const p1, 0x7f0600c4

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NE:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NE:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogTatics$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogTatics$1;-><init>(Lcom/brasfoot/v2028/DialogTatics;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0600c1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NG:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NG:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogTatics$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogTatics$2;-><init>(Lcom/brasfoot/v2028/DialogTatics;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0600c2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NF:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NF:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogTatics$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogTatics$3;-><init>(Lcom/brasfoot/v2028/DialogTatics;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0600c3

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTatics;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NH:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTatics;->NH:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/DialogTatics$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/DialogTatics$4;-><init>(Lcom/brasfoot/v2028/DialogTatics;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogTatics;->sL()V

    return-void
.end method

.method public sL()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lD()La/p;

    move-result-object v0

    const v1, 0x7f0b011c

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NE:Landroid/widget/Button;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NE:Landroid/widget/Button;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTatics;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lC()La/p;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NG:Landroid/widget/Button;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lC()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    :goto_2
    invoke-virtual {v0, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NG:Landroid/widget/Button;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTatics;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_2

    :goto_3
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mF()La/p;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NF:Landroid/widget/Button;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v2}, La/ac;->mF()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    :goto_4
    invoke-virtual {v0, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_5

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NF:Landroid/widget/Button;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTatics;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_4

    :goto_5
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mG()La/p;

    move-result-object v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NH:Landroid/widget/Button;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTatics;->po:La/ac;

    invoke-virtual {v1}, La/ac;->mG()La/p;

    move-result-object v1

    invoke-virtual {v1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v1

    :goto_6
    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTatics;->NH:Landroid/widget/Button;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTatics;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_6

    return-void
.end method
