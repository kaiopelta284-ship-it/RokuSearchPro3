.class public Lcom/brasfoot/v2028/ActivitySave;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivitySave$b;,
        Lcom/brasfoot/v2028/ActivitySave$a;
    }
.end annotation


# static fields
.field public static LT:Z


# instance fields
.field private JM:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cp;",
            ">;"
        }
    .end annotation
.end field

.field JN:Ljava/io/File;

.field private JP:Lcom/brasfoot/v2028/b;

.field JU:Ljava/lang/ThreadGroup;

.field JV:Ljava/lang/Thread;

.field LQ:Lcomponents/au;

.field LR:Landroid/app/Dialog;

.field LS:Z

.field LU:Lcom/brasfoot/v2028/ActivitySave$b;

.field public LV:Ljava/lang/String;

.field public LW:Ljava/lang/String;

.field public LX:Ljava/lang/String;

.field public ni:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 9

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JN:Ljava/io/File;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LS:Z

    new-instance v1, Lcom/brasfoot/v2028/ActivitySave$b;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivitySave$b;-><init>(Lcom/brasfoot/v2028/ActivitySave;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LU:Lcom/brasfoot/v2028/ActivitySave$b;

    new-instance v1, Ljava/lang/ThreadGroup;

    const-string v2, "threadGroup"

    invoke-direct {v1, v2}, Ljava/lang/ThreadGroup;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JU:Ljava/lang/ThreadGroup;

    new-instance v1, Ljava/lang/Thread;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivitySave;->JU:Ljava/lang/ThreadGroup;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivitySave;->LU:Lcom/brasfoot/v2028/ActivitySave$b;

    const-string v6, "My thread"

    const-wide/32 v7, 0x1e8480

    move-object v3, v1

    invoke-direct/range {v3 .. v8}, Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;J)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JV:Ljava/lang/Thread;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LV:Ljava/lang/String;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivitySave;)Lcom/brasfoot/v2028/b;
    .locals 0

    iget-object p0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    return-object p0
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivitySave;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySave;->pw()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivitySave;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySave;->qQ()V

    return-void
.end method

.method private pw()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivitySave$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivitySave$2;-><init>(Lcom/brasfoot/v2028/ActivitySave;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivitySave;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private qQ()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivitySave$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivitySave$3;-><init>(Lcom/brasfoot/v2028/ActivitySave;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivitySave;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private qR()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivitySave$4;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivitySave$4;-><init>(Lcom/brasfoot/v2028/ActivitySave;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivitySave;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method


# virtual methods
.method public L(Ljava/lang/String;)V
    .locals 4

    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v1

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    :catch_1
    move-exception p1

    goto :goto_2

    :catch_2
    move-exception v1

    :try_start_1
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V

    :goto_0
    new-instance v1, Ljava/io/ObjectInputStream;

    invoke-direct {v1, v0}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lest/InfoArquivoSalvoType;

    if-eqz v2, :cond_5

    new-instance v3, Lcomponents/cp;

    invoke-direct {v3}, Lcomponents/cp;-><init>()V

    invoke-virtual {v3, p1}, Lcomponents/cp;->setPath(Ljava/lang/String;)V

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getA()Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getA()Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->ad(I)V

    :cond_0
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getN()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getN()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->ar(Ljava/lang/String;)V

    :cond_1
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getTc()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getTc()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->setTecnico(Ljava/lang/String;)V

    :cond_2
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getI()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_3

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getI()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->ap(Ljava/lang/String;)V

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    if-nez p1, :cond_4

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->close()V

    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :goto_1
    invoke-virtual {p1}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    return-void

    :goto_2
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    return-void
.end method

.method public clickDelete(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {p1}, Lcomponents/au;->th()I

    move-result p1

    const/4 v0, 0x1

    if-ltz p1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-le v1, p1, :cond_0

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/cp;

    invoke-virtual {p1}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p1

    if-eqz p1, :cond_1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JN:Ljava/io/File;

    new-instance p1, Landroid/app/Dialog;

    invoke-direct {p1, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v0, 0x7f07002e

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->setContentView(I)V

    const v0, 0x7f0600a6

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f0b0284

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    const v0, 0x7f060062

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivitySave$5;

    invoke-direct {v1, p0, p1}, Lcom/brasfoot/v2028/ActivitySave$5;-><init>(Lcom/brasfoot/v2028/ActivitySave;Landroid/app/Dialog;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f06004d

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivitySave$6;

    invoke-direct {v1, p0, p1}, Lcom/brasfoot/v2028/ActivitySave$6;-><init>(Lcom/brasfoot/v2028/ActivitySave;Landroid/app/Dialog;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b022f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivitySave;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070021

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySave;->setContentView(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->qL()V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->dismiss()V

    :cond_0
    return-void
.end method

.method public qL()V
    .locals 9

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eF()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eF()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    if-nez v1, :cond_1

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    goto :goto_1

    :cond_1
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    :goto_1
    new-instance v1, Lcomponents/cp;

    invoke-direct {v1}, Lcomponents/cp;-><init>()V

    const-string v2, "novo"

    invoke-virtual {v1, v2}, Lcomponents/cp;->setPath(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {v2}, Ljava/io/File;->mkdir()Z

    move-result v3

    goto :goto_2

    :cond_2
    const/4 v3, 0x1

    :goto_2
    const/4 v4, 0x0

    if-eqz v2, :cond_4

    if-eqz v3, :cond_4

    invoke-virtual {v2}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    array-length v3, v2

    const/4 v5, 0x0

    :goto_3
    if-ge v5, v3, :cond_4

    aget-object v6, v2, v5

    invoke-virtual {v6}, Ljava/io/File;->isFile()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-virtual {v6}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v7

    const-string v8, ".ai21"

    invoke-virtual {v7, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-virtual {v6}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_4
    const/4 v2, 0x0

    :goto_4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivitySave;->L(Ljava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_5
    const v1, 0x7f06017f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivitySave;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    new-instance v2, Lcomponents/au;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-direct {v2, v3, p0, p0}, Lcomponents/au;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v2, Lcom/brasfoot/v2028/ActivitySave$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivitySave$1;-><init>(Lcom/brasfoot/v2028/ActivitySave;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const/4 v1, -0x1

    if-eqz v0, :cond_7

    const/4 v2, 0x0

    :goto_5
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_7

    new-instance v3, Ljava/io/File;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcomponents/cp;

    invoke-virtual {v5}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    const-string v6, "[.][^.]+$"

    const-string v7, ""

    invoke-virtual {v3, v6, v7}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "[.][^.]+$"

    const-string v7, ""

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    goto :goto_6

    :cond_6
    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_7
    const/4 v2, -0x1

    :goto_6
    if-lez v2, :cond_8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {v0, v2}, Lcomponents/au;->dm(I)V

    :cond_8
    sget-boolean v0, Lcom/brasfoot/v2028/ActivitySave;->LT:Z

    if-eqz v0, :cond_a

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {v0}, Lcomponents/au;->th()I

    move-result v0

    if-ne v0, v1, :cond_9

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {v0, v4}, Lcomponents/au;->dm(I)V

    :cond_9
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->rW()V

    sput-boolean v4, Lcom/brasfoot/v2028/ActivitySave;->LT:Z

    :cond_a
    return-void
.end method

.method public qN()V
    .locals 3

    new-instance v0, Lcom/brasfoot/v2028/b;

    const v1, 0x7f0b01b2

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivitySave;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lcom/brasfoot/v2028/b;-><init>(Landroid/content/Context;Ljava/lang/String;I)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/b;->setCancelable(Z)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->show()V

    return-void
.end method

.method public qU()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JN:Ljava/io/File;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JN:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->qL()V

    :cond_1
    return-void
.end method

.method public rF()Z
    .locals 3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->getFilesDir()Ljava/io/File;

    const-string v0, "options.bcf"

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivitySave;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v0

    new-instance v1, Ljava/io/ObjectOutputStream;

    invoke-direct {v1, v0}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    :goto_0
    const/4 v0, 0x1

    return v0
.end method

.method public rW()V
    .locals 5

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LS:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {v0}, Lcomponents/au;->th()I

    move-result v0

    const/4 v1, 0x0

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LV:Ljava/lang/String;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b022f

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivitySave;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto/16 :goto_0

    :cond_0
    if-nez v0, :cond_1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "bf"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".s121"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ".ai21"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    goto :goto_0

    :cond_1
    if-lez v0, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-le v1, v0, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->JM:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/cp;

    invoke-virtual {v1}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LV:Ljava/lang/String;

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->LV:Ljava/lang/String;

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    const-string v3, "[.][^.]+$"

    const-string v4, ""

    invoke-virtual {v2, v3, v4}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".s21"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    :cond_2
    :goto_0
    if-ltz v0, :cond_3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->rY()V

    :cond_3
    return-void
.end method

.method public rX()Z
    .locals 18

    move-object/from16 v1, p0

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivitySave;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivitySave;->rF()Z

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v4, 0x1

    if-nez v3, :cond_0

    invoke-virtual {v2}, Ljava/io/File;->mkdir()Z

    move-result v2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    :goto_0
    const/4 v3, 0x0

    if-eqz v2, :cond_9

    iget-object v5, v1, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    if-eqz v5, :cond_9

    iget-object v5, v1, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    if-eqz v5, :cond_9

    invoke-static {}, Lc/b;->wC()V

    invoke-static {}, Lc/b;->wB()V

    invoke-static {}, Lc/b;->wE()V

    :try_start_0
    iget-object v5, v1, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    invoke-virtual {v1, v5, v3}, Lcom/brasfoot/v2028/ActivitySave;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v5
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    new-instance v6, Lcom/esotericsoftware/kryo/io/Output;

    invoke-direct {v6, v5}, Lcom/esotericsoftware/kryo/io/Output;-><init>(Ljava/io/OutputStream;)V

    new-instance v7, Lcom/esotericsoftware/kryo/Kryo;

    invoke-direct {v7}, Lcom/esotericsoftware/kryo/Kryo;-><init>()V

    invoke-virtual {v7, v3}, Lcom/esotericsoftware/kryo/Kryo;->setRegistrationRequired(Z)V

    sget-object v8, Lc/a;->TF:La/b;

    invoke-virtual {v7, v6, v8}, Lcom/esotericsoftware/kryo/Kryo;->writeClassAndObject(Lcom/esotericsoftware/kryo/io/Output;Ljava/lang/Object;)V

    invoke-virtual {v6}, Lcom/esotericsoftware/kryo/io/Output;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v6, 0x1

    goto :goto_1

    :catch_0
    const/4 v6, 0x0

    :goto_1
    if-eqz v6, :cond_8

    :try_start_2
    const-string v6, ""

    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivitySave;->getFilesDir()Ljava/io/File;

    move-result-object v7

    invoke-virtual {v7}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v7

    array-length v8, v7

    const/4 v9, 0x0

    :goto_2
    const/4 v10, 0x0

    if-ge v9, v8, :cond_2

    aget-object v11, v7, v9

    invoke-virtual {v11}, Ljava/io/File;->isFile()Z

    move-result v12

    if-eqz v12, :cond_1

    invoke-virtual {v11}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v12

    iget-object v13, v1, Lcom/brasfoot/v2028/ActivitySave;->LX:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1

    invoke-virtual {v11}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v6

    goto :goto_3

    :cond_1
    add-int/lit8 v9, v9, 0x1

    goto :goto_2

    :cond_2
    move-object v11, v10

    :goto_3
    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v7

    invoke-virtual {v7, v6}, Lest/InfoArquivoSalvoType;->setPath(Ljava/lang/String;)V

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7, v6}, La/b;->j(Ljava/lang/String;)V

    iget-object v7, v1, Lcom/brasfoot/v2028/ActivitySave;->LW:Ljava/lang/String;

    invoke-virtual {v1, v7, v3}, Lcom/brasfoot/v2028/ActivitySave;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v7

    new-instance v8, Ljava/io/ObjectOutputStream;

    invoke-direct {v8, v7}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {v8}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V

    iput-boolean v4, v1, Lcom/brasfoot/v2028/ActivitySave;->LS:Z

    if-eqz v11, :cond_7

    const-string v4, ".s21"

    const-string v5, ""

    invoke-virtual {v6, v4, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ".sbck"

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v5, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_3

    invoke-virtual {v5}, Ljava/io/File;->createNewFile()Z
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    :cond_3
    :try_start_3
    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, v11}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v4}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    new-instance v6, Ljava/io/FileOutputStream;

    invoke-direct {v6, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v6}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v5
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const-wide/16 v14, 0x0

    :try_start_5
    invoke-virtual {v4}, Ljava/nio/channels/FileChannel;->size()J

    move-result-wide v16

    move-object v12, v5

    move-object v13, v4

    invoke-virtual/range {v12 .. v17}, Ljava/nio/channels/FileChannel;->transferFrom(Ljava/nio/channels/ReadableByteChannel;JJ)J
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    if-eqz v4, :cond_4

    :try_start_6
    invoke-virtual {v4}, Ljava/nio/channels/FileChannel;->close()V

    :cond_4
    if-eqz v5, :cond_7

    invoke-virtual {v5}, Ljava/nio/channels/FileChannel;->close()V

    goto :goto_5

    :catchall_0
    move-exception v0

    move-object v2, v0

    move-object v10, v5

    goto :goto_4

    :catchall_1
    move-exception v0

    move-object v2, v0

    goto :goto_4

    :catchall_2
    move-exception v0

    move-object v2, v0

    move-object v4, v10

    :goto_4
    if-eqz v4, :cond_5

    invoke-virtual {v4}, Ljava/nio/channels/FileChannel;->close()V

    :cond_5
    if-eqz v10, :cond_6

    invoke-virtual {v10}, Ljava/nio/channels/FileChannel;->close()V

    :cond_6
    throw v2

    :cond_7
    :goto_5
    invoke-virtual/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivitySave;->finish()V

    return v2

    :cond_8
    invoke-direct/range {p0 .. p0}, Lcom/brasfoot/v2028/ActivitySave;->qR()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1

    return v2

    :catch_1
    move-exception v0

    move-object v2, v0

    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V

    const/4 v2, 0x0

    :cond_9
    return v2
.end method

.method public rY()V
    .locals 1

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySave;->pw()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave;->JV:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public save()Z
    .locals 6

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->rF()Z

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    if-nez v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->LV:Ljava/lang/String;

    if-eqz v1, :cond_1

    new-instance v1, Ljava/io/File;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySave;->LV:Ljava/lang/String;

    invoke-direct {v1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    :cond_1
    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    if-eqz v3, :cond_2

    invoke-static {}, Lc/b;->wC()V

    invoke-static {}, Lc/b;->wB()V

    invoke-static {}, Lc/b;->wE()V

    :try_start_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    invoke-virtual {p0, v3, v1}, Lcom/brasfoot/v2028/ActivitySave;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v3

    new-instance v4, Ljava/io/ObjectOutputStream;

    invoke-direct {v4, v3}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v4, v5}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivitySave;->ni:Ljava/lang/String;

    invoke-virtual {v3, v4}, La/b;->j(Ljava/lang/String;)V

    iput-boolean v2, p0, Lcom/brasfoot/v2028/ActivitySave;->LS:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->finish()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    const/4 v0, 0x0

    :cond_2
    return v0
.end method

.method public saveClick(Landroid/view/View;)V
    .locals 2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySave;->LQ:Lcomponents/au;

    invoke-virtual {p1}, Lcomponents/au;->th()I

    move-result p1

    const/4 v0, -0x1

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b022f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivitySave;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    if-ltz p1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivitySave;->rW()V

    :cond_1
    return-void
.end method
