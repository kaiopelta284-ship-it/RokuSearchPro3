.class public Lcom/brasfoot/v2028/RcSimTick;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public act:Landroid/app/Activity;

.field public handler:Landroid/os/Handler;

.field public startYear:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    :try_start_0
    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0x6

    if-ge v1, v2, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, La/b;->db()I

    move-result v2

    iget v3, p0, Lcom/brasfoot/v2028/RcSimTick;->startYear:I

    if-ne v2, v3, :cond_1

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v0}, La/b;->dd()I

    move-result v3

    if-ge v3, v2, :cond_1

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->play()V

    invoke-static {}, La/t;->jl()V

    invoke-static {}, La/b;->dC()V

    invoke-virtual {v0}, La/b;->ec()V

    invoke-virtual {v0}, La/b;->dL()V

    invoke-virtual {v0}, La/b;->dJ()I

    invoke-virtual {v0}, La/b;->dd()I

    move-result v4

    if-eq v4, v3, :cond_1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/RcSimTick;->handler:Landroid/os/Handler;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_1

    return-void

    :cond_1
    :goto_1
    :try_start_1
    iget-object v0, p0, Lcom/brasfoot/v2028/RcSimTick;->act:Landroid/app/Activity;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V
    :try_end_1
    .catch Ljava/lang/Throwable; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_2
    return-void

    :catch_1
    move-exception v0

    goto :goto_1
.end method
