.class public Lcom/brasfoot/v2028/ActivityPenalty;
.super Landroid/app/Activity;


# instance fields
.field FC:La/t;

.field Jx:Landroid/os/Handler;

.field KG:Lcomponents/ac;

.field KH:Lcomponents/ab;

.field KI:Landroid/widget/ListView;

.field KJ:Landroid/widget/ListView;

.field KK:Landroid/widget/TextView;

.field KL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field KM:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field KN:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field KO:I

.field KP:Landroid/widget/Button;

.field KQ:Landroid/widget/Button;

.field KR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/ca;",
            ">;"
        }
    .end annotation
.end field

.field public KS:Ljava/lang/Runnable;

.field KT:Landroid/os/Handler;

.field public KU:Ljava/lang/Runnable;

.field private KV:[I

.field private KW:[I

.field private KX:I

.field private KY:I

.field private KZ:I

.field private La:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    const/4 v0, 0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KO:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KR:Ljava/util/ArrayList;

    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->Jx:Landroid/os/Handler;

    new-instance v1, Lcom/brasfoot/v2028/ActivityPenalty$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityPenalty$1;-><init>(Lcom/brasfoot/v2028/ActivityPenalty;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KS:Ljava/lang/Runnable;

    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KT:Landroid/os/Handler;

    new-instance v1, Lcom/brasfoot/v2028/ActivityPenalty$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityPenalty$2;-><init>(Lcom/brasfoot/v2028/ActivityPenalty;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KU:Ljava/lang/Runnable;

    const/4 v1, 0x2

    new-array v1, v1, [I

    fill-array-data v1, :array_0

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    const/4 v1, 0x3

    new-array v1, v1, [I

    fill-array-data v1, :array_1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    const/4 v1, 0x0

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
        0x0
    .end array-data
.end method

.method private C(La/ac;)V
    .locals 3

    const v0, 0x7f06012d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v2, 0x7f0b0285

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityPenalty;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, La/ac;->ma()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {p1}, La/ac;->lZ()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityPenalty;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rz()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityPenalty;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rD()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivityPenalty;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rC()V

    return-void
.end method

.method private de(I)Z
    .locals 6

    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ne v0, v4, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget v0, v0, v4

    if-gt v0, v2, :cond_1

    if-ne p1, v4, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget p1, p1, v1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget v0, v0, v3

    rsub-int/lit8 v0, v0, 0x5

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v5, v5, v4

    add-int/2addr v0, v5

    if-le p1, v0, :cond_0

    iput v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return v4

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget p1, p1, v4

    sub-int/2addr v2, p1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget p1, p1, v1

    add-int/2addr v2, p1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget p1, p1, v4

    if-ge v2, p1, :cond_5

    iput v3, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return v4

    :cond_1
    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne v0, v3, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget v0, v0, v3

    if-gt v0, v2, :cond_3

    if-ne p1, v4, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget p1, p1, v4

    rsub-int/lit8 p1, p1, 0x5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v0, v0, v1

    add-int/2addr p1, v0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v0, v0, v4

    if-ge p1, v0, :cond_2

    iput v3, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return v4

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget p1, p1, v1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget v0, v0, v3

    sub-int/2addr v2, v0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v0, v0, v4

    add-int/2addr v2, v0

    if-le p1, v2, :cond_5

    iput v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return v4

    :cond_3
    iget p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne p1, v3, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget p1, p1, v3

    if-le p1, v2, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget p1, p1, v1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v0, v0, v4

    if-le p1, v0, :cond_4

    iput v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return v4

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget p1, p1, v1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v0, v0, v4

    if-ge p1, v0, :cond_5

    iput v3, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    return v4

    :cond_5
    return v1
.end method

.method private rA()V
    .locals 2

    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v0, v1}, La/t;->t(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v0}, La/t;->ji()La/ac;

    move-result-object v0

    :goto_0
    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->C(La/ac;)V

    goto :goto_1

    :cond_0
    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->La:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v0, v1}, La/t;->t(La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v0}, La/t;->jj()La/ac;

    move-result-object v0

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    invoke-virtual {v0, v1}, La/t;->h([I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KQ:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rC()V

    :cond_2
    return-void
.end method

.method private rB()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KK:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    const/4 v3, 0x0

    aget v2, v2, v3

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    const/4 v3, 0x1

    aget v2, v2, v3

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private rC()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->finish()V

    return-void
.end method

.method private rD()V
    .locals 4

    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KO:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    goto :goto_0

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1

    const v0, 0x7f0601f1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ma()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601f2

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->ma()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundColor(I)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f06019d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KJ:Landroid/widget/ListView;

    new-instance v0, Lcomponents/ab;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KR:Ljava/util/ArrayList;

    invoke-direct {v0, v2, p0, p0}, Lcomponents/ab;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KH:Lcomponents/ab;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KJ:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KH:Lcomponents/ab;

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    const v0, 0x7f0601f0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KK:Landroid/widget/TextView;

    const v0, 0x7f0600e5

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ViewFlipper;

    invoke-virtual {v0, v1}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->Jx:Landroid/os/Handler;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KS:Ljava/lang/Runnable;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x2

    if-gtz v0, :cond_2

    new-array v0, v1, [I

    fill-array-data v0, :array_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    :goto_2
    invoke-virtual {v1, v2}, La/t;->t(La/ac;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1, v0}, La/t;->h([I)V

    goto :goto_3

    :cond_2
    new-array v0, v1, [I

    fill-array-data v0, :array_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    goto :goto_2

    :goto_3
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rC()V

    return-void

    nop

    :array_0
    .array-data 4
        0x4
        0x5
    .end array-data

    :array_1
    .array-data 4
        0x5
        0x4
    .end array-data
.end method

.method private rz()V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KT:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v0, 0x3

    new-array v1, v0, [D

    fill-array-data v1, :array_0

    new-array v1, v0, [D

    fill-array-data v1, :array_1

    new-array v0, v0, [D

    fill-array-data v0, :array_2

    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    iget v3, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lt v3, v4, :cond_1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    iget v3, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lt v3, v4, :cond_1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    :cond_1
    :goto_0
    new-instance v3, Lcomponents/ca;

    invoke-direct {v3}, Lcomponents/ca;-><init>()V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    invoke-virtual {v3, v4}, Lcomponents/ca;->dM(I)V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    const/4 v5, 0x2

    if-ne v4, v2, :cond_2

    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    :goto_1
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    invoke-virtual {v3, v0}, Lcomponents/ca;->k(La/p;)V

    goto :goto_2

    :cond_2
    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne v4, v5, :cond_3

    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    goto :goto_1

    :cond_3
    :goto_2
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v4, 0x64

    invoke-virtual {v0, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/2addr v0, v2

    const/16 v4, 0x46

    if-gt v0, v4, :cond_4

    const/4 v0, 0x1

    goto :goto_3

    :cond_4
    const/4 v0, 0x0

    :goto_3
    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne v4, v2, :cond_5

    invoke-virtual {v3, v0}, Lcomponents/ca;->dN(I)V

    iget v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    add-int/2addr v4, v2

    iput v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget v6, v4, v2

    add-int/2addr v6, v2

    aput v6, v4, v2

    if-ne v0, v2, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v6, v4, v1

    add-int/2addr v6, v2

    aput v6, v4, v1

    goto :goto_4

    :cond_5
    iget v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne v1, v5, :cond_6

    invoke-virtual {v3, v0}, Lcomponents/ca;->dN(I)V

    iget v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    add-int/2addr v1, v2

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KW:[I

    aget v4, v1, v5

    add-int/2addr v4, v2

    aput v4, v1, v5

    if-ne v0, v2, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KV:[I

    aget v4, v1, v2

    add-int/2addr v4, v2

    aput v4, v1, v2

    :cond_6
    :goto_4
    const v1, 0x7f06012d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    if-nez v0, :cond_7

    const v4, 0x7f0b0104

    :goto_5
    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityPenalty;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_6

    :cond_7
    const v4, 0x7f0b0145

    goto :goto_5

    :goto_6
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KR:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KJ:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KH:Lcomponents/ab;

    invoke-virtual {v1}, Lcomponents/ab;->notifyDataSetChanged()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rB()V

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityPenalty;->de(I)Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rA()V

    return-void

    :cond_8
    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne v0, v2, :cond_9

    iput v5, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    goto :goto_7

    :cond_9
    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    if-ne v0, v5, :cond_a

    iput v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    :cond_a
    :goto_7
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->Jx:Landroid/os/Handler;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KS:Ljava/lang/Runnable;

    const-wide/16 v2, 0x4b0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :array_0
    .array-data 8
        0x401f333333333333L    # 7.8
        0x4046e3d70a3d70a4L    # 45.78
        0x404ac28f5c28f5c3L    # 53.52
    .end array-data

    :array_1
    .array-data 8
        0x402599999999999aL    # 10.8
        0x4045e3d70a3d70a4L    # 43.78
        0x404ac28f5c28f5c3L    # 53.52
    .end array-data

    :array_2
    .array-data 8
        0x402a666666666666L    # 13.2
        0x404263d70a3d70a4L    # 36.78
        0x4046428f5c28f5c3L    # 44.52
    .end array-data
.end method


# virtual methods
.method public ag(II)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    invoke-static {v0, p1, p2}, Ljava/util/Collections;->swap(Ljava/util/List;II)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KI:Landroid/widget/ListView;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->setSelection(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    invoke-virtual {p1, p2}, Lcomponents/ac;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    invoke-virtual {p1}, Lcomponents/ac;->notifyDataSetChanged()V

    return-void
.end method

.method public onBackPressed()V
    .locals 0

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07001a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPenalty;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityJogo;->qz()La/t;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {p1}, La/t;->ji()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RG:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RG:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 p1, 0x1

    :goto_0
    iput p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KO:I

    goto :goto_1

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {p1}, La/t;->jj()La/ac;

    move-result-object p1

    invoke-virtual {p1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RG:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RG:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 p1, 0x2

    goto :goto_0

    :cond_1
    :goto_1
    const p1, 0x7f060321

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " x "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0601a4

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KI:Landroid/widget/ListView;

    new-instance p1, Lcomponents/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KL:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/ac;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KI:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KI:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityPenalty$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityPenalty$3;-><init>(Lcom/brasfoot/v2028/ActivityPenalty;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const p1, 0x7f06004e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KP:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KP:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityPenalty$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityPenalty$4;-><init>(Lcom/brasfoot/v2028/ActivityPenalty;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KQ:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KQ:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityPenalty$5;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityPenalty$5;-><init>(Lcom/brasfoot/v2028/ActivityPenalty;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method protected onResume()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    return-void
.end method

.method public onStart()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityPenalty;->rD()V

    :cond_0
    return-void
.end method

.method public ry()V
    .locals 4

    iget v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KZ:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KM:Ljava/util/ArrayList;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lt v2, v3, :cond_0

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    :cond_0
    iget v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KX:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1}, La/t;->ji()La/ac;

    move-result-object v1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KN:Ljava/util/ArrayList;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lt v2, v3, :cond_2

    iput v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    :cond_2
    iget v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KY:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->FC:La/t;

    invoke-virtual {v1}, La/t;->jj()La/ac;

    move-result-object v1

    :goto_0
    const v2, 0x7f06012d

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityPenalty;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v1}, La/ac;->ma()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v1}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "..."

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KT:Landroid/os/Handler;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityPenalty;->KU:Ljava/lang/Runnable;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
