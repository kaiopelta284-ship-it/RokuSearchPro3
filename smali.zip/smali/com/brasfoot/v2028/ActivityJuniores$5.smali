.class Lcom/brasfoot/v2028/ActivityJuniores$5;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityJuniores;->e(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic JJ:Lcom/brasfoot/v2028/ActivityJuniores;

.field final synthetic JK:I


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityJuniores;ILandroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JJ:Lcom/brasfoot/v2028/ActivityJuniores;

    iput p2, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JK:I

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    iget p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JK:I

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JJ:Lcom/brasfoot/v2028/ActivityJuniores;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityJuniores;->qG()V

    goto :goto_0

    :cond_0
    iget p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JK:I

    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JJ:Lcom/brasfoot/v2028/ActivityJuniores;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityJuniores;->qI()V

    goto :goto_0

    :cond_1
    iget p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JK:I

    const/4 v0, 0x3

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->JJ:Lcom/brasfoot/v2028/ActivityJuniores;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityJuniores;->d(Lcom/brasfoot/v2028/ActivityJuniores;)V

    :cond_2
    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores$5;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
