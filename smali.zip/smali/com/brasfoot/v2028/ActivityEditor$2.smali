.class Lcom/brasfoot/v2028/ActivityEditor$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityEditor;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Hx:Lcom/brasfoot/v2028/ActivityEditor;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityEditor;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor$2;->Hx:Lcom/brasfoot/v2028/ActivityEditor;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEditor$2;->Hx:Lcom/brasfoot/v2028/ActivityEditor;

    const/4 p2, 0x1

    invoke-static {p1, p3, p2}, Lcom/brasfoot/v2028/ActivityEditor;->a(Lcom/brasfoot/v2028/ActivityEditor;IZ)V

    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
