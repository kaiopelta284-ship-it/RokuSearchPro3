.class Lcom/brasfoot/v2028/DialogIgrokInfo$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogIgrokInfo;->sD()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    iput-object p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Fm:Landroid/app/Dialog;

    const v0, 0x7f0600b7

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "000"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, ""

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "\\d+"

    invoke-virtual {p1, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->G(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    if-ltz v1, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, -0x1

    :goto_0
    if-ltz p1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Fm:Landroid/app/Dialog;

    const v2, 0x7f06021c

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/RadioButton;

    invoke-virtual {v1}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v1

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Fm:Landroid/app/Dialog;

    invoke-virtual {v2, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v1, v0}, Lcom/brasfoot/v2028/DialogIgrokInfo;->a(Lcom/brasfoot/v2028/DialogIgrokInfo;ZLjava/lang/String;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$3;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b00d7

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method
