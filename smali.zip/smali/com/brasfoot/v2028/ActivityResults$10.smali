.class Lcom/brasfoot/v2028/ActivityResults$10;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityResults;->rO()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic LP:Lcom/brasfoot/v2028/ActivityResults;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityResults;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityResults;->a(Lcom/brasfoot/v2028/ActivityResults;)I

    move-result p1

    const/4 p2, 0x1

    if-le p1, p2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    invoke-static {p1, p3}, Lcom/brasfoot/v2028/ActivityResults;->b(Lcom/brasfoot/v2028/ActivityResults;I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    invoke-virtual {p1}, Lcomponents/af;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityResults;->LF:Lcomponents/af;

    const/4 p3, -0x1

    invoke-virtual {p1, p3}, Lcomponents/af;->dm(I)V

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityResults$10;->LP:Lcom/brasfoot/v2028/ActivityResults;

    invoke-virtual {p1, p2}, Lcom/brasfoot/v2028/ActivityResults;->ag(Z)V

    :cond_1
    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
