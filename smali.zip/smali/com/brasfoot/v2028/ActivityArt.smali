.class public Lcom/brasfoot/v2028/ActivityArt;
.super Landroid/app/Activity;


# static fields
.field public static oa:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcomponents/az;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field Fo:Landroid/widget/Spinner;

.field Fp:Landroid/widget/Spinner;

.field private Fq:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field private Fr:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bu;",
            ">;"
        }
    .end annotation
.end field

.field Fs:Landroid/widget/ListView;

.field private Ft:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/az;",
            ">;"
        }
    .end annotation
.end field

.field Fu:Lcomponents/e;

.field Fv:Landroid/widget/Spinner;

.field Fw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fx:Lcomponents/ai;

.field Fy:Z

.field Fz:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/ActivityArt$5;

    invoke-direct {v0}, Lcom/brasfoot/v2028/ActivityArt$5;-><init>()V

    sput-object v0, Lcom/brasfoot/v2028/ActivityArt;->oa:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fw:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fz:I

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityArt;Z)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityArt;->ab(Z)V

    return-void
.end method

.method private ab(Z)V
    .locals 5

    const v0, 0x7f0602ab

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    const v1, 0x7f0b021d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->cG()I

    move-result v0

    const/16 v1, 0x8

    const/16 v2, 0x3e8

    if-ne v0, v2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->pk()V

    return-void

    :cond_1
    const/16 v2, 0x3e9

    if-ne v0, v2, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    const v0, 0x7f0602ab

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_2

    const-string v1, "Assist."

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->pkAssist()V

    return-void

    :cond_3
    const/16 v2, 0x3ea

    if-ne v0, v2, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    const v0, 0x7f0602ab

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_4

    const-string v1, "Titulos"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_4
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->pkTitulos()V

    return-void

    :cond_5
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v2}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bu;

    invoke-virtual {v0}, Lcomponents/bu;->uR()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ne v2, v3, :cond_7

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v2, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1, v4}, Landroid/widget/Spinner;->setVisibility(I)V

    if-eqz p1, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uS()La/y;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityArt;->d(La/y;)V

    goto :goto_1

    :cond_6
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uS()La/y;

    move-result-object p1

    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    move-object v0, p1

    check-cast v0, La/al;

    goto :goto_1

    :cond_7
    invoke-virtual {v0}, La/al;->cG()I

    move-result p1

    const/4 v2, 0x3

    if-ne p1, v2, :cond_8

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bu;

    invoke-virtual {p1}, Lcomponents/bu;->uR()La/al;

    move-result-object v0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {p1, v4}, Landroid/widget/Spinner;->setVisibility(I)V

    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_1

    :cond_8
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    goto :goto_0

    :goto_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, La/al;->nW()V

    if-eqz v0, :cond_a

    :goto_2
    invoke-virtual {v0}, La/al;->nU()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v4, p1, :cond_9

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    new-instance v1, Lcomponents/az;

    invoke-virtual {v0}, La/al;->nU()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/ay;

    invoke-direct {v1, v2}, Lcomponents/az;-><init>(Lcomponents/ay;)V

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_9
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fu:Lcomponents/e;

    invoke-virtual {p1}, Lcomponents/e;->notifyDataSetChanged()V

    :cond_a
    return-void
.end method

.method private d(La/y;)V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b007d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b0075

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0077

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b0079

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const v1, 0x7f0b007b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityArt;->Fw:Ljava/util/ArrayList;

    add-int/lit8 v1, v1, 0x1

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    new-instance p1, Lcomponents/ai;

    const v0, 0x7f070066

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fw:Ljava/util/ArrayList;

    invoke-direct {p1, p0, v0, v1}, Lcomponents/ai;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fx:Lcomponents/ai;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fx:Lcomponents/ai;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityArt$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityArt$4;-><init>(Lcom/brasfoot/v2028/ActivityArt;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fz:I

    const/4 v0, -0x1

    if-le p1, v0, :cond_1

    iget p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fz:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    if-gt p1, v1, :cond_1

    iget v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fz:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fz:I

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pj()V
    .locals 8

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v0

    if-eqz v0, :cond_a

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v0

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v1

    invoke-virtual {v1}, La/t;->jb()La/al;

    move-result-object v1

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qV()La/t;

    move-result-object v2

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_0
    if-eqz v1, :cond_1

    invoke-virtual {v1}, La/al;->cG()I

    move-result v3

    goto :goto_0

    :cond_1
    const/4 v3, -0x1

    :goto_0
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v4, :cond_4

    const/4 v4, 0x3

    if-ne v3, v4, :cond_4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v4, v5}, Landroid/widget/Spinner;->setSelection(I)V

    const/4 v4, 0x0

    :goto_1
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v4, v7, :cond_4

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/bu;

    invoke-virtual {v7}, Lcomponents/bu;->uR()La/al;

    move-result-object v7

    if-eq v7, v0, :cond_3

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/bu;

    invoke-virtual {v7}, Lcomponents/bu;->uR()La/al;

    move-result-object v7

    if-ne v7, v1, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    invoke-virtual {v7, v4}, Landroid/widget/Spinner;->setSelection(I)V

    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    :cond_4
    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    if-nez v4, :cond_7

    if-ne v3, v6, :cond_7

    const/4 v3, 0x0

    :goto_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_7

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    if-eqz v4, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bu;

    invoke-virtual {v4}, Lcomponents/bu;->uR()La/al;

    move-result-object v4

    invoke-virtual {v4}, La/al;->nR()La/y;

    move-result-object v4

    invoke-virtual {v4}, La/y;->kC()I

    move-result v4

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v7

    if-ne v4, v7, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v4, v3}, Landroid/widget/Spinner;->setSelection(I)V

    if-eqz v2, :cond_5

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v3

    if-lez v3, :cond_5

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v2

    sub-int/2addr v2, v6

    iput v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fz:I

    :cond_5
    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    goto :goto_4

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_7
    :goto_4
    iget-boolean v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    if-nez v2, :cond_a

    :goto_5
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v5, v2, :cond_a

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    if-eq v2, v0, :cond_9

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bu;

    invoke-virtual {v2}, Lcomponents/bu;->uR()La/al;

    move-result-object v2

    if-ne v2, v1, :cond_8

    goto :goto_6

    :cond_8
    add-int/lit8 v5, v5, 0x1

    goto :goto_5

    :cond_9
    :goto_6
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    invoke-virtual {v0, v5}, Landroid/widget/Spinner;->setSelection(I)V

    iput-boolean v6, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    :cond_a
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070002

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityArt;->setContentView(I)V

    new-instance p1, Lcomponents/bu;

    invoke-direct {p1}, Lcomponents/bu;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p0, v0, v1}, Lcomponents/bu;->a(Landroid/content/Context;IZ)Ljava/util/ArrayList;

    move-result-object v2

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    new-instance v2, Lcomponents/bu;

    invoke-direct {v2}, Lcomponents/bu;-><init>()V

    const v3, 0x7f0b0263

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityArt;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcomponents/bu;->Q(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "ic_art"

    const-string v5, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Lcomponents/bu;->dD(I)V

    const/16 v3, 0x3e8

    invoke-virtual {v2, v3}, Lcomponents/bu;->W(I)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v2, Lcomponents/bu;

    invoke-direct {v2}, Lcomponents/bu;-><init>()V

    const-string v3, "Maiores Assistentes"

    invoke-virtual {v2, v3}, Lcomponents/bu;->Q(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "ic_art"

    const-string v5, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Lcomponents/bu;->dD(I)V

    const/16 v3, 0x3e9

    invoke-virtual {v2, v3}, Lcomponents/bu;->W(I)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v2, Lcomponents/bu;

    invoke-direct {v2}, Lcomponents/bu;-><init>()V

    const-string v3, "Ranking de titulos individuais"

    invoke-virtual {v2, v3}, Lcomponents/bu;->Q(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "ic_art"

    const-string v5, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityArt;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Lcomponents/bu;->dD(I)V

    const/16 v3, 0x3ea

    invoke-virtual {v2, v3}, Lcomponents/bu;->W(I)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const v2, 0x7f060229

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Spinner;

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fv:Landroid/widget/Spinner;

    const v2, 0x7f060253

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Spinner;

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    new-instance v3, Lcomponents/k;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityArt;->Fq:Ljava/util/ArrayList;

    invoke-direct {v3, p0, v0, v4}, Lcomponents/k;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    invoke-virtual {v2, v3}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fo:Landroid/widget/Spinner;

    new-instance v2, Lcom/brasfoot/v2028/ActivityArt$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivityArt$1;-><init>(Lcom/brasfoot/v2028/ActivityArt;)V

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-virtual {p1, p0}, Lcomponents/bu;->k(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->Rq:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const p1, 0x7f060230

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    new-instance v0, Lcomponents/k;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Fr:Ljava/util/ArrayList;

    invoke-direct {v0, p0, v1, v2}, Lcomponents/k;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fp:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivityArt$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityArt$2;-><init>(Lcom/brasfoot/v2028/ActivityArt;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const p1, 0x7f060178

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityArt;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fs:Landroid/widget/ListView;

    new-instance p1, Lcomponents/e;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/e;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fu:Lcomponents/e;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fs:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fu:Lcomponents/e;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fs:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityArt$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityArt$3;-><init>(Lcom/brasfoot/v2028/ActivityArt;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityArt;->pj()V

    iget-boolean p1, p0, Lcom/brasfoot/v2028/ActivityArt;->Fy:Z

    if-nez p1, :cond_0

    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityArt;->ab(Z)V

    :cond_0
    return-void
.end method

.method public pk()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-virtual {v3}, La/p;->iH()I

    move-result v3

    if-lez v3, :cond_0

    new-instance v3, Lcomponents/az;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getNome()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->hE()La/ac;

    move-result-object v5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->iH()I

    move-result v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    invoke-virtual {v7}, La/p;->iI()I

    move-result v7

    invoke-direct {v3, v4, v5, v6, v7}, Lcomponents/az;-><init>(Ljava/lang/String;La/ac;II)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_1
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    new-instance v3, Lcomponents/az;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/ax;

    invoke-virtual {v4}, Lcomponents/ax;->getN()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcomponents/ax;

    invoke-virtual {v6}, Lcomponents/ax;->tk()I

    move-result v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->eV()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcomponents/ax;

    invoke-virtual {v7}, Lcomponents/ax;->fC()I

    move-result v7

    invoke-direct {v3, v4, v5, v6, v7}, Lcomponents/az;-><init>(Ljava/lang/String;La/ac;II)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    sget-object v2, Lcom/brasfoot/v2028/ActivityArt;->oa:Ljava/util/Comparator;

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xc7

    if-ne v1, v2, :cond_3

    goto :goto_3

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_4
    :goto_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fu:Lcomponents/e;

    invoke-virtual {v0}, Lcomponents/e;->notifyDataSetChanged()V

    return-void
.end method

.method public pkAssist()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->careerAssists(La/p;)I

    move-result v3

    if-lez v3, :cond_0

    new-instance v3, Lcomponents/az;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getNome()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->hE()La/ac;

    move-result-object v5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-static {v6}, Lcom/brasfoot/v2028/Recopa;->careerAssists(La/p;)I

    move-result v6

    sget-object v7, Lc/a;->TF:La/b;

    invoke-virtual {v7}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/p;

    invoke-static {v7}, Lcom/brasfoot/v2028/Recopa;->careerGames(La/p;)I

    move-result v7

    invoke-direct {v3, v4, v5, v6, v7}, Lcomponents/az;-><init>(Ljava/lang/String;La/ac;II)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    sget-object v2, Lcom/brasfoot/v2028/ActivityArt;->oa:Ljava/util/Comparator;

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xc7

    if-ne v1, v2, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fu:Lcomponents/e;

    invoke-virtual {v0}, Lcomponents/e;->notifyDataSetChanged()V

    return-void
.end method

.method public pkTitulos()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/p;

    invoke-static {v3}, Lcom/brasfoot/v2028/Recopa;->totalIndividualTitles(La/p;)I

    move-result v3

    if-lez v3, :cond_0

    new-instance v3, Lcomponents/az;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/p;

    invoke-virtual {v4}, La/p;->getNome()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    invoke-virtual {v5}, La/p;->hE()La/ac;

    move-result-object v5

    sget-object v6, Lc/a;->TF:La/b;

    invoke-virtual {v6}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-static {v6}, Lcom/brasfoot/v2028/Recopa;->totalIndividualTitles(La/p;)I

    move-result v6

    const/4 v7, 0x0

    invoke-direct {v3, v4, v5, v6, v7}, Lcomponents/az;-><init>(Ljava/lang/String;La/ac;II)V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    sget-object v2, Lcom/brasfoot/v2028/ActivityArt;->oa:Ljava/util/Comparator;

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityArt;->Ft:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xc7

    if-ne v1, v2, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityArt;->Fu:Lcomponents/e;

    invoke-virtual {v0}, Lcomponents/e;->notifyDataSetChanged()V

    return-void
.end method
