.class Lcom/brasfoot/v2028/ActivityLoad$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityLoad;->qR()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic JW:Lcom/brasfoot/v2028/ActivityLoad;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityLoad;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad$4;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad$4;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-static {v0}, Lcom/brasfoot/v2028/ActivityLoad;->b(Lcom/brasfoot/v2028/ActivityLoad;)Lcom/brasfoot/v2028/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->dismiss()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad$4;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityLoad;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b006c

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad$4;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    new-instance v7, Ljava/lang/Thread;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad$4;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    iget-object v2, v1, Lcom/brasfoot/v2028/ActivityLoad;->JU:Ljava/lang/ThreadGroup;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad$4;->JW:Lcom/brasfoot/v2028/ActivityLoad;

    iget-object v3, v1, Lcom/brasfoot/v2028/ActivityLoad;->JT:Lcom/brasfoot/v2028/ActivityLoad$b;

    const-string v4, "My thread"

    const-wide/32 v5, 0x1e8480

    move-object v1, v7

    invoke-direct/range {v1 .. v6}, Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;J)V

    iput-object v7, v0, Lcom/brasfoot/v2028/ActivityLoad;->JV:Ljava/lang/Thread;

    return-void
.end method
