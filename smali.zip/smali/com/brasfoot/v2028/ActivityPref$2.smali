.class Lcom/brasfoot/v2028/ActivityPref$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityPref;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Ld:Lcom/brasfoot/v2028/ActivityPref;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityPref;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPref$2;->Ld:Lcom/brasfoot/v2028/ActivityPref;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 2

    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    invoke-virtual {v0, p2}, Lest/Options;->setModoBilionario(Z)V

    return-void
.end method
