.class public Lcom/brasfoot/v2028/ActivitySub;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivitySub$a;
    }
.end annotation


# instance fields
.field Mc:Landroid/widget/TextView;

.field Md:Landroid/widget/TextView;

.field Me:Landroid/widget/TextView;

.field Mf:Landroid/widget/TextView;

.field private Mg:Lb/a/c;

.field private Mh:Lb/a/b;

.field private Mi:Lcom/brasfoot/v2028/ActivitySub$a;

.field Mj:Landroid/widget/Button;

.field Mk:Landroid/widget/ProgressBar;

.field Ml:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/SkuDetails;",
            ">;"
        }
    .end annotation
.end field

.field Mm:Ljava/lang/String;

.field Mn:Ljava/lang/String;

.field Mo:Ljava/lang/String;

.field Mp:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mi:Lcom/brasfoot/v2028/ActivitySub$a;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Ml:Ljava/util/List;

    const-string v0, ""

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mm:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mn:Ljava/lang/String;

    const-string v0, "pv2024"

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mo:Ljava/lang/String;

    const-string v0, "pv2024"

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mp:Ljava/lang/String;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivitySub;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySub;->se()V

    return-void
.end method

.method private pw()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivitySub$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivitySub$1;-><init>(Lcom/brasfoot/v2028/ActivitySub;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivitySub;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private se()V
    .locals 2

    const-string v0, "screenPreference"

    const/16 v1, 0x780

    invoke-static {p0, v0, v1}, La/ak;->a(Landroid/content/Context;Ljava/lang/String;I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mc:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Md:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Me:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mk:Landroid/widget/ProgressBar;

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mj:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mf:Landroid/widget/TextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method public cBInfo(Landroid/view/View;)V
    .locals 2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    invoke-virtual {p1}, Lb/a/b;->op()I

    move-result p1

    const/4 v0, -0x1

    if-le p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mp:Ljava/lang/String;

    const-string v1, "inapp"

    invoke-virtual {p1, v0, v1}, Lb/a/b;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070025

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->setContentView(I)V

    const p1, 0x7f06030c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mc:Landroid/widget/TextView;

    const p1, 0x7f060322

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Md:Landroid/widget/TextView;

    const p1, 0x7f060323

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Me:Landroid/widget/TextView;

    const p1, 0x7f060033

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mj:Landroid/widget/Button;

    const p1, 0x7f0601fc

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ProgressBar;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mk:Landroid/widget/ProgressBar;

    const p1, 0x7f060320

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivitySub;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mf:Landroid/widget/TextView;

    new-instance p1, Lcom/brasfoot/v2028/ActivitySub$a;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lcom/brasfoot/v2028/ActivitySub$a;-><init>(Lcom/brasfoot/v2028/ActivitySub;Lcom/brasfoot/v2028/ActivitySub$1;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mi:Lcom/brasfoot/v2028/ActivitySub$a;

    new-instance p1, Lb/a/b;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mi:Lcom/brasfoot/v2028/ActivitySub$a;

    invoke-direct {p1, p0, v0}, Lb/a/b;-><init>(Landroid/app/Activity;Lb/a/b$a;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    return-void
.end method

.method protected onResume()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    invoke-virtual {v0}, Lb/a/b;->op()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    invoke-virtual {v0}, Lb/a/b;->or()V

    :cond_0
    return-void
.end method

.method protected onStart()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    return-void
.end method

.method public sd()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Ml:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/billingclient/api/SkuDetails;

    invoke-virtual {v1}, Lcom/android/billingclient/api/SkuDetails;->oA()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/billingclient/api/SkuDetails;->oR()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivitySub;->Mo:Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    iput-object v3, p0, Lcom/brasfoot/v2028/ActivitySub;->Mm:Ljava/lang/String;

    invoke-virtual {v1}, Lcom/android/billingclient/api/SkuDetails;->getDescription()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mn:Ljava/lang/String;

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Md:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mn:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Me:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mm:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Me:Landroid/widget/TextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mj:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySub;->Mk:Landroid/widget/ProgressBar;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method

.method public sf()V
    .locals 5

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySub;->pw()V

    return-void
.end method

.method public sg()V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivitySub;->pw()V

    return-void
.end method

.method public sh()V
    .locals 4

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mo:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {}, Lcom/android/billingclient/api/SkuDetailsParams;->pc()Lcom/android/billingclient/api/SkuDetailsParams$Builder;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/android/billingclient/api/SkuDetailsParams$Builder;->b(Ljava/util/List;)Lcom/android/billingclient/api/SkuDetailsParams$Builder;

    move-result-object v1

    const-string v2, "inapp"

    invoke-virtual {v1, v2}, Lcom/android/billingclient/api/SkuDetailsParams$Builder;->C(Ljava/lang/String;)Lcom/android/billingclient/api/SkuDetailsParams$Builder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivitySub;->Mh:Lb/a/b;

    const-string v2, "inapp"

    new-instance v3, Lcom/brasfoot/v2028/ActivitySub$2;

    invoke-direct {v3, p0}, Lcom/brasfoot/v2028/ActivitySub$2;-><init>(Lcom/brasfoot/v2028/ActivitySub;)V

    invoke-virtual {v1, v2, v0, v3}, Lb/a/b;->a(Ljava/lang/String;Ljava/util/List;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V

    return-void
.end method
