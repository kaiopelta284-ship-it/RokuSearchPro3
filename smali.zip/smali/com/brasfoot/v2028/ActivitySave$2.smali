.class Lcom/brasfoot/v2028/ActivitySave$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivitySave;->pw()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic LY:Lcom/brasfoot/v2028/ActivitySave;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivitySave;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySave$2;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivitySave$2;->LY:Lcom/brasfoot/v2028/ActivitySave;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivitySave;->qN()V

    return-void
.end method
