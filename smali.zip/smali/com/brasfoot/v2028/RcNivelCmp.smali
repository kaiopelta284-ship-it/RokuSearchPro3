.class public Lcom/brasfoot/v2028/RcNivelCmp;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "La/ac;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public compare(La/ac;La/ac;)I
    .locals 4

    const/4 v0, 0x0

    if-eqz p1, :cond_1

    if-eqz p2, :cond_1

    :try_start_0
    invoke-virtual {p1}, La/ac;->getNivel()I

    move-result v1

    invoke-virtual {p2}, La/ac;->getNivel()I

    move-result v2

    if-eq v1, v2, :cond_0

    sub-int v0, v2, v1

    return v0

    :cond_0
    invoke-virtual {p1}, La/ac;->getReputacao()I

    move-result v1

    invoke-virtual {p2}, La/ac;->getReputacao()I

    move-result v2

    sub-int v0, v2, v1

    return v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v1

    const/4 v0, 0x0

    :cond_1
    return v0
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 1

    check-cast p1, La/ac;

    check-cast p2, La/ac;

    invoke-virtual {p0, p1, p2}, Lcom/brasfoot/v2028/RcNivelCmp;->compare(La/ac;La/ac;)I

    move-result p1

    return p1
.end method
