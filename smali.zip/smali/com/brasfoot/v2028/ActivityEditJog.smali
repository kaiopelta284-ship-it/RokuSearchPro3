.class public Lcom/brasfoot/v2028/ActivityEditJog;
.super Landroid/app/Activity;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# static fields
.field public static target:La/p;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private static ages()[Ljava/lang/String;
    .locals 4

    const/16 v0, 0x1a

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    add-int/lit8 v2, v1, 0xf

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method private static fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V
    .locals 3

    new-instance v0, Landroid/widget/ArrayAdapter;

    const v1, 0x1090008

    invoke-direct {v0, p0, v1, p2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    const v1, 0x1090009

    invoke-virtual {v0, v1}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    if-ltz p3, :cond_0

    array-length v2, p2

    if-lt p3, v2, :cond_1

    :cond_0
    const/4 p3, 0x0

    :cond_1
    invoke-virtual {p1, p3}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private setPaisFlag(I)V
    .locals 5

    const v0, 0x7f060409

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "flag_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_0
    return-void
.end method


# virtual methods
.method public clickCancel(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->finish()V

    return-void
.end method

.method public onClickSave(Landroid/view/View;)V
    .locals 5

    sget-object v0, Lcom/brasfoot/v2028/ActivityEditJog;->target:La/p;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->finish()V

    return-void

    :cond_0
    const v1, 0x7f0600bb

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_1

    invoke-virtual {v0, v1}, La/p;->setNome(Ljava/lang/String;)V

    :cond_1
    const v1, 0x7f060405

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_2

    :try_start_0
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v0, v1}, La/p;->setForca(I)V

    :catch_0
    :cond_2
    const v1, 0x7f06024e

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPosicao(I)V

    const v1, 0x7f060255

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setLado(I)V

    const v1, 0x7f06023f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    add-int/lit8 v1, v1, 0xf

    invoke-virtual {v0, v1}, La/p;->setIdade(I)V

    const v1, 0x7f060240

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr1(I)V

    const v1, 0x7f060241

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setCr2(I)V

    const v1, 0x7f06024d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setPais(I)V

    const v1, 0x7f060075

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setStar(Z)V

    const v1, 0x7f060076

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/p;->setTop(Z)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 9

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07000b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEditJog;->setContentView(I)V

    sget-object v0, Lcom/brasfoot/v2028/ActivityEditJog;->target:La/p;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->finish()V

    return-void

    :cond_0
    const v1, 0x7f0600bb

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f060405

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v0}, La/p;->hG()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f06024e

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "Goleiro"

    aput-object v4, v2, v3

    const/4 v3, 0x1

    const-string v4, "Lateral"

    aput-object v4, v2, v3

    const/4 v3, 0x2

    const-string v4, "Zagueiro"

    aput-object v4, v2, v3

    const/4 v3, 0x3

    const-string v4, "Meia"

    aput-object v4, v2, v3

    const/4 v3, 0x4

    const-string v4, "Atacante"

    aput-object v4, v2, v3

    invoke-virtual {v0}, La/p;->getPosicao()I

    move-result v3

    invoke-static {p0, v1, v2, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V

    const v1, 0x7f060255

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "Direito"

    aput-object v4, v2, v3

    const/4 v3, 0x1

    const-string v4, "Esquerdo"

    aput-object v4, v2, v3

    invoke-virtual {v0}, La/p;->getLado()I

    move-result v3

    invoke-static {p0, v1, v2, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V

    const v1, 0x7f06023f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-static {}, Lcom/brasfoot/v2028/ActivityEditJog;->ages()[Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, La/p;->getIdade()I

    move-result v3

    add-int/lit8 v3, v3, -0xf

    invoke-static {p0, v1, v2, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f010005

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v5

    const v1, 0x7f060240

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v0}, La/p;->getCr1()I

    move-result v3

    invoke-static {p0, v1, v5, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V

    const v1, 0x7f060241

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v0}, La/p;->getCr2()I

    move-result v3

    invoke-static {p0, v1, v5, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V

    const v1, 0x7f06024d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEditJog;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f010004

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, La/p;->getPais()I

    move-result v3

    invoke-static {p0, v1, v2, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->fillSpinner(Landroid/content/Context;Landroid/widget/Spinner;[Ljava/lang/String;I)V

    invoke-virtual {v0}, La/p;->getPais()I

    move-result v3

    invoke-direct {p0, v3}, Lcom/brasfoot/v2028/ActivityEditJog;->setPaisFlag(I)V

    invoke-virtual {v1, p0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const v1, 0x7f060075

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v0}, La/p;->hD()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    const v1, 0x7f060076

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEditJog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v0}, La/p;->iD()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    return-void
.end method

.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    invoke-direct {p0, p3}, Lcom/brasfoot/v2028/ActivityEditJog;->setPaisFlag(I)V

    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0

    return-void
.end method
