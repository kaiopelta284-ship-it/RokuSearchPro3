.class public Lcom/brasfoot/v2028/ActivityJuniores;
.super Landroid/app/Activity;


# instance fields
.field ID:Landroid/widget/Button;

.field JD:Lcomponents/aa;

.field private JE:La/ac;

.field private JF:La/q;

.field JG:Landroid/widget/Button;

.field JH:Landroid/widget/Button;

.field JI:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityJuniores;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qF()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityJuniores;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qH()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivityJuniores;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qJ()V

    return-void
.end method

.method static synthetic d(Lcom/brasfoot/v2028/ActivityJuniores;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qK()V

    return-void
.end method

.method private qF()V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    const/16 v2, 0x63

    if-lt v0, v2, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b0155

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->th()I

    move-result v0

    if-ltz v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->th()I

    move-result v0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v2}, Lcomponents/aa;->th()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/q;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v2, 0x7f0b027f

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    invoke-virtual {v5}, La/q;->gN()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-virtual {v0, v2, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->e(Ljava/lang/String;I)V

    :cond_2
    return-void
.end method

.method private qH()V
    .locals 4

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v1}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v1}, Lcomponents/aa;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/q;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    if-eqz v0, :cond_1

    const v0, 0x7f0b027e

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    invoke-virtual {v3}, La/q;->gN()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->e(Ljava/lang/String;I)V

    :cond_1
    return-void
.end method

.method private qJ()V
    .locals 6

    sget-object v0, La/ak;->AH:[I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v1}, La/ac;->getDivisao()I

    move-result v1

    aget v0, v0, v1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JI:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v1}, La/ac;->lA()J

    move-result-wide v1

    int-to-long v3, v0

    cmp-long v0, v1, v3

    const/4 v1, 0x1

    if-gez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v5, 0x7f0b011b

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v3, v4}, La/n;->b(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_0
    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v2, 0x12

    if-lt v0, v2, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b028b

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b0280

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v3, v4}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x3

    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->e(Ljava/lang/String;I)V

    return-void
.end method

.method private qK()V
    .locals 7

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0, v1}, La/b;->c(La/ac;)I

    move-result v0

    const/4 v1, 0x1

    if-lez v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f0b028e

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v4, v5

    invoke-virtual {v2, v3, v4}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v2, 0x7f0b028f

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v2

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lcomponents/ce;->RE:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->notifyDataSetChanged()V

    goto :goto_0

    :cond_1
    const v0, 0x7f0b028d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    iget v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JI:I

    const/16 v2, 0x9

    invoke-virtual {v0, v1, v2}, La/ac;->V(II)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qE()V

    return-void
.end method


# virtual methods
.method public e(Ljava/lang/String;I)V
    .locals 2

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityJuniores$5;

    invoke-direct {v1, p0, p2, v0}, Lcom/brasfoot/v2028/ActivityJuniores$5;-><init>(Lcom/brasfoot/v2028/ActivityJuniores;ILandroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance p2, Lcom/brasfoot/v2028/ActivityJuniores$6;

    invoke-direct {p2, p0, v0}, Lcom/brasfoot/v2028/ActivityJuniores$6;-><init>(Lcom/brasfoot/v2028/ActivityJuniores;Landroid/app/Dialog;)V

    invoke-virtual {p1, p2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070016

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJuniores;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    const p1, 0x7f060197

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJuniores;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v0, Lcomponents/aa;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v1}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v1

    invoke-direct {v0, v1, p0, p0}, Lcomponents/aa;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v0, Lcom/brasfoot/v2028/ActivityJuniores$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityJuniores$1;-><init>(Lcom/brasfoot/v2028/ActivityJuniores;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {p1}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcomponents/aa;->dm(I)V

    :cond_0
    const p1, 0x7f06001f

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJuniores;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JG:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JG:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityJuniores$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityJuniores$2;-><init>(Lcom/brasfoot/v2028/ActivityJuniores;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060015

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJuniores;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->ID:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->ID:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityJuniores$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityJuniores$3;-><init>(Lcom/brasfoot/v2028/ActivityJuniores;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06001d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJuniores;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JH:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JH:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityJuniores$4;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityJuniores$4;-><init>(Lcom/brasfoot/v2028/ActivityJuniores;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qE()V

    return-void
.end method

.method public qE()V
    .locals 4

    const v0, 0x7f060314

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJuniores;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f0b0148

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v2}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_1

    :cond_0
    const v1, 0x7f0b0175

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v1

    :cond_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0290

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityJuniores;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v3}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public qG()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    const/4 v2, 0x0

    invoke-static {v2, v0, v1}, La/u;->a(ZLa/q;La/ac;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lcomponents/ce;->RE:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->notifyDataSetChanged()V

    const/4 v0, 0x1

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kl:Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0, v2}, Lcomponents/aa;->dm(I)V

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qE()V

    return-void
.end method

.method public qI()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JF:La/q;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    sget-object v1, Lcomponents/ce;->RE:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    invoke-virtual {v0}, Lcomponents/aa;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JE:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityJuniores;->JD:Lcomponents/aa;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcomponents/aa;->dm(I)V

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJuniores;->qE()V

    return-void
.end method
