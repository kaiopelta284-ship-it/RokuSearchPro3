.class public Lcom/brasfoot/v2028/ActivityAmistososSelecao;
.super Landroid/app/Activity;


# instance fields
.field private EY:La/ac;

.field private EZ:La/ac;

.field private Fa:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field Fb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fc:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fd:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/List<",
            "La/ac;",
            ">;>;"
        }
    .end annotation
.end field

.field Fe:Lcomponents/ar;

.field Ff:Lcomponents/ai;

.field Fg:Landroid/widget/Spinner;

.field Fh:I

.field Fi:I

.field Fj:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Fk:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "La/ac;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fa:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fb:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fc:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fd:Ljava/util/List;

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fh:I

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fi:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fk:Ljava/util/HashMap;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityAmistososSelecao;La/ac;)La/ac;
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    return-object p1
.end method

.method private pe()V
    .locals 6

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fk:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fd:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fc:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fa:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fc:Ljava/util/List;

    const v1, 0x7f0b0112

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-static {}, La/z;->lj()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-static {}, La/g;->gg()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bz;

    invoke-virtual {v3}, Lcomponents/bz;->getPais()I

    move-result v3

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4, v3}, La/b;->al(I)La/y;

    move-result-object v3

    invoke-virtual {v3}, La/y;->kV()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, La/y;->li()La/ac;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    if-eq v4, v5, :cond_0

    invoke-virtual {v3}, La/y;->li()La/ac;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fd:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v0, 0x7f060193

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ExpandableListView;

    new-instance v2, Lcomponents/ar;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fc:Ljava/util/List;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fk:Ljava/util/HashMap;

    invoke-direct {v2, p0, v3, v4}, Lcomponents/ar;-><init>(Landroid/content/Context;Ljava/util/List;Ljava/util/HashMap;)V

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fe:Lcomponents/ar;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fe:Lcomponents/ar;

    invoke-virtual {v0, v2}, Landroid/widget/ExpandableListView;->setAdapter(Landroid/widget/ExpandableListAdapter;)V

    new-instance v2, Lcom/brasfoot/v2028/ActivityAmistososSelecao$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao$1;-><init>(Lcom/brasfoot/v2028/ActivityAmistososSelecao;)V

    invoke-virtual {v0, v2}, Landroid/widget/ExpandableListView;->setOnChildClickListener(Landroid/widget/ExpandableListView$OnChildClickListener;)V

    const/4 v2, 0x0

    :goto_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fd:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fk:Ljava/util/HashMap;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fc:Ljava/util/List;

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fd:Ljava/util/List;

    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fd:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_3

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v1, v2}, Landroid/widget/ExpandableListView;->setSelectedChild(IIZ)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fe:Lcomponents/ar;

    invoke-virtual {v2, v1, v1}, Lcomponents/ar;->al(II)V

    invoke-virtual {v0, v1}, Landroid/widget/ExpandableListView;->expandGroup(I)Z

    :cond_3
    return-void
.end method


# virtual methods
.method public onClickAmis(Landroid/view/View;)V
    .locals 5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    iget v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fh:I

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-static {p1, v0, v1, v2}, Ld/a;->a(La/ac;La/ac;II)I

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    const/4 v0, 0x1

    if-ltz p1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    if-nez p1, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b0231

    goto :goto_1

    :cond_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    if-eq p1, v1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    if-eqz p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    if-eqz p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    const v1, 0x7f06021a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/RadioButton;

    const v1, 0x7f06021b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/RadioButton;

    invoke-virtual {v1}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v2, v3, v1, p1}, Ld/a;->b(La/ac;La/ac;II)V

    sget-object p1, Lc/a;->TF:La/b;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->getPais()I

    move-result v1

    invoke-virtual {p1, v1}, La/b;->al(I)La/y;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, La/y;->N(Z)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b022d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->pi()V

    return-void

    :cond_3
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b0222

    :goto_1
    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_4
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070001

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->pf()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->pe()V

    return-void
.end method

.method public pf()V
    .locals 5

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fh:I

    const/4 v1, -0x1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fi:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fb:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->EZ:La/ac;

    invoke-static {v1}, Ld/a;->J(La/ac;)Ljava/util/ArrayList;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fb:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cK()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const v1, 0x7f060227

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/ai;

    const v2, 0x7f070068

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fb:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v2, v3}, Lcomponents/ai;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Ff:Lcomponents/ai;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Ff:Lcomponents/ai;

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->Fg:Landroid/widget/Spinner;

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_1
    return-void
.end method

.method public pi()V
    .locals 2

    const v0, 0x7f0602ce

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->pf()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAmistososSelecao;->pe()V

    return-void
.end method
