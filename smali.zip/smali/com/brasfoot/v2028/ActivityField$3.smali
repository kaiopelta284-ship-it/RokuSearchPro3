.class Lcom/brasfoot/v2028/ActivityField$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityField;
.end annotation


# instance fields
.field final fIdx:I


# direct methods
.method constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/brasfoot/v2028/ActivityField$3;->fIdx:I

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    iget v0, p0, Lcom/brasfoot/v2028/ActivityField$3;->fIdx:I

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selFormation:I

    const/4 v0, -0x1

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selTitIdx:I

    sput v0, Lcom/brasfoot/v2028/ActivityField;->selSubIdx:I

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    if-eqz v0, :cond_0

    iget v1, p0, Lcom/brasfoot/v2028/ActivityField$3;->fIdx:I

    invoke-static {v1}, Lcom/brasfoot/v2028/ActivityField;->formCampToGame(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityEscala;->setFormIdx(I)V

    :cond_0
    sget-object v0, Lcom/brasfoot/v2028/ActivityField;->sInst:Lcom/brasfoot/v2028/ActivityField;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityField;->rebuildSlotMap()V

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityField;->renderFormationBar()V

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityField;->refreshField()V

    :cond_1
    return-void
.end method
