.class public Lcom/brasfoot/v2028/ActivityAmistosos2024;
.super Landroid/app/Activity;


# instance fields
.field private EY:La/ac;

.field private EZ:La/ac;

.field private Fa:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field Fb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fc:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fd:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/List<",
            "La/ac;",
            ">;>;"
        }
    .end annotation
.end field

.field Fe:Lcomponents/ar;

.field Ff:Lcomponents/ai;

.field Fg:Landroid/widget/Spinner;

.field Fh:I

.field Fi:I

.field Fj:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Fk:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "La/ac;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fa:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fb:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fc:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fd:Ljava/util/List;

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fh:I

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fi:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fk:Ljava/util/HashMap;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityAmistosos2024;La/ac;)La/ac;
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    return-object p1
.end method

.method private pe()V
    .locals 6

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fk:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fd:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fc:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fa:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fc:Ljava/util/List;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kX()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    :goto_1
    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld/q;

    invoke-virtual {v4}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_0

    const/4 v4, 0x0

    :goto_2
    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    invoke-virtual {v5}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/q;

    invoke-virtual {v5}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_0

    sget-object v5, Lc/a;->TF:La/b;

    invoke-virtual {v5}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/y;

    invoke-virtual {v5}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld/q;

    invoke-virtual {v5}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fd:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v2, 0x7f060193

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ExpandableListView;

    new-instance v3, Lcomponents/ar;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fc:Ljava/util/List;

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fk:Ljava/util/HashMap;

    invoke-direct {v3, p0, v4, v5}, Lcomponents/ar;-><init>(Landroid/content/Context;Ljava/util/List;Ljava/util/HashMap;)V

    iput-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fe:Lcomponents/ar;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fe:Lcomponents/ar;

    invoke-virtual {v2, v3}, Landroid/widget/ExpandableListView;->setAdapter(Landroid/widget/ExpandableListAdapter;)V

    new-instance v3, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;

    invoke-direct {v3, p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024$1;-><init>(Lcom/brasfoot/v2028/ActivityAmistosos2024;)V

    invoke-virtual {v2, v3}, Landroid/widget/ExpandableListView;->setOnChildClickListener(Landroid/widget/ExpandableListView$OnChildClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_2
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fc:Ljava/util/List;

    const v2, 0x7f0b0255

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    :goto_3
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_4

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fa:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_4
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fa:Ljava/util/ArrayList;

    sget-object v3, Lcomponents/ce;->RK:Ljava/util/Comparator;

    invoke-static {v2, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v2, 0x0

    :goto_4
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fa:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_5

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fa:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_5
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fd:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_5
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fd:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fk:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fc:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fd:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_6
    return-void
.end method


# virtual methods
.method public onClickAmis(Landroid/view/View;)V
    .locals 5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fg:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    const/4 v0, 0x1

    if-ltz p1, :cond_5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_0

    goto/16 :goto_0

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    if-nez p1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b0231

    goto/16 :goto_1

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    if-eq p1, v1, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    if-eqz p1, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    if-eqz p1, :cond_6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fg:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    const v1, 0x7f06021a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/RadioButton;

    const v1, 0x7f06021b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/RadioButton;

    invoke-virtual {v1}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-static {v2, v3, v1, v4}, Ld/a;->a(La/ac;La/ac;II)I

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b022a

    goto :goto_1

    :cond_2
    if-ne v2, v0, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v2, v3, v1, p1}, Ld/a;->b(La/ac;La/ac;II)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b022d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pi()V

    return-void

    :cond_3
    const/4 v3, 0x2

    if-ne v2, v3, :cond_4

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v1, 0x7f0b0213

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    goto :goto_2

    :cond_4
    const/4 v0, 0x3

    if-ne v2, v0, :cond_6

    iput v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fh:I

    iput p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fi:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pg()V

    return-void

    :cond_5
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b0222

    :goto_1
    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    :goto_2
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_6
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/high16 p1, 0x7f070000

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pf()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pe()V

    return-void
.end method

.method public pf()V
    .locals 5

    const/4 v0, 0x0

    iput v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fh:I

    const/4 v1, -0x1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fi:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fb:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    invoke-static {v1}, Ld/a;->I(La/ac;)Ljava/util/ArrayList;

    move-result-object v1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fb:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cK()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    const v1, 0x7f060227

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fg:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/ai;

    const v2, 0x7f070068

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fb:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v2, v3}, Lcomponents/ai;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Ff:Lcomponents/ai;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fg:Landroid/widget/Spinner;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Ff:Lcomponents/ai;

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fg:Landroid/widget/Spinner;

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_1
    return-void
.end method

.method public pg()V
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b00b1

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ld/a;->wS()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/app/Dialog;

    invoke-direct {v1, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v2, 0x7f07002e

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setContentView(I)V

    const v2, 0x7f0600a6

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060062

    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityAmistosos2024$2;

    invoke-direct {v2, p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024$2;-><init>(Lcom/brasfoot/v2028/ActivityAmistosos2024;Landroid/app/Dialog;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f06004d

    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityAmistosos2024$3;

    invoke-direct {v2, p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024$3;-><init>(Lcom/brasfoot/v2028/ActivityAmistosos2024;Landroid/app/Dialog;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public ph()V
    .locals 5

    iget v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fi:I

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EY:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fh:I

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fj:Ljava/util/ArrayList;

    iget v4, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->Fi:I

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v0, v1, v2, v3}, Ld/a;->b(La/ac;La/ac;II)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityAmistosos2024;->EZ:La/ac;

    invoke-static {}, Ld/a;->wS()I

    move-result v1

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, La/ac;->V(II)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b022d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pi()V

    :cond_0
    return-void
.end method

.method public pi()V
    .locals 2

    const v0, 0x7f0602ce

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pf()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityAmistosos2024;->pe()V

    return-void
.end method
