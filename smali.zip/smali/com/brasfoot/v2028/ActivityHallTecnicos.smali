.class public Lcom/brasfoot/v2028/ActivityHallTecnicos;
.super Landroid/app/Activity;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public onClickVoltar(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityHallTecnicos;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070078

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityHallTecnicos;->setContentView(I)V

    const p1, 0x7f060401

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityHallTecnicos;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    invoke-static {p0, p1}, Lcom/brasfoot/v2028/Recopa;->hallTecnicos(Landroid/app/Activity;Landroid/widget/LinearLayout;)V

    return-void
.end method
