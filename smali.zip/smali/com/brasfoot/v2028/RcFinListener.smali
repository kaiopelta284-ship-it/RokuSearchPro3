.class public Lcom/brasfoot/v2028/RcFinListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 1

    :try_start_0
    invoke-static {}, Lc/a;->wz()Lest/Options;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p2}, Lest/Options;->setFinRealista(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-void

    :catch_0
    move-exception v0

    return-void
.end method
