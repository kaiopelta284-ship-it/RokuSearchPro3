.class public Lcom/brasfoot/v2028/ActivityTimes;
.super Landroid/app/Activity;


# instance fields
.field private EY:La/ac;

.field private EZ:La/ac;

.field Fv:Landroid/widget/Spinner;

.field Fw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field GQ:Landroid/widget/ListView;

.field private GS:La/p;

.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Hj:Landroid/widget/Spinner;

.field Ip:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field private KL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field MF:Landroid/widget/Spinner;

.field MG:Landroid/widget/Button;

.field MH:Lcomponents/ap;

.field MI:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private MJ:La/y;

.field public oL:I

.field oO:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ha:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hb:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->oO:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fw:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MI:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    return-void
.end method

.method public static G(Ljava/lang/String;)Z
    .locals 1

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    return v0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityTimes;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->so()V

    return-void
.end method

.method private ah(Z)V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MI:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/q;

    invoke-virtual {v3}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {p1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_3

    const/4 p1, 0x0

    :goto_1
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_3

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v2}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_2
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->lN()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->RK:Ljava/util/Comparator;

    invoke-static {p1, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_5

    const/4 p1, 0x0

    :goto_3
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_4

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MI:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_3

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MF:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/am;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->MI:Ljava/util/ArrayList;

    const/4 v4, 0x1

    invoke-direct {v1, p0, v2, v3, v4}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MF:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityTimes$6;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityTimes$6;-><init>(Lcom/brasfoot/v2028/ActivityTimes;)V

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/ac;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MF:Landroid/widget/Spinner;

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->ss()V

    :cond_5
    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityTimes;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sp()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivityTimes;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sq()V

    return-void
.end method

.method static synthetic d(Lcom/brasfoot/v2028/ActivityTimes;)La/ac;
    .locals 0

    iget-object p0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    return-object p0
.end method

.method private sm()V
    .locals 9

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hb:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kX()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->oO:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ha:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3, p0}, La/y;->f(Landroid/content/Context;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kC()I

    move-result v3

    if-ne v2, v3, :cond_0

    move v1, v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hb:Ljava/util/ArrayList;

    const v2, 0x7f0b0256

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ha:Ljava/util/ArrayList;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const-string v3, "ic_world"

    const-string v4, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hj:Landroid/widget/Spinner;

    new-instance v8, Lcomponents/al;

    const v4, 0x7f070066

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hb:Ljava/util/ArrayList;

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ha:Ljava/util/ArrayList;

    const/4 v7, 0x0

    move-object v2, v8

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Lcomponents/al;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {v0, v8}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hj:Landroid/widget/Spinner;

    new-instance v2, Lcom/brasfoot/v2028/ActivityTimes$4;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/ActivityTimes$4;-><init>(Lcom/brasfoot/v2028/ActivityTimes;)V

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->oO:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sn()V

    return-void
.end method

.method private sn()V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->oO:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    if-ge v0, v1, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setVisibility(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->oO:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b007d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    const v3, 0x7f0b0075

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, v0, v4

    const/4 v3, 0x2

    const v5, 0x7f0b0077

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v0, v3

    const/4 v3, 0x3

    const v5, 0x7f0b0079

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v0, v3

    const/4 v3, 0x4

    const v5, 0x7f0b007b

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v0, v3

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    const/4 v1, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fw:Ljava/util/ArrayList;

    add-int/lit8 v1, v1, 0x1

    aget-object v5, v0, v1

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v1}, La/y;->kY()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fw:Ljava/util/ArrayList;

    aget-object v0, v0, v2

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/am;

    const v3, 0x7f070066

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fw:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v3, v5, v4}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityTimes$5;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityTimes$5;-><init>(Lcom/brasfoot/v2028/ActivityTimes;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setSelection(I)V

    invoke-direct {p0, v4}, Lcom/brasfoot/v2028/ActivityTimes;->ah(Z)V

    return-void

    :cond_2
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setVisibility(I)V

    invoke-direct {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->ah(Z)V

    return-void
.end method

.method private so()V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sn()V

    return-void
.end method

.method private sp()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MJ:La/y;

    invoke-virtual {v1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    invoke-virtual {v0}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const v3, 0x7f0b00ce

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    if-eqz v0, :cond_1

    invoke-direct {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->ah(Z)V

    :cond_1
    return-void
.end method

.method private sq()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->ss()V

    return-void
.end method

.method private sr()V
    .locals 4

    const v0, 0x7f0602d9

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v2, 0x7f0b0288

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {v2}, La/ac;->lA()J

    move-result-wide v2

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public M(Ljava/lang/String;)V
    .locals 7

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "000"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_0

    const-string v0, "\\d+"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityTimes;->G(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-lez v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, -0x1

    :goto_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, v0, v2, p1}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;I)I

    move-result v0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v2}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v2}, La/p;->hI()I

    move-result v2

    if-lt p1, v2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, p1, v0, v1, v1}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;II)V

    return-void

    :cond_1
    const/4 v2, 0x1

    if-ne v0, v2, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, v0, v2, p1, v1}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;II)V

    return-void

    :cond_2
    const/4 p1, 0x6

    new-array v1, p1, [Ljava/lang/String;

    const/4 v3, 0x0

    const v4, 0x7f0b000a

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    const v3, 0x7f0b0227

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    const/4 v3, 0x2

    const v4, 0x7f0b0150

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    const v3, 0x7f0b0155

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    aput-object v3, v1, v4

    const v3, 0x7f0b0082

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    aput-object v3, v1, v5

    const v3, 0x7f0b011a

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    aput-object v3, v1, v6

    if-gt v0, v6, :cond_3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    aget-object v0, v1, v0

    invoke-static {p1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_3
    const v1, 0x7f0b0287

    if-ne v0, p1, :cond_4

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v0, 0x7f0b0229

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, La/f;->ga()I

    move-result v0

    int-to-long v2, v0

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v4}, Lcom/brasfoot/v2028/ActivityTimes;->e(Ljava/lang/String;I)V

    return-void

    :cond_4
    const/4 p1, 0x7

    if-ne v0, p1, :cond_5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v0, 0x7f0b0216

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->oL:I

    int-to-long v2, v0

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v5}, Lcom/brasfoot/v2028/ActivityTimes;->e(Ljava/lang/String;I)V

    :cond_5
    return-void
.end method

.method public N(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "000"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "\\d+"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityTimes;->G(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-ltz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    int-to-long v0, p1

    invoke-static {v0, v1}, La/n;->b(J)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    const p1, 0x7f0b00d7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public a(La/p;La/ac;)I
    .locals 3

    const/4 v0, 0x0

    if-eqz p1, :cond_8

    if-nez p2, :cond_0

    return v0

    :cond_0
    invoke-virtual {p1}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1

    const/4 p1, 0x5

    return p1

    :cond_1
    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v1

    if-ne p2, v1, :cond_2

    const/4 p1, 0x2

    return p1

    :cond_2
    invoke-virtual {p2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v2, 0x63

    if-lt v1, v2, :cond_3

    const/4 p1, 0x6

    return p1

    :cond_3
    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_5

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-eqz v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-ne v2, p2, :cond_4

    add-int/lit8 v1, v1, 0x1

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    const/4 v0, 0x4

    if-lt v1, v0, :cond_6

    const/4 p1, 0x3

    return p1

    :cond_6
    invoke-static {p1, p2}, La/f;->d(La/p;La/ac;)Z

    move-result p1

    if-nez p1, :cond_7

    return v0

    :cond_7
    const/4 p1, 0x1

    return p1

    :cond_8
    return v0
.end method

.method public a(La/p;La/ac;I)I
    .locals 10

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/ac;->T(Z)[I

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_0

    const/4 v3, 0x6

    new-array v4, v3, [D

    fill-array-data v4, :array_1

    new-array v5, v3, [D

    fill-array-data v5, :array_2

    new-array v6, v3, [D

    fill-array-data v6, :array_3

    new-array v7, v3, [I

    fill-array-data v7, :array_4

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v8

    aget v8, v0, v8

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v9

    aget v2, v2, v9

    const/4 v9, 0x1

    if-lt v8, v2, :cond_2

    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    const/16 v2, 0x63

    if-lt v0, v2, :cond_1

    invoke-virtual {p1}, La/p;->getIdade()I

    move-result v0

    const/16 v2, 0x23

    if-le v0, v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    int-to-double v4, v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    aget-wide v7, v6, v0

    mul-double v4, v4, v7

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    invoke-virtual {p1}, La/p;->hI()I

    move-result v2

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v4

    aget v4, v7, v4

    mul-int v2, v2, v4

    div-int/lit8 v2, v2, 0x64

    int-to-float v2, v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    sub-int v2, v0, v2

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v2

    aget v0, v0, v2

    if-ne v0, v9, :cond_3

    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    int-to-double v5, v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    aget-wide v7, v4, v0

    mul-double v5, v5, v7

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    :goto_1
    long-to-int v0, v4

    invoke-virtual {p1}, La/p;->hI()I

    move-result v2

    add-int/2addr v2, v0

    goto :goto_2

    :cond_3
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    int-to-double v6, v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    aget-wide v4, v5, v0

    mul-double v6, v6, v4

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    goto :goto_1

    :goto_2
    const/4 v0, 0x2

    if-lt p3, v2, :cond_6

    invoke-static {p1, p2}, La/f;->c(La/p;La/ac;)I

    move-result p1

    if-ne p1, v9, :cond_4

    const/4 p1, 0x4

    return p1

    :cond_4
    if-ne p1, v0, :cond_5

    return v3

    :cond_5
    return v9

    :cond_6
    invoke-virtual {p2}, La/ac;->lA()J

    move-result-wide v3

    int-to-long v5, v2

    cmp-long p3, v3, v5

    if-ltz p3, :cond_8

    invoke-static {p1, p2}, La/f;->c(La/p;La/ac;)I

    move-result p1

    if-eqz p1, :cond_7

    if-ne p1, v0, :cond_8

    :cond_7
    iput v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->oL:I

    const/4 p1, 0x7

    return p1

    :cond_8
    return v1

    nop

    :array_0
    .array-data 4
        0x3
        0x4
        0x4
        0x5
        0x4
    .end array-data

    :array_1
    .array-data 8
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x4000000000000000L    # 2.0
        0x3ff0000000000000L    # 1.0
    .end array-data

    :array_2
    .array-data 8
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff8000000000000L    # 1.5
        0x4000000000000000L    # 2.0
    .end array-data

    :array_3
    .array-data 8
        0x3fe0000000000000L    # 0.5
        0x3fc999999999999aL    # 0.2
        0x3fc999999999999aL    # 0.2
        0x3fc999999999999aL    # 0.2
        0x3fe0000000000000L    # 0.5
        0x3ff0000000000000L    # 1.0
    .end array-data

    :array_4
    .array-data 4
        0xf
        0x14
        0x14
        0xa
        0xa
        0x2
    .end array-data
.end method

.method public a(La/p;La/ac;II)V
    .locals 7

    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    if-lez p3, :cond_0

    move v3, p3

    goto :goto_0

    :cond_0
    move v3, v0

    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p1

    move-object v2, p2

    invoke-virtual/range {v1 .. v6}, La/p;->a(La/ac;IZZZ)V

    if-lez p4, :cond_1

    invoke-virtual {p1, p4}, La/p;->aQ(I)V

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const p2, 0x7f0b0227

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 p3, 0x1

    invoke-static {p1, p2, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->st()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sr()V

    return-void
.end method

.method public abreSpinTimes(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MF:Landroid/widget/Spinner;

    invoke-virtual {p1}, Landroid/widget/Spinner;->performClick()Z

    return-void
.end method

.method public b(La/p;La/ac;)I
    .locals 5

    if-eqz p1, :cond_5

    if-eqz p2, :cond_5

    invoke-virtual {p1}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v0

    if-ne p2, v0, :cond_1

    const/4 p1, 0x2

    return p1

    :cond_1
    invoke-virtual {p2}, La/ac;->lA()J

    move-result-wide v0

    invoke-virtual {p1}, La/p;->hI()I

    move-result v2

    int-to-long v2, v2

    cmp-long v4, v0, v2

    if-gez v4, :cond_2

    const/4 p1, 0x5

    return p1

    :cond_2
    invoke-virtual {p2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x63

    if-lt v0, v1, :cond_3

    const/4 p1, 0x3

    return p1

    :cond_3
    invoke-static {p1, p2}, La/f;->d(La/p;La/ac;)Z

    move-result p1

    if-nez p1, :cond_4

    const/4 p1, 0x4

    return p1

    :cond_4
    const/4 p1, 0x1

    return p1

    :cond_5
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public dd(I)V
    .locals 3

    const/4 v0, -0x1

    const/4 v1, 0x1

    if-ne p1, v1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, p1, v1, v0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;II)V

    return-void

    :cond_0
    const/4 v1, 0x2

    if-ne p1, v1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityTimes;->e(La/p;La/ac;)V

    return-void

    :cond_1
    const/4 v1, 0x3

    if-ne p1, v1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-static {}, La/f;->ga()I

    move-result v2

    invoke-virtual {p0, p1, v1, v0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;II)V

    return-void

    :cond_2
    const/4 v1, 0x4

    if-ne p1, v1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->oL:I

    invoke-virtual {p0, p1, v1, v2, v0}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;II)V

    :cond_3
    return-void
.end method

.method public dh(I)I
    .locals 3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "flag_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "drawable"

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, p1, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public e(La/p;La/ac;)V
    .locals 1

    invoke-virtual {p1, p2}, La/p;->l(La/ac;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const p2, 0x7f0b0228

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x1

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->st()V

    return-void
.end method

.method public e(Ljava/lang/String;I)V
    .locals 2

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityTimes$7;

    invoke-direct {v1, p0, p2, v0}, Lcom/brasfoot/v2028/ActivityTimes$7;-><init>(Lcom/brasfoot/v2028/ActivityTimes;ILandroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance p2, Lcom/brasfoot/v2028/ActivityTimes$8;

    invoke-direct {p2, p0, v0}, Lcom/brasfoot/v2028/ActivityTimes$8;-><init>(Lcom/brasfoot/v2028/ActivityTimes;Landroid/app/Dialog;)V

    invoke-virtual {p1, p2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public onClickAssumirTime(Landroid/view/View;)V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    if-eqz v0, :cond_3

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_1

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/af;

    invoke-virtual {v4}, La/af;->ly()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_0

    move-object v2, v4

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-eqz v2, :cond_3

    invoke-virtual {v2}, La/af;->hE()La/ac;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v3}, La/ac;->mc()La/af;

    :cond_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v5

    invoke-virtual {v3, v0, v5, v2}, La/b;->a(La/ac;La/af;La/af;)V

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dH()Z

    sput-object v2, La/o;->pU:La/af;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Time assumido: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    new-instance v0, Landroid/content/Intent;

    const-class v3, Lcom/brasfoot/v2028/ActivityMainTeam;

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v3, 0x4000000

    invoke-virtual {v0, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->finish()V

    :cond_3
    return-void
.end method

.method public onClickCalend(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-static {p1}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityCalendario;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onClickCompra(Landroid/view/View;)V
    .locals 4

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1}, Lcomponents/ap;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1}, Lcomponents/ap;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    const v0, 0x7f0b0224

    const/4 v1, 0x1

    if-eqz p1, :cond_2

    const/4 p1, 0x0

    invoke-static {p1}, La/f;->z(Z)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, v2, v3}, Lcom/brasfoot/v2028/ActivityTimes;->b(La/p;La/ac;)I

    move-result v2

    const/4 v3, 0x6

    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v3, p1

    const-string p1, ""

    aput-object p1, v3, v1

    const/4 p1, 0x2

    const v0, 0x7f0b0150

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v3, p1

    const/4 p1, 0x3

    const v0, 0x7f0b0155

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v3, p1

    const/4 p1, 0x4

    const v0, 0x7f0b0082

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v3, p1

    const/4 p1, 0x5

    const v0, 0x7f0b011a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v3, p1

    if-eq v2, v1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    aget-object v0, v3, v2

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v0, 0x7f0b0047

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "?"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v1}, Lcom/brasfoot/v2028/ActivityTimes;->e(Ljava/lang/String;I)V

    return-void

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public onClickEditarJogador(Landroid/view/View;)V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/p;

    if-eqz v1, :cond_0

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    sput-object v1, Lcom/brasfoot/v2028/ActivityEditJog;->target:La/p;

    new-instance v2, Landroid/content/Intent;

    const-class v3, Lcom/brasfoot/v2028/ActivityEditJog;

    invoke-direct {v2, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onClickEmprestimo(Landroid/view/View;)V
    .locals 6

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1}, Lcomponents/ap;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1}, Lcomponents/ap;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/p;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityTimes;->a(La/p;La/ac;)I

    move-result p1

    const/4 v0, 0x7

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const v2, 0x7f0b0223

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v1

    const-string v1, ""

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0150

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    aput-object v1, v0, v4

    const/4 v1, 0x3

    const v5, 0x7f0b00e2

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v0, v1

    const/4 v1, 0x4

    const v5, 0x7f0b0082

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v0, v1

    const/4 v1, 0x5

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x6

    const v2, 0x7f0b0155

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    if-ne p1, v3, :cond_1

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v0, 0x7f0b0028

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v0}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "?"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v4}, Lcom/brasfoot/v2028/ActivityTimes;->e(Ljava/lang/String;I)V

    return-void

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    aget-object p1, v0, p1

    invoke-static {v1, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public onClickHistTime(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    if-eqz v0, :cond_0

    sput-object v0, Lcom/brasfoot/v2028/ActivityHist;->fixedClub:La/ac;

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityHist;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onClickInfoJogador(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->py()V

    return-void
.end method

.method public onClickOferta(Landroid/view/View;)V
    .locals 2

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    if-eq p1, v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->qY()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b00c9

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method

.method public onClickTH(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-static {p1}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityTeamHistory;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onClickTecStats(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object p1

    sput-object p1, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    sget-object p1, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    if-eqz p1, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityTecnico;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070029

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    const p1, 0x7f060195

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GQ:Landroid/widget/ListView;

    new-instance p1, Lcomponents/ap;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/ap;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GQ:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GQ:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityTimes$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTimes$1;-><init>(Lcom/brasfoot/v2028/ActivityTimes;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->GQ:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityTimes$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTimes$3;-><init>(Lcom/brasfoot/v2028/ActivityTimes;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemLongClickListener(Landroid/widget/AdapterView$OnItemLongClickListener;)V

    const p1, 0x7f060239

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Hj:Landroid/widget/Spinner;

    const p1, 0x7f060238

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->Fv:Landroid/widget/Spinner;

    const p1, 0x7f06023a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MF:Landroid/widget/Spinner;

    const p1, 0x7f060022

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MG:Landroid/widget/Button;

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sm()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTimes;->sr()V

    return-void
.end method

.method public py()V
    .locals 2

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v1}, Lcomponents/ap;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->s(La/p;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public qY()V
    .locals 3

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v1}, Lcomponents/ap;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v0}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    const/4 v2, 0x1

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b0150

    :goto_0
    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x63

    if-lt v0, v1, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b0155

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->rH()V

    :cond_3
    return-void
.end method

.method public rH()V
    .locals 5

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f070037

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f06031f

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0b01d2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    const v1, 0x7f060099

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602ef

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0172

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->GS:La/p;

    invoke-virtual {v3}, La/p;->hI()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, La/n;->b(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602f0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0289

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602c7

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0600b4

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/EditText;

    new-instance v3, Lcom/brasfoot/v2028/ActivityTimes$9;

    invoke-direct {v3, p0, v1, v2}, Lcom/brasfoot/v2028/ActivityTimes$9;-><init>(Lcom/brasfoot/v2028/ActivityTimes;Landroid/widget/TextView;Landroid/widget/EditText;)V

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v3, Lcom/brasfoot/v2028/ActivityTimes$10;

    invoke-direct {v3, p0, v2, v0}, Lcom/brasfoot/v2028/ActivityTimes$10;-><init>(Lcom/brasfoot/v2028/ActivityTimes;Landroid/widget/EditText;Landroid/app/Dialog;)V

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityTimes$2;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityTimes$2;-><init>(Lcom/brasfoot/v2028/ActivityTimes;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public ss()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->Ip:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->MF:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    const v0, 0x7f0602dc

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f0602ec

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/String;

    const v3, 0x7f0b019f

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const v3, 0x7f0b01a0

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, v2, v4

    const v3, 0x7f0b01a1

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x2

    aput-object v3, v2, v4

    const v3, 0x7f0b01a2

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    aput-object v3, v2, v4

    const v3, 0x7f0b01a3

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x4

    aput-object v3, v2, v4

    const v3, 0x7f0b01a4

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityTimes;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x5

    aput-object v3, v2, v4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    if-eqz v3, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v3}, La/ac;->getReputacao()I

    move-result v3

    aget-object v2, v2, v3

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v0}, La/ac;->lz()La/af;

    move-result-object v0

    invoke-virtual {v0}, La/af;->gN()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    const v0, 0x7f0b0257

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(I)V

    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->getPais()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v0

    invoke-virtual {v0}, La/z;->getNome()Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f0602e5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f060112

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTimes;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    const/16 v4, 0x1d

    if-ne v3, v4, :cond_1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " ("

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, La/ak;->Ap:[Ljava/lang/String;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v4}, La/ac;->getEstado()I

    move-result v4

    aget-object v0, v0, v4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTimes;->dh(I)I

    move-result v0

    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTimes;->st()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MG:Landroid/widget/Button;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->lZ()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MG:Landroid/widget/Button;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MG:Landroid/widget/Button;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->ma()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextColor(I)V

    return-void
.end method

.method public st()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTimes;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0}, Lcomponents/ap;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->KL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->GQ:Landroid/widget/ListView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTimes;->MH:Lcomponents/ap;

    invoke-virtual {v0, v1}, Lcomponents/ap;->dm(I)V

    :cond_0
    return-void
.end method
