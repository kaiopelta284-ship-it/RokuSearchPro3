.class public Lcom/brasfoot/v2028/RcSpListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field private mode:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/brasfoot/v2028/RcSpListener;->mode:I

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_0

    iget v1, p0, Lcom/brasfoot/v2028/RcSpListener;->mode:I

    iput v1, v0, La/b;->rcSpMode:I

    invoke-virtual {v0}, La/b;->db()I

    move-result v1

    add-int/lit8 v1, v1, 0x2

    iput v1, v0, La/b;->rcSpUntil:I

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userClub()La/ac;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, La/ac;->getNivel()I

    move-result v1

    invoke-static {v1}, Lcom/brasfoot/v2028/Recopa;->spPctFor(I)I

    move-result v1

    iput v1, v0, La/b;->rcSpPct:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-void

    :catch_0
    move-exception v0

    return-void
.end method
