.class final Lcom/brasfoot/v2028/ActivityRankings$7;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityRankings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcomponents/cc;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcomponents/cc;Lcomponents/cc;)I
    .locals 2

    invoke-virtual {p1}, Lcomponents/cc;->vd()I

    move-result v0

    invoke-virtual {p2}, Lcomponents/cc;->vd()I

    move-result v1

    invoke-virtual {p1}, Lcomponents/cc;->vf()I

    move-result p1

    invoke-virtual {p2}, Lcomponents/cc;->vf()I

    move-result p2

    if-eq v0, v1, :cond_0

    sub-int/2addr v1, v0

    return v1

    :cond_0
    if-eq p1, p2, :cond_1

    sub-int/2addr p2, p1

    return p2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcomponents/cc;

    check-cast p2, Lcomponents/cc;

    invoke-virtual {p0, p1, p2}, Lcom/brasfoot/v2028/ActivityRankings$7;->a(Lcomponents/cc;Lcomponents/cc;)I

    move-result p1

    return p1
.end method
