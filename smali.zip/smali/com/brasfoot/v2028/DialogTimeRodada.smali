.class public Lcom/brasfoot/v2028/DialogTimeRodada;
.super Landroid/app/Activity;


# static fields
.field private static NP:La/y;

.field private static NQ:Ld/q;


# instance fields
.field FL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Fv:Landroid/widget/Spinner;

.field Fw:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Gi:I

.field Gk:Landroid/widget/Spinner;

.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Hj:Landroid/widget/Spinner;

.field private MJ:La/y;

.field NK:Landroid/widget/ListView;

.field NL:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field private NM:Ld/q;

.field private NN:La/p;

.field NO:Lcomponents/ao;

.field lU:I

.field oO:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/y;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Ha:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hb:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->oO:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fw:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NL:Ljava/util/ArrayList;

    const/4 v1, 0x0

    iput v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NN:La/p;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/DialogTimeRodada;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->so()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/DialogTimeRodada;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sP()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/DialogTimeRodada;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sp()V

    return-void
.end method

.method public static f(La/y;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NP:La/y;

    return-void
.end method

.method public static k(Ld/q;)V
    .locals 0

    sput-object p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NQ:Ld/q;

    return-void
.end method

.method private sN()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/am;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fw:Ljava/util/ArrayList;

    const v3, 0x7f070066

    const/4 v4, 0x1

    invoke-direct {v1, p0, v3, v2, v4}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/DialogTimeRodada$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogTimeRodada$3;-><init>(Lcom/brasfoot/v2028/DialogTimeRodada;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    return-void
.end method

.method private sO()V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/am;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    const v3, 0x7f070066

    const/4 v4, 0x1

    invoke-direct {v1, p0, v3, v2, v4}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/DialogTimeRodada$4;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogTimeRodada$4;-><init>(Lcom/brasfoot/v2028/DialogTimeRodada;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    return-void
.end method

.method private sP()V
    .locals 7

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NN:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const v0, 0x7f0602eb

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    const/16 v3, 0xb

    new-array v3, v3, [I

    fill-array-data v3, :array_0

    iget v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    const/4 v4, 0x0

    if-nez v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v5}, Ld/q;->xQ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_2

    if-ltz v3, :cond_2

    const/4 v1, 0x0

    :goto_0
    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v5}, Ld/q;->xQ()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ah;

    invoke-virtual {v5}, La/ah;->nA()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v1, v5, :cond_3

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NL:Ljava/util/ArrayList;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v6}, Ld/q;->xQ()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ah;

    invoke-virtual {v6}, La/ah;->nA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v5}, Ld/q;->oc()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_1

    if-ltz v3, :cond_1

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v5}, Ld/q;->oc()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    iput-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NN:La/p;

    :cond_1
    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v5}, Ld/q;->ob()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_2

    if-ltz v3, :cond_2

    const/4 v1, 0x0

    :goto_1
    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v5}, Ld/q;->ob()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/ah;

    invoke-virtual {v5}, La/ah;->nA()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v1, v5, :cond_3

    iget-object v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NL:Ljava/util/ArrayList;

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v6}, Ld/q;->ob()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ah;

    invoke-virtual {v6}, La/ah;->nA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_3
    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NO:Lcomponents/ao;

    invoke-virtual {v1}, Lcomponents/ao;->notifyDataSetChanged()V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NO:Lcomponents/ao;

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NN:La/p;

    invoke-virtual {v1, v2}, Lcomponents/ao;->t(La/p;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NL:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_4

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_4
    return-void

    :array_0
    .array-data 4
        0x1
        0x9
        0x3
        0x5
        0x2
        0xb
        0xd
        0xe
        0x10
        0x16
        0x18
    .end array-data
.end method

.method public static sQ()La/y;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/DialogTimeRodada;->NP:La/y;

    return-object v0
.end method

.method public static sR()Ld/q;
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/DialogTimeRodada;->NQ:Ld/q;

    return-object v0
.end method

.method private so()V
    .locals 5

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b0073

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b0074

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0076

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b0078

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const v1, 0x7f0b007a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const v1, 0x7f0b007c

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    aput-object v1, v0, v3

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fw:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    invoke-virtual {v3}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fw:Ljava/util/ArrayList;

    add-int/lit8 v1, v1, 0x1

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setSelection(I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sN()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sp()V

    return-void
.end method

.method private sp()V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    invoke-virtual {v1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    invoke-virtual {v0}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld/q;

    iput-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010003

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_2

    iget v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    if-nez v1, :cond_4

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v1}, Ld/q;->xO()I

    move-result v1

    sub-int/2addr v1, v3

    if-ge v2, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v2, v2, 0x1

    aget-object v5, v0, v2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v5, 0x7f0b01a9

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v0}, Ld/q;->xO()I

    move-result v0

    add-int/lit8 v0, v0, -0x2

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    if-ge v0, v1, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v1}, Ld/q;->xO()I

    move-result v1

    goto :goto_2

    :cond_2
    :goto_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    if-ge v2, v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    add-int/lit16 v1, v2, 0x7ea

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    if-le v0, v3, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getCount()I

    move-result v1

    :goto_2
    add-int/lit8 v1, v1, -0x2

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_4
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sP()V

    return-void
.end method


# virtual methods
.method public onClickBolaDeOuro(Landroid/view/View;)V
    .locals 2

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityBolaDeOuro;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/DialogTimeRodada;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickFechar(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->finish()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 10

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070039

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->setContentView(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_0

    const-string v0, "tipo"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    :cond_0
    sget-object p1, Lcom/brasfoot/v2028/DialogTimeRodada;->NP:La/y;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    const/4 v0, 0x0

    if-nez p1, :cond_1

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    :cond_1
    sget-object p1, Lcom/brasfoot/v2028/DialogTimeRodada;->NQ:Ld/q;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    if-nez p1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld/q;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    :cond_2
    const p1, 0x7f060235

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hj:Landroid/widget/Spinner;

    const p1, 0x7f06022c

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    const p1, 0x7f060236

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Gk:Landroid/widget/Spinner;

    const p1, 0x7f060180

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NK:Landroid/widget/ListView;

    const v1, 0x7f06027b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    if-nez v2, :cond_3

    const v2, 0x7f0b024e

    :goto_0
    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_3
    const v2, 0x7f0b024f

    goto :goto_0

    :goto_1
    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_2
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_5

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hb:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4}, La/y;->kX()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->oO:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Ha:Ljava/util/ArrayList;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/y;

    invoke-virtual {v4, p0}, La/y;->f(Landroid/content/Context;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v3, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    sget-object v4, Lc/a;->TF:La/b;

    invoke-virtual {v4}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_4

    move v2, v1

    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_5
    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hj:Landroid/widget/Spinner;

    new-instance v9, Lcomponents/al;

    const v5, 0x7f070066

    iget-object v6, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hb:Ljava/util/ArrayList;

    iget-object v7, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Ha:Ljava/util/ArrayList;

    const/4 v8, 0x0

    move-object v3, v9

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lcomponents/al;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {v1, v9}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Hj:Landroid/widget/Spinner;

    new-instance v2, Lcom/brasfoot/v2028/DialogTimeRodada$1;

    invoke-direct {v2, p0}, Lcom/brasfoot/v2028/DialogTimeRodada$1;-><init>(Lcom/brasfoot/v2028/DialogTimeRodada;)V

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const/4 v1, 0x6

    new-array v1, v1, [Ljava/lang/String;

    const v2, 0x7f0b0073

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const v2, 0x7f0b0074

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    aput-object v2, v1, v3

    const/4 v2, 0x2

    const v4, 0x7f0b0076

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v2

    const/4 v2, 0x3

    const v4, 0x7f0b0078

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v2

    const/4 v2, 0x4

    const v4, 0x7f0b007a

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v2

    const/4 v2, 0x5

    const v4, 0x7f0b007c

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v2

    const/4 v2, 0x0

    :goto_3
    iget-object v4, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->MJ:La/y;

    invoke-virtual {v4}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fw:Ljava/util/ArrayList;

    add-int/lit8 v2, v2, 0x1

    aget-object v5, v1, v2

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_6
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sN()V

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f010003

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v1

    iget v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    if-nez v2, :cond_7

    :goto_4
    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NM:Ld/q;

    invoke-virtual {v2}, Ld/q;->xO()I

    move-result v2

    sub-int/2addr v2, v3

    if-ge v0, v2, :cond_8

    iget-object v2, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v0, v0, 0x1

    aget-object v5, v1, v0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v5, 0x7f0b01a9

    invoke-virtual {p0, v5}, Lcom/brasfoot/v2028/DialogTimeRodada;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_7
    :goto_5
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->db()I

    move-result v1

    if-ge v0, v1, :cond_8

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->FL:Ljava/util/ArrayList;

    add-int/lit16 v2, v0, 0x7ea

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_8
    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sO()V

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->Fv:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/DialogTimeRodada$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/DialogTimeRodada$2;-><init>(Lcom/brasfoot/v2028/DialogTimeRodada;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/DialogTimeRodada;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v6, Lcomponents/ao;

    iget-object v1, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NL:Ljava/util/ArrayList;

    const/4 v4, 0x0

    iget v5, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->lU:I

    move-object v0, v6

    move-object v2, p0

    move-object v3, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/ao;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;La/p;I)V

    iput-object v6, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NO:Lcomponents/ao;

    iget-object v0, p0, Lcom/brasfoot/v2028/DialogTimeRodada;->NO:Lcomponents/ao;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/DialogTimeRodada;->sP()V

    return-void
.end method
