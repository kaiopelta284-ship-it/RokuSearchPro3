.class public Lcom/brasfoot/v2028/ActivityProcura;
.super Landroid/app/Activity;


# instance fields
.field private EZ:La/ac;

.field GA:Landroid/widget/Button;

.field GC:Landroid/widget/Button;

.field GD:Landroid/widget/Button;

.field GH:Landroid/widget/Spinner;

.field GI:Landroid/widget/Spinner;

.field GJ:Landroid/widget/Spinner;

.field GK:Landroid/widget/Spinner;

.field GL:Landroid/widget/Spinner;

.field GN:Landroid/widget/TextView;

.field GP:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field GQ:Landroid/widget/ListView;

.field GR:Lfield/RangeSeekBar;

.field private GS:La/p;

.field Gs:Landroid/widget/ViewFlipper;

.field Gz:Landroid/widget/Button;

.field Le:Landroid/widget/ImageView;

.field Lf:Landroid/widget/ImageView;

.field Lg:Landroid/widget/ImageView;

.field Lh:Landroid/widget/ImageView;

.field Li:Landroid/widget/Spinner;

.field Lj:Lcomponents/c;

.field public oL:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    return-void
.end method

.method public static G(Ljava/lang/String;)Z
    .locals 1

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    return v0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityProcura;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pA()V

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityProcura;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->cK(I)V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityProcura;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pz()V

    return-void
.end method

.method static synthetic c(Lcom/brasfoot/v2028/ActivityProcura;)La/ac;
    .locals 0

    iget-object p0, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    return-object p0
.end method

.method private cK(I)V
    .locals 3

    const v0, 0x7f030010

    const v1, 0x7f030013

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gs:Landroid/widget/ViewFlipper;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/ViewFlipper;->setDisplayedChild(I)V

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gz:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GA:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gs:Landroid/widget/ViewFlipper;

    const/4 v0, 0x1

    goto :goto_0

    return-void
.end method

.method private pA()V
    .locals 8

    new-instance v0, La/aa;

    invoke-direct {v0}, La/aa;-><init>()V

    const v1, 0x7f0600b9

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, La/aa;->setNome(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GH:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, La/aa;->bN(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GI:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, La/aa;->bO(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GK:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, La/aa;->bP(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Li:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, La/aa;->bQ(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, La/aa;->bR(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GL:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, La/aa;->bU(I)V

    const v1, 0x7f060078

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->O(Z)V

    const v1, 0x7f060079

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->P(Z)V

    const v1, 0x7f060077

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->Q(Z)V

    const v1, 0x7f06007a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->R(Z)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v1}, Lfield/RangeSeekBar;->getSelectedMinValue()Ljava/lang/Number;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->bV(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v1}, Lfield/RangeSeekBar;->getSelectedMaxValue()Ljava/lang/Number;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, La/aa;->bW(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, La/aa;->ln()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/16 v6, 0x64

    if-ge v3, v5, :cond_1

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/2addr v4, v2

    if-lt v4, v6, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    sget-object v4, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {v3, v4}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0b01c1

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ne v4, v2, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v2, 0x7f0b01c0

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_3

    :cond_2
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-le v4, v2, :cond_3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v4, v6, :cond_3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0b01be

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v2, v1

    :goto_2
    invoke-virtual {v3, v4, v2}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    goto :goto_3

    :cond_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lt v4, v6, :cond_4

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0b01bf

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v2, v1

    goto :goto_2

    :cond_4
    :goto_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GN:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0, v1}, Lcomponents/c;->dm(I)V

    :cond_5
    return-void
.end method

.method private pB()V
    .locals 4

    const v0, 0x7f060244

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GL:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/y;

    invoke-virtual {v3}, La/y;->kX()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance v2, Landroid/widget/ArrayAdapter;

    const v3, 0x1090008

    invoke-direct {v2, p0, v3, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v2, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GL:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GL:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pC()V
    .locals 3

    const v0, 0x7f060248

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GH:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0183

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0188

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0181

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0185

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b0180

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GH:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GH:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pD()V
    .locals 3

    const v0, 0x7f060247

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GI:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b01c5

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const v1, 0x7f0b01c3

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GI:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GI:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pE()V
    .locals 3

    const v0, 0x7f060246

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GK:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "1..10"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "11..30"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "31..50"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "51..70"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "71..100"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GK:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GK:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pF()V
    .locals 4

    const/16 v0, 0xe

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b015f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b015e

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const v1, 0x7f0b0160

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b015a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    aput-object v1, v0, v3

    const v1, 0x7f0b0163

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    aput-object v1, v0, v3

    const v1, 0x7f0b0159

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    aput-object v1, v0, v3

    const v1, 0x7f0b015b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    aput-object v1, v0, v3

    const v1, 0x7f0b0165

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    aput-object v1, v0, v3

    const v1, 0x7f0b015c

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x8

    aput-object v1, v0, v3

    const v1, 0x7f0b0164

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x9

    aput-object v1, v0, v3

    const v1, 0x7f0b0161

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xa

    aput-object v1, v0, v3

    const v1, 0x7f0b0162

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xb

    aput-object v1, v0, v3

    const v1, 0x7f0b0166

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xc

    aput-object v1, v0, v3

    const v1, 0x7f0b015d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xd

    aput-object v1, v0, v3

    const v1, 0x7f060245

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Spinner;

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GJ:Landroid/widget/Spinner;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const v3, 0x7f0b01b4

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    new-instance v0, Landroid/widget/ArrayAdapter;

    const v3, 0x1090008

    invoke-direct {v0, p0, v3, v1}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v1, 0x1090009

    invoke-virtual {v0, v1}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private pz()V
    .locals 3

    const v0, 0x7f0600b9

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GH:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GI:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GK:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Li:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GJ:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GL:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v2}, Lfield/RangeSeekBar;->getAbsoluteMinValue()Ljava/lang/Number;

    move-result-object v2

    invoke-virtual {v0, v2}, Lfield/RangeSeekBar;->setSelectedMinValue(Ljava/lang/Number;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    invoke-virtual {v2}, Lfield/RangeSeekBar;->getAbsoluteMaxValue()Ljava/lang/Number;

    move-result-object v2

    invoke-virtual {v0, v2}, Lfield/RangeSeekBar;->setSelectedMaxValue(Ljava/lang/Number;)V

    const v0, 0x7f060078

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    const v0, 0x7f060079

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    const v0, 0x7f060077

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    const v0, 0x7f06007a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GN:Landroid/widget/TextView;

    const v1, 0x7f0b01b7

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->notifyDataSetChanged()V

    return-void
.end method

.method private rG()V
    .locals 3

    const v0, 0x7f06024c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Li:Landroid/widget/Spinner;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const v1, 0x7f0b01b4

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "1K ... 1M"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "1M ... 5M"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "5M ... 10M"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "10M ... 30M"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "30M ... 50M"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "50M ... 100M"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "+100M ..."

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    const v0, 0x1090009

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Li:Landroid/widget/Spinner;

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Li:Landroid/widget/Spinner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method


# virtual methods
.method public M(Ljava/lang/String;)V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    if-eqz v0, :cond_5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "000"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_0

    const-string v0, "\\d+"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityProcura;->G(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-lez v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, -0x1

    :goto_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, v0, v2, p1}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;I)I

    move-result v0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v2}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v2}, La/p;->hI()I

    move-result v2

    if-lt p1, v2, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, p1, v0, v1, v1}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;II)V

    return-void

    :cond_1
    const/4 v2, 0x1

    if-ne v0, v2, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, v0, v2, p1, v1}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;II)V

    return-void

    :cond_2
    const/4 p1, 0x6

    new-array v1, p1, [Ljava/lang/String;

    const/4 v3, 0x0

    const v4, 0x7f0b000a

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    const v3, 0x7f0b0227

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    const/4 v3, 0x2

    const v4, 0x7f0b0150

    invoke-virtual {p0, v4}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    const v3, 0x7f0b0155

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    aput-object v3, v1, v4

    const v3, 0x7f0b0082

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    aput-object v3, v1, v5

    const v3, 0x7f0b011a

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    aput-object v3, v1, v6

    if-gt v0, v6, :cond_3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    aget-object v0, v1, v0

    invoke-static {p1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_3
    const v1, 0x7f0b0287

    if-ne v0, p1, :cond_4

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const v0, 0x7f0b0229

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, La/f;->ga()I

    move-result v0

    int-to-long v2, v0

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v4}, Lcom/brasfoot/v2028/ActivityProcura;->e(Ljava/lang/String;I)V

    return-void

    :cond_4
    const/4 p1, 0x7

    if-ne v0, p1, :cond_5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v0, 0x7f0b0216

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->oL:I

    int-to-long v2, v0

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v5}, Lcom/brasfoot/v2028/ActivityProcura;->e(Ljava/lang/String;I)V

    :cond_5
    return-void
.end method

.method public N(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "000"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "\\d+"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/brasfoot/v2028/ActivityProcura;->G(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-ltz v0, :cond_0

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    int-to-long v0, p1

    invoke-static {v0, v1}, La/n;->b(J)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    const p1, 0x7f0b00d7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public a(La/p;La/ac;)I
    .locals 3

    const/4 v0, 0x0

    if-eqz p1, :cond_8

    if-nez p2, :cond_0

    return v0

    :cond_0
    invoke-virtual {p1}, La/p;->hX()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1

    const/4 p1, 0x5

    return p1

    :cond_1
    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v1

    if-ne p2, v1, :cond_2

    const/4 p1, 0x2

    return p1

    :cond_2
    invoke-virtual {p2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v2, 0x63

    if-lt v1, v2, :cond_3

    const/4 p1, 0x6

    return p1

    :cond_3
    const/4 v1, 0x0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_5

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-eqz v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->eH()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bn;

    invoke-virtual {v2}, Lcomponents/bn;->nD()La/p;

    move-result-object v2

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v2

    if-ne v2, p2, :cond_4

    add-int/lit8 v1, v1, 0x1

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    const/4 v0, 0x4

    if-lt v1, v0, :cond_6

    :cond_6
    invoke-static {p1, p2}, La/f;->d(La/p;La/ac;)Z

    move-result p1

    if-nez p1, :cond_7

    return v0

    :cond_7
    const/4 p1, 0x1

    return p1

    :cond_8
    return v0
.end method

.method public a(La/p;La/ac;I)I
    .locals 10

    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/ac;->T(Z)[I

    move-result-object v0

    const/4 v2, 0x6

    new-array v3, v2, [I

    fill-array-data v3, :array_0

    new-array v4, v2, [D

    fill-array-data v4, :array_1

    new-array v5, v2, [D

    fill-array-data v5, :array_2

    new-array v6, v2, [D

    fill-array-data v6, :array_3

    new-array v7, v2, [I

    fill-array-data v7, :array_4

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v8

    aget v8, v0, v8

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v9

    aget v3, v3, v9

    const/4 v9, 0x1

    if-lt v8, v3, :cond_2

    invoke-virtual {p1}, La/p;->hG()I

    move-result v0

    const/16 v3, 0x63

    if-lt v0, v3, :cond_1

    invoke-virtual {p1}, La/p;->getIdade()I

    move-result v0

    const/16 v3, 0x23

    if-le v0, v3, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    int-to-double v3, v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    aget-wide v5, v6, v0

    mul-double v3, v3, v5

    goto :goto_2

    :cond_1
    :goto_0
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    invoke-virtual {p1}, La/p;->hI()I

    move-result v3

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v4

    aget v4, v7, v4

    mul-int v3, v3, v4

    div-int/lit8 v3, v3, 0x64

    int-to-float v3, v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    sub-int v3, v0, v3

    goto :goto_3

    :cond_2
    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v3

    aget v0, v0, v3

    if-ne v0, v9, :cond_3

    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    int-to-double v5, v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    aget-wide v3, v4, v0

    mul-double v5, v5, v3

    invoke-static {v5, v6}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    :goto_1
    long-to-int v0, v3

    invoke-virtual {p1}, La/p;->hI()I

    move-result v3

    add-int/2addr v3, v0

    goto :goto_3

    :cond_3
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    int-to-double v3, v0

    invoke-virtual {p1}, La/p;->getPosicao()I

    move-result v0

    aget-wide v6, v5, v0

    mul-double v3, v3, v6

    :goto_2
    invoke-static {v3, v4}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    goto :goto_1

    :goto_3
    const/4 v0, 0x2

    if-lt p3, v3, :cond_6

    invoke-static {p1, p2}, La/f;->c(La/p;La/ac;)I

    move-result p1

    if-ne p1, v9, :cond_4

    const/4 p1, 0x4

    return p1

    :cond_4
    if-ne p1, v0, :cond_5

    return v2

    :cond_5
    return v9

    :cond_6
    invoke-virtual {p2}, La/ac;->lA()J

    move-result-wide v4

    int-to-long v6, v3

    cmp-long p3, v4, v6

    if-ltz p3, :cond_8

    invoke-static {p1, p2}, La/f;->c(La/p;La/ac;)I

    move-result p1

    if-eqz p1, :cond_7

    if-ne p1, v0, :cond_8

    :cond_7
    iput v3, p0, Lcom/brasfoot/v2028/ActivityProcura;->oL:I

    const/4 p1, 0x7

    return p1

    :cond_8
    return v1

    :array_0
    .array-data 4
        0x3
        0x4
        0x4
        0x5
        0x4
        0x4
    .end array-data

    :array_1
    .array-data 8
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x3ff8000000000000L    # 1.5
        0x4000000000000000L    # 2.0
        0x3ff0000000000000L    # 1.0
    .end array-data

    :array_2
    .array-data 8
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff0000000000000L    # 1.0
        0x3ff8000000000000L    # 1.5
        0x4000000000000000L    # 2.0
    .end array-data

    :array_3
    .array-data 8
        0x3fe0000000000000L    # 0.5
        0x3fc999999999999aL    # 0.2
        0x3fc999999999999aL    # 0.2
        0x3fc999999999999aL    # 0.2
        0x3fe0000000000000L    # 0.5
        0x3ff0000000000000L    # 1.0
    .end array-data

    :array_4
    .array-data 4
        0xf
        0x14
        0x14
        0xa
        0xa
        0x2
    .end array-data
.end method

.method public a(La/p;La/ac;II)V
    .locals 7

    if-eqz p1, :cond_2

    :try_start_0
    invoke-virtual {p1}, La/p;->hI()I

    move-result v0

    if-lez p3, :cond_0

    move v3, p3

    goto :goto_0

    :cond_0
    move v3, v0

    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p1

    move-object v2, p2

    invoke-virtual/range {v1 .. v6}, La/p;->a(La/ac;IZZZ)V

    if-lez p4, :cond_1

    invoke-virtual {p1, p4}, La/p;->aQ(I)V

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const p2, 0x7f0b0227

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 p3, 0x1

    invoke-static {p1, p2, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    return-void
.end method

.method public b(La/p;La/ac;)I
    .locals 5

    if-eqz p1, :cond_5

    if-eqz p2, :cond_5

    invoke-virtual {p1}, La/p;->hR()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, La/p;->hE()La/ac;

    move-result-object v0

    if-ne p2, v0, :cond_1

    const/4 p1, 0x2

    return p1

    :cond_1
    invoke-virtual {p2}, La/ac;->lA()J

    move-result-wide v0

    invoke-virtual {p1}, La/p;->hI()I

    move-result v2

    int-to-long v2, v2

    cmp-long v4, v0, v2

    if-gez v4, :cond_2

    const/4 p1, 0x5

    return p1

    :cond_2
    invoke-virtual {p2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x63

    if-lt v0, v1, :cond_3

    const/4 p1, 0x3

    return p1

    :cond_3
    invoke-static {p1, p2}, La/f;->d(La/p;La/ac;)Z

    move-result p1

    if-nez p1, :cond_4

    const/4 p1, 0x4

    return p1

    :cond_4
    const/4 p1, 0x1

    return p1

    :cond_5
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public dd(I)V
    .locals 3

    const/4 v0, -0x1

    const/4 v1, 0x1

    if-ne p1, v1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, p1, v1, v0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;II)V

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    if-ne p1, v1, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityProcura;->e(La/p;La/ac;)V

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    if-ne p1, v1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-static {}, La/f;->ga()I

    move-result v2

    invoke-virtual {p0, p1, v1, v0, v2}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;II)V

    goto :goto_0

    :cond_2
    const/4 v1, 0x4

    if-ne p1, v1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->oL:I

    invoke-virtual {p0, p1, v1, v2, v0}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;II)V

    :cond_3
    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    invoke-virtual {p1}, Landroid/widget/ListView;->deferNotifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {p1}, Lcomponents/c;->notifyDataSetChanged()V

    return-void
.end method

.method public e(La/p;La/ac;)V
    .locals 1

    invoke-virtual {p1, p2}, La/p;->l(La/ac;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const p2, 0x7f0b0228

    invoke-virtual {p0, p2}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x1

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public e(Ljava/lang/String;I)V
    .locals 2

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f07002e

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f0600a6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f060062

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityProcura$3;

    invoke-direct {v1, p0, p2, v0}, Lcom/brasfoot/v2028/ActivityProcura$3;-><init>(Lcom/brasfoot/v2028/ActivityProcura;ILandroid/app/Dialog;)V

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06004d

    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    new-instance p2, Lcom/brasfoot/v2028/ActivityProcura$4;

    invoke-direct {p2, p0, v0}, Lcom/brasfoot/v2028/ActivityProcura$4;-><init>(Lcom/brasfoot/v2028/ActivityProcura;Landroid/app/Dialog;)V

    invoke-virtual {p1, p2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public onBackPressed()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gs:Landroid/widget/ViewFlipper;

    invoke-virtual {v0}, Landroid/widget/ViewFlipper;->getDisplayedChild()I

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->finish()V

    return-void

    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->cK(I)V

    return-void
.end method

.method public onClickCompra()V
    .locals 5

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v1}, Lcomponents/c;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    const v1, 0x7f0b0224

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    invoke-static {v0}, La/f;->z(Z)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, v3, v4}, Lcom/brasfoot/v2028/ActivityProcura;->b(La/p;La/ac;)I

    move-result v3

    const/4 v4, 0x6

    new-array v4, v4, [Ljava/lang/String;

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v4, v0

    const-string v0, ""

    aput-object v0, v4, v2

    const/4 v0, 0x2

    const v1, 0x7f0b0150

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v4, v0

    const/4 v0, 0x3

    const v1, 0x7f0b0155

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v4, v0

    const/4 v0, 0x4

    const v1, 0x7f0b0082

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v4, v0

    const/4 v0, 0x5

    const v1, 0x7f0b011a

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v4, v0

    if-eq v3, v2, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    aget-object v1, v4, v3

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b0047

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "?"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Lcom/brasfoot/v2028/ActivityProcura;->e(Ljava/lang/String;I)V

    return-void

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public onClickEmprestimo()V
    .locals 7

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v1}, Lcomponents/c;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {p0, v0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->a(La/p;La/ac;)I

    move-result v0

    const/4 v1, 0x7

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const v3, 0x7f0b0223

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v2

    const-string v2, ""

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const v2, 0x7f0b0150

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    aput-object v2, v1, v5

    const/4 v2, 0x3

    const v6, 0x7f0b00e2

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v1, v2

    const/4 v2, 0x4

    const v6, 0x7f0b0082

    invoke-virtual {p0, v6}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v1, v2

    const/4 v2, 0x5

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    const/4 v2, 0x6

    const v3, 0x7f0b0155

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    if-ne v0, v4, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b0028

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v1}, La/p;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "?"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v5}, Lcom/brasfoot/v2028/ActivityProcura;->e(Ljava/lang/String;I)V

    return-void

    :cond_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    aget-object v0, v1, v0

    invoke-static {v2, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public onClickOferta()V
    .locals 3

    invoke-static {p0}, Lc/a;->m(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->qY()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b00c9

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07001d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->finish()V

    :cond_0
    :goto_0
    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    const p1, 0x7f060224

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lfield/RangeSeekBar;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GR:Lfield/RangeSeekBar;

    const p1, 0x7f0600e4

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ViewFlipper;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gs:Landroid/widget/ViewFlipper;

    const p1, 0x7f060050

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gz:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Gz:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$1;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060051

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GA:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GA:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$8;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$8;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06001e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GC:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GC:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$9;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$9;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060021

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GD:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GD:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$10;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$10;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pC()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pD()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->rG()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pF()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pE()V

    :try_start_4
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityProcura;->pB()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    :catch_3
    const p1, 0x7f060198

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    new-instance p1, Lcomponents/c;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/c;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$11;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$11;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GQ:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$12;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$12;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemLongClickListener(Landroid/widget/AdapterView$OnItemLongClickListener;)V

    const p1, 0x7f06031d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GN:Landroid/widget/TextView;

    const p1, 0x7f060012

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Le:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Le:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$13;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$13;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060016

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lf:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lf:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$14;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$14;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f06001b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lg:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lg:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$15;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$15;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060052

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lh:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lh:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityProcura$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityProcura$2;-><init>(Lcom/brasfoot/v2028/ActivityProcura;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityProcura;->cK(I)V

    return-void
.end method

.method public py()V
    .locals 2

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v1}, Lcomponents/c;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->s(La/p;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityProcura;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public qY()V
    .locals 3

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v0}, Lcomponents/c;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GP:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->Lj:Lcomponents/c;

    invoke-virtual {v1}, Lcomponents/c;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/p;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v0}, La/p;->hE()La/ac;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    const/4 v2, 0x1

    if-eq v0, v1, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v0}, La/p;->iC()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityProcura;->EZ:La/ac;

    invoke-virtual {v0}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/16 v1, 0x63

    if-lt v0, v1, :cond_2

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b0155

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->rH()V

    return-void

    :cond_3
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityProcura;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0b0150

    :goto_1
    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_4
    return-void
.end method

.method public rH()V
    .locals 5

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v1, 0x7f070037

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(I)V

    const v1, 0x7f06031f

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0b01d2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    const v1, 0x7f060099

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602ef

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0172

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityProcura;->GS:La/p;

    invoke-virtual {v3}, La/p;->hI()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, La/n;->b(J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602f0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b0289

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityProcura;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f0602c7

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const v2, 0x7f0600b4

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/EditText;

    new-instance v3, Lcom/brasfoot/v2028/ActivityProcura$5;

    invoke-direct {v3, p0, v1, v2}, Lcom/brasfoot/v2028/ActivityProcura$5;-><init>(Lcom/brasfoot/v2028/ActivityProcura;Landroid/widget/TextView;Landroid/widget/EditText;)V

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const v1, 0x7f060062

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v3, Lcom/brasfoot/v2028/ActivityProcura$6;

    invoke-direct {v3, p0, v2, v0}, Lcom/brasfoot/v2028/ActivityProcura$6;-><init>(Lcom/brasfoot/v2028/ActivityProcura;Landroid/widget/EditText;Landroid/app/Dialog;)V

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v1, 0x7f06004d

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    new-instance v2, Lcom/brasfoot/v2028/ActivityProcura$7;

    invoke-direct {v2, p0, v0}, Lcom/brasfoot/v2028/ActivityProcura$7;-><init>(Lcom/brasfoot/v2028/ActivityProcura;Landroid/app/Dialog;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method
