.class Lcom/brasfoot/v2028/ActivityFimAno$a;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityFimAno;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic IZ:Lcom/brasfoot/v2028/ActivityFimAno;


# direct methods
.method private constructor <init>(Lcom/brasfoot/v2028/ActivityFimAno;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno$a;->IZ:Lcom/brasfoot/v2028/ActivityFimAno;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/brasfoot/v2028/ActivityFimAno;Lcom/brasfoot/v2028/ActivityFimAno$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno$a;-><init>(Lcom/brasfoot/v2028/ActivityFimAno;)V

    return-void
.end method


# virtual methods
.method protected varargs b([Ljava/lang/String;)Ljava/lang/Boolean;
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno$a;->IZ:Lcom/brasfoot/v2028/ActivityFimAno;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityFimAno;->qq()V

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno$a;->b([Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected l(Ljava/lang/Boolean;)V
    .locals 3

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->freemiumBlocked()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno$a;->IZ:Lcom/brasfoot/v2028/ActivityFimAno;

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->freemiumEndDialog(Landroid/app/Activity;)V

    return-void

    :cond_0
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFimAno$a;->IZ:Lcom/brasfoot/v2028/ActivityFimAno;

    const-class v2, Lcom/brasfoot/v2028/ActivityBolaDeOuro;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFimAno$a;->IZ:Lcom/brasfoot/v2028/ActivityFimAno;

    invoke-virtual {v1, v0}, Lcom/brasfoot/v2028/ActivityFimAno;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method protected synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno$a;->l(Ljava/lang/Boolean;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno$a;->IZ:Lcom/brasfoot/v2028/ActivityFimAno;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/ActivityFimAno;->pv()V

    return-void
.end method
