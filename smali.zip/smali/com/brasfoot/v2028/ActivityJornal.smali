.class public Lcom/brasfoot/v2028/ActivityJornal;
.super Landroid/app/Activity;


# static fields
.field public static limite:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 3

    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x41700000    # 15.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    const v1, -0xe5e5e6

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v2, 0x6

    const/16 v1, 0x10

    invoke-virtual {v0, v2, v1, v2, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private addRow(Landroid/widget/LinearLayout;Lest/TransRec;)V
    .locals 9

    iget-object v1, p2, Lest/TransRec;->jog:Ljava/lang/String;

    invoke-static {p2}, Lcom/brasfoot/v2028/ActivityJornal;->valStr(Lest/TransRec;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p2, Lest/TransRec;->lxDe:Ljava/lang/String;

    iget-object v4, p2, Lest/TransRec;->lxPara:Ljava/lang/String;

    iget-object v5, p2, Lest/TransRec;->de:Ljava/lang/String;

    iget-object v6, p2, Lest/TransRec;->para:Ljava/lang/String;

    const v7, -0xe5e5e6

    move-object v0, p0

    invoke-static/range {v0 .. v7}, Lcom/brasfoot/v2028/Recopa;->jornalTransferRow(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const v1, -0x94a1c6

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private addSecV(Landroid/widget/LinearLayout;Ljava/lang/String;II)I
    .locals 8

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v1, Lc/a;->TF:La/b;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, La/b;->getTransHist()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_3

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_3

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lest/TransRec;

    iget v4, v3, Lest/TransRec;->ano:I

    if-ne v4, p3, :cond_2

    const/4 v4, 0x2

    if-ne p4, v4, :cond_0

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    if-ne p4, v4, :cond_1

    iget v4, v3, Lest/TransRec;->paisDe:I

    invoke-direct {p0, v4}, Lcom/brasfoot/v2028/ActivityJornal;->paisNome(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2

    goto :goto_1

    :cond_1
    iget v4, v3, Lest/TransRec;->pais:I

    invoke-direct {p0, v4}, Lcom/brasfoot/v2028/ActivityJornal;->paisNome(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2

    :goto_1
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    sget-object v1, Lcom/brasfoot/v2028/TransCmp;->INST:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v2, 0x0

    :goto_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_4

    sget v3, Lcom/brasfoot/v2028/ActivityJornal;->limite:I

    if-ge v2, v3, :cond_4

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lest/TransRec;

    invoke-direct {p0, p1, v3}, Lcom/brasfoot/v2028/ActivityJornal;->addRow(Landroid/widget/LinearLayout;Lest/TransRec;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_4
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method private addVerMais(Landroid/widget/LinearLayout;)V
    .locals 3

    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v1, "Ver mais (+50)"

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityJornal$More;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityJornal$More;-><init>(Lcom/brasfoot/v2028/ActivityJornal;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private anoList()[Ljava/lang/String;
    .locals 8

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/b;->getTransHist()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-gtz v2, :cond_1

    :cond_0
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->currentYear()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    return-object v0

    :cond_1
    const v3, 0x7fffffff

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v2, :cond_4

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lest/TransRec;

    iget v6, v6, Lest/TransRec;->ano:I

    if-ge v6, v3, :cond_2

    move v3, v6

    :cond_2
    if-le v6, v4, :cond_3

    move v4, v6

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    sub-int v0, v4, v3

    add-int/lit8 v0, v0, 0x1

    if-gtz v0, :cond_5

    const/4 v0, 0x1

    :cond_5
    new-array v1, v0, [Ljava/lang/String;

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v0, :cond_6

    sub-int v6, v4, v5

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v1, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_6
    return-object v1
.end method

.method private fill(I[Ljava/lang/String;)V
    .locals 3

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJornal;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    new-instance v1, Landroid/widget/ArrayAdapter;

    const v2, 0x1090008

    invoke-direct {v1, p0, v2, p2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    const v2, 0x1090009

    invoke-virtual {v1, v2}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    :cond_0
    return-void
.end method

.method private paisList()[Ljava/lang/String;
    .locals 9

    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/b;->getTransHist()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_3

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lest/TransRec;

    iget v3, v3, Lest/TransRec;->pais:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v6, v2, 0x1

    new-array v3, v6, [Ljava/lang/String;

    const/4 v6, 0x0

    const-string v7, "Todos"

    aput-object v7, v3, v6

    const/4 v4, 0x0

    :goto_1
    if-ge v4, v2, :cond_2

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-direct {p0, v5}, Lcom/brasfoot/v2028/ActivityJornal;->paisNome(I)Ljava/lang/String;

    move-result-object v5

    add-int/lit8 v6, v4, 0x1

    aput-object v5, v3, v6

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_2
    return-object v3

    :cond_3
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "Todos"

    aput-object v2, v0, v1

    return-object v0
.end method

.method private paisNome(I)Ljava/lang/String;
    .locals 3

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityJornal;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    if-ltz p1, :cond_0

    array-length v1, v0

    if-ge p1, v1, :cond_0

    aget-object v0, v0, p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    :cond_0
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private selStr(I)Ljava/lang/String;
    .locals 2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJornal;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItem()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const-string v0, ""

    return-object v0
.end method

.method private static valStr(Lest/TransRec;)Ljava/lang/String;
    .locals 4

    iget v0, p0, Lest/TransRec;->tipo:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const-string v0, "emprestimo"

    return-object v0

    :cond_0
    iget v0, p0, Lest/TransRec;->valor:I

    if-gtz v0, :cond_1

    const-string v0, "livre"

    return-object v0

    :cond_1
    iget v0, p0, Lest/TransRec;->valor:I

    int-to-long v2, v0

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public onClickMostrarJor(Landroid/view/View;)V
    .locals 7

    const v0, 0x7f060432

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJornal;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    const v1, 0x7f06042f

    invoke-direct {p0, v1}, Lcom/brasfoot/v2028/ActivityJornal;->selStr(I)Ljava/lang/String;

    move-result-object v1

    const v2, 0x7f060430

    invoke-direct {p0, v2}, Lcom/brasfoot/v2028/ActivityJornal;->selStr(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    :try_start_0
    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v4

    const/4 v3, 0x0

    :goto_0
    const-string v4, "Todos"

    invoke-static {v4, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_1

    const-string v4, "Maiores transferencias"

    invoke-direct {p0, v0, v4}, Lcom/brasfoot/v2028/ActivityJornal;->addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    const/4 v4, 0x2

    invoke-direct {p0, v0, v1, v3, v4}, Lcom/brasfoot/v2028/ActivityJornal;->addSecV(Landroid/widget/LinearLayout;Ljava/lang/String;II)I

    move-result v4

    if-nez v4, :cond_0

    const-string v4, "Nenhuma transferencia."

    invoke-direct {p0, v0, v4}, Lcom/brasfoot/v2028/ActivityJornal;->addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    goto :goto_1

    :cond_0
    sget v5, Lcom/brasfoot/v2028/ActivityJornal;->limite:I

    if-le v4, v5, :cond_5

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityJornal;->addVerMais(Landroid/widget/LinearLayout;)V

    goto :goto_1

    :cond_1
    const-string v4, "ENTRADAS"

    invoke-direct {p0, v0, v4}, Lcom/brasfoot/v2028/ActivityJornal;->addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-direct {p0, v0, v1, v3, v4}, Lcom/brasfoot/v2028/ActivityJornal;->addSecV(Landroid/widget/LinearLayout;Ljava/lang/String;II)I

    move-result v4

    if-nez v4, :cond_2

    const-string v5, "(nenhuma)"

    invoke-direct {p0, v0, v5}, Lcom/brasfoot/v2028/ActivityJornal;->addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    :cond_2
    const-string v5, "SAIDAS"

    invoke-direct {p0, v0, v5}, Lcom/brasfoot/v2028/ActivityJornal;->addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    const/4 v5, 0x1

    invoke-direct {p0, v0, v1, v3, v5}, Lcom/brasfoot/v2028/ActivityJornal;->addSecV(Landroid/widget/LinearLayout;Ljava/lang/String;II)I

    move-result v5

    if-nez v5, :cond_3

    const-string v6, "(nenhuma)"

    invoke-direct {p0, v0, v6}, Lcom/brasfoot/v2028/ActivityJornal;->addHeader(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    :cond_3
    sget v6, Lcom/brasfoot/v2028/ActivityJornal;->limite:I

    if-gt v4, v6, :cond_4

    if-le v5, v6, :cond_5

    :cond_4
    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityJornal;->addVerMais(Landroid/widget/LinearLayout;)V

    :cond_5
    :goto_1
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07007b

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityJornal;->setContentView(I)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJornal;->paisList()[Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f06042f

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityJornal;->fill(I[Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityJornal;->anoList()[Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f060430

    invoke-direct {p0, v1, v0}, Lcom/brasfoot/v2028/ActivityJornal;->fill(I[Ljava/lang/String;)V

    const/16 v0, 0x32

    sput v0, Lcom/brasfoot/v2028/ActivityJornal;->limite:I

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityJornal;->onClickMostrarJor(Landroid/view/View;)V

    return-void
.end method
