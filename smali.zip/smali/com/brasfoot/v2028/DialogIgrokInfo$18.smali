.class Lcom/brasfoot/v2028/DialogIgrokInfo$18;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogIgrokInfo;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogIgrokInfo;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$18;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$18;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/DialogIgrokInfo;->sK()V

    return-void
.end method
