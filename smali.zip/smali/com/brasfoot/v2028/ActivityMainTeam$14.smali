.class Lcom/brasfoot/v2028/ActivityMainTeam$14;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/PopupMenu$OnMenuItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityMainTeam;->ri()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic KF:Lcom/brasfoot/v2028/ActivityMainTeam;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam$14;->KF:Lcom/brasfoot/v2028/ActivityMainTeam;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMenuItemClick(Landroid/view/MenuItem;)Z
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam$14;->KF:Lcom/brasfoot/v2028/ActivityMainTeam;

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const/16 v1, 0x7777

    if-ne p1, v1, :cond_0

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->showIdolos(Landroid/app/Activity;)V

    const/4 p1, 0x1

    return p1

    :cond_0
    const/16 v1, 0x7778

    if-ne p1, v1, :cond_1

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->showRecordes(Landroid/app/Activity;)V

    const/4 p1, 0x1

    return p1

    :cond_1
    const/16 v1, 0x7779

    if-ne p1, v1, :cond_2

    invoke-static {v0}, Lcom/brasfoot/v2028/RcShop;->show(Landroid/app/Activity;)V

    const/4 p1, 0x1

    return p1

    :cond_2
    const/16 v1, 0x777a

    if-ne p1, v1, :cond_3

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->showEmprestados(Landroid/app/Activity;)V

    const/4 p1, 0x1

    return p1

    :cond_3
    invoke-static {v0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->c(Lcom/brasfoot/v2028/ActivityMainTeam;I)V

    const/4 p1, 0x1

    return p1
.end method
