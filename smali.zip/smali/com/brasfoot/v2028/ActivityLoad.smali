.class public Lcom/brasfoot/v2028/ActivityLoad;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityLoad$b;,
        Lcom/brasfoot/v2028/ActivityLoad$a;
    }
.end annotation


# instance fields
.field JL:Lcomponents/as;

.field private JM:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cp;",
            ">;"
        }
    .end annotation
.end field

.field JN:Ljava/io/File;

.field JO:Ljava/io/File;

.field private JP:Lcom/brasfoot/v2028/b;

.field private JQ:Lcom/brasfoot/v2028/b;

.field private JR:Landroid/os/Handler;

.field private JS:Ljava/lang/Runnable;

.field JT:Lcom/brasfoot/v2028/ActivityLoad$b;

.field JU:Ljava/lang/ThreadGroup;

.field JV:Ljava/lang/Thread;


# direct methods
.method public constructor <init>()V
    .locals 8

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JN:Ljava/io/File;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JO:Ljava/io/File;

    new-instance v0, Lcom/brasfoot/v2028/ActivityLoad$b;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityLoad$b;-><init>(Lcom/brasfoot/v2028/ActivityLoad;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JT:Lcom/brasfoot/v2028/ActivityLoad$b;

    new-instance v0, Ljava/lang/ThreadGroup;

    const-string v1, "threadGroup"

    invoke-direct {v0, v1}, Ljava/lang/ThreadGroup;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JU:Ljava/lang/ThreadGroup;

    new-instance v0, Ljava/lang/Thread;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityLoad;->JU:Ljava/lang/ThreadGroup;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityLoad;->JT:Lcom/brasfoot/v2028/ActivityLoad$b;

    const-string v5, "My thread"

    const-wide/32 v6, 0x1e8480

    move-object v2, v0

    invoke-direct/range {v2 .. v7}, Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;J)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JV:Ljava/lang/Thread;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityLoad;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityLoad;->pw()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityLoad;)Lcom/brasfoot/v2028/b;
    .locals 0

    iget-object p0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    return-object p0
.end method

.method private pw()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityLoad$2;-><init>(Lcom/brasfoot/v2028/ActivityLoad;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private qQ()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityLoad$3;-><init>(Lcom/brasfoot/v2028/ActivityLoad;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method private qR()V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$4;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityLoad$4;-><init>(Lcom/brasfoot/v2028/ActivityLoad;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method


# virtual methods
.method public K(Ljava/lang/String;)V
    .locals 2

    :try_start_0
    new-instance v0, Lcom/esotericsoftware/kryo/io/Input;

    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lcom/esotericsoftware/kryo/io/Input;-><init>(Ljava/io/InputStream;)V

    new-instance v0, Lest/InfoArquivoSalvoType;

    invoke-direct {v0}, Lest/InfoArquivoSalvoType;-><init>()V

    const-string v1, "teste"

    invoke-virtual {v0, v1}, Lest/InfoArquivoSalvoType;->setN(Ljava/lang/String;)V

    if-eqz v0, :cond_5

    new-instance v1, Lcomponents/cp;

    invoke-direct {v1}, Lcomponents/cp;-><init>()V

    invoke-virtual {v1, p1}, Lcomponents/cp;->setPath(Ljava/lang/String;)V

    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getA()Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getA()Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v1, p1}, Lcomponents/cp;->ad(I)V

    :cond_0
    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getN()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getN()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lcomponents/cp;->ar(Ljava/lang/String;)V

    :cond_1
    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getTc()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getTc()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lcomponents/cp;->setTecnico(Ljava/lang/String;)V

    :cond_2
    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getI()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_3

    invoke-virtual {v0}, Lest/InfoArquivoSalvoType;->getI()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lcomponents/cp;->ap(Ljava/lang/String;)V

    :cond_3
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-nez p1, :cond_4

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    :cond_5
    return-void
.end method

.method public L(Ljava/lang/String;)V
    .locals 4

    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v1

    goto :goto_0

    :catch_0
    move-exception p1

    goto/16 :goto_1

    :catch_1
    move-exception p1

    goto/16 :goto_2

    :catch_2
    move-exception v1

    :try_start_1
    invoke-virtual {v1}, Ljava/io/FileNotFoundException;->printStackTrace()V

    :goto_0
    new-instance v1, Ljava/io/ObjectInputStream;

    invoke-direct {v1, v0}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lest/InfoArquivoSalvoType;

    if-eqz v2, :cond_6

    new-instance v3, Lcomponents/cp;

    invoke-direct {v3}, Lcomponents/cp;-><init>()V

    invoke-virtual {v3, p1}, Lcomponents/cp;->an(Ljava/lang/String;)V

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getA()Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getA()Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->ad(I)V

    :cond_0
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getN()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getN()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->ar(Ljava/lang/String;)V

    :cond_1
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getTc()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getTc()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->setTecnico(Ljava/lang/String;)V

    :cond_2
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getI()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_3

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getI()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->ap(Ljava/lang/String;)V

    :cond_3
    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getPath()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_4

    invoke-virtual {v2}, Lest/InfoArquivoSalvoType;->getPath()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Lcomponents/cp;->setPath(Ljava/lang/String;)V

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-nez p1, :cond_5

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    :cond_5
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->close()V

    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :goto_1
    invoke-virtual {p1}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    return-void

    :goto_2
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    return-void
.end method

.method public clickDelete(Landroid/view/View;)V
    .locals 4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JL:Lcomponents/as;

    invoke-virtual {p1}, Lcomponents/as;->th()I

    move-result p1

    const/4 v0, 0x1

    if-ltz p1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-le v1, p1, :cond_0

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/cp;

    invoke-virtual {v2}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/cp;

    invoke-virtual {p1}, Lcomponents/cp;->wo()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p1

    if-eqz p1, :cond_1

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JN:Ljava/io/File;

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JO:Ljava/io/File;

    new-instance p1, Landroid/app/Dialog;

    invoke-direct {p1, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const v0, 0x7f07002e

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->setContentView(I)V

    const v0, 0x7f0600a6

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f0b0284

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    const v0, 0x7f060062

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$6;

    invoke-direct {v1, p0, p1}, Lcom/brasfoot/v2028/ActivityLoad$6;-><init>(Lcom/brasfoot/v2028/ActivityLoad;Landroid/app/Dialog;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f06004d

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$7;

    invoke-direct {v1, p0, p1}, Lcom/brasfoot/v2028/ActivityLoad$7;-><init>(Lcom/brasfoot/v2028/ActivityLoad;Landroid/app/Dialog;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v1, 0x7f0b022f

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityLoad;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method

.method public clickLoad(Landroid/view/View;)V
    .locals 2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JL:Lcomponents/as;

    invoke-virtual {p1}, Lcomponents/as;->th()I

    move-result p1

    if-ltz p1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, p1, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qO()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b022f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070017

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityLoad;->setContentView(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qM()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qL()V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->dismiss()V

    :cond_0
    return-void
.end method

.method public qL()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :goto_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    move-result v2

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    :goto_1
    const/4 v3, 0x0

    if-eqz v1, :cond_3

    if-eqz v2, :cond_3

    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v1

    array-length v2, v1

    const/4 v4, 0x0

    :goto_2
    if-ge v4, v2, :cond_3

    aget-object v5, v1, v4

    invoke-virtual {v5}, Ljava/io/File;->isFile()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v6

    const-string v7, ".ai21"

    invoke-virtual {v6, v7}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_3
    const/4 v1, 0x0

    :goto_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityLoad;->L(Ljava/lang/String;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_4
    const v0, 0x7f06017f

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/as;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/as;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JL:Lcomponents/as;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JL:Lcomponents/as;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityLoad$1;-><init>(Lcom/brasfoot/v2028/ActivityLoad;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const v0, 0x7f060125

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_5

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_5
    return-void
.end method

.method public qM()V
    .locals 7

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    const/4 v3, 0x0

    if-eqz v0, :cond_3

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v4, 0x0

    :goto_1
    if-ge v3, v1, :cond_2

    aget-object v5, v0, v3

    invoke-virtual {v5}, Ljava/io/File;->isFile()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    const-string v6, ".png"

    invoke-virtual {v5, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    add-int/lit8 v4, v4, 0x1

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_2
    move v3, v4

    :cond_3
    const/16 v0, 0xa

    if-le v3, v0, :cond_4

    sput-boolean v2, Lcom/brasfoot/v2028/MainActivity;->Oa:Z

    :cond_4
    return-void
.end method

.method public qN()V
    .locals 3

    new-instance v0, Lcom/brasfoot/v2028/b;

    const v1, 0x7f0b00e3

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityLoad;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lcom/brasfoot/v2028/b;-><init>(Landroid/content/Context;Ljava/lang/String;I)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0, v2}, Lcom/brasfoot/v2028/b;->setCancelable(Z)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JP:Lcom/brasfoot/v2028/b;

    invoke-virtual {v0}, Lcom/brasfoot/v2028/b;->show()V

    :cond_0
    return-void
.end method

.method public qO()V
    .locals 1

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityLoad;->pw()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JV:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public qP()V
    .locals 6

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    if-eqz v0, :cond_2

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, ".bcf"

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    :goto_2
    if-eqz v0, :cond_3

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_3

    :try_start_0
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, v0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    new-instance v0, Ljava/io/ObjectInputStream;

    invoke-direct {v0, v1}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lest/Options;

    invoke-static {v2}, Lc/a;->a(Lest/Options;)V

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->close()V

    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/io/OptionalDataException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/io/StreamCorruptedException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    return-void

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    return-void

    :catch_2
    move-exception v0

    invoke-virtual {v0}, Ljava/io/StreamCorruptedException;->printStackTrace()V

    return-void

    :catch_3
    move-exception v0

    invoke-virtual {v0}, Ljava/io/OptionalDataException;->printStackTrace()V

    return-void

    :catch_4
    move-exception v0

    invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V

    :cond_3
    return-void
.end method

.method public qS()V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JL:Lcomponents/as;

    invoke-virtual {v0}, Lcomponents/as;->th()I

    move-result v0

    const/4 v1, 0x1

    if-ltz v0, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-le v2, v0, :cond_3

    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cp;

    invoke-virtual {v3}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qP()V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    const/4 v2, 0x0

    :try_start_0
    new-instance v3, Ljava/io/FileInputStream;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/cp;

    invoke-virtual {v4}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    new-instance v4, Lcom/esotericsoftware/kryo/io/Input;

    invoke-direct {v4, v3}, Lcom/esotericsoftware/kryo/io/Input;-><init>(Ljava/io/InputStream;)V

    new-instance v3, Lcom/esotericsoftware/kryo/Kryo;

    invoke-direct {v3}, Lcom/esotericsoftware/kryo/Kryo;-><init>()V

    invoke-virtual {v3, v2}, Lcom/esotericsoftware/kryo/Kryo;->setRegistrationRequired(Z)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    invoke-virtual {v3, v4}, Lcom/esotericsoftware/kryo/Kryo;->readClassAndObject(Lcom/esotericsoftware/kryo/io/Input;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/b;

    invoke-static {v3}, Lc/a;->a(La/b;)V

    invoke-virtual {v4}, Lcom/esotericsoftware/kryo/io/Input;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v3, 0x1

    goto :goto_1

    :catch_0
    move-exception v3

    :try_start_2
    invoke-virtual {v3}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    move-exception v3

    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    :goto_0
    const/4 v3, 0x0

    :goto_1
    if-nez v3, :cond_0

    :try_start_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/cp;

    invoke-virtual {v4}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, ".s21"

    const-string v6, ".sbck"

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_0

    new-instance v5, Ljava/io/FileInputStream;

    invoke-direct {v5, v4}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    new-instance v4, Lcom/esotericsoftware/kryo/io/Input;

    invoke-direct {v4, v5}, Lcom/esotericsoftware/kryo/io/Input;-><init>(Ljava/io/InputStream;)V

    new-instance v5, Lcom/esotericsoftware/kryo/Kryo;

    invoke-direct {v5}, Lcom/esotericsoftware/kryo/Kryo;-><init>()V

    invoke-virtual {v5, v2}, Lcom/esotericsoftware/kryo/Kryo;->setRegistrationRequired(Z)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3

    :try_start_4
    invoke-virtual {v5, v4}, Lcom/esotericsoftware/kryo/Kryo;->readClassAndObject(Lcom/esotericsoftware/kryo/io/Input;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/b;

    invoke-static {v5}, Lc/a;->a(La/b;)V

    invoke-virtual {v4}, Lcom/esotericsoftware/kryo/io/Input;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_2

    :catch_2
    move-exception v4

    :try_start_5
    invoke-virtual {v4}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3

    goto :goto_2

    :catch_3
    move-exception v4

    invoke-virtual {v4}, Ljava/io/IOException;->printStackTrace()V

    :cond_0
    :goto_2
    sget-object v4, Lc/a;->TF:La/b;

    if-eqz v4, :cond_2

    if-eqz v3, :cond_2

    invoke-static {}, Lf/b;->wD()V

    invoke-static {}, Lf/b;->wA()V

    invoke-static {}, Lf/b;->wF()V

    sget-object v3, Lc/a;->TF:La/b;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cp;

    invoke-virtual {v0}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, La/b;->j(Ljava/lang/String;)V

    sget-object v0, Lc/a;->TF:La/b;

    iput-boolean v1, v0, La/b;->nt:Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->da()V

    invoke-static {p0}, La/v;->g(Landroid/content/Context;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->p(Z)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->finish()V

    if-eqz v2, :cond_1

    :try_start_6
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/brasfoot/v2028/ActivityLoad$5;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityLoad$5;-><init>(Lcom/brasfoot/v2028/ActivityLoad;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityLoad;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    :catch_4
    :cond_1
    invoke-static {}, La/o;->hv()V

    return-void

    :cond_2
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qR()V

    return-void

    :cond_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b022f

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityLoad;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_4
    return-void
.end method

.method public qT()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JL:Lcomponents/as;

    invoke-virtual {v0}, Lcomponents/as;->th()I

    move-result v0

    const/4 v1, 0x1

    if-ltz v0, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-le v2, v0, :cond_0

    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/cp;

    invoke-virtual {v3}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qP()V

    invoke-static {}, Lc/a;->wz()Lest/Options;

    :try_start_0
    new-instance v2, Ljava/io/FileInputStream;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityLoad;->JM:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/cp;

    invoke-virtual {v0}, Lcomponents/cp;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    new-instance v0, Ljava/io/ObjectInputStream;

    invoke-direct {v0, v2}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lest/InfoArquivoSalvoType;

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/b;

    invoke-static {v3}, Lc/a;->a(La/b;)V

    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->close()V

    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/io/OptionalDataException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/io/StreamCorruptedException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    goto :goto_0

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0

    :catch_2
    move-exception v0

    invoke-virtual {v0}, Ljava/io/StreamCorruptedException;->printStackTrace()V

    goto :goto_0

    :catch_3
    move-exception v0

    invoke-virtual {v0}, Ljava/io/OptionalDataException;->printStackTrace()V

    goto :goto_0

    :catch_4
    move-exception v0

    invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V

    :goto_0
    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_1

    invoke-static {}, Lf/b;->wD()V

    invoke-static {}, Lf/b;->wA()V

    invoke-static {}, Lf/b;->wF()V

    sget-object v0, Lc/a;->TF:La/b;

    iput-boolean v1, v0, La/b;->nt:Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->da()V

    invoke-static {p0}, La/v;->g(Landroid/content/Context;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->p(Z)V

    invoke-static {}, La/o;->hv()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->finish()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0b022f

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityLoad;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method

.method public qU()V
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JN:Ljava/io/File;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JN:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JO:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityLoad;->qL()V

    :cond_1
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JN:Ljava/io/File;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityLoad;->JO:Ljava/io/File;

    return-void
.end method
