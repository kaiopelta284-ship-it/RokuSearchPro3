.class public Lcom/brasfoot/v2028/ActivityConviteSelecao;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityConviteSelecao$b;,
        Lcom/brasfoot/v2028/ActivityConviteSelecao$a;
    }
.end annotation


# instance fields
.field private Gu:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/ac;",
            ">;"
        }
    .end annotation
.end field

.field Gv:La/af;

.field Gw:[Landroid/widget/RadioButton;

.field Gx:[Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .locals 9

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gv:La/af;

    const/4 v1, 0x6

    new-array v2, v1, [Landroid/widget/RadioButton;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v4, 0x1

    aput-object v0, v2, v4

    const/4 v5, 0x2

    aput-object v0, v2, v5

    const/4 v6, 0x3

    aput-object v0, v2, v6

    const/4 v7, 0x4

    aput-object v0, v2, v7

    const/4 v8, 0x5

    aput-object v0, v2, v8

    iput-object v2, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    new-array v1, v1, [Landroid/widget/TextView;

    aput-object v0, v1, v3

    aput-object v0, v1, v4

    aput-object v0, v1, v5

    aput-object v0, v1, v6

    aput-object v0, v1, v7

    aput-object v0, v1, v8

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityConviteSelecao;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->pu()V

    return-void
.end method

.method private pu()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/RadioButton;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_1
    if-ltz v0, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gv:La/af;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/ac;->getPais()I

    move-result v0

    invoke-virtual {v1, v0}, La/b;->al(I)La/y;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gv:La/af;

    invoke-virtual {v0, v1}, La/y;->c(La/af;)V

    :cond_2
    const/4 v0, 0x0

    sput-object v0, La/o;->pS:Ljava/util/ArrayList;

    invoke-static {}, La/o;->hy()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->finish()V

    return-void
.end method

.method private pw()V
    .locals 1

    new-instance v0, Lcom/brasfoot/v2028/ActivityConviteSelecao$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao$1;-><init>(Lcom/brasfoot/v2028/ActivityConviteSelecao;)V

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void
.end method


# virtual methods
.method public onBackPressed()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->pr()V

    return-void
.end method

.method public onClickAccept(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->pt()V

    return-void
.end method

.method public onClickCancel(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->pr()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070007

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->setContentView(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    const v0, 0x7f060089

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const/4 v1, 0x0

    aput-object v0, p1, v1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    const v0, 0x7f06008a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const/4 v2, 0x1

    aput-object v0, p1, v2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    const v0, 0x7f06008b

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const/4 v3, 0x2

    aput-object v0, p1, v3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    const v0, 0x7f06008c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const/4 v4, 0x3

    aput-object v0, p1, v4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    const v0, 0x7f06008d

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const/4 v5, 0x4

    aput-object v0, p1, v5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    const v0, 0x7f06008e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    const/4 v6, 0x5

    aput-object v0, p1, v6

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    const v0, 0x7f060090

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    aput-object v0, p1, v1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    const v0, 0x7f060091

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    aput-object v0, p1, v2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    const v0, 0x7f060092

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    aput-object v0, p1, v3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    const v0, 0x7f060093

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    aput-object v0, p1, v4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    const v0, 0x7f060094

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    aput-object v0, p1, v5

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    const v0, 0x7f060095

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    aput-object v0, p1, v6

    invoke-static {}, La/o;->hA()Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    sget-object p1, La/o;->pU:La/af;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gv:La/af;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    if-eqz p1, :cond_3

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gv:La/af;

    if-eqz p1, :cond_3

    const/4 p1, 0x6

    new-array v0, p1, [Ljava/lang/String;

    const v7, 0x7f0b0073

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v1

    const v7, 0x7f0b0074

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v2

    const v7, 0x7f0b0076

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v3

    const v7, 0x7f0b0078

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v4

    const v7, 0x7f0b007a

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v5

    const v7, 0x7f0b007c

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v6

    new-array p1, p1, [Ljava/lang/String;

    const v7, 0x7f0b004c

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, p1, v1

    const v7, 0x7f0b004d

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, p1, v2

    const v2, 0x7f0b0049

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, p1, v3

    const v2, 0x7f0b004a

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, p1, v4

    const v2, 0x7f0b004b

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, p1, v5

    const v2, 0x7f0b0009

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, p1, v6

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    array-length v3, v3

    if-ge v2, v3, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lt v2, v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    aget-object v3, v3, v2

    invoke-virtual {v3, v5}, Landroid/widget/RadioButton;->setVisibility(I)V

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    array-length v2, v2

    if-ge v1, v2, :cond_2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "P"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ac;

    invoke-virtual {v3}, La/ac;->getPais()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, La/z;->valueOf(Ljava/lang/String;)La/z;

    move-result-object v2

    invoke-virtual {v2}, La/z;->getNome()Ljava/lang/String;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->getDivisao()I

    move-result v2

    aget-object v2, v0, v2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/ac;

    invoke-virtual {v2}, La/ac;->iw()I

    move-result v2

    aget-object v2, p1, v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    aget-object v3, v3, v1

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gu:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ac;

    invoke-virtual {v4}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/RadioButton;->setText(Ljava/lang/CharSequence;)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gx:[Landroid/widget/TextView;

    aget-object v3, v3, v1

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    array-length p1, p1

    if-ge v1, p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConviteSelecao;->Gw:[Landroid/widget/RadioButton;

    aget-object p1, p1, v1

    invoke-virtual {p1, v5}, Landroid/widget/RadioButton;->setVisibility(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method public onStart()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->pr()V

    :cond_0
    return-void
.end method

.method public pr()V
    .locals 2

    new-instance v0, Lcom/brasfoot/v2028/ActivityConviteSelecao$b;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/brasfoot/v2028/ActivityConviteSelecao$b;-><init>(Lcom/brasfoot/v2028/ActivityConviteSelecao;Lcom/brasfoot/v2028/ActivityConviteSelecao$1;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityConviteSelecao$b;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method public ps()V
    .locals 1

    const/4 v0, 0x0

    sput-object v0, La/o;->pS:Ljava/util/ArrayList;

    invoke-static {}, La/o;->hy()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->finish()V

    return-void
.end method

.method public pt()V
    .locals 2

    new-instance v0, Lcom/brasfoot/v2028/ActivityConviteSelecao$a;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/brasfoot/v2028/ActivityConviteSelecao$a;-><init>(Lcom/brasfoot/v2028/ActivityConviteSelecao;Lcom/brasfoot/v2028/ActivityConviteSelecao$1;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityConviteSelecao$a;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method public pv()V
    .locals 2

    const v0, 0x7f0601ff

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityConviteSelecao;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method
