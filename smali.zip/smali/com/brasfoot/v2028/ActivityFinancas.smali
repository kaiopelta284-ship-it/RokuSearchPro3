.class public Lcom/brasfoot/v2028/ActivityFinancas;
.super Landroid/app/Activity;


# instance fields
.field private EY:La/ac;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    return-void
.end method

.method private cS(I)V
    .locals 2

    const v0, 0x7f060131

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    const/4 v1, 0x1

    if-ne p1, v1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {p1}, La/ac;->mj()La/n;

    move-result-object p1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {p1, v1}, La/n;->h(La/ac;)Z

    move-result p1

    if-nez p1, :cond_1

    const p1, 0x7f0b00ab

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFinancas;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_0

    :cond_0
    const/4 v0, -0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {p1}, La/ac;->mj()La/n;

    move-result-object p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {p1, v0}, La/n;->g(La/ac;)Z

    :cond_1
    :goto_0
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityFinancas;->qs()V

    return-void
.end method

.method private qs()V
    .locals 4

    const v0, 0x7f06012e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v2, 0x7f0b0029

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityFinancas;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {v2}, La/ac;->mj()La/n;

    move-result-object v2

    invoke-virtual {v2}, La/n;->ho()I

    move-result v2

    int-to-long v2, v2

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060130

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v2, 0x7f0b0105

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityFinancas;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {v2}, La/ac;->mj()La/n;

    move-result-object v2

    invoke-virtual {v2}, La/n;->hr()I

    move-result v2

    int-to-long v2, v2

    invoke-static {v2, v3}, La/n;->b(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public onClick1(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityFinancas;->cS(I)V

    return-void
.end method

.method public onClick2(Landroid/view/View;)V
    .locals 0

    const/4 p1, -0x1

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityFinancas;->cS(I)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070013

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFinancas;->setContentView(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {p1}, La/ac;->mj()La/n;

    move-result-object p1

    if-eqz p1, :cond_2

    const v0, 0x7f06011c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hf()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060124

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hh()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060120

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hg()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v0}, Lcom/brasfoot/v2028/Recopa;->appendPrizeBreakdown(Landroid/widget/TextView;)V

    const v0, 0x7f06011e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hi()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->getSponsorLogoResId()I

    move-result v1

    const v0, 0x7f060345

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-lez v1, :cond_0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_0

    :cond_0
    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-static {v1}, Lcom/brasfoot/v2028/Recopa;->spDisplay(La/ac;)Ljava/lang/String;

    move-result-object v1

    const v0, 0x7f060346

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f060122

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->ha()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601e0

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hk()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601d4

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hj()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601dc

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hp()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601d6

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hl()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601da

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hn()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601d7

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hm()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0601de

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hc()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f0600e1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p1}, La/n;->hd()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v0, 0x7f06042e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_1

    invoke-virtual {p1}, La/n;->ha()J

    move-result-wide v1

    invoke-virtual {p1}, La/n;->hp()J

    move-result-wide v3

    invoke-static {v1, v2, v3, v4}, Lcom/brasfoot/v2028/Recopa;->finBar(JJ)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    const p1, 0x7f0602a2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b00af

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFinancas;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->mi()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f0602a1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFinancas;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b00ae

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFinancas;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFinancas;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->lA()J

    move-result-wide v1

    invoke-static {v1, v2}, La/n;->b(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ""

    invoke-static {v1}, Lorg/objenesis/strategy/StdInstantiatorStrategy;->z(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityFinancas;->qs()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->showBoardInFinancas(Landroid/app/Activity;)V

    :cond_2
    return-void
.end method
