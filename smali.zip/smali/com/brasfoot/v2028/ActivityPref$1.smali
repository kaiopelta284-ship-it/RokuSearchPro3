.class Lcom/brasfoot/v2028/ActivityPref$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityPref;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Ld:Lcom/brasfoot/v2028/ActivityPref;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityPref;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPref$1;->Ld:Lcom/brasfoot/v2028/ActivityPref;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPref$1;->Ld:Lcom/brasfoot/v2028/ActivityPref;

    invoke-virtual {p1, p2}, Lcom/brasfoot/v2028/ActivityPref;->af(Z)V

    return-void
.end method
