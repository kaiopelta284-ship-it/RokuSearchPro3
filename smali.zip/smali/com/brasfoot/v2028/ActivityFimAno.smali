.class public Lcom/brasfoot/v2028/ActivityFimAno;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityFimAno$a;
    }
.end annotation


# instance fields
.field IS:Lcomponents/v;

.field IT:Lcomponents/v;

.field IU:Landroid/widget/ImageView;

.field IV:Landroid/widget/ImageView;

.field IW:Landroid/widget/ImageView;

.field private IX:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cq;",
            ">;"
        }
    .end annotation
.end field

.field private IY:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cq;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IY:Ljava/util/ArrayList;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityFimAno;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityFimAno;->qo()V

    return-void
.end method

.method private a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcomponents/cq;",
            ">;",
            "La/c;",
            "Ljava/lang/String;",
            "IIZ)V"
        }
    .end annotation

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const v1, 0x7f0b0073

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const v1, 0x7f0b0075

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const v1, 0x7f0b0077

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    aput-object v1, v0, v3

    const v1, 0x7f0b0079

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    aput-object v1, v0, v4

    const v1, 0x7f0b007b

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    aput-object v1, v0, v5

    const v1, 0x7f0b007d

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    aput-object v1, v0, v5

    const-string v1, ""

    if-le p5, v2, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, " - "

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v0, p5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_0
    new-instance v0, Lcomponents/cq;

    invoke-direct {v0}, Lcomponents/cq;-><init>()V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {v0, p3}, Lcomponents/cq;->Q(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lcomponents/cq;->ar(Z)V

    invoke-virtual {v0, p4}, Lcomponents/cq;->setPais(I)V

    const/4 p3, -0x1

    if-eqz p6, :cond_1

    invoke-virtual {v0, p3}, Lcomponents/cq;->setPais(I)V

    invoke-virtual {v0, p4}, Lcomponents/cq;->setEstado(I)V

    :cond_1
    if-ne p5, p3, :cond_2

    const/16 p3, 0x64

    invoke-virtual {v0, p3}, Lcomponents/cq;->W(I)V

    :cond_2
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance p3, Lcomponents/cq;

    invoke-direct {p3}, Lcomponents/cq;-><init>()V

    invoke-virtual {p3, v2}, Lcomponents/cq;->W(I)V

    invoke-virtual {p2}, La/c;->fu()La/ac;

    move-result-object p4

    invoke-virtual {p3, p4}, Lcomponents/cq;->f(La/ac;)V

    invoke-virtual {p2}, La/c;->fz()La/af;

    move-result-object p4

    if-eqz p4, :cond_3

    invoke-virtual {p2}, La/c;->fz()La/af;

    move-result-object p4

    invoke-virtual {p4}, La/af;->gN()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p3, p4}, Lcomponents/cq;->at(Ljava/lang/String;)V

    :cond_3
    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance p3, Lcomponents/cq;

    invoke-direct {p3}, Lcomponents/cq;-><init>()V

    invoke-virtual {p3, v3}, Lcomponents/cq;->W(I)V

    invoke-virtual {p2}, La/c;->fv()La/ac;

    move-result-object p4

    invoke-virtual {p3, p4}, Lcomponents/cq;->f(La/ac;)V

    invoke-virtual {p2}, La/c;->fA()La/af;

    move-result-object p4

    if-eqz p4, :cond_4

    invoke-virtual {p2}, La/c;->fA()La/af;

    move-result-object p4

    invoke-virtual {p4}, La/af;->gN()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p3, p4}, Lcomponents/cq;->at(Ljava/lang/String;)V

    :cond_4
    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance p3, Lcomponents/cq;

    invoke-direct {p3}, Lcomponents/cq;-><init>()V

    invoke-virtual {p3, v4}, Lcomponents/cq;->W(I)V

    invoke-virtual {p2}, La/c;->fy()I

    move-result p4

    invoke-static {p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p3, p4}, Lcomponents/cq;->at(Ljava/lang/String;)V

    invoke-virtual {p2}, La/c;->fx()La/ac;

    move-result-object p4

    invoke-virtual {p3, p4}, Lcomponents/cq;->f(La/ac;)V

    invoke-virtual {p2}, La/c;->fw()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Lcomponents/cq;->au(Ljava/lang/String;)V

    invoke-virtual {p3, v4}, Lcomponents/cq;->W(I)V

    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addModChamps()V
    .locals 11

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;

    if-eqz v0, :cond_4

    iget-object v1, v0, La/b;->superMundial:Ld/sm;

    if-eqz v1, :cond_0

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->champOfYearSM()La/c;

    move-result-object v6

    if-eqz v6, :cond_0

    move-object v4, p0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IY:Ljava/util/ArrayList;

    invoke-virtual {v1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v7

    const/4 v8, -0x1

    const/4 v9, -0x1

    const/4 v10, 0x0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_0
    iget-object v1, v0, La/b;->cssCopa:Ld/css;

    if-eqz v1, :cond_1

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->champOfYearCss()La/c;

    move-result-object v6

    if-eqz v6, :cond_1

    move-object v4, p0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    invoke-virtual {v1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x1d

    const/4 v9, -0x1

    const/4 v10, 0x0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_1
    iget-object v1, v0, La/b;->cneCopa:Ld/cne;

    if-eqz v1, :cond_2

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->champOfYearCne()La/c;

    move-result-object v6

    if-eqz v6, :cond_2

    move-object v4, p0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    invoke-virtual {v1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x1d

    const/4 v9, -0x1

    const/4 v10, 0x0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_2
    iget-object v1, v0, La/b;->cvCopa:Ld/cv;

    if-eqz v1, :cond_3

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->champOfYearCv()La/c;

    move-result-object v6

    if-eqz v6, :cond_3

    move-object v4, p0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    invoke-virtual {v1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x1d

    const/4 v9, -0x1

    const/4 v10, 0x0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->champFinalThisYear()La/c;

    move-result-object v6

    if-eqz v6, :cond_3

    move-object v4, p0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IY:Ljava/util/ArrayList;

    const-string v7, "Finalissima"

    const/4 v8, -0x1

    const/4 v9, -0x1

    const/4 v10, 0x0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_3
    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->userPais()I

    move-result v2

    if-ltz v2, :cond_4

    invoke-virtual {v0, v2}, La/b;->recopaFor(I)Ld/q;

    move-result-object v1

    if-eqz v1, :cond_4

    invoke-virtual {v0}, La/b;->db()I

    move-result v3

    invoke-static {v1, v3}, Lcom/brasfoot/v2028/Recopa;->champOfYear(La/al;I)La/c;

    move-result-object v6

    if-eqz v6, :cond_4

    move-object v4, p0

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    invoke-virtual {v1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v7

    move v8, v2

    const/4 v9, -0x1

    const/4 v10, 0x0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_4
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityFimAno;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityFimAno;->qp()V

    return-void
.end method

.method private qo()V
    .locals 4

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/DialogTimeRodada;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const-string v2, "tipo"

    const/4 v3, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFimAno;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private qp()V
    .locals 2

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object v0

    invoke-virtual {v0}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object v0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ac;

    invoke-virtual {v1}, La/ac;->ly()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dj()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/ac;

    invoke-static {v0}, Lcom/brasfoot/v2028/MainActivity;->B(La/ac;)V

    goto :goto_1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_3

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityAmistosos2024;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFimAno;->startActivity(Landroid/content/Intent;)V

    :cond_3
    return-void
.end method

.method private qs()V
    .locals 10

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->di()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_7

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    invoke-virtual {v2}, La/p;->iB()D

    move-result-wide v3

    const/4 v5, 0x1

    :goto_0
    if-ge v5, v1, :cond_1

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/p;

    invoke-virtual {v6}, La/p;->iB()D

    move-result-wide v7

    cmpg-double v9, v3, v7

    if-gez v9, :cond_0

    move-wide v3, v7

    move-object v2, v6

    :cond_0
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v2}, La/p;->iB()D

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmpl-double v7, v3, v5

    if-lez v7, :cond_7

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    add-int/lit16 v0, v0, 0x7e8

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ":\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " ("

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->hE()La/ac;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const-string v0, ")\n"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->getPosicao()I

    move-result v3

    const/4 v4, 0x0

    if-eq v3, v4, :cond_3

    const/4 v4, 0x1

    if-eq v3, v4, :cond_4

    const/4 v4, 0x2

    if-eq v3, v4, :cond_5

    const/4 v4, 0x3

    if-eq v3, v4, :cond_6

    const-string v0, "ATA"

    goto :goto_1

    :cond_3
    const-string v0, "GOL"

    goto :goto_1

    :cond_4
    const-string v0, "LAT"

    goto :goto_1

    :cond_5
    const-string v0, "ZAG"

    goto :goto_1

    :cond_6
    const-string v0, "MEI"

    :goto_1
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " - "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, La/p;->getIdade()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1, v0}, La/b;->appendBolaDeOuroHistory(Ljava/lang/String;)V

    :cond_7
    return-void
.end method


# virtual methods
.method public onBackPressed()V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFimAno;->qr()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SetTextI18n"
        }
    .end annotation

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->finEndOfYearNet()V

    const p1, 0x7f070012

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno;->setContentView(I)V

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    const/4 v1, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->nN()La/c;

    move-result-object v2

    if-eqz v2, :cond_0

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->nN()La/c;

    move-result-object v5

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->nT()Ljava/lang/String;

    move-result-object v6

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/y;

    invoke-virtual {v2}, La/y;->kC()I

    move-result v7

    add-int/lit8 v8, v1, 0x1

    const/4 v9, 0x0

    move-object v3, p0

    invoke-direct/range {v3 .. v9}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_2
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaEstadual()Z

    move-result v0

    if-eqz v0, :cond_5

    const v0, 0x7f060315

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const v1, 0x7f0b0268

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    const/4 v0, 0x0

    :goto_2
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_5

    const/4 v1, 0x0

    :goto_3
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->nN()La/c;

    move-result-object v2

    if-eqz v2, :cond_3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->kJ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/q;

    invoke-virtual {v2}, Ld/q;->nN()La/c;

    move-result-object v5

    sget-object v2, La/ak;->Ar:[Ljava/lang/String;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ld/m;

    invoke-virtual {v3}, Ld/m;->getEstado()I

    move-result v3

    aget-object v6, v2, v3

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dQ()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ld/m;

    invoke-virtual {v2}, Ld/m;->getEstado()I

    move-result v7

    add-int/lit8 v8, v1, 0x1

    const/4 v9, 0x1

    move-object v3, p0

    invoke-direct/range {v3 .. v9}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_2

    :cond_5
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaIntClubes()Z

    move-result v0

    const v1, 0x7f0601a1

    const/16 v2, 0x8

    if-nez v0, :cond_6

    const v0, 0x7f06030e

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setVisibility(I)V

    :cond_6
    sget-object v0, Lc/a;->TF:La/b;

    const/16 v3, 0x12

    new-array v3, v3, [La/al;

    invoke-virtual {v0}, La/b;->fe()Ld/o;

    move-result-object v4

    aput-object v4, v3, p1

    invoke-virtual {v0}, La/b;->fg()Ld/n;

    move-result-object v4

    const/4 v5, 0x1

    aput-object v4, v3, v5

    const/4 v4, 0x2

    invoke-virtual {v0}, La/b;->ff()Ld/c;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x3

    invoke-virtual {v0}, La/b;->ee()Ld/y;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x4

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x5

    invoke-virtual {v0}, La/b;->dX()Ld/v;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x6

    invoke-virtual {v0}, La/b;->dR()Ld/p;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x7

    invoke-virtual {v0}, La/b;->dU()Ld/ad;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-virtual {v0}, La/b;->eb()Ld/s;

    move-result-object v4

    aput-object v4, v3, v2

    const/16 v2, 0x9

    invoke-virtual {v0}, La/b;->ea()Ld/r;

    move-result-object v4

    aput-object v4, v3, v2

    const/16 v2, 0xa

    invoke-virtual {v0}, La/b;->dZ()Ld/u;

    move-result-object v4

    aput-object v4, v3, v2

    const/16 v2, 0xb

    invoke-virtual {v0}, La/b;->dY()Ld/w;

    move-result-object v0

    aput-object v0, v3, v2

    const/16 v2, 0xc

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v0

    aput-object v0, v3, v2

    const/16 v2, 0xd

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->ouroCopa:Ld/ouro;

    aput-object v0, v3, v2

    const/16 v2, 0xe

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->africaCopa:Ld/africa;

    aput-object v0, v3, v2

    const/16 v2, 0xf

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->asiaCopa:Ld/asia;

    aput-object v0, v3, v2

    const/16 v2, 0x10

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->ofcCopa:Ld/ofc;

    aput-object v0, v3, v2

    const/16 v2, 0x11

    sget-object v0, Lc/a;->TF:La/b;

    iget-object v0, v0, La/b;->elimccCopa:Ld/elimcc;

    aput-object v0, v3, v2

    :goto_4
    array-length v0, v3

    if-ge p1, v0, :cond_8

    aget-object v0, v3, p1

    aget-object v2, v3, p1

    if-eqz v2, :cond_7

    invoke-virtual {v0}, La/al;->nN()La/c;

    move-result-object v2

    if-eqz v2, :cond_7

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IY:Ljava/util/ArrayList;

    invoke-virtual {v0}, La/al;->nN()La/c;

    move-result-object v6

    invoke-virtual {v0}, La/al;->getNome()Ljava/lang/String;

    move-result-object v7

    const/4 v8, -0x1

    const/4 v9, -0x1

    const/4 v10, 0x0

    move-object v4, p0

    invoke-direct/range {v4 .. v10}, Lcom/brasfoot/v2028/ActivityFimAno;->a(Ljava/util/ArrayList;La/c;Ljava/lang/String;IIZ)V

    :cond_7
    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_8
    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityFimAno;->addModChamps()V

    invoke-static {p0}, Lcom/brasfoot/v2028/Recopa;->announceBoard(Landroid/app/Activity;)V

    const p1, 0x7f0601a2

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v0, Lcomponents/v;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IX:Ljava/util/ArrayList;

    invoke-direct {v0, v2, p0, p0}, Lcomponents/v;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IS:Lcomponents/v;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IS:Lcomponents/v;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    new-instance v0, Lcomponents/v;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IY:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/v;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IT:Lcomponents/v;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IT:Lcomponents/v;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    const p1, 0x7f0600d7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IU:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IU:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityFimAno$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityFimAno$1;-><init>(Lcom/brasfoot/v2028/ActivityFimAno;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0600d8

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IV:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IV:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityFimAno$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityFimAno$2;-><init>(Lcom/brasfoot/v2028/ActivityFimAno;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0600d9

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IW:Landroid/widget/ImageView;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityFimAno;->IW:Landroid/widget/ImageView;

    new-instance v0, Lcom/brasfoot/v2028/ActivityFimAno$3;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityFimAno$3;-><init>(Lcom/brasfoot/v2028/ActivityFimAno;)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f0602fc

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b01cf

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->db()I

    move-result v1

    add-int/lit16 v1, v1, 0x7e9

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dx()V

    return-void
.end method

.method public onStart()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    const/16 v1, 0xa

    if-lt v0, v1, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, La/b;->o(Z)V

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFimAno;->qr()V

    :cond_1
    return-void
.end method

.method public pv()V
    .locals 2

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityFimAno;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method

.method public qq()V
    .locals 11

    invoke-static {}, Lcom/brasfoot/v2028/Recopa;->freemiumBlocked()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, La/b;->q(Z)V

    invoke-static {}, La/o;->hu()V

    invoke-virtual {v0}, La/b;->fe()Ld/o;

    move-result-object v1

    if-eqz v1, :cond_1

    move-object v2, v1

    if-eqz v2, :cond_1

    invoke-virtual {v2}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_1

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/c;

    invoke-virtual {v4}, La/c;->db()I

    move-result v5

    invoke-virtual {v0}, La/b;->db()I

    move-result v6

    if-ne v5, v6, :cond_1

    invoke-virtual {v4}, La/c;->fu()La/ac;

    move-result-object v5

    if-eqz v5, :cond_1

    invoke-virtual {v4}, La/c;->fu()La/ac;

    move-result-object v6

    invoke-virtual {v6, v2}, La/ac;->p(La/al;)V

    invoke-virtual {v4}, La/c;->fu()La/ac;

    move-result-object v5

    invoke-virtual {v5}, La/ac;->lz()La/af;

    move-result-object v5

    if-eqz v5, :cond_1

    const/4 v6, 0x1

    invoke-virtual {v4}, La/c;->db()I

    move-result v7

    invoke-virtual {v5, v2, v6, v7}, La/af;->b(La/al;II)V

    :cond_1
    invoke-virtual {v0}, La/b;->fg()Ld/n;

    move-result-object v1

    if-eqz v1, :cond_2

    move-object v2, v1

    if-eqz v2, :cond_2

    invoke-virtual {v2}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_2

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/c;

    invoke-virtual {v4}, La/c;->db()I

    move-result v5

    invoke-virtual {v0}, La/b;->db()I

    move-result v6

    if-ne v5, v6, :cond_2

    invoke-virtual {v4}, La/c;->fu()La/ac;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-virtual {v4}, La/c;->fu()La/ac;

    move-result-object v6

    invoke-virtual {v6, v2}, La/ac;->p(La/al;)V

    invoke-virtual {v4}, La/c;->fu()La/ac;

    move-result-object v5

    invoke-virtual {v5}, La/ac;->lz()La/af;

    move-result-object v5

    if-eqz v5, :cond_2

    const/4 v6, 0x1

    invoke-virtual {v4}, La/c;->db()I

    move-result v7

    invoke-virtual {v5, v2, v6, v7}, La/af;->b(La/al;II)V

    :cond_2
    invoke-virtual {v0}, La/b;->d0()Ld/ag;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {v1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/c;

    invoke-virtual {v3}, La/c;->fu()La/ac;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-virtual {v3}, La/c;->fu()La/ac;

    move-result-object v5

    invoke-virtual {v5, v1}, La/ac;->p(La/al;)V

    invoke-virtual {v3}, La/c;->fu()La/ac;

    move-result-object v4

    invoke-virtual {v4}, La/ac;->lz()La/af;

    move-result-object v4

    if-eqz v4, :cond_3

    const/4 v5, 0x1

    invoke-virtual {v3}, La/c;->db()I

    move-result v6

    invoke-virtual {v4, v1, v5, v6}, La/af;->b(La/al;II)V

    :cond_3
    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object v1

    if-nez v1, :cond_4

    invoke-virtual {v0}, La/b;->dV()Ld/t;

    move-result-object v2

    if-nez v2, :cond_4

    invoke-virtual {v1, v2}, La/ac;->p(La/al;)V

    :cond_4
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityFimAno;->finish()V

    return-void
.end method

.method public qr()V
    .locals 2

    new-instance v0, Lcom/brasfoot/v2028/ActivityFimAno$a;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/brasfoot/v2028/ActivityFimAno$a;-><init>(Lcom/brasfoot/v2028/ActivityFimAno;Lcom/brasfoot/v2028/ActivityFimAno$1;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivityFimAno$a;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
