.class Lcom/brasfoot/v2028/ActivityClass$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityClass;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Gt:Lcom/brasfoot/v2028/ActivityClass;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityClass;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityClass$1;->Gt:Lcom/brasfoot/v2028/ActivityClass;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityClass$1;->Gt:Lcom/brasfoot/v2028/ActivityClass;

    const/4 p2, 0x1

    const/4 p3, -0x1

    invoke-static {p1, p2, p3}, Lcom/brasfoot/v2028/ActivityClass;->a(Lcom/brasfoot/v2028/ActivityClass;ZI)V

    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    return-void
.end method
