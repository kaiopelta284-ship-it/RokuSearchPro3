.class public Lcom/brasfoot/v2028/ActivityCalendario;
.super Landroid/app/Activity;


# static fields
.field private static FC:La/t;


# instance fields
.field private EY:La/ac;

.field private FB:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation
.end field

.field FD:Landroid/widget/ListView;

.field FE:Landroid/widget/Spinner;

.field FF:Lcomponents/f;

.field private lS:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/al;",
            ">;"
        }
    .end annotation
.end field

.field private yn:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/t;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCalendario;->yn:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FB:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCalendario;->EY:La/ac;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityCalendario;->lS:Ljava/util/ArrayList;

    return-void
.end method

.method private cI(I)V
    .locals 1

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FB:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FB:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCalendario;->yn:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FF:Lcomponents/f;

    invoke-virtual {p1}, Lcomponents/f;->notifyDataSetChanged()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070003

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityCalendario;->setContentView(I)V

    invoke-static {}, Lcom/brasfoot/v2028/MainActivity;->qW()La/ac;

    move-result-object p1

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->EY:La/ac;

    const p1, 0x7f060299

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityCalendario;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f0b024c

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityCalendario;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->EY:La/ac;

    invoke-virtual {v1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->lS:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_0
    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    const/4 v1, 0x0

    :goto_1
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->ji()La/ac;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityCalendario;->EY:La/ac;

    if-eq v2, v3, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/a;

    invoke-virtual {v2}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/t;

    invoke-virtual {v2}, La/t;->jj()La/ac;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityCalendario;->EY:La/ac;

    if-ne v2, v3, :cond_1

    :cond_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityCalendario;->yn:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/a;

    invoke-virtual {v3}, La/a;->cN()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityCalendario;->yn:Ljava/util/ArrayList;

    sget-object v1, Lcom/brasfoot/v2028/CalSort;->INST:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const v0, 0x7f060177

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityCalendario;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/f;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FB:Ljava/util/ArrayList;

    invoke-direct {v1, v2, p0, p0}, Lcomponents/f;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FF:Lcomponents/f;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityCalendario;->FF:Lcomponents/f;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityCalendario$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityCalendario$1;-><init>(Lcom/brasfoot/v2028/ActivityCalendario;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityCalendario;->cI(I)V

    return-void
.end method
