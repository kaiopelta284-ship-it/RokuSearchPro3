.class public Lcom/brasfoot/v2028/ActivityEscala;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityEscala$a;
    }
.end annotation


# static fields
.field public static Ie:Z

.field public static If:Lcomponents/cf;

.field public static sInst:Lcom/brasfoot/v2028/ActivityEscala;


# instance fields
.field private Gi:I

.field HR:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field HS:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field HT:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/p;",
            ">;"
        }
    .end annotation
.end field

.field HU:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/bb;",
            ">;"
        }
    .end annotation
.end field

.field HV:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field HW:Z

.field HX:Landroid/widget/ListView;

.field private HY:I

.field HZ:Lcomponents/r;

.field Ia:Lcomponents/s;

.field Ib:Lcomponents/s;

.field Ic:Landroid/widget/Spinner;

.field Id:Z

.field private nx:La/t;

.field private po:La/ac;

.field private pp:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HT:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HV:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HW:Z

    const/4 v1, 0x4

    iput v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Id:Z

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityEscala;)I
    .locals 1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Gi:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Gi:I

    return v0
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityEscala;I)I
    .locals 0

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    return p1
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivityEscala;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityEscala;->gL()V

    return-void
.end method

.method private gL()V
    .locals 6

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v0}, La/ac;->mo()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v0

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    goto :goto_1

    :cond_0
    iget v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v0, 0x0

    const/4 v2, 0x0

    :goto_2
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_4

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    if-eqz v3, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->ts()I

    move-result v3

    if-lez v3, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->ts()I

    move-result v3

    const/16 v4, 0x1a

    if-ge v3, v4, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->ts()I

    move-result v4

    invoke-virtual {v3, v4}, La/p;->bd(I)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v3, v4}, La/p;->b(Ljava/lang/Boolean;)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v3}, La/ac;->mo()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    if-nez v3, :cond_2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v3}, La/t;->jv()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v3}, La/t;->jz()Ljava/util/ArrayList;

    move-result-object v3

    :goto_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_2
    iget v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    if-ne v3, v1, :cond_3

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v3}, La/t;->jw()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v3}, La/t;->jA()Ljava/util/ArrayList;

    move-result-object v3

    goto :goto_3

    :cond_3
    :goto_4
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_2

    :cond_4
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v2}, La/ac;->mp()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_5
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_7

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    if-eqz v4, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->ts()I

    move-result v4

    const/4 v5, -0x1

    if-ne v4, v5, :cond_6

    add-int/lit8 v3, v3, 0x1

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    add-int/lit8 v5, v3, 0x19

    invoke-virtual {v4, v5}, La/p;->bd(I)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcomponents/bb;

    invoke-virtual {v4}, Lcomponents/bb;->tt()La/p;

    move-result-object v4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v4, v5}, La/p;->b(Ljava/lang/Boolean;)V

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v4}, La/ac;->mp()Ljava/util/ArrayList;

    move-result-object v4

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcomponents/bb;

    invoke-virtual {v5}, Lcomponents/bb;->tt()La/p;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    if-nez v4, :cond_5

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v4}, La/t;->jx()Ljava/util/ArrayList;

    move-result-object v4

    :goto_6
    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcomponents/bb;

    invoke-virtual {v5}, Lcomponents/bb;->tt()La/p;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_5
    iget v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    if-ne v4, v1, :cond_6

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v4}, La/t;->jy()Ljava/util/ArrayList;

    move-result-object v4

    goto :goto_6

    :cond_6
    :goto_7
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_5

    :cond_7
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v2, v1}, La/ac;->S(Z)V

    sget-object v2, Lcom/brasfoot/v2028/ActivityMainTeam;->Kq:Lcom/brasfoot/v2028/ActivityMainTeam;

    if-eqz v2, :cond_8

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qX()Lcom/brasfoot/v2028/ActivityMainTeam;

    move-result-object v2

    invoke-virtual {v2}, Lcom/brasfoot/v2028/ActivityMainTeam;->finish()V

    :cond_8
    const/4 v2, 0x0

    sput-object v2, Lcom/brasfoot/v2028/ActivityMainTeam;->Kq:Lcom/brasfoot/v2028/ActivityMainTeam;

    sput-boolean v1, Lcom/brasfoot/v2028/ActivityMainTeam;->Km:Z

    sput-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kn:Z

    invoke-static {}, La/o;->hv()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->finish()V

    return-void
.end method


# virtual methods
.method public C(Z)V
    .locals 5

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HW:Z

    const/4 v1, 0x0

    if-nez v0, :cond_1

    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HW:Z

    invoke-virtual {v2, v3, v4}, La/p;->a(La/t;Z)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    :goto_1
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HT:Ljava/util/ArrayList;

    goto :goto_1

    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_3
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_3

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v2}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/p;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    iget-boolean v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HW:Z

    invoke-virtual {v2, v3, v4}, La/p;->a(La/t;Z)Z

    move-result v2

    if-eqz v2, :cond_2

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v3}, La/ac;->lB()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_3
    if-eqz p1, :cond_4

    :goto_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {p1}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v1, p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v0}, La/ac;->lW()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/q;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-static {v0, v2}, La/u;->a(La/q;La/ac;)La/p;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    :cond_4
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RH:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HT:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method public af(II)V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bb;

    invoke-virtual {v0}, Lcomponents/bb;->tt()La/p;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/p;

    if-eqz p2, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bb;

    invoke-virtual {p1, p2}, Lcomponents/bb;->u(La/p;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_0
    if-eqz v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    sget-object p2, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {p1, p2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Lcomponents/s;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1, p2}, Lcomponents/r;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->notifyDataSetChanged()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qb()V

    return-void
.end method

.method public ag(II)V
    .locals 3

    if-ltz p1, :cond_0

    if-ltz p2, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcomponents/bb;

    invoke-virtual {v0}, Lcomponents/bb;->tt()La/p;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->tt()La/p;

    move-result-object v1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bb;

    invoke-virtual {p1, v1}, Lcomponents/bb;->u(La/p;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcomponents/bb;

    invoke-virtual {p1, v0}, Lcomponents/bb;->u(La/p;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->notifyDataSetChanged()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HX:Landroid/widget/ListView;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->setSelection(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1, p2}, Lcomponents/r;->dm(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qb()V

    :cond_0
    return-void
.end method

.method public b(Lcomponents/cf;)V
    .locals 7

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const v0, 0x7f0602f1

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const v2, 0x7f0b01df

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEscala;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, La/ak;->AY:[Ljava/lang/String;

    iget v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    aget-object v3, v3, v4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, Lcomponents/cf;->vq()I

    move-result v1

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEscala;->cM(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {p1}, Lcomponents/cf;->vq()I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v1, v4, v3}, La/ac;->T(II)V

    iput v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->Gi:I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    invoke-virtual {p1}, Lcomponents/cf;->vq()I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/Spinner;->setSelection(I)V

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p1}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_2

    invoke-virtual {p1}, Lcomponents/cf;->vs()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {p1}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/p;

    const/16 v6, 0x19

    if-le v3, v6, :cond_0

    const/4 v3, -0x1

    :cond_0
    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    new-instance v6, Lcomponents/bb;

    invoke-direct {v6}, Lcomponents/bb;-><init>()V

    invoke-virtual {v6, v5}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v6, v3}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v6, v4}, Lcomponents/bb;->aj(Z)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    new-instance v5, Lcomponents/bb;

    invoke-direct {v5}, Lcomponents/bb;-><init>()V

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v5, v3}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v5, v4}, Lcomponents/bb;->aj(Z)V

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEscala;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " ("

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, La/ak;->AY:[Ljava/lang/String;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    aget-object v1, v1, v2

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    sget-object v0, Lcomponents/ce;->LM:Ljava/util/Comparator;

    invoke-static {p1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    sput-boolean v4, Lcom/brasfoot/v2028/ActivityEscala;->Ie:Z

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qb()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qd()V

    return-void
.end method

.method public cM(I)V
    .locals 0

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    return-void
.end method

.method public onBackPressed()V
    .locals 1

    iget-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Id:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->finish()V

    return-void
.end method

.method public onClickAgendaEsc(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityAgenda;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickChange(Landroid/view/View;)V
    .locals 2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->th()I

    move-result p1

    const/4 v0, -0x1

    if-eq p1, v0, :cond_1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->th()I

    move-result p1

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {p1}, Lcomponents/s;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_2

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {p1}, Lcomponents/r;->th()I

    move-result p1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {v0}, Lcomponents/s;->th()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lcom/brasfoot/v2028/ActivityEscala;->af(II)V

    return-void

    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f0b0232

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_2
    return-void
.end method

.method public onClickField(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivityField;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickJogar(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qg()V

    return-void
.end method

.method public onClickSavedTatics(Landroid/view/View;)V
    .locals 1

    const/4 p1, 0x0

    sput-boolean p1, Lcom/brasfoot/v2028/ActivityEscala;->Ie:Z

    const/4 p1, 0x0

    sput-object p1, Lcom/brasfoot/v2028/ActivityEscala;->If:Lcomponents/cf;

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivitySavedTatics;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickTatica(Landroid/view/View;)V
    .locals 1

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/DialogTatics;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07000d

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->setContentView(I)V

    sput-object p0, Lcom/brasfoot/v2028/ActivityEscala;->sInst:Lcom/brasfoot/v2028/ActivityEscala;

    sget-object p1, Lc/a;->TF:La/b;

    if-nez p1, :cond_0

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getBaseContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/high16 v0, 0x4000000

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->finish()V

    :cond_0
    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Id:Z

    sget-boolean v0, Lcom/brasfoot/v2028/ActivityMainTeam;->Kf:Z

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HW:Z

    const v0, 0x7f060237

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    const/4 v0, 0x0

    :goto_0
    sget-object v1, La/ak;->AY:[Ljava/lang/String;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HV:Ljava/util/ArrayList;

    sget-object v2, La/ak;->AY:[Ljava/lang/String;

    aget-object v2, v2, v0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    new-instance v1, Lcomponents/am;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HV:Ljava/util/ArrayList;

    const/4 v4, 0x1

    invoke-direct {v1, p0, v2, v3, v4}, Lcomponents/am;-><init>(Landroid/content/Context;ILjava/util/ArrayList;I)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    iget v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEscala$1;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEscala$1;-><init>(Lcom/brasfoot/v2028/ActivityEscala;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qW()La/ac;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-static {}, Lcom/brasfoot/v2028/ActivityMainTeam;->qV()La/t;

    move-result-object v0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->ji()La/ac;

    move-result-object v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    if-ne v0, v1, :cond_2

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    goto :goto_1

    :cond_2
    iput v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->pp:I

    :goto_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->nx:La/t;

    invoke-virtual {v0}, La/t;->jH()La/al;

    move-result-object v0

    invoke-virtual {v0}, La/al;->cG()I

    move-result v0

    if-nez v0, :cond_3

    const/4 p1, 0x1

    :cond_3
    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->C(Z)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {p1}, La/ac;->mn()Lcomponents/cf;

    move-result-object p1

    if-eqz p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {p1}, La/ac;->mn()Lcomponents/cf;

    move-result-object p1

    invoke-virtual {p1}, Lcomponents/cf;->vq()I

    move-result p1

    if-ltz p1, :cond_4

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {p1}, La/ac;->mn()Lcomponents/cf;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->b(Lcomponents/cf;)V

    goto :goto_2

    :cond_4
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qa()V

    :goto_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qc()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qe()V

    const p1, 0x7f0600d0

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HT:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_5

    new-instance v0, Lcomponents/s;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HT:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0, v4}, Lcomponents/s;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;Z)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ib:Lcomponents/s;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ib:Lcomponents/s;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    return-void

    :cond_5
    const v0, 0x7f060325

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {p1, v1}, Landroid/widget/ListView;->setVisibility(I)V

    return-void
.end method

.method protected onResume()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcomponents/r;->notifyDataSetChanged()V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcomponents/s;->notifyDataSetChanged()V

    :cond_1
    return-void
.end method

.method public onStart()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    sget-object v0, Lc/a;->TF:La/b;

    if-nez v0, :cond_0

    :try_start_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->finish()V

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isBot()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    const/4 v1, 0x1

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    goto :goto_1

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    const/4 v1, 0x0

    goto :goto_0

    :goto_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qg()V

    :cond_2
    sget-boolean v0, Lcom/brasfoot/v2028/ActivityEscala;->Ie:Z

    if-eqz v0, :cond_3

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->If:Lcomponents/cf;

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->pZ()V

    :cond_3
    return-void
.end method

.method public pZ()V
    .locals 1

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->If:Lcomponents/cf;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/brasfoot/v2028/ActivityEscala;->If:Lcomponents/cf;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->b(Lcomponents/cf;)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {v0}, Lcomponents/r;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {v0}, Lcomponents/s;->notifyDataSetChanged()V

    return-void
.end method

.method public pv()V
    .locals 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Id:Z

    const v0, 0x7f0601fd

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    return-void
.end method

.method public qa()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const v1, 0x7f0602f1

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const v3, 0x7f0b01df

    invoke-virtual {p0, v3}, Lcom/brasfoot/v2028/ActivityEscala;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, La/ak;->AY:[Ljava/lang/String;

    iget v4, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    iget v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    const/4 v3, 0x0

    invoke-virtual {v1, v3, v2}, La/ac;->T(II)V

    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0xb

    const/4 v4, 0x0

    if-ge v1, v2, :cond_1

    sget-object v2, La/ak;->AX:[[I

    iget v5, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    aget-object v2, v2, v5

    aget v2, v2, v1

    invoke-static {v0, v2, v3, v3}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v5

    if-eqz v5, :cond_0

    new-instance v4, Lcomponents/bb;

    invoke-direct {v4}, Lcomponents/bb;-><init>()V

    invoke-virtual {v4, v5}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v4, v2}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v4, v3}, Lcomponents/bb;->aj(Z)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    new-instance v5, Lcomponents/bb;

    invoke-direct {v5}, Lcomponents/bb;-><init>()V

    invoke-virtual {v5, v4}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v5, v2}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v5, v3}, Lcomponents/bb;->aj(Z)V

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_2
    sget-object v2, La/ak;->AW:[I

    array-length v2, v2

    if-ge v1, v2, :cond_3

    sget-object v2, La/ak;->AW:[I

    aget v2, v2, v1

    const/4 v5, 0x1

    invoke-static {v0, v2, v5, v3}, La/ac;->a(Ljava/util/ArrayList;IZZ)La/p;

    move-result-object v2

    const/4 v6, -0x1

    if-eqz v2, :cond_2

    new-instance v7, Lcomponents/bb;

    invoke-direct {v7}, Lcomponents/bb;-><init>()V

    invoke-virtual {v7, v2}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v7, v6}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v7, v5}, Lcomponents/bb;->aj(Z)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_2
    new-instance v2, Lcomponents/bb;

    invoke-direct {v2}, Lcomponents/bb;-><init>()V

    invoke-virtual {v2, v4}, Lcomponents/bb;->u(La/p;)V

    invoke-virtual {v2, v6}, Lcomponents/bb;->dt(I)V

    invoke-virtual {v2, v5}, Lcomponents/bb;->aj(Z)V

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->LM:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qb()V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qd()V

    return-void
.end method

.method public qb()V
    .locals 4

    new-instance v0, Lcomponents/cf;

    invoke-direct {v0}, Lcomponents/cf;-><init>()V

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    invoke-virtual {v0}, Lcomponents/cf;->vr()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcomponents/cf;->vs()Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->ts()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    invoke-virtual {v0, v1}, Lcomponents/cf;->dW(I)V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->po:La/ac;

    invoke-virtual {v1, v0}, La/ac;->a(Lcomponents/cf;)V

    return-void
.end method

.method public qc()V
    .locals 2

    const v0, 0x7f06006c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HX:Landroid/widget/ListView;

    new-instance v0, Lcomponents/r;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-direct {v0, v1, p0, p0}, Lcomponents/r;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HX:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HX:Landroid/widget/ListView;

    new-instance v1, Lcom/brasfoot/v2028/ActivityEscala$2;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEscala$2;-><init>(Lcom/brasfoot/v2028/ActivityEscala;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public qd()V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HR:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcomponents/bb;

    invoke-virtual {v1}, Lcomponents/bb;->tt()La/p;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcomponents/bb;

    invoke-virtual {v2}, Lcomponents/bb;->tt()La/p;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    sget-object v1, Lcomponents/ce;->RD:Ljava/util/Comparator;

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method public qe()V
    .locals 4

    const v0, 0x7f0600cf

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityEscala;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    new-instance v1, Lcomponents/s;

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivityEscala;->HS:Ljava/util/ArrayList;

    const/4 v3, 0x0

    invoke-direct {v1, v2, p0, p0, v3}, Lcomponents/s;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;Z)V

    iput-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Lcom/brasfoot/v2028/ActivityEscala$3;

    invoke-direct {v1, p0}, Lcom/brasfoot/v2028/ActivityEscala$3;-><init>(Lcom/brasfoot/v2028/ActivityEscala;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public qf()I
    .locals 1

    iget v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    return v0
.end method

.method public qg()V
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->tt()La/p;

    move-result-object v3

    if-eqz v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->ts()I

    move-result v3

    if-lez v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityEscala;->HU:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcomponents/bb;

    invoke-virtual {v3}, Lcomponents/bb;->ts()I

    move-result v3

    const/16 v4, 0x1a

    if-ge v3, v4, :cond_0

    add-int/lit8 v2, v2, 0x1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/16 v1, 0xb

    if-ge v2, v1, :cond_5

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f0b0233

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityEscala;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->isBot()Z

    move-result v1

    if-eqz v1, :cond_6

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    iput v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    iget v1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    if-eqz v1, :cond_2

    :goto_1
    iput v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    goto :goto_2

    :cond_2
    const/4 v0, 0x3

    goto :goto_1

    :goto_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qa()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    const/4 v1, -0x1

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {v0}, Lcomponents/r;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    invoke-virtual {v0, v1}, Lcomponents/r;->dm(I)V

    :cond_3
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {v0}, Lcomponents/s;->notifyDataSetChanged()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    invoke-virtual {v0, v1}, Lcomponents/s;->dm(I)V

    :cond_4
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qg()V

    return-void

    :cond_5
    new-instance v1, Lcom/brasfoot/v2028/ActivityEscala$a;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lcom/brasfoot/v2028/ActivityEscala$a;-><init>(Lcom/brasfoot/v2028/ActivityEscala;Lcom/brasfoot/v2028/ActivityEscala$1;)V

    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/brasfoot/v2028/ActivityEscala$a;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :cond_6
    return-void
.end method

.method public setFormIdx(I)V
    .locals 2

    iput p1, p0, Lcom/brasfoot/v2028/ActivityEscala;->HY:I

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityEscala;->qa()V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ic:Landroid/widget/Spinner;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/widget/Spinner;->setSelection(I)V

    :cond_0
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->HZ:Lcomponents/r;

    const/4 v1, -0x1

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcomponents/r;->notifyDataSetChanged()V

    invoke-virtual {v0, v1}, Lcomponents/r;->dm(I)V

    :cond_1
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityEscala;->Ia:Lcomponents/s;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lcomponents/s;->notifyDataSetChanged()V

    invoke-virtual {v0, v1}, Lcomponents/s;->dm(I)V

    :cond_2
    return-void
.end method
