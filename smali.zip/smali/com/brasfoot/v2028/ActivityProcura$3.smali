.class Lcom/brasfoot/v2028/ActivityProcura$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityProcura;->e(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic JK:I

.field final synthetic Lk:Lcom/brasfoot/v2028/ActivityProcura;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityProcura;ILandroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura$3;->Lk:Lcom/brasfoot/v2028/ActivityProcura;

    iput p2, p0, Lcom/brasfoot/v2028/ActivityProcura$3;->JK:I

    iput-object p3, p0, Lcom/brasfoot/v2028/ActivityProcura$3;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura$3;->Lk:Lcom/brasfoot/v2028/ActivityProcura;

    iget v0, p0, Lcom/brasfoot/v2028/ActivityProcura$3;->JK:I

    invoke-virtual {p1, v0}, Lcom/brasfoot/v2028/ActivityProcura;->dd(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityProcura$3;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
