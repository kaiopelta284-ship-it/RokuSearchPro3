.class final Lcom/brasfoot/v2028/ActivityResults$9;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/brasfoot/v2028/ActivityResults;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcomponents/bh;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcomponents/bh;Lcomponents/bh;)I
    .locals 3

    invoke-virtual {p1}, Lcomponents/bh;->tt()La/p;

    move-result-object v0

    invoke-virtual {v0}, La/p;->io()I

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    sget-object v0, La/ak;->AS:[[I

    invoke-virtual {p1}, Lcomponents/bh;->tt()La/p;

    move-result-object p1

    invoke-virtual {p1}, La/p;->io()I

    move-result p1

    aget-object p1, v0, p1

    aget p1, p1, v2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p2}, Lcomponents/bh;->tt()La/p;

    move-result-object v0

    invoke-virtual {v0}, La/p;->io()I

    move-result v0

    if-eq v0, v1, :cond_1

    sget-object v0, La/ak;->AS:[[I

    invoke-virtual {p2}, Lcomponents/bh;->tt()La/p;

    move-result-object p2

    invoke-virtual {p2}, La/p;->io()I

    move-result p2

    aget-object p2, v0, p2

    aget p2, p2, v2

    goto :goto_1

    :cond_1
    const/4 p2, 0x0

    :goto_1
    if-eq p1, p2, :cond_2

    sub-int/2addr p1, p2

    return p1

    :cond_2
    return v2
.end method

.method public synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcomponents/bh;

    check-cast p2, Lcomponents/bh;

    invoke-virtual {p0, p1, p2}, Lcom/brasfoot/v2028/ActivityResults$9;->a(Lcomponents/bh;Lcomponents/bh;)I

    move-result p1

    return p1
.end method
