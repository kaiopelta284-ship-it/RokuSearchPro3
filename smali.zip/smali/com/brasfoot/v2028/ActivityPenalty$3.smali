.class Lcom/brasfoot/v2028/ActivityPenalty$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityPenalty;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Lb:Lcom/brasfoot/v2028/ActivityPenalty;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityPenalty;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$3;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$3;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    invoke-virtual {p1}, Lcomponents/ac;->th()I

    move-result p1

    if-ne p3, p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$3;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Lcomponents/ac;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$3;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityPenalty;->KI:Landroid/widget/ListView;

    invoke-virtual {p1, p2}, Landroid/widget/ListView;->setSelection(I)V

    return-void

    :cond_0
    if-ltz p1, :cond_1

    iget-object p2, p0, Lcom/brasfoot/v2028/ActivityPenalty$3;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    invoke-virtual {p2, p1, p3}, Lcom/brasfoot/v2028/ActivityPenalty;->ag(II)V

    return-void

    :cond_1
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityPenalty$3;->Lb:Lcom/brasfoot/v2028/ActivityPenalty;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityPenalty;->KG:Lcomponents/ac;

    invoke-virtual {p1, p3}, Lcomponents/ac;->dm(I)V

    return-void
.end method
