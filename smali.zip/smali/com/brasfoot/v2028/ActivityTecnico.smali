.class public Lcom/brasfoot/v2028/ActivityTecnico;
.super Landroid/app/Activity;


# instance fields
.field private MA:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/d;",
            ">;"
        }
    .end annotation
.end field

.field private MB:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcomponents/cj;",
            ">;"
        }
    .end annotation
.end field

.field Mt:Landroid/widget/ListView;

.field Mu:Landroid/widget/ListView;

.field Mv:Landroid/widget/Button;

.field Mw:Landroid/widget/Button;

.field My:Lcomponents/an;

.field Mz:Lcomponents/aq;

.field pU:La/af;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MA:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    return-void
.end method

.method private a(ILa/ac;Ljava/lang/String;Z)V
    .locals 1

    new-instance v0, Lcomponents/cj;

    invoke-direct {v0}, Lcomponents/cj;-><init>()V

    invoke-virtual {v0, p1}, Lcomponents/cj;->ad(I)V

    invoke-virtual {v0, p2}, Lcomponents/cj;->i(La/ac;)V

    invoke-virtual {v0, p3}, Lcomponents/cj;->Q(Ljava/lang/String;)V

    invoke-virtual {v0, p4}, Lcomponents/cj;->ap(Z)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivityTecnico;I)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->cK(I)V

    return-void
.end method

.method private cK(I)V
    .locals 10

    const v0, 0x7f0601a7

    const v1, 0x7f06019a

    const v2, 0x7f060147

    const v3, 0x7f030010

    const v4, 0x7f030007

    const v5, 0x7f030038

    const v6, 0x7f030013

    const/16 v7, 0x8

    const/4 v8, 0x0

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v8}, Landroid/widget/ListView;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v6}, Landroid/content/res/Resources;->getColor(I)I

    move-result v6

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mv:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/Button;->setTextColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mw:Landroid/widget/Button;

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setTextColor(I)V

    invoke-virtual {p0, v2}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    invoke-virtual {p1, v7}, Landroid/widget/ListView;->setVisibility(I)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v8}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private m(III)V
    .locals 10

    const/4 p3, 0x6

    new-array p3, p3, [Ljava/lang/String;

    const v0, 0x7f0b0073

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    aput-object v0, p3, v1

    const v0, 0x7f0b0074

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    aput-object v0, p3, v2

    const v0, 0x7f0b0076

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    aput-object v0, p3, v3

    const v0, 0x7f0b0078

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    aput-object v0, p3, v4

    const v0, 0x7f0b007a

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    aput-object v0, p3, v5

    const v0, 0x7f0b007c

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    aput-object v0, p3, v5

    const/4 v0, 0x0

    const/4 v5, -0x1

    if-eq p1, v2, :cond_8

    if-ne p1, v4, :cond_0

    goto/16 :goto_4

    :cond_0
    if-ne p2, v5, :cond_5

    invoke-static {}, La/z;->lj()I

    move-result p2

    new-array p2, p2, [I

    const/4 p2, 0x0

    const/4 p3, 0x1

    :goto_0
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge p2, v4, :cond_e

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->fL()I

    move-result v4

    if-ltz v4, :cond_4

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->cG()I

    move-result v4

    if-ne v4, p1, :cond_4

    if-eqz p3, :cond_3

    iget-object p3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {p3}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/ai;

    invoke-virtual {p3}, La/ai;->jb()La/al;

    move-result-object p3

    invoke-virtual {p3}, La/al;->getNome()Ljava/lang/String;

    move-result-object p3

    if-ne p1, v3, :cond_1

    const p3, 0x7f0b010e

    :goto_1
    invoke-virtual {p0, p3}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object p3

    goto :goto_2

    :cond_1
    const/16 v4, 0x8

    if-ne p1, v4, :cond_2

    const p3, 0x7f0b006e

    goto :goto_1

    :cond_2
    :goto_2
    invoke-direct {p0, v5, v0, p3, v2}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    const/4 p3, 0x0

    :cond_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->db()I

    move-result v4

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->fL()I

    move-result v6

    invoke-static {v6}, La/b;->aq(I)La/ac;

    move-result-object v6

    const-string v7, ""

    invoke-direct {p0, v4, v6, v7, v1}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    :cond_4
    add-int/lit8 p2, p2, 0x1

    goto/16 :goto_0

    :cond_5
    invoke-static {}, La/z;->lj()I

    move-result p3

    new-array p3, p3, [I

    const/4 p3, 0x0

    const/4 v3, 0x1

    :goto_3
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge p3, v4, :cond_e

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->fL()I

    move-result v4

    if-ltz v4, :cond_7

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->cG()I

    move-result v4

    if-ne v4, p1, :cond_7

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->gT()I

    move-result v4

    if-ne v4, p2, :cond_7

    if-eqz v3, :cond_6

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v3}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ai;

    invoke-virtual {v3}, La/ai;->jb()La/al;

    move-result-object v3

    invoke-virtual {v3}, La/al;->getNome()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v5, v0, v3, v2}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    const/4 v3, 0x0

    :cond_6
    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/ai;

    invoke-virtual {v4}, La/ai;->db()I

    move-result v4

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->fL()I

    move-result v6

    invoke-static {v6}, La/b;->aq(I)La/ac;

    move-result-object v6

    const-string v7, ""

    invoke-direct {p0, v4, v6, v7, v1}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    :cond_7
    add-int/lit8 p3, p3, 0x1

    goto/16 :goto_3

    :cond_8
    :goto_4
    invoke-static {}, La/z;->lj()I

    move-result v3

    new-array v3, v3, [I

    const/4 v3, 0x0

    const/4 v6, 0x1

    :goto_5
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v3, v7, :cond_e

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->fL()I

    move-result v7

    if-ltz v7, :cond_d

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->cG()I

    move-result v7

    if-ne v7, p1, :cond_d

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->gT()I

    move-result v7

    if-ne v7, p2, :cond_d

    if-eqz v6, :cond_c

    const-string v6, ""

    if-ne p1, v2, :cond_9

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const v7, 0x7f0b010f

    invoke-virtual {p0, v7}, Lcom/brasfoot/v2028/ActivityTecnico;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->jb()La/al;

    move-result-object v7

    invoke-virtual {v7}, La/al;->nS()I

    move-result v7

    aget-object v7, p3, v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto :goto_6

    :cond_9
    if-ne p1, v4, :cond_b

    const-string v6, ""

    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->fL()I

    move-result v7

    invoke-static {v7}, La/b;->aq(I)La/ac;

    move-result-object v7

    if-eqz v7, :cond_a

    sget-object v6, La/ak;->Ar:[Ljava/lang/String;

    invoke-virtual {v7}, La/ac;->getEstado()I

    move-result v7

    aget-object v6, v6, v7

    :cond_a
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " "

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->jb()La/al;

    move-result-object v6

    invoke-virtual {v6}, La/al;->nS()I

    move-result v6

    aget-object v6, p3, v6

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    :cond_b
    :goto_6
    invoke-direct {p0, v5, v0, v6, v2}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    const/4 v6, 0x0

    :cond_c
    iget-object v7, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v7}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/ai;

    invoke-virtual {v7}, La/ai;->db()I

    move-result v7

    iget-object v8, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v8}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/ai;

    invoke-virtual {v8}, La/ai;->fL()I

    move-result v8

    invoke-static {v8}, La/b;->aq(I)La/ac;

    move-result-object v8

    const-string v9, ""

    invoke-direct {p0, v7, v8, v9, v1}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    :cond_d
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_5

    :cond_e
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mz:Lcomponents/aq;

    invoke-virtual {p1}, Lcomponents/aq;->notifyDataSetChanged()V

    return-void
.end method

.method private sk()V
    .locals 8

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/16 v0, 0x20

    new-array v0, v0, [I

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v1}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_8

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v3}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x1

    if-ge v2, v3, :cond_1

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v3}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ai;

    invoke-virtual {v3}, La/ai;->cG()I

    move-result v3

    if-lez v3, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v3}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ai;

    invoke-virtual {v3}, La/ai;->cG()I

    move-result v3

    array-length v5, v0

    if-ge v3, v5, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v3}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/ai;

    invoke-virtual {v3}, La/ai;->cG()I

    move-result v3

    aget v5, v0, v3

    add-int/2addr v5, v4

    aput v5, v0, v3

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    :goto_1
    array-length v3, v0

    if-ge v2, v3, :cond_8

    aget v3, v0, v2

    if-lez v3, :cond_7

    const/16 v3, 0xe

    if-ge v2, v3, :cond_6

    const/4 v3, 0x5

    if-eq v2, v3, :cond_6

    const/4 v3, 0x2

    if-ne v2, v3, :cond_2

    goto :goto_4

    :cond_2
    const/16 v3, 0x14

    new-array v3, v3, [I

    const/4 v5, 0x0

    :goto_2
    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_4

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->cG()I

    move-result v6

    if-ne v6, v2, :cond_3

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->gT()I

    move-result v6

    if-ltz v6, :cond_3

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->gT()I

    move-result v6

    array-length v7, v3

    if-ge v6, v7, :cond_3

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v6}, La/af;->mA()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/ai;

    invoke-virtual {v6}, La/ai;->gT()I

    move-result v6

    aget v7, v3, v6

    add-int/2addr v7, v4

    aput v7, v3, v6

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_4
    const/4 v5, 0x0

    :goto_3
    array-length v6, v3

    if-ge v5, v6, :cond_7

    aget v6, v3, v5

    if-lez v6, :cond_5

    aget v6, v3, v5

    invoke-direct {p0, v2, v5, v6}, Lcom/brasfoot/v2028/ActivityTecnico;->m(III)V

    :cond_5
    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_6
    :goto_4
    const/4 v3, -0x1

    aget v5, v0, v2

    invoke-direct {p0, v2, v3, v5}, Lcom/brasfoot/v2028/ActivityTecnico;->m(III)V

    :cond_7
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_1

    :cond_8
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->isJogaSelecoesAll()Z

    move-result v0

    if-eqz v0, :cond_9

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fe()Ld/o;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->t(La/al;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ff()Ld/c;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->t(La/al;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fg()Ld/n;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->t(La/al;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fh()Ld/b;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->t(La/al;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fi()Ld/d;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->t(La/al;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->fj()Ld/f;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->t(La/al;)V

    :cond_9
    return-void
.end method

.method private t(La/al;)V
    .locals 8

    if-eqz p1, :cond_4

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    :goto_0
    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v2, v5, :cond_4

    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/c;

    invoke-virtual {v5}, La/c;->fz()La/af;

    move-result-object v5

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    if-ne v5, v6, :cond_3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    if-eqz v5, :cond_1

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_1

    const/4 v5, 0x0

    :goto_1
    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_1

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcomponents/cj;

    invoke-virtual {v6}, Lcomponents/cj;->db()I

    move-result v6

    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/c;

    invoke-virtual {v7}, La/c;->db()I

    move-result v7

    if-ne v6, v7, :cond_0

    iget-object v6, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcomponents/cj;

    invoke-virtual {v6}, Lcomponents/cj;->hE()La/ac;

    move-result-object v6

    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La/c;

    invoke-virtual {v7}, La/c;->fu()La/ac;

    move-result-object v7

    if-ne v6, v7, :cond_0

    const/4 v4, 0x1

    goto :goto_2

    :cond_0
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_1
    :goto_2
    if-nez v4, :cond_3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, La/al;->getNome()Ljava/lang/String;

    move-result-object v6

    invoke-direct {p0, v3, v5, v6, v1}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    const/4 v3, 0x0

    :cond_2
    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/c;

    invoke-virtual {v5}, La/c;->db()I

    move-result v5

    invoke-virtual {p1}, La/al;->nM()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/c;

    invoke-virtual {v6}, La/c;->fu()La/ac;

    move-result-object v6

    const-string v7, ""

    invoke-direct {p0, v5, v6, v7, v0}, Lcom/brasfoot/v2028/ActivityTecnico;->a(ILa/ac;Ljava/lang/String;Z)V

    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_4
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070027

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->setContentView(I)V

    sget-object p1, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    const p1, 0x7f0602e1

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v0}, La/af;->gN()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f06019a

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mt:Landroid/widget/ListView;

    new-instance p1, Lcomponents/an;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MA:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/an;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->My:Lcomponents/an;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mt:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->My:Lcomponents/an;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    const p1, 0x7f0601a7

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mu:Landroid/widget/ListView;

    new-instance p1, Lcomponents/aq;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MB:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/aq;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mz:Lcomponents/aq;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mu:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mz:Lcomponents/aq;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->sl()V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivityTecnico;->sk()V

    const p1, 0x7f060045

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mv:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mv:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityTecnico$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTecnico$1;-><init>(Lcom/brasfoot/v2028/ActivityTecnico;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const p1, 0x7f060060

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTecnico;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mw:Landroid/widget/Button;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->Mw:Landroid/widget/Button;

    new-instance v0, Lcom/brasfoot/v2028/ActivityTecnico$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTecnico$2;-><init>(Lcom/brasfoot/v2028/ActivityTecnico;)V

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public sl()V
    .locals 6

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MA:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v1}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    :goto_0
    if-ltz v1, :cond_0

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MA:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v1}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v2

    :goto_1
    if-ltz v1, :cond_1

    const/4 v3, 0x0

    aget v4, v0, v3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v5}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/d;

    invoke-virtual {v5}, La/d;->fC()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    aget v3, v0, v2

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v4}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/d;

    invoke-virtual {v4}, La/d;->fE()I

    move-result v4

    add-int/2addr v3, v4

    aput v3, v0, v2

    const/4 v3, 0x2

    aget v4, v0, v3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v5}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/d;

    invoke-virtual {v5}, La/d;->fG()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    const/4 v3, 0x3

    aget v4, v0, v3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v5}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/d;

    invoke-virtual {v5}, La/d;->fI()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    const/4 v3, 0x4

    aget v4, v0, v3

    iget-object v5, p0, Lcom/brasfoot/v2028/ActivityTecnico;->pU:La/af;

    invoke-virtual {v5}, La/af;->nd()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/d;

    invoke-virtual {v5}, La/d;->fJ()I

    move-result v5

    add-int/2addr v4, v5

    aput v4, v0, v3

    add-int/lit8 v1, v1, -0x1

    goto :goto_1

    :cond_1
    new-instance v1, La/d;

    invoke-direct {v1, v0}, La/d;-><init>([I)V

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->MA:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityTecnico;->My:Lcomponents/an;

    invoke-virtual {v0}, Lcomponents/an;->notifyDataSetChanged()V

    :cond_2
    return-void

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method
