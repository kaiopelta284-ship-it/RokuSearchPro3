.class Lcom/brasfoot/v2028/DialogIgrokInfo$4;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/DialogIgrokInfo;->sD()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/DialogIgrokInfo;Landroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$4;->Nq:Lcom/brasfoot/v2028/DialogIgrokInfo;

    iput-object p2, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$4;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/DialogIgrokInfo$4;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->cancel()V

    return-void
.end method
