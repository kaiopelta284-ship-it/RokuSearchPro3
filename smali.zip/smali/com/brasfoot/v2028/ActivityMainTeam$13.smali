.class Lcom/brasfoot/v2028/ActivityMainTeam$13;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/PopupMenu$OnMenuItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityMainTeam;->rh()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic KF:Lcom/brasfoot/v2028/ActivityMainTeam;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityMainTeam;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityMainTeam$13;->KF:Lcom/brasfoot/v2028/ActivityMainTeam;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMenuItemClick(Landroid/view/MenuItem;)Z
    .locals 1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivityMainTeam$13;->KF:Lcom/brasfoot/v2028/ActivityMainTeam;

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    invoke-static {v0, p1}, Lcom/brasfoot/v2028/ActivityMainTeam;->b(Lcom/brasfoot/v2028/ActivityMainTeam;I)V

    const/4 p1, 0x1

    return p1
.end method
