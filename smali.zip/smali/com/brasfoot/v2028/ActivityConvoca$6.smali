.class Lcom/brasfoot/v2028/ActivityConvoca$6;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityConvoca;->pI()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Fm:Landroid/app/Dialog;

.field final synthetic GX:Lcom/brasfoot/v2028/ActivityConvoca;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityConvoca;Landroid/app/Dialog;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$6;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    iput-object p2, p0, Lcom/brasfoot/v2028/ActivityConvoca$6;->Fm:Landroid/app/Dialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$6;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityConvoca;->pJ()V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$6;->Fm:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
