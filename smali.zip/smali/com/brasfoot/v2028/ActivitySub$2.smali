.class Lcom/brasfoot/v2028/ActivitySub$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/android/billingclient/api/SkuDetailsResponseListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivitySub;->sh()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Mq:Lcom/brasfoot/v2028/ActivitySub;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivitySub;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivitySub$2;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public b(ILjava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/SkuDetails;",
            ">;)V"
        }
    .end annotation

    if-eqz p2, :cond_0

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySub$2;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    iput-object p2, p1, Lcom/brasfoot/v2028/ActivitySub;->Ml:Ljava/util/List;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivitySub$2;->Mq:Lcom/brasfoot/v2028/ActivitySub;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivitySub;->sd()V

    :cond_0
    return-void
.end method
