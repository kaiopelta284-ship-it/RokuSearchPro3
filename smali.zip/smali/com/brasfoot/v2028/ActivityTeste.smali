.class public Lcom/brasfoot/v2028/ActivityTeste;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/brasfoot/v2028/ActivityTeste$a;
    }
.end annotation


# instance fields
.field JU:Ljava/lang/ThreadGroup;

.field JV:Ljava/lang/Thread;

.field MD:Lcom/brasfoot/v2028/ActivityTeste$a;


# direct methods
.method public constructor <init>()V
    .locals 8

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Lcom/brasfoot/v2028/ActivityTeste$a;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivityTeste$a;-><init>(Lcom/brasfoot/v2028/ActivityTeste;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTeste;->MD:Lcom/brasfoot/v2028/ActivityTeste$a;

    new-instance v0, Ljava/lang/ThreadGroup;

    const-string v1, "threadGroup"

    invoke-direct {v0, v1}, Ljava/lang/ThreadGroup;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTeste;->JU:Ljava/lang/ThreadGroup;

    new-instance v0, Ljava/lang/Thread;

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivityTeste;->JU:Ljava/lang/ThreadGroup;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivityTeste;->MD:Lcom/brasfoot/v2028/ActivityTeste$a;

    const-string v5, "My thread"

    const-wide/32 v6, 0x1e8480

    move-object v2, v0

    invoke-direct/range {v2 .. v7}, Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;J)V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivityTeste;->JV:Ljava/lang/Thread;

    return-void
.end method

.method private D(La/ac;)V
    .locals 2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v0

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object v1

    invoke-virtual {v1}, La/af;->gN()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lest/InfoArquivoSalvoType;->setTc(Ljava/lang/String;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v0

    invoke-virtual {p1}, La/ac;->getNome()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lest/InfoArquivoSalvoType;->setN(Ljava/lang/String;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object p1

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, v0}, Lest/InfoArquivoSalvoType;->setA(Ljava/lang/Integer;)V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object p1

    const-string v0, ""

    invoke-virtual {p1, v0}, Lest/InfoArquivoSalvoType;->setI(Ljava/lang/String;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public d(Landroid/content/Context;I)V
    .locals 3

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeste;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/g;->a([Ljava/lang/String;)V

    new-instance v0, Lc/a;

    invoke-direct {v0}, Lc/a;-><init>()V

    invoke-static {p1}, La/h;->a(Landroid/content/Context;)V

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x0

    iput-boolean v1, v0, La/b;->nt:Z

    sget-object v0, Lc/a;->TF:La/b;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, La/b;->k(Z)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->setJogaEstadual(Z)V

    sget-object v0, Lc/a;->TF:La/b;

    const/16 v2, 0x14

    invoke-virtual {v0, v2}, La/b;->as(I)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0, v1}, La/b;->setJogaIntClubes(Z)V

    invoke-static {p1}, La/h;->b(Landroid/content/Context;)V

    :goto_0
    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->db()I

    move-result p1

    :cond_0
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    if-lt v0, p2, :cond_2

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dl()Ljava/util/ArrayList;

    move-result-object v0

    const/16 v1, 0xf4

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a;

    invoke-virtual {v0}, La/a;->cJ()Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_1

    :cond_1
    return-void

    :cond_2
    :goto_1
    invoke-static {}, La/o;->hu()V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->db()I

    move-result v0

    if-eq p1, v0, :cond_0

    goto :goto_0
.end method

.method public g(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 4

    sget-object p2, Lc/a;->TF:La/b;

    invoke-virtual {p2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p2

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/y;

    invoke-virtual {p2}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ld/q;

    invoke-virtual {p2}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/ac;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {p2, v2}, La/ac;->j(Ljava/lang/Boolean;)V

    invoke-virtual {p2}, La/ac;->lz()La/af;

    move-result-object v2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v2, v3}, La/af;->j(Ljava/lang/Boolean;)V

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {p2}, La/ac;->lz()La/af;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-direct {p0, p2}, Lcom/brasfoot/v2028/ActivityTeste;->D(La/ac;)V

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivityTeste;->getFilesDir()Ljava/io/File;

    move-result-object p2

    const-string v2, "teste.s21"

    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p2}, Ljava/io/File;->mkdir()Z

    move-result v1

    :cond_0
    if-nez v2, :cond_1

    if-eqz p1, :cond_1

    new-instance p2, Ljava/io/File;

    invoke-direct {p2, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    :cond_1
    if-eqz v1, :cond_2

    if-eqz v2, :cond_2

    invoke-static {}, Lc/b;->wC()V

    invoke-static {}, Lc/b;->wB()V

    invoke-static {}, Lc/b;->wE()V

    :try_start_0
    invoke-virtual {p0, v2, v0}, Lcom/brasfoot/v2028/ActivityTeste;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object p1

    new-instance p2, Ljava/io/ObjectOutputStream;

    invoke-direct {p2, p1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->eG()Lest/InfoArquivoSalvoType;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {p2, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/io/ObjectOutputStream;->close()V

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1, v2}, La/b;->j(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    :cond_2
    return v1
.end method

.method public onClickSalvar(Landroid/view/View;)V
    .locals 2

    sget-object p1, Lc/a;->TF:La/b;

    invoke-virtual {p1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/y;

    invoke-virtual {p1}, La/y;->kJ()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld/q;

    invoke-virtual {p1}, Ld/q;->xy()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/ac;

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p1, v1}, La/ac;->j(Ljava/lang/Boolean;)V

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v1, v0}, La/af;->j(Ljava/lang/Boolean;)V

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dg()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1}, La/ac;->lz()La/af;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->ed()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-direct {p0, p1}, Lcom/brasfoot/v2028/ActivityTeste;->D(La/ac;)V

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/brasfoot/v2028/ActivitySave;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeste;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onClickTeste(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x2

    invoke-virtual {p0, p0, p1}, Lcom/brasfoot/v2028/ActivityTeste;->d(Landroid/content/Context;I)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f070028

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivityTeste;->setContentView(I)V

    return-void
.end method
