.class public Lcom/brasfoot/v2028/ActivtyRankingTecnicos;
.super Landroid/app/Activity;


# instance fields
.field Ha:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field Hb:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field Hc:Landroid/widget/ListView;

.field Hj:Landroid/widget/Spinner;

.field private Lq:I

.field private Lr:I

.field ML:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La/af;",
            ">;"
        }
    .end annotation
.end field

.field private MM:I

.field MN:Lcomponents/ad;

.field private MO:La/af;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    const/4 v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Lq:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Lr:I

    iput v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MM:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Ha:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hb:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MO:La/af;

    return-void
.end method

.method static synthetic a(Lcom/brasfoot/v2028/ActivtyRankingTecnicos;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->su()V

    return-void
.end method

.method static synthetic b(Lcom/brasfoot/v2028/ActivtyRankingTecnicos;)V
    .locals 0

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->rJ()V

    return-void
.end method

.method private rJ()V
    .locals 4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hj:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, 0x0

    if-lez v0, :cond_2

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v2

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/y;

    invoke-virtual {v0}, La/y;->kK()I

    move-result v0

    :goto_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->hE()La/ac;

    move-result-object v2

    if-eqz v2, :cond_0

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->hE()La/ac;

    move-result-object v2

    invoke-virtual {v2}, La/ac;->getPais()I

    move-result v2

    goto :goto_1

    :cond_0
    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/af;

    invoke-virtual {v2}, La/af;->eN()I

    move-result v2

    :goto_1
    if-ne v2, v0, :cond_1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    sget-object v3, Lc/a;->TF:La/b;

    invoke-virtual {v3}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MO:La/af;

    if-ne v2, v3, :cond_1

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MM:I

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    :goto_2
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v1, v0, :cond_4

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    sget-object v2, Lc/a;->TF:La/b;

    invoke-virtual {v2}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->df()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    iget-object v2, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MO:La/af;

    if-ne v0, v2, :cond_3

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MM:I

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_4
    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MN:Lcomponents/ad;

    invoke-virtual {v0}, Lcomponents/ad;->notifyDataSetChanged()V

    return-void
.end method

.method private su()V
    .locals 2

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MN:Lcomponents/ad;

    invoke-virtual {v0}, Lcomponents/ad;->th()I

    move-result v0

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MN:Lcomponents/ad;

    invoke-virtual {v1}, Lcomponents/ad;->th()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/af;

    sput-object v0, Lcom/brasfoot/v2028/MainActivity;->NZ:La/af;

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/brasfoot/v2028/ActivityTecnico;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->startActivity(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f07001e

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->setContentView(I)V

    const/high16 p1, 0x4000000

    :try_start_0
    sget-object v0, Lc/a;->TF:La/b;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_0

    :try_start_1
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    :try_start_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->finish()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_0

    :catch_1
    :try_start_3
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-void

    :catch_2
    invoke-virtual {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->finish()V

    :cond_0
    :goto_0
    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hb:Ljava/util/ArrayList;

    const v0, 0x7f0b00d9

    invoke-virtual {p0, v0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Ha:Ljava/util/ArrayList;

    const/4 v0, -0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    :goto_1
    sget-object v0, Lc/a;->TF:La/b;

    invoke-virtual {v0}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_1

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hb:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1}, La/y;->kX()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Ha:Ljava/util/ArrayList;

    sget-object v1, Lc/a;->TF:La/b;

    invoke-virtual {v1}, La/b;->dh()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/y;

    invoke-virtual {v1, p0}, La/y;->f(Landroid/content/Context;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_1
    const p1, 0x7f060254

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Spinner;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hj:Landroid/widget/Spinner;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hj:Landroid/widget/Spinner;

    new-instance v6, Lcomponents/aw;

    const v2, 0x7f070066

    iget-object v3, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hb:Ljava/util/ArrayList;

    iget-object v4, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Ha:Ljava/util/ArrayList;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lcomponents/aw;-><init>(Landroid/content/Context;ILjava/util/ArrayList;Ljava/util/ArrayList;Z)V

    invoke-virtual {p1, v6}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    const p1, 0x7f0601a5

    invoke-virtual {p0, p1}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hc:Landroid/widget/ListView;

    new-instance p1, Lcomponents/ad;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->ML:Ljava/util/ArrayList;

    invoke-direct {p1, v0, p0, p0}, Lcomponents/ad;-><init>(Ljava/util/ArrayList;Landroid/app/Activity;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MN:Lcomponents/ad;

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hc:Landroid/widget/ListView;

    iget-object v0, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->MN:Lcomponents/ad;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hc:Landroid/widget/ListView;

    new-instance v0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$1;-><init>(Lcom/brasfoot/v2028/ActivtyRankingTecnicos;)V

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->Hj:Landroid/widget/Spinner;

    new-instance v0, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$2;

    invoke-direct {v0, p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos$2;-><init>(Lcom/brasfoot/v2028/ActivtyRankingTecnicos;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-direct {p0}, Lcom/brasfoot/v2028/ActivtyRankingTecnicos;->rJ()V

    return-void
.end method
