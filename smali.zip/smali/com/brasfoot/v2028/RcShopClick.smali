.class public Lcom/brasfoot/v2028/RcShopClick;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public act:Landroid/app/Activity;

.field public idx:I

.field public mode:I


# direct methods
.method public constructor <init>(Landroid/app/Activity;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/brasfoot/v2028/RcShopClick;->act:Landroid/app/Activity;

    iput p2, p0, Lcom/brasfoot/v2028/RcShopClick;->mode:I

    iput p3, p0, Lcom/brasfoot/v2028/RcShopClick;->idx:I

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/RcShopClick;->act:Landroid/app/Activity;

    iget v1, p0, Lcom/brasfoot/v2028/RcShopClick;->mode:I

    const/16 v2, 0xa

    if-ne v1, v2, :cond_0

    invoke-static {v0, p2}, Lcom/brasfoot/v2028/RcShop;->setPais(Landroid/app/Activity;I)V

    return-void

    :cond_0
    const/16 v2, 0xb

    if-ne v1, v2, :cond_1

    invoke-static {v0, p2}, Lcom/brasfoot/v2028/RcShop;->setStars(Landroid/app/Activity;I)V

    :cond_1
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 3

    iget-object v0, p0, Lcom/brasfoot/v2028/RcShopClick;->act:Landroid/app/Activity;

    iget v1, p0, Lcom/brasfoot/v2028/RcShopClick;->mode:I

    if-nez v1, :cond_0

    invoke-static {v0}, Lcom/brasfoot/v2028/RcShop;->pickPais(Landroid/app/Activity;)V

    return-void

    :cond_0
    const/4 v2, 0x1

    if-ne v1, v2, :cond_1

    invoke-static {v0}, Lcom/brasfoot/v2028/RcShop;->pickStars(Landroid/app/Activity;)V

    return-void

    :cond_1
    const/4 v2, 0x2

    if-ne v1, v2, :cond_2

    invoke-static {v0}, Lcom/brasfoot/v2028/RcShop;->peneira(Landroid/app/Activity;)V

    return-void

    :cond_2
    const/4 v2, 0x3

    if-ne v1, v2, :cond_3

    iget v1, p0, Lcom/brasfoot/v2028/RcShopClick;->idx:I

    invoke-static {v0, v1}, Lcom/brasfoot/v2028/RcShop;->buy(Landroid/app/Activity;I)V

    return-void

    :cond_3
    const/4 v2, 0x4

    if-ne v1, v2, :cond_4

    invoke-static {v0}, Lcom/brasfoot/v2028/RcShop;->peneiraElite(Landroid/app/Activity;)V

    return-void

    :cond_4
    const/4 v2, 0x5

    if-ne v1, v2, :cond_5

    invoke-static {v0}, Lcom/brasfoot/v2028/RcShop;->basesView(Landroid/app/Activity;)V

    :cond_5
    return-void
.end method
