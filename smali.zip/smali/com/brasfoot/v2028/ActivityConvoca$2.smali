.class Lcom/brasfoot/v2028/ActivityConvoca$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/AdapterView$OnItemLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/brasfoot/v2028/ActivityConvoca;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic GX:Lcom/brasfoot/v2028/ActivityConvoca;


# direct methods
.method constructor <init>(Lcom/brasfoot/v2028/ActivityConvoca;)V
    .locals 0

    iput-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$2;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemLongClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)Z"
        }
    .end annotation

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$2;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    iget-object p1, p1, Lcom/brasfoot/v2028/ActivityConvoca;->GM:Lcomponents/a;

    invoke-virtual {p1, p3}, Lcomponents/a;->dm(I)V

    iget-object p1, p0, Lcom/brasfoot/v2028/ActivityConvoca$2;->GX:Lcom/brasfoot/v2028/ActivityConvoca;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivityConvoca;->py()V

    const/4 p1, 0x1

    return p1
.end method
