.class public final Lcom/android/billingclient/BuildConfig;
.super Ljava/lang/Object;


# static fields
.field public static final CQ:Ljava/lang/String; = "com.android.billingclient"

.field public static final CR:Ljava/lang/String; = "release"

.field public static final CS:Ljava/lang/String; = ""

.field public static final CT:I = -0x1

.field public static final CU:Ljava/lang/String; = "1.1"

.field public static final DEBUG:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
