.class public interface abstract Lcom/android/billingclient/api/SkuDetailsResponseListener;
.super Ljava/lang/Object;


# virtual methods
.method public abstract b(ILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/SkuDetails;",
            ">;)V"
        }
    .end annotation
.end method
