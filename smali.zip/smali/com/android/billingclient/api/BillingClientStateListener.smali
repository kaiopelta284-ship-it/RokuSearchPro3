.class public interface abstract Lcom/android/billingclient/api/BillingClientStateListener;
.super Ljava/lang/Object;


# virtual methods
.method public abstract cE(I)V
.end method

.method public abstract os()V
.end method
