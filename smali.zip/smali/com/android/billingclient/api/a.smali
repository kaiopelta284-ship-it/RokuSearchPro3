.class Lcom/android/billingclient/api/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/billingclient/api/a$a;
    }
.end annotation


# static fields
.field private static final ACTION:Ljava/lang/String; = "com.android.vending.billing.PURCHASES_UPDATED"

.field private static final TAG:Ljava/lang/String; = "BillingBroadcastManager"


# instance fields
.field private final CV:Lcom/android/billingclient/api/a$a;

.field private final mContext:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/android/billingclient/api/PurchasesUpdatedListener;)V
    .locals 1
    .param p2    # Lcom/android/billingclient/api/PurchasesUpdatedListener;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/billingclient/api/a;->mContext:Landroid/content/Context;

    new-instance p1, Lcom/android/billingclient/api/a$a;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lcom/android/billingclient/api/a$a;-><init>(Lcom/android/billingclient/api/a;Lcom/android/billingclient/api/PurchasesUpdatedListener;Lcom/android/billingclient/api/a$1;)V

    iput-object p1, p0, Lcom/android/billingclient/api/a;->CV:Lcom/android/billingclient/api/a$a;

    return-void
.end method

.method static synthetic a(Lcom/android/billingclient/api/a;)Lcom/android/billingclient/api/a$a;
    .locals 0

    iget-object p0, p0, Lcom/android/billingclient/api/a;->CV:Lcom/android/billingclient/api/a$a;

    return-object p0
.end method


# virtual methods
.method destroy()V
    .locals 2

    iget-object v0, p0, Lcom/android/billingclient/api/a;->CV:Lcom/android/billingclient/api/a$a;

    iget-object v1, p0, Lcom/android/billingclient/api/a;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/a$a;->h(Landroid/content/Context;)V

    return-void
.end method

.method ou()V
    .locals 4

    iget-object v0, p0, Lcom/android/billingclient/api/a;->CV:Lcom/android/billingclient/api/a$a;

    iget-object v1, p0, Lcom/android/billingclient/api/a;->mContext:Landroid/content/Context;

    new-instance v2, Landroid/content/IntentFilter;

    const-string v3, "com.android.vending.billing.PURCHASES_UPDATED"

    invoke-direct {v2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2}, Lcom/android/billingclient/api/a$a;->a(Landroid/content/Context;Landroid/content/IntentFilter;)V

    return-void
.end method

.method ov()Lcom/android/billingclient/api/PurchasesUpdatedListener;
    .locals 1

    iget-object v0, p0, Lcom/android/billingclient/api/a;->CV:Lcom/android/billingclient/api/a$a;

    invoke-static {v0}, Lcom/android/billingclient/api/a$a;->a(Lcom/android/billingclient/api/a$a;)Lcom/android/billingclient/api/PurchasesUpdatedListener;

    move-result-object v0

    return-object v0
.end method
