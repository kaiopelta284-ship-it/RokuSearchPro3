.class public interface abstract Lcom/android/billingclient/api/PurchaseHistoryResponseListener;
.super Ljava/lang/Object;


# virtual methods
.method public abstract c(ILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/Purchase;",
            ">;)V"
        }
    .end annotation
.end method
