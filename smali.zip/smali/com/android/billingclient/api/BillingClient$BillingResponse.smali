.class public interface abstract annotation Lcom/android/billingclient/api/BillingClient$BillingResponse;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/billingclient/api/BillingClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2609
    name = "BillingResponse"
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->SOURCE:Ljava/lang/annotation/RetentionPolicy;
.end annotation


# static fields
.field public static final CZ:I = -0x2

.field public static final Da:I = -0x1

.field public static final Db:I = 0x1

.field public static final Dc:I = 0x2

.field public static final Dd:I = 0x3

.field public static final De:I = 0x4

.field public static final Df:I = 0x5

.field public static final Dg:I = 0x7

.field public static final Dh:I = 0x8

.field public static final ERROR:I = 0x6

.field public static final OK:I
