.class public abstract Lcom/android/billingclient/api/BillingClient;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/billingclient/api/BillingClient$Builder;,
        Lcom/android/billingclient/api/BillingClient$BillingResponse;,
        Lcom/android/billingclient/api/BillingClient$FeatureType;,
        Lcom/android/billingclient/api/BillingClient$SkuType;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static i(Landroid/content/Context;)Lcom/android/billingclient/api/BillingClient$Builder;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation

    new-instance v0, Lcom/android/billingclient/api/BillingClient$Builder;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/android/billingclient/api/BillingClient$Builder;-><init>(Landroid/content/Context;Lcom/android/billingclient/api/BillingClient$1;)V

    return-object v0
.end method


# virtual methods
.method public abstract a(Landroid/app/Activity;Lcom/android/billingclient/api/BillingFlowParams;)I
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract a(Lcom/android/billingclient/api/BillingClientStateListener;)V
    .param p1    # Lcom/android/billingclient/api/BillingClientStateListener;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract a(Lcom/android/billingclient/api/SkuDetailsParams;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract a(Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract a(Ljava/lang/String;Lcom/android/billingclient/api/PurchaseHistoryResponseListener;)V
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract ow()Z
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract ox()V
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract u(Ljava/lang/String;)I
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method

.method public abstract v(Ljava/lang/String;)Lcom/android/billingclient/api/Purchase$PurchasesResult;
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation
.end method
