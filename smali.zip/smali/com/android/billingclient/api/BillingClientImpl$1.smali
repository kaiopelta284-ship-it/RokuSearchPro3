.class Lcom/android/billingclient/api/BillingClientImpl$1;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/billingclient/api/BillingClientImpl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic DD:Lcom/android/billingclient/api/BillingClientImpl;


# direct methods
.method constructor <init>(Lcom/android/billingclient/api/BillingClientImpl;)V
    .locals 0

    iput-object p1, p0, Lcom/android/billingclient/api/BillingClientImpl$1;->DD:Lcom/android/billingclient/api/BillingClientImpl;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    iget-object p1, p0, Lcom/android/billingclient/api/BillingClientImpl$1;->DD:Lcom/android/billingclient/api/BillingClientImpl;

    invoke-static {p1}, Lcom/android/billingclient/api/BillingClientImpl;->a(Lcom/android/billingclient/api/BillingClientImpl;)Lcom/android/billingclient/api/a;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/billingclient/api/a;->ov()Lcom/android/billingclient/api/PurchasesUpdatedListener;

    move-result-object p1

    if-nez p1, :cond_0

    const-string p1, "BillingClient"

    const-string p2, "PurchasesUpdatedListener is null - no way to return the response."

    invoke-static {p1, p2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    const-string v0, "response_code_key"

    const/4 v1, 0x6

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "response_bundle_key"

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p2

    invoke-static {p2}, Lcom/android/billingclient/util/BillingHelper;->a(Landroid/os/Bundle;)Ljava/util/List;

    move-result-object p2

    invoke-interface {p1, v0, p2}, Lcom/android/billingclient/api/PurchasesUpdatedListener;->a(ILjava/util/List;)V

    return-void
.end method
