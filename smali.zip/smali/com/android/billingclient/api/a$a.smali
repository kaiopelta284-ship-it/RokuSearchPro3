.class Lcom/android/billingclient/api/a$a;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/billingclient/api/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field private final CW:Lcom/android/billingclient/api/PurchasesUpdatedListener;

.field private CX:Z

.field final synthetic CY:Lcom/android/billingclient/api/a;


# direct methods
.method private constructor <init>(Lcom/android/billingclient/api/a;Lcom/android/billingclient/api/PurchasesUpdatedListener;)V
    .locals 0
    .param p2    # Lcom/android/billingclient/api/PurchasesUpdatedListener;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    iput-object p1, p0, Lcom/android/billingclient/api/a$a;->CY:Lcom/android/billingclient/api/a;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    iput-object p2, p0, Lcom/android/billingclient/api/a$a;->CW:Lcom/android/billingclient/api/PurchasesUpdatedListener;

    return-void
.end method

.method synthetic constructor <init>(Lcom/android/billingclient/api/a;Lcom/android/billingclient/api/PurchasesUpdatedListener;Lcom/android/billingclient/api/a$1;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/android/billingclient/api/a$a;-><init>(Lcom/android/billingclient/api/a;Lcom/android/billingclient/api/PurchasesUpdatedListener;)V

    return-void
.end method

.method static synthetic a(Lcom/android/billingclient/api/a$a;)Lcom/android/billingclient/api/PurchasesUpdatedListener;
    .locals 0

    iget-object p0, p0, Lcom/android/billingclient/api/a$a;->CW:Lcom/android/billingclient/api/PurchasesUpdatedListener;

    return-object p0
.end method


# virtual methods
.method public a(Landroid/content/Context;Landroid/content/IntentFilter;)V
    .locals 1

    iget-boolean v0, p0, Lcom/android/billingclient/api/a$a;->CX:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/android/billingclient/api/a$a;->CY:Lcom/android/billingclient/api/a;

    invoke-static {v0}, Lcom/android/billingclient/api/a;->a(Lcom/android/billingclient/api/a;)Lcom/android/billingclient/api/a$a;

    move-result-object v0

    invoke-virtual {p1, v0, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/android/billingclient/api/a$a;->CX:Z

    :cond_0
    return-void
.end method

.method public h(Landroid/content/Context;)V
    .locals 1

    iget-boolean v0, p0, Lcom/android/billingclient/api/a$a;->CX:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/billingclient/api/a$a;->CY:Lcom/android/billingclient/api/a;

    invoke-static {v0}, Lcom/android/billingclient/api/a;->a(Lcom/android/billingclient/api/a;)Lcom/android/billingclient/api/a$a;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/android/billingclient/api/a$a;->CX:Z

    return-void

    :cond_0
    const-string p1, "BillingBroadcastManager"

    const-string v0, "Receiver is not registered."

    invoke-static {p1, v0}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    const-string p1, "BillingBroadcastManager"

    invoke-static {p2, p1}, Lcom/android/billingclient/util/BillingHelper;->a(Landroid/content/Intent;Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    invoke-static {p2}, Lcom/android/billingclient/util/BillingHelper;->a(Landroid/os/Bundle;)Ljava/util/List;

    move-result-object p2

    iget-object v0, p0, Lcom/android/billingclient/api/a$a;->CW:Lcom/android/billingclient/api/PurchasesUpdatedListener;

    invoke-interface {v0, p1, p2}, Lcom/android/billingclient/api/PurchasesUpdatedListener;->a(ILjava/util/List;)V

    return-void
.end method
