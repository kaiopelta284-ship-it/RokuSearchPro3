.class Lcom/android/billingclient/api/BillingClientImpl$2$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/billingclient/api/BillingClientImpl$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic DG:Lcom/android/billingclient/api/SkuDetails$a;

.field final synthetic DH:Lcom/android/billingclient/api/BillingClientImpl$2;


# direct methods
.method constructor <init>(Lcom/android/billingclient/api/BillingClientImpl$2;Lcom/android/billingclient/api/SkuDetails$a;)V
    .locals 0

    iput-object p1, p0, Lcom/android/billingclient/api/BillingClientImpl$2$1;->DH:Lcom/android/billingclient/api/BillingClientImpl$2;

    iput-object p2, p0, Lcom/android/billingclient/api/BillingClientImpl$2$1;->DG:Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl$2$1;->DH:Lcom/android/billingclient/api/BillingClientImpl$2;

    iget-object v0, v0, Lcom/android/billingclient/api/BillingClientImpl$2;->CJ:Lcom/android/billingclient/api/SkuDetailsResponseListener;

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl$2$1;->DG:Lcom/android/billingclient/api/SkuDetails$a;

    invoke-virtual {v1}, Lcom/android/billingclient/api/SkuDetails$a;->getResponseCode()I

    move-result v1

    iget-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl$2$1;->DG:Lcom/android/billingclient/api/SkuDetails$a;

    invoke-virtual {v2}, Lcom/android/billingclient/api/SkuDetails$a;->pa()Ljava/util/List;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Lcom/android/billingclient/api/SkuDetailsResponseListener;->b(ILjava/util/List;)V

    return-void
.end method
