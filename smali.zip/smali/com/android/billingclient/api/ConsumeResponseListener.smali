.class public interface abstract Lcom/android/billingclient/api/ConsumeResponseListener;
.super Ljava/lang/Object;


# virtual methods
.method public abstract c(ILjava/lang/String;)V
.end method
