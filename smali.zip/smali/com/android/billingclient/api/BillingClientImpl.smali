.class Lcom/android/billingclient/api/BillingClientImpl;
.super Lcom/android/billingclient/api/BillingClient;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/billingclient/api/BillingClientImpl$a;,
        Lcom/android/billingclient/api/BillingClientImpl$ClientState;
    }
.end annotation


# static fields
.field private static final Do:I = 0x14

.field private static final Dq:Ljava/lang/String; = "ITEM_ID_LIST"

.field private static final Dr:Ljava/lang/String; = "libraryVersion"

.field private static final Ds:Ljava/lang/String; = "1.1"

.field private static final TAG:Ljava/lang/String; = "BillingClient"


# instance fields
.field private DA:Z

.field private DB:Ljava/util/concurrent/ExecutorService;

.field private final DC:Landroid/content/BroadcastReceiver;

.field private Dp:I

.field private final Dt:Landroid/os/Handler;

.field private final Du:Lcom/android/billingclient/api/a;

.field private final Dv:Landroid/content/Context;

.field private Dw:Lcom/android/vending/billing/IInAppBillingService;

.field private Dx:Landroid/content/ServiceConnection;

.field private Dy:Z

.field private Dz:Z


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/android/billingclient/api/PurchasesUpdatedListener;)V
    .locals 1
    .param p1    # Landroid/content/Context;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Lcom/android/billingclient/api/PurchasesUpdatedListener;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroid/support/annotation/UiThread;
    .end annotation

    invoke-direct {p0}, Lcom/android/billingclient/api/BillingClient;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dt:Landroid/os/Handler;

    new-instance v0, Lcom/android/billingclient/api/BillingClientImpl$1;

    invoke-direct {v0, p0}, Lcom/android/billingclient/api/BillingClientImpl$1;-><init>(Lcom/android/billingclient/api/BillingClientImpl;)V

    iput-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->DC:Landroid/content/BroadcastReceiver;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    new-instance p1, Lcom/android/billingclient/api/a;

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-direct {p1, v0, p2}, Lcom/android/billingclient/api/a;-><init>(Landroid/content/Context;Lcom/android/billingclient/api/PurchasesUpdatedListener;)V

    iput-object p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Du:Lcom/android/billingclient/api/a;

    return-void
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;I)I
    .locals 0

    iput p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    return p1
.end method

.method private a(Lcom/android/billingclient/api/BillingFlowParams;)Landroid/os/Bundle;
    .locals 5

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->oF()I

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "prorationMode"

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->oF()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    :cond_0
    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->getAccountId()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1

    const-string v1, "accountId"

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->getAccountId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->oE()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    const-string v1, "vr"

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    :cond_2
    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->oD()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3

    const-string v1, "skusToReplace"

    new-instance v3, Ljava/util/ArrayList;

    new-array v2, v2, [Ljava/lang/String;

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingFlowParams;->oD()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v2, v4

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-direct {v3, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0, v1, v3}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_3
    return-object v0
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;Ljava/lang/String;Z)Lcom/android/billingclient/api/Purchase$PurchasesResult;
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/android/billingclient/api/BillingClientImpl;->a(Ljava/lang/String;Z)Lcom/android/billingclient/api/Purchase$PurchasesResult;

    move-result-object p0

    return-object p0
.end method

.method private a(Ljava/lang/String;Z)Lcom/android/billingclient/api/Purchase$PurchasesResult;
    .locals 17

    move-object/from16 v1, p0

    move-object/from16 v8, p1

    move/from16 v9, p2

    const-string v2, "BillingClient"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Querying owned items, item type: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "; history: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x0

    move-object v6, v11

    :goto_0
    if-eqz v9, :cond_1

    :try_start_0
    iget-boolean v2, v1, Lcom/android/billingclient/api/BillingClientImpl;->DA:Z

    if-nez v2, :cond_0

    const-string v2, "BillingClient"

    const-string v3, "getPurchaseHistory is not supported on current device"

    invoke-static {v2, v3}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v3, -0x2

    invoke-direct {v2, v3, v11}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_0
    iget-object v2, v1, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v3, 0x6

    iget-object v4, v1, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    move-object v5, v8

    invoke-interface/range {v2 .. v7}, Lcom/android/vending/billing/IInAppBillingService;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v2

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v2, v0

    goto/16 :goto_4

    :cond_1
    iget-object v2, v1, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v3, 0x3

    iget-object v4, v1, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v3, v4, v8, v6}, Lcom/android/vending/billing/IInAppBillingService;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    const/4 v3, 0x6

    if-nez v2, :cond_2

    const-string v2, "BillingClient"

    const-string v4, "queryPurchases got null owned items list"

    invoke-static {v2, v4}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    invoke-direct {v2, v3, v11}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_2
    const-string v4, "BillingClient"

    invoke-static {v2, v4}, Lcom/android/billingclient/util/BillingHelper;->a(Landroid/os/Bundle;Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_3

    const-string v2, "BillingClient"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "getPurchases() failed. Response code: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    invoke-direct {v2, v4, v11}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_3
    const-string v4, "INAPP_PURCHASE_ITEM_LIST"

    invoke-virtual {v2, v4}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_b

    const-string v4, "INAPP_PURCHASE_DATA_LIST"

    invoke-virtual {v2, v4}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_b

    const-string v4, "INAPP_DATA_SIGNATURE_LIST"

    invoke-virtual {v2, v4}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_4

    goto/16 :goto_3

    :cond_4
    const-string v4, "INAPP_PURCHASE_ITEM_LIST"

    invoke-virtual {v2, v4}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v4

    const-string v5, "INAPP_PURCHASE_DATA_LIST"

    invoke-virtual {v2, v5}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v5

    const-string v6, "INAPP_DATA_SIGNATURE_LIST"

    invoke-virtual {v2, v6}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v6

    if-nez v4, :cond_5

    const-string v2, "BillingClient"

    const-string v4, "Bundle returned from getPurchases() contains null SKUs list."

    invoke-static {v2, v4}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    invoke-direct {v2, v3, v11}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_5
    if-nez v5, :cond_6

    const-string v2, "BillingClient"

    const-string v4, "Bundle returned from getPurchases() contains null purchases list."

    invoke-static {v2, v4}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    invoke-direct {v2, v3, v11}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_6
    if-nez v6, :cond_7

    const-string v2, "BillingClient"

    const-string v4, "Bundle returned from getPurchases() contains null signatures list."

    invoke-static {v2, v4}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    invoke-direct {v2, v3, v11}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_7
    const/4 v12, 0x0

    :goto_2
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v13

    if-ge v12, v13, :cond_9

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-virtual {v4, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    const-string v7, "BillingClient"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Sku is owned: "

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v7, v3}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_1
    new-instance v3, Lcom/android/billingclient/api/Purchase;

    invoke-direct {v3, v13, v14}, Lcom/android/billingclient/api/Purchase;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    invoke-virtual {v3}, Lcom/android/billingclient/api/Purchase;->oM()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_8

    const-string v7, "BillingClient"

    const-string v11, "BUG: empty/null token!"

    invoke-static {v7, v11}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    invoke-interface {v10, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    const/4 v3, 0x6

    const/4 v11, 0x0

    goto :goto_2

    :catch_1
    move-exception v0

    move-object v2, v0

    const-string v3, "BillingClient"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Got an exception trying to decode the purchase: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v2, v4, v3}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_9
    const-string v3, "INAPP_CONTINUATION_TOKEN"

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v2, "BillingClient"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Continuation token: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_a

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v10}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :cond_a
    const/4 v11, 0x0

    goto/16 :goto_0

    :cond_b
    :goto_3
    const-string v2, "BillingClient"

    const-string v3, "Bundle returned from getPurchases() doesn\'t contain required fields."

    invoke-static {v2, v3}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v2, v4, v3}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2

    :goto_4
    const-string v3, "BillingClient"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Got exception trying to get purchases: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, "; try to reconnect"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v3, -0x1

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object v2
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;)Lcom/android/billingclient/api/a;
    .locals 0

    iget-object p0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Du:Lcom/android/billingclient/api/a;

    return-object p0
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;Lcom/android/vending/billing/IInAppBillingService;)Lcom/android/vending/billing/IInAppBillingService;
    .locals 0

    iput-object p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    return-object p1
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;Ljava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/android/billingclient/api/BillingClientImpl;->d(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/android/billingclient/api/BillingClientImpl;->b(Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V

    return-void
.end method

.method static synthetic a(Lcom/android/billingclient/api/BillingClientImpl;Z)Z
    .locals 0

    iput-boolean p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dy:Z

    return p1
.end method

.method static synthetic b(Lcom/android/billingclient/api/BillingClientImpl;)Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    return-object p0
.end method

.method private b(Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V
    .locals 4
    .annotation build Landroid/support/annotation/WorkerThread;
    .end annotation

    :try_start_0
    const-string v0, "BillingClient"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Consuming purchase with token: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2, p1}, Lcom/android/vending/billing/IInAppBillingService;->b(ILjava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const-string v1, "BillingClient"

    const-string v2, "Successfully consumed purchase."

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p2, :cond_1

    new-instance v1, Lcom/android/billingclient/api/BillingClientImpl$5;

    invoke-direct {v1, p0, p2, v0, p1}, Lcom/android/billingclient/api/BillingClientImpl$5;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Lcom/android/billingclient/api/ConsumeResponseListener;ILjava/lang/String;)V

    :goto_0
    invoke-direct {p0, v1}, Lcom/android/billingclient/api/BillingClientImpl;->d(Ljava/lang/Runnable;)V

    return-void

    :cond_0
    const-string v1, "BillingClient"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Error consuming purchase with token. Response code: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Lcom/android/billingclient/api/BillingClientImpl$6;

    invoke-direct {v1, p0, p2, v0, p1}, Lcom/android/billingclient/api/BillingClientImpl$6;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Lcom/android/billingclient/api/ConsumeResponseListener;ILjava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    new-instance v1, Lcom/android/billingclient/api/BillingClientImpl$7;

    invoke-direct {v1, p0, v0, p2, p1}, Lcom/android/billingclient/api/BillingClientImpl$7;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Landroid/os/RemoteException;Lcom/android/billingclient/api/ConsumeResponseListener;Ljava/lang/String;)V

    invoke-direct {p0, v1}, Lcom/android/billingclient/api/BillingClientImpl;->d(Ljava/lang/Runnable;)V

    :cond_1
    return-void
.end method

.method static synthetic b(Lcom/android/billingclient/api/BillingClientImpl;Z)Z
    .locals 0

    iput-boolean p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dz:Z

    return p1
.end method

.method static synthetic c(Lcom/android/billingclient/api/BillingClientImpl;)Lcom/android/vending/billing/IInAppBillingService;
    .locals 0

    iget-object p0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    return-object p0
.end method

.method private c(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->DB:Ljava/util/concurrent/ExecutorService;

    if-nez v0, :cond_0

    sget v0, Lcom/android/billingclient/util/BillingHelper;->EL:I

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->DB:Ljava/util/concurrent/ExecutorService;

    :cond_0
    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->DB:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, p1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    return-void
.end method

.method static synthetic c(Lcom/android/billingclient/api/BillingClientImpl;Z)Z
    .locals 0

    iput-boolean p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->DA:Z

    return p1
.end method

.method private cG(I)I
    .locals 2

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Du:Lcom/android/billingclient/api/a;

    invoke-virtual {v0}, Lcom/android/billingclient/api/a;->ov()Lcom/android/billingclient/api/PurchasesUpdatedListener;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, p1, v1}, Lcom/android/billingclient/api/PurchasesUpdatedListener;->a(ILjava/util/List;)V

    return p1
.end method

.method private d(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dt:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic d(Lcom/android/billingclient/api/BillingClientImpl;)Z
    .locals 0

    iget-boolean p0, p0, Lcom/android/billingclient/api/BillingClientImpl;->DA:Z

    return p0
.end method

.method private oz()Landroid/os/Bundle;
    .locals 3

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "vr"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    return-object v0
.end method

.method private w(Ljava/lang/String;)I
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v1, 0x7

    iget-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0}, Lcom/android/billingclient/api/BillingClientImpl;->oz()Landroid/os/Bundle;

    move-result-object v3

    invoke-interface {v0, v1, v2, p1, v3}, Lcom/android/vending/billing/IInAppBillingService;->b(ILjava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)I

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    const/4 p1, -0x2

    return p1

    :catch_0
    const-string p1, "BillingClient"

    const-string v0, "RemoteException while checking if billing is supported; try to reconnect"

    invoke-static {p1, v0}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, -0x1

    return p1
.end method


# virtual methods
.method public a(Landroid/app/Activity;Lcom/android/billingclient/api/BillingFlowParams;)I
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v2

    const/4 v3, -0x1

    if-nez v2, :cond_0

    invoke-direct {v0, v3}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_0
    invoke-virtual/range {p2 .. p2}, Lcom/android/billingclient/api/BillingFlowParams;->oB()Ljava/lang/String;

    move-result-object v8

    invoke-virtual/range {p2 .. p2}, Lcom/android/billingclient/api/BillingFlowParams;->oA()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    if-nez v2, :cond_1

    const-string v1, "BillingClient"

    const-string v2, "Please fix the input params. SKU can\'t be null."

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_1
    if-nez v8, :cond_2

    const-string v1, "BillingClient"

    const-string v2, "Please fix the input params. SkuType can\'t be null."

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_2
    const-string v4, "subs"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v5, -0x2

    if-eqz v4, :cond_3

    iget-boolean v4, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dy:Z

    if-nez v4, :cond_3

    const-string v1, "BillingClient"

    const-string v2, "Current client doesn\'t support subscriptions."

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v5}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_3
    invoke-virtual/range {p2 .. p2}, Lcom/android/billingclient/api/BillingFlowParams;->oD()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/16 v16, 0x0

    if-eqz v4, :cond_4

    const/4 v4, 0x1

    goto :goto_0

    :cond_4
    const/4 v4, 0x0

    :goto_0
    if-eqz v4, :cond_5

    iget-boolean v7, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dz:Z

    if-nez v7, :cond_5

    const-string v1, "BillingClient"

    const-string v2, "Current client doesn\'t support subscriptions update."

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v5}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_5
    invoke-virtual/range {p2 .. p2}, Lcom/android/billingclient/api/BillingFlowParams;->oG()Z

    move-result v7

    if-eqz v7, :cond_6

    iget-boolean v7, v0, Lcom/android/billingclient/api/BillingClientImpl;->DA:Z

    if-nez v7, :cond_6

    const-string v1, "BillingClient"

    const-string v2, "Current client doesn\'t support extra params for buy intent."

    invoke-static {v1, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v5}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_6
    :try_start_0
    const-string v5, "BillingClient"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Constructing buy intent for "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, ", item type: "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-boolean v5, v0, Lcom/android/billingclient/api/BillingClientImpl;->DA:Z

    if-eqz v5, :cond_8

    move-object/from16 v5, p2

    invoke-direct {v0, v5}, Lcom/android/billingclient/api/BillingClientImpl;->a(Lcom/android/billingclient/api/BillingFlowParams;)Landroid/os/Bundle;

    move-result-object v10

    const-string v4, "libraryVersion"

    const-string v6, "1.1"

    invoke-virtual {v10, v4, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p2 .. p2}, Lcom/android/billingclient/api/BillingFlowParams;->oE()Z

    move-result v4

    if-eqz v4, :cond_7

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_1

    :cond_7
    const/4 v4, 0x6

    const/4 v5, 0x6

    :goto_1
    iget-object v4, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    iget-object v6, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x0

    move-object v7, v2

    invoke-interface/range {v4 .. v10}, Lcom/android/vending/billing/IInAppBillingService;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v4

    goto :goto_2

    :cond_8
    move-object/from16 v5, p2

    if-eqz v4, :cond_9

    iget-object v9, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v10, 0x5

    iget-object v4, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    new-array v4, v6, [Ljava/lang/String;

    invoke-virtual/range {p2 .. p2}, Lcom/android/billingclient/api/BillingFlowParams;->oD()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v16

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v12

    const-string v14, "subs"

    const/4 v15, 0x0

    move-object v13, v2

    invoke-interface/range {v9 .. v15}, Lcom/android/vending/billing/IInAppBillingService;->a(ILjava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v4

    goto :goto_2

    :cond_9
    iget-object v4, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v5, 0x3

    iget-object v6, v0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x0

    move-object v7, v2

    invoke-interface/range {v4 .. v9}, Lcom/android/vending/billing/IInAppBillingService;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v4

    :goto_2
    const-string v5, "BillingClient"

    invoke-static {v4, v5}, Lcom/android/billingclient/util/BillingHelper;->a(Landroid/os/Bundle;Ljava/lang/String;)I

    move-result v5

    if-eqz v5, :cond_a

    const-string v1, "BillingClient"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Unable to buy item, Error response code: "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v5}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1

    :cond_a
    new-instance v5, Landroid/content/Intent;

    const-class v6, Lcom/android/billingclient/api/ProxyBillingActivity;

    invoke-direct {v5, v1, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v6, "BUY_INTENT"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v4

    check-cast v4, Landroid/app/PendingIntent;

    const-string v6, "BUY_INTENT"

    invoke-virtual {v5, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    invoke-virtual {v1, v5}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v16

    :catch_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "RemoteException while launching launching replace subscriptions flow: ; for sku: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "; try to reconnect"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "BillingClient"

    invoke-static {v2, v1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/android/billingclient/api/BillingClientImpl;->cG(I)I

    move-result v1

    return v1
.end method

.method a(Ljava/lang/String;Ljava/util/List;)Lcom/android/billingclient/api/SkuDetails$a;
    .locals 12
    .annotation build Landroid/support/annotation/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/android/billingclient/api/SkuDetails$a;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_6

    add-int/lit8 v4, v3, 0x14

    if-le v4, v1, :cond_0

    move v5, v1

    goto :goto_1

    :cond_0
    move v5, v4

    :goto_1
    new-instance v6, Ljava/util/ArrayList;

    invoke-interface {p2, v3, v5}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v3

    invoke-direct {v6, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string v5, "ITEM_ID_LIST"

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v5, "libraryVersion"

    const-string v6, "1.1"

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    :try_start_0
    iget-object v6, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    const/4 v7, 0x3

    iget-object v8, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v7, v8, p1, v3}, Lcom/android/vending/billing/IInAppBillingService;->a(ILjava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v3
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const-string p1, "BillingClient"

    const-string p2, "querySkuDetailsAsync got null sku details list"

    invoke-static {p1, p2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p1, v6, v5}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_1
    const-string v7, "DETAILS_LIST"

    invoke-virtual {v3, v7}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v7

    const/4 v8, 0x6

    if-nez v7, :cond_3

    const-string p1, "BillingClient"

    invoke-static {v3, p1}, Lcom/android/billingclient/util/BillingHelper;->a(Landroid/os/Bundle;Ljava/lang/String;)I

    move-result p1

    if-eqz p1, :cond_2

    const-string p2, "BillingClient"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getSkuDetails() failed. Response code: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p2, v1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p2, Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p2, p1, v0}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p2

    :cond_2
    const-string p1, "BillingClient"

    const-string p2, "getSkuDetails() returned a bundle with neither an error nor a detail list."

    invoke-static {p1, p2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p1, v8, v0}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_3
    const-string v7, "DETAILS_LIST"

    invoke-virtual {v3, v7}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v3

    if-nez v3, :cond_4

    const-string p1, "BillingClient"

    const-string p2, "querySkuDetailsAsync got null response list"

    invoke-static {p1, p2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p1, v6, v5}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_4
    const/4 v6, 0x0

    :goto_2
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_5

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    :try_start_1
    new-instance v9, Lcom/android/billingclient/api/SkuDetails;

    invoke-direct {v9, v7}, Lcom/android/billingclient/api/SkuDetails;-><init>(Ljava/lang/String;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const-string v7, "BillingClient"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Got sku details: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v7, v10}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :catch_0
    const-string p1, "BillingClient"

    const-string p2, "Got a JSON exception trying to decode SkuDetails"

    invoke-static {p1, p2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p1, v8, v5}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_5
    move v3, v4

    goto/16 :goto_0

    :catch_1
    move-exception p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "querySkuDetailsAsync got a remote exception (try to reconnect): "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "BillingClient"

    invoke-static {p2, p1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/android/billingclient/api/SkuDetails$a;

    const/4 p2, -0x1

    invoke-direct {p1, p2, v5}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_6
    new-instance p1, Lcom/android/billingclient/api/SkuDetails$a;

    invoke-direct {p1, v2, v0}, Lcom/android/billingclient/api/SkuDetails$a;-><init>(ILjava/util/List;)V

    return-object p1
.end method

.method public a(Lcom/android/billingclient/api/BillingClientStateListener;)V
    .locals 7
    .param p1    # Lcom/android/billingclient/api/BillingClientStateListener;
        .annotation build Landroid/support/annotation/NonNull;
        .end annotation
    .end param

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "BillingClient"

    const-string v2, "Service connection is valid. No need to re-initialize."

    invoke-static {v0, v2}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1, v1}, Lcom/android/billingclient/api/BillingClientStateListener;->cE(I)V

    return-void

    :cond_0
    iget v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ne v0, v3, :cond_1

    const-string v0, "BillingClient"

    const-string v1, "Client is already in the process of connecting to billing service."

    invoke-static {v0, v1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1, v2}, Lcom/android/billingclient/api/BillingClientStateListener;->cE(I)V

    return-void

    :cond_1
    iget v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    const/4 v4, 0x3

    if-ne v0, v4, :cond_2

    const-string v0, "BillingClient"

    const-string v1, "Client was already closed and can\'t be reused. Please create another instance."

    invoke-static {v0, v1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1, v2}, Lcom/android/billingclient/api/BillingClientStateListener;->cE(I)V

    return-void

    :cond_2
    iput v3, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Du:Lcom/android/billingclient/api/a;

    invoke-virtual {v0}, Lcom/android/billingclient/api/a;->ou()V

    new-instance v0, Landroid/content/IntentFilter;

    const-string v2, "proxy_activity_response_intent_action"

    invoke-direct {v0, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-static {v2}, Lcom/android/billingclient/api/b;->j(Landroid/content/Context;)Lcom/android/billingclient/api/b;

    move-result-object v2

    iget-object v5, p0, Lcom/android/billingclient/api/BillingClientImpl;->DC:Landroid/content/BroadcastReceiver;

    invoke-virtual {v2, v5, v0}, Lcom/android/billingclient/api/b;->a(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    const-string v0, "BillingClient"

    const-string v2, "Starting in-app billing setup."

    invoke-static {v0, v2}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Lcom/android/billingclient/api/BillingClientImpl$a;

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, v2}, Lcom/android/billingclient/api/BillingClientImpl$a;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Lcom/android/billingclient/api/BillingClientStateListener;Lcom/android/billingclient/api/BillingClientImpl$1;)V

    iput-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dx:Landroid/content/ServiceConnection;

    new-instance v0, Landroid/content/Intent;

    const-string v2, "com.android.vending.billing.InAppBillingService.BIND"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "com.android.vending"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    iget-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    if-eqz v2, :cond_5

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_5

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ResolveInfo;

    iget-object v5, v2, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-eqz v5, :cond_5

    iget-object v5, v2, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v5, v5, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    iget-object v2, v2, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    const-string v6, "com.android.vending"

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    if-eqz v2, :cond_4

    new-instance v6, Landroid/content/ComponentName;

    invoke-direct {v6, v5, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    invoke-virtual {v2, v6}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const-string v0, "libraryVersion"

    const-string v5, "1.1"

    invoke-virtual {v2, v0, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    iget-object v5, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dx:Landroid/content/ServiceConnection;

    invoke-virtual {v0, v2, v5, v3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string p1, "BillingClient"

    const-string v0, "Service was bonded successfully."

    invoke-static {p1, v0}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_3
    const-string v0, "BillingClient"

    const-string v2, "Connection to Billing service is blocked."

    goto :goto_0

    :cond_4
    const-string v0, "BillingClient"

    const-string v2, "The device doesn\'t have valid Play Store."

    :goto_0
    invoke-static {v0, v2}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    iput v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    const-string v0, "BillingClient"

    const-string v1, "Billing service unavailable on device."

    invoke-static {v0, v1}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1, v4}, Lcom/android/billingclient/api/BillingClientStateListener;->cE(I)V

    return-void
.end method

.method public a(Lcom/android/billingclient/api/SkuDetailsParams;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V
    .locals 4

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 p1, -0x1

    invoke-interface {p2, p1, v1}, Lcom/android/billingclient/api/SkuDetailsResponseListener;->b(ILjava/util/List;)V

    return-void

    :cond_0
    invoke-virtual {p1}, Lcom/android/billingclient/api/SkuDetailsParams;->oB()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/billingclient/api/SkuDetailsParams;->pb()Ljava/util/List;

    move-result-object p1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v3, 0x5

    if-eqz v2, :cond_1

    const-string p1, "BillingClient"

    const-string v0, "Please fix the input params. SKU type can\'t be empty."

    invoke-static {p1, v0}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p2, v3, v1}, Lcom/android/billingclient/api/SkuDetailsResponseListener;->b(ILjava/util/List;)V

    return-void

    :cond_1
    if-nez p1, :cond_2

    const-string p1, "BillingClient"

    const-string v0, "Please fix the input params. The list of SKUs can\'t be empty."

    invoke-static {p1, v0}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p2, v3, v1}, Lcom/android/billingclient/api/SkuDetailsResponseListener;->b(ILjava/util/List;)V

    return-void

    :cond_2
    new-instance v1, Lcom/android/billingclient/api/BillingClientImpl$2;

    invoke-direct {v1, p0, v0, p1, p2}, Lcom/android/billingclient/api/BillingClientImpl$2;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Ljava/lang/String;Ljava/util/List;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V

    invoke-direct {p0, v1}, Lcom/android/billingclient/api/BillingClientImpl;->c(Ljava/lang/Runnable;)V

    return-void
.end method

.method public a(Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V
    .locals 2

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, -0x1

    const/4 v0, 0x0

    invoke-interface {p2, p1, v0}, Lcom/android/billingclient/api/ConsumeResponseListener;->c(ILjava/lang/String;)V

    return-void

    :cond_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "BillingClient"

    const-string v1, "Please provide a valid purchase token got from queryPurchases result."

    invoke-static {v0, v1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x5

    invoke-interface {p2, v0, p1}, Lcom/android/billingclient/api/ConsumeResponseListener;->c(ILjava/lang/String;)V

    return-void

    :cond_1
    new-instance v0, Lcom/android/billingclient/api/BillingClientImpl$3;

    invoke-direct {v0, p0, p1, p2}, Lcom/android/billingclient/api/BillingClientImpl$3;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V

    invoke-direct {p0, v0}, Lcom/android/billingclient/api/BillingClientImpl;->c(Ljava/lang/Runnable;)V

    return-void
.end method

.method public a(Ljava/lang/String;Lcom/android/billingclient/api/PurchaseHistoryResponseListener;)V
    .locals 1

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, -0x1

    const/4 v0, 0x0

    invoke-interface {p2, p1, v0}, Lcom/android/billingclient/api/PurchaseHistoryResponseListener;->c(ILjava/util/List;)V

    return-void

    :cond_0
    new-instance v0, Lcom/android/billingclient/api/BillingClientImpl$4;

    invoke-direct {v0, p0, p1, p2}, Lcom/android/billingclient/api/BillingClientImpl$4;-><init>(Lcom/android/billingclient/api/BillingClientImpl;Ljava/lang/String;Lcom/android/billingclient/api/PurchaseHistoryResponseListener;)V

    invoke-direct {p0, v0}, Lcom/android/billingclient/api/BillingClientImpl;->c(Ljava/lang/Runnable;)V

    return-void
.end method

.method public ow()Z
    .locals 2

    iget v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dx:Landroid/content/ServiceConnection;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public ox()V
    .locals 5

    const/4 v0, 0x3

    :try_start_0
    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    invoke-static {v1}, Lcom/android/billingclient/api/b;->j(Landroid/content/Context;)Lcom/android/billingclient/api/b;

    move-result-object v1

    iget-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->DC:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2}, Lcom/android/billingclient/api/b;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Du:Lcom/android/billingclient/api/a;

    invoke-virtual {v1}, Lcom/android/billingclient/api/a;->destroy()V

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dx:Landroid/content/ServiceConnection;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    if-eqz v1, :cond_0

    const-string v1, "BillingClient"

    const-string v3, "Unbinding from service."

    invoke-static {v1, v3}, Lcom/android/billingclient/util/BillingHelper;->c(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dv:Landroid/content/Context;

    iget-object v3, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dx:Landroid/content/ServiceConnection;

    invoke-virtual {v1, v3}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    iput-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dx:Landroid/content/ServiceConnection;

    :cond_0
    iput-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dw:Lcom/android/vending/billing/IInAppBillingService;

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->DB:Ljava/util/concurrent/ExecutorService;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/android/billingclient/api/BillingClientImpl;->DB:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    iput-object v2, p0, Lcom/android/billingclient/api/BillingClientImpl;->DB:Ljava/util/concurrent/ExecutorService;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :catch_0
    move-exception v1

    :try_start_1
    const-string v2, "BillingClient"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "There was an exception while ending connection: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_1
    :goto_0
    iput v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    return-void

    :goto_1
    iput v0, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dp:I

    throw v1
.end method

.method public u(Ljava/lang/String;)I
    .locals 4

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v2, -0x1928a0a1

    const/4 v3, 0x0

    if-eq v0, v2, :cond_4

    const v2, 0x116ae57f

    if-eq v0, v2, :cond_3

    const v2, 0x48aff111

    if-eq v0, v2, :cond_2

    const v2, 0x7674caf6

    if-eq v0, v2, :cond_1

    goto :goto_0

    :cond_1
    const-string v0, "subscriptions"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v1, 0x0

    goto :goto_0

    :cond_2
    const-string v0, "subscriptionsOnVr"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v1, 0x3

    goto :goto_0

    :cond_3
    const-string v0, "inAppItemsOnVr"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v1, 0x2

    goto :goto_0

    :cond_4
    const-string v0, "subscriptionsUpdate"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/4 v1, 0x1

    :cond_5
    :goto_0
    const/4 v0, -0x2

    packed-switch v1, :pswitch_data_0

    const-string v0, "BillingClient"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unsupported feature: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x5

    return p1

    :pswitch_0
    const-string p1, "subs"

    invoke-direct {p0, p1}, Lcom/android/billingclient/api/BillingClientImpl;->w(Ljava/lang/String;)I

    move-result p1

    return p1

    :pswitch_1
    const-string p1, "inapp"

    invoke-direct {p0, p1}, Lcom/android/billingclient/api/BillingClientImpl;->w(Ljava/lang/String;)I

    move-result p1

    return p1

    :pswitch_2
    iget-boolean p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dz:Z

    if-eqz p1, :cond_6

    const/4 v0, 0x0

    :cond_6
    return v0

    :pswitch_3
    iget-boolean p1, p0, Lcom/android/billingclient/api/BillingClientImpl;->Dy:Z

    if-eqz p1, :cond_7

    const/4 v0, 0x0

    :cond_7
    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public v(Ljava/lang/String;)Lcom/android/billingclient/api/Purchase$PurchasesResult;
    .locals 2

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClientImpl;->ow()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    new-instance p1, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v0, -0x1

    invoke-direct {p1, v0, v1}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p1, "BillingClient"

    const-string v0, "Please provide a valid SKU type."

    invoke-static {p1, v0}, Lcom/android/billingclient/util/BillingHelper;->d(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Lcom/android/billingclient/api/Purchase$PurchasesResult;

    const/4 v0, 0x5

    invoke-direct {p1, v0, v1}, Lcom/android/billingclient/api/Purchase$PurchasesResult;-><init>(ILjava/util/List;)V

    return-object p1

    :cond_1
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/android/billingclient/api/BillingClientImpl;->a(Ljava/lang/String;Z)Lcom/android/billingclient/api/Purchase$PurchasesResult;

    move-result-object p1

    return-object p1
.end method
