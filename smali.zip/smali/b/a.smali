.class public Lb/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb/a$a;
    }
.end annotation


# static fields
.field private static Cf:[I = null

.field private static final Cg:I = 0x4

.field private static final TAG:Ljava/lang/String; = "MainViewController"


# instance fields
.field private final Ch:Lb/a$a;

.field private Ci:Lcom/brasfoot/v2028/ActivitySub;

.field private Cj:Z

.field private Ck:Z

.field private Cl:Z

.field private Cm:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    new-array v0, v0, [I

    sput-object v0, Lb/a;->Cf:[I

    return-void
.end method

.method public constructor <init>(Lcom/brasfoot/v2028/ActivitySub;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lb/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lb/a$a;-><init>(Lb/a;Lb/a$1;)V

    iput-object v0, p0, Lb/a;->Ch:Lb/a$a;

    iput-object p1, p0, Lb/a;->Ci:Lcom/brasfoot/v2028/ActivitySub;

    invoke-direct {p0}, Lb/a;->om()V

    return-void
.end method

.method static synthetic a(Lb/a;)I
    .locals 0

    iget p0, p0, Lb/a;->Cm:I

    return p0
.end method

.method static synthetic a(Lb/a;I)I
    .locals 0

    iput p1, p0, Lb/a;->Cm:I

    return p1
.end method

.method static synthetic a(Lb/a;Z)Z
    .locals 0

    iput-boolean p1, p0, Lb/a;->Cj:Z

    return p1
.end method

.method static synthetic b(Lb/a;)V
    .locals 0

    invoke-direct {p0}, Lb/a;->ol()V

    return-void
.end method

.method static synthetic b(Lb/a;Z)Z
    .locals 0

    iput-boolean p1, p0, Lb/a;->Ck:Z

    return p1
.end method

.method private ol()V
    .locals 3

    iget-object v0, p0, Lb/a;->Ci:Lcom/brasfoot/v2028/ActivitySub;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivitySub;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "tank"

    iget v2, p0, Lb/a;->Cm:I

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private om()V
    .locals 3

    iget-object v0, p0, Lb/a;->Ci:Lcom/brasfoot/v2028/ActivitySub;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/brasfoot/v2028/ActivitySub;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "tank"

    const/4 v2, 0x2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    iput v0, p0, Lb/a;->Cm:I

    return-void
.end method


# virtual methods
.method public od()V
    .locals 1

    iget v0, p0, Lb/a;->Cm:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lb/a;->Cm:I

    invoke-direct {p0}, Lb/a;->ol()V

    return-void
.end method

.method public oe()Lb/a$a;
    .locals 1

    iget-object v0, p0, Lb/a;->Ch:Lb/a$a;

    return-object v0
.end method

.method public of()Z
    .locals 1

    iget v0, p0, Lb/a;->Cm:I

    if-gtz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public og()Z
    .locals 2

    iget v0, p0, Lb/a;->Cm:I

    const/4 v1, 0x4

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public oh()Z
    .locals 1

    iget-boolean v0, p0, Lb/a;->Cl:Z

    return v0
.end method

.method public oi()Z
    .locals 1

    iget-boolean v0, p0, Lb/a;->Cj:Z

    return v0
.end method

.method public oj()Z
    .locals 1

    iget-boolean v0, p0, Lb/a;->Ck:Z

    return v0
.end method

.method public ok()I
    .locals 2
    .annotation build Landroid/support/annotation/DrawableRes;
    .end annotation

    iget v0, p0, Lb/a;->Cm:I

    sget-object v1, Lb/a;->Cf:[I

    array-length v1, v1

    if-lt v0, v1, :cond_0

    sget-object v0, Lb/a;->Cf:[I

    array-length v0, v0

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    iget v0, p0, Lb/a;->Cm:I

    :goto_0
    sget-object v1, Lb/a;->Cf:[I

    aget v0, v1, v0

    return v0
.end method
