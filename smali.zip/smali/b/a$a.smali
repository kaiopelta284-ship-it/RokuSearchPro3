.class Lb/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lb/a/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic Cn:Lb/a;


# direct methods
.method private constructor <init>(Lb/a;)V
    .locals 0

    iput-object p1, p0, Lb/a$a;->Cn:Lb/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lb/a;Lb/a$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lb/a$a;-><init>(Lb/a;)V

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/Purchase;",
            ">;)V"
        }
    .end annotation

    iget-object p1, p0, Lb/a$a;->Cn:Lb/a;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lb/a;->a(Lb/a;Z)Z

    iget-object p1, p0, Lb/a$a;->Cn:Lb/a;

    invoke-static {p1, v0}, Lb/a;->b(Lb/a;Z)Z

    return-void
.end method

.method public d(Ljava/lang/String;I)V
    .locals 1

    if-nez p2, :cond_1

    iget-object p1, p0, Lb/a$a;->Cn:Lb/a;

    iget-object p2, p0, Lb/a$a;->Cn:Lb/a;

    invoke-static {p2}, Lb/a;->a(Lb/a;)I

    move-result p2

    const/4 v0, 0x4

    if-ne p2, v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p2, p0, Lb/a$a;->Cn:Lb/a;

    invoke-static {p2}, Lb/a;->a(Lb/a;)I

    move-result p2

    add-int/lit8 v0, p2, 0x1

    :goto_0
    invoke-static {p1, v0}, Lb/a;->a(Lb/a;I)I

    iget-object p1, p0, Lb/a$a;->Cn:Lb/a;

    invoke-static {p1}, Lb/a;->b(Lb/a;)V

    :cond_1
    return-void
.end method

.method public on()V
    .locals 0

    return-void
.end method
