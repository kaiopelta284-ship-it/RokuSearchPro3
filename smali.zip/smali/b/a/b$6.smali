.class Lb/a/b$6;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;->or()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;


# direct methods
.method constructor <init>(Lb/a/b;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$6;->CD:Lb/a/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    iget-object v0, p0, Lb/a/b$6;->CD:Lb/a/b;

    invoke-static {v0}, Lb/a/b;->c(Lb/a/b;)Lcom/android/billingclient/api/BillingClient;

    move-result-object v0

    const-string v1, "inapp"

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/BillingClient;->v(Ljava/lang/String;)Lcom/android/billingclient/api/Purchase$PurchasesResult;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$6;->CD:Lb/a/b;

    invoke-virtual {v1}, Lb/a/b;->oq()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lb/a/b$6;->CD:Lb/a/b;

    invoke-static {v1}, Lb/a/b;->c(Lb/a/b;)Lcom/android/billingclient/api/BillingClient;

    move-result-object v1

    const-string v2, "subs"

    invoke-virtual {v1, v2}, Lcom/android/billingclient/api/BillingClient;->v(Ljava/lang/String;)Lcom/android/billingclient/api/Purchase$PurchasesResult;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/billingclient/api/Purchase$PurchasesResult;->getResponseCode()I

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v0}, Lcom/android/billingclient/api/Purchase$PurchasesResult;->oQ()Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/billingclient/api/Purchase$PurchasesResult;->oQ()Ljava/util/List;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lcom/android/billingclient/api/Purchase$PurchasesResult;->getResponseCode()I

    :cond_1
    :goto_0
    iget-object v1, p0, Lb/a/b$6;->CD:Lb/a/b;

    invoke-static {v1, v0}, Lb/a/b;->a(Lb/a/b;Lcom/android/billingclient/api/Purchase$PurchasesResult;)V

    return-void
.end method
