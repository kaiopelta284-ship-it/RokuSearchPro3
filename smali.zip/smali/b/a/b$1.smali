.class Lb/a/b$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;-><init>(Landroid/app/Activity;Lb/a/b$a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;


# direct methods
.method constructor <init>(Lb/a/b;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$1;->CD:Lb/a/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lb/a/b$1;->CD:Lb/a/b;

    invoke-static {v0}, Lb/a/b;->a(Lb/a/b;)Lb/a/b$a;

    move-result-object v0

    invoke-interface {v0}, Lb/a/b$a;->on()V

    iget-object v0, p0, Lb/a/b$1;->CD:Lb/a/b;

    invoke-virtual {v0}, Lb/a/b;->or()V

    return-void
.end method
