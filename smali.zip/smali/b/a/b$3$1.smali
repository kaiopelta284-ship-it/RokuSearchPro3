.class Lb/a/b$3$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/android/billingclient/api/SkuDetailsResponseListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b$3;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CK:Lb/a/b$3;


# direct methods
.method constructor <init>(Lb/a/b$3;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$3$1;->CK:Lb/a/b$3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public b(ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/SkuDetails;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Lb/a/b$3$1;->CK:Lb/a/b$3;

    iget-object v0, v0, Lb/a/b$3;->CJ:Lcom/android/billingclient/api/SkuDetailsResponseListener;

    invoke-interface {v0, p1, p2}, Lcom/android/billingclient/api/SkuDetailsResponseListener;->b(ILjava/util/List;)V

    return-void
.end method
