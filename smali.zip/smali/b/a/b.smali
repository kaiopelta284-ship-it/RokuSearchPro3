.class public Lb/a/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/android/billingclient/api/PurchasesUpdatedListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb/a/b$b;,
        Lb/a/b$a;
    }
.end annotation


# static fields
.field private static final CC:Ljava/lang/String; = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7LaoPWh2PVQStvuFsoIYlCmyf+bXUaQ5CFfiBBmR054/q7EWDojWwToM5wZLqvaZJPkkqv0S3z+fv4PYLhTBIkGrMQbzMlsHPukIhMMym92SXu0ZFU+pOOr/nOpr/jxMLMhV3usWhhO4vPFQ09D1R9z95xKggRWyjQMvR1PYRDc83aDRdVnXm2D0Eh9Lh45kTkO+kwfHxPC1rbyJnNK/tCCMwILn+SM6J87XWj9MSYToc0Mqb/BpfMY8raALlMtx/thFA3QFldzILU3aiXnV8/jRfIoZTM8UPyeznKTFMdSIKdlAqxGGa9zVqT8AnY7INcJ0GGPKa2V6mF4hSFyQmQIDAQAB"

.field public static final Cu:I = -0x1

.field private static final TAG:Ljava/lang/String; = "bf18"


# instance fields
.field private CA:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private CB:I

.field private Cv:Lcom/android/billingclient/api/BillingClient;

.field private Cw:Z

.field private final Cx:Lb/a/b$a;

.field private final Cy:Landroid/app/Activity;

.field private final Cz:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/Purchase;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/app/Activity;Lb/a/b$a;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lb/a/b;->Cz:Ljava/util/List;

    const/4 v0, -0x1

    iput v0, p0, Lb/a/b;->CB:I

    iput-object p1, p0, Lb/a/b;->Cy:Landroid/app/Activity;

    iput-object p2, p0, Lb/a/b;->Cx:Lb/a/b$a;

    iget-object p1, p0, Lb/a/b;->Cy:Landroid/app/Activity;

    invoke-static {p1}, Lcom/android/billingclient/api/BillingClient;->i(Landroid/content/Context;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object p1

    invoke-virtual {p1, p0}, Lcom/android/billingclient/api/BillingClient$Builder;->a(Lcom/android/billingclient/api/PurchasesUpdatedListener;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingClient$Builder;->oy()Lcom/android/billingclient/api/BillingClient;

    move-result-object p1

    iput-object p1, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    new-instance p1, Lb/a/b$1;

    invoke-direct {p1, p0}, Lb/a/b$1;-><init>(Lb/a/b;)V

    invoke-virtual {p0, p1}, Lb/a/b;->a(Ljava/lang/Runnable;)V

    return-void
.end method

.method static synthetic a(Lb/a/b;I)I
    .locals 0

    iput p1, p0, Lb/a/b;->CB:I

    return p1
.end method

.method static synthetic a(Lb/a/b;)Lb/a/b$a;
    .locals 0

    iget-object p0, p0, Lb/a/b;->Cx:Lb/a/b$a;

    return-object p0
.end method

.method static synthetic a(Lb/a/b;Lcom/android/billingclient/api/Purchase$PurchasesResult;)V
    .locals 0

    invoke-direct {p0, p1}, Lb/a/b;->a(Lcom/android/billingclient/api/Purchase$PurchasesResult;)V

    return-void
.end method

.method private a(Lcom/android/billingclient/api/Purchase$PurchasesResult;)V
    .locals 1

    iget-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Lcom/android/billingclient/api/Purchase$PurchasesResult;->getResponseCode()I

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lb/a/b;->Cz:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v0, 0x0

    invoke-virtual {p1}, Lcom/android/billingclient/api/Purchase$PurchasesResult;->oQ()Ljava/util/List;

    move-result-object p1

    invoke-virtual {p0, v0, p1}, Lb/a/b;->a(ILjava/util/List;)V

    :cond_1
    return-void
.end method

.method private a(Lcom/android/billingclient/api/Purchase;)V
    .locals 1

    iget-object v0, p0, Lb/a/b;->Cz:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method static synthetic a(Lb/a/b;Z)Z
    .locals 0

    iput-boolean p1, p0, Lb/a/b;->Cw:Z

    return p1
.end method

.method static synthetic b(Lb/a/b;)Landroid/app/Activity;
    .locals 0

    iget-object p0, p0, Lb/a/b;->Cy:Landroid/app/Activity;

    return-object p0
.end method

.method private b(Ljava/lang/Runnable;)V
    .locals 1

    iget-boolean v0, p0, Lb/a/b;->Cw:Z

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    :cond_0
    invoke-virtual {p0, p1}, Lb/a/b;->a(Ljava/lang/Runnable;)V

    return-void
.end method

.method private b(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    const-string v0, "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7LaoPWh2PVQStvuFsoIYlCmyf+bXUaQ5CFfiBBmR054/q7EWDojWwToM5wZLqvaZJPkkqv0S3z+fv4PYLhTBIkGrMQbzMlsHPukIhMMym92SXu0ZFU+pOOr/nOpr/jxMLMhV3usWhhO4vPFQ09D1R9z95xKggRWyjQMvR1PYRDc83aDRdVnXm2D0Eh9Lh45kTkO+kwfHxPC1rbyJnNK/tCCMwILn+SM6J87XWj9MSYToc0Mqb/BpfMY8raALlMtx/thFA3QFldzILU3aiXnV8/jRfIoZTM8UPyeznKTFMdSIKdlAqxGGa9zVqT8AnY7INcJ0GGPKa2V6mF4hSFyQmQIDAQAB"

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance p1, Ljava/lang/RuntimeException;

    const-string p2, ""

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_0
    :try_start_0
    const-string v0, "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7LaoPWh2PVQStvuFsoIYlCmyf+bXUaQ5CFfiBBmR054/q7EWDojWwToM5wZLqvaZJPkkqv0S3z+fv4PYLhTBIkGrMQbzMlsHPukIhMMym92SXu0ZFU+pOOr/nOpr/jxMLMhV3usWhhO4vPFQ09D1R9z95xKggRWyjQMvR1PYRDc83aDRdVnXm2D0Eh9Lh45kTkO+kwfHxPC1rbyJnNK/tCCMwILn+SM6J87XWj9MSYToc0Mqb/BpfMY8raALlMtx/thFA3QFldzILU3aiXnV8/jRfIoZTM8UPyeznKTFMdSIKdlAqxGGa9zVqT8AnY7INcJ0GGPKa2V6mF4hSFyQmQIDAQAB"

    invoke-static {v0, p1, p2}, Lb/a/d;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    const/4 p1, 0x0

    return p1
.end method

.method static synthetic c(Lb/a/b;)Lcom/android/billingclient/api/BillingClient;
    .locals 0

    iget-object p0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    return-object p0
.end method


# virtual methods
.method public a(ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/Purchase;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x7

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lb/a/b;->Cy:Landroid/app/Activity;

    check-cast p1, Lcom/brasfoot/v2028/ActivitySub;

    invoke-virtual {p1}, Lcom/brasfoot/v2028/ActivitySub;->sg()V

    return-void

    :cond_0
    if-nez p1, :cond_2

    if-eqz p2, :cond_2

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/android/billingclient/api/Purchase;

    invoke-direct {p0, p2}, Lb/a/b;->a(Lcom/android/billingclient/api/Purchase;)V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lb/a/b;->Cx:Lb/a/b$a;

    iget-object p2, p0, Lb/a/b;->Cz:Ljava/util/List;

    invoke-interface {p1, p2}, Lb/a/b$a;->a(Ljava/util/List;)V

    :cond_2
    return-void
.end method

.method public a(Ljava/lang/Runnable;)V
    .locals 2

    iget-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    new-instance v1, Lb/a/b$7;

    invoke-direct {v1, p0, p1}, Lb/a/b$7;-><init>(Lb/a/b;Ljava/lang/Runnable;)V

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/BillingClient;->a(Lcom/android/billingclient/api/BillingClientStateListener;)V

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0, p2}, Lb/a/b;->a(Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;)V

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    new-instance v0, Lb/a/b$2;

    invoke-direct {v0, p0, p1, p3, p2}, Lb/a/b$2;-><init>(Lb/a/b;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    invoke-direct {p0, v0}, Lb/a/b;->b(Ljava/lang/Runnable;)V

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/util/List;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/android/billingclient/api/SkuDetailsResponseListener;",
            ")V"
        }
    .end annotation

    new-instance v0, Lb/a/b$3;

    invoke-direct {v0, p0, p2, p1, p3}, Lb/a/b$3;-><init>(Lb/a/b;Ljava/util/List;Ljava/lang/String;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V

    invoke-direct {p0, v0}, Lb/a/b;->b(Ljava/lang/Runnable;)V

    return-void
.end method

.method public destroy()V
    .locals 1

    iget-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    invoke-virtual {v0}, Lcom/android/billingclient/api/BillingClient;->ow()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    invoke-virtual {v0}, Lcom/android/billingclient/api/BillingClient;->ox()V

    const/4 v0, 0x0

    iput-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    :cond_0
    return-void
.end method

.method public getContext()Landroid/content/Context;
    .locals 1

    iget-object v0, p0, Lb/a/b;->Cy:Landroid/app/Activity;

    return-object v0
.end method

.method public oo()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/android/billingclient/api/Purchase;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lb/a/b;->Cz:Ljava/util/List;

    return-object v0
.end method

.method public op()I
    .locals 1

    iget v0, p0, Lb/a/b;->CB:I

    return v0
.end method

.method public oq()Z
    .locals 2

    iget-object v0, p0, Lb/a/b;->Cv:Lcom/android/billingclient/api/BillingClient;

    const-string v1, "subscriptions"

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/BillingClient;->u(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public or()V
    .locals 1

    new-instance v0, Lb/a/b$6;

    invoke-direct {v0, p0}, Lb/a/b$6;-><init>(Lb/a/b;)V

    invoke-direct {p0, v0}, Lb/a/b;->b(Ljava/lang/Runnable;)V

    return-void
.end method

.method public s(Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lb/a/b;->CA:Ljava/util/Set;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lb/a/b;->CA:Ljava/util/Set;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lb/a/b;->CA:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    :cond_1
    :goto_0
    iget-object v0, p0, Lb/a/b;->CA:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    new-instance v0, Lb/a/b$4;

    invoke-direct {v0, p0}, Lb/a/b$4;-><init>(Lb/a/b;)V

    new-instance v1, Lb/a/b$5;

    invoke-direct {v1, p0, p1, v0}, Lb/a/b$5;-><init>(Lb/a/b;Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V

    invoke-direct {p0, v1}, Lb/a/b;->b(Ljava/lang/Runnable;)V

    return-void
.end method
