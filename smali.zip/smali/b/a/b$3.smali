.class Lb/a/b$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;->a(Ljava/lang/String;Ljava/util/List;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;

.field final synthetic CH:Ljava/util/List;

.field final synthetic CI:Ljava/lang/String;

.field final synthetic CJ:Lcom/android/billingclient/api/SkuDetailsResponseListener;


# direct methods
.method constructor <init>(Lb/a/b;Ljava/util/List;Ljava/lang/String;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$3;->CD:Lb/a/b;

    iput-object p2, p0, Lb/a/b$3;->CH:Ljava/util/List;

    iput-object p3, p0, Lb/a/b$3;->CI:Ljava/lang/String;

    iput-object p4, p0, Lb/a/b$3;->CJ:Lcom/android/billingclient/api/SkuDetailsResponseListener;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    invoke-static {}, Lcom/android/billingclient/api/SkuDetailsParams;->pc()Lcom/android/billingclient/api/SkuDetailsParams$Builder;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$3;->CH:Ljava/util/List;

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/SkuDetailsParams$Builder;->b(Ljava/util/List;)Lcom/android/billingclient/api/SkuDetailsParams$Builder;

    move-result-object v1

    iget-object v2, p0, Lb/a/b$3;->CI:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/android/billingclient/api/SkuDetailsParams$Builder;->C(Ljava/lang/String;)Lcom/android/billingclient/api/SkuDetailsParams$Builder;

    iget-object v1, p0, Lb/a/b$3;->CD:Lb/a/b;

    invoke-static {v1}, Lb/a/b;->c(Lb/a/b;)Lcom/android/billingclient/api/BillingClient;

    move-result-object v1

    invoke-virtual {v0}, Lcom/android/billingclient/api/SkuDetailsParams$Builder;->pd()Lcom/android/billingclient/api/SkuDetailsParams;

    move-result-object v0

    new-instance v2, Lb/a/b$3$1;

    invoke-direct {v2, p0}, Lb/a/b$3$1;-><init>(Lb/a/b$3;)V

    invoke-virtual {v1, v0, v2}, Lcom/android/billingclient/api/BillingClient;->a(Lcom/android/billingclient/api/SkuDetailsParams;Lcom/android/billingclient/api/SkuDetailsResponseListener;)V

    return-void
.end method
