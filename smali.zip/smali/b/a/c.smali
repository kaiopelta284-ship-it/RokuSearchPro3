.class public interface abstract Lb/a/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract og()Z
.end method

.method public abstract oh()Z
.end method

.method public abstract oj()Z
.end method

.method public abstract ot()Lb/a/b;
.end method
