.class public final Lb/a/a;
.super Ljava/lang/Object;


# static fields
.field public static final Co:Ljava/lang/String; = "pv1801"

.field public static final Cp:Ljava/lang/String; = "gas"

.field public static final Cq:Ljava/lang/String; = "gold_monthly"

.field public static final Cr:Ljava/lang/String; = "gold_yearly"

.field private static final Cs:[Ljava/lang/String;

.field private static final Ct:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "gas"

    const-string v1, "pv1801"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb/a/a;->Cs:[Ljava/lang/String;

    const-string v0, "gold_monthly"

    const-string v1, "gold_yearly"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb/a/a;->Ct:[Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final r(Ljava/lang/String;)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v0, "inapp"

    if-ne p0, v0, :cond_0

    sget-object p0, Lb/a/a;->Cs:[Ljava/lang/String;

    :goto_0
    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_0
    sget-object p0, Lb/a/a;->Ct:[Ljava/lang/String;

    goto :goto_0

    return-object p0
.end method
