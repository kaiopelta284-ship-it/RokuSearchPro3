.class Lb/a/b$4;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/android/billingclient/api/ConsumeResponseListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;->s(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;


# direct methods
.method constructor <init>(Lb/a/b;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$4;->CD:Lb/a/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public c(ILjava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lb/a/b$4;->CD:Lb/a/b;

    invoke-static {v0}, Lb/a/b;->a(Lb/a/b;)Lb/a/b$a;

    move-result-object v0

    invoke-interface {v0, p2, p1}, Lb/a/b$a;->d(Ljava/lang/String;I)V

    return-void
.end method
