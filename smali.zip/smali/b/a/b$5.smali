.class Lb/a/b$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;->s(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;

.field final synthetic CL:Ljava/lang/String;

.field final synthetic CM:Lcom/android/billingclient/api/ConsumeResponseListener;


# direct methods
.method constructor <init>(Lb/a/b;Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$5;->CD:Lb/a/b;

    iput-object p2, p0, Lb/a/b$5;->CL:Ljava/lang/String;

    iput-object p3, p0, Lb/a/b$5;->CM:Lcom/android/billingclient/api/ConsumeResponseListener;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Lb/a/b$5;->CD:Lb/a/b;

    invoke-static {v0}, Lb/a/b;->c(Lb/a/b;)Lcom/android/billingclient/api/BillingClient;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$5;->CL:Ljava/lang/String;

    iget-object v2, p0, Lb/a/b$5;->CM:Lcom/android/billingclient/api/ConsumeResponseListener;

    invoke-virtual {v0, v1, v2}, Lcom/android/billingclient/api/BillingClient;->a(Ljava/lang/String;Lcom/android/billingclient/api/ConsumeResponseListener;)V

    return-void
.end method
