.class Lb/a/b$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;->a(Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;

.field final synthetic CE:Ljava/lang/String;

.field final synthetic CF:Ljava/lang/String;

.field final synthetic CG:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lb/a/b;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$2;->CD:Lb/a/b;

    iput-object p2, p0, Lb/a/b$2;->CE:Ljava/lang/String;

    iput-object p3, p0, Lb/a/b$2;->CF:Ljava/lang/String;

    iput-object p4, p0, Lb/a/b$2;->CG:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    invoke-static {}, Lcom/android/billingclient/api/BillingFlowParams;->oH()Lcom/android/billingclient/api/BillingFlowParams$Builder;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$2;->CE:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/BillingFlowParams$Builder;->x(Ljava/lang/String;)Lcom/android/billingclient/api/BillingFlowParams$Builder;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$2;->CF:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/BillingFlowParams$Builder;->y(Ljava/lang/String;)Lcom/android/billingclient/api/BillingFlowParams$Builder;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$2;->CG:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Lcom/android/billingclient/api/BillingFlowParams$Builder;->U(Ljava/util/ArrayList;)Lcom/android/billingclient/api/BillingFlowParams$Builder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/billingclient/api/BillingFlowParams$Builder;->oI()Lcom/android/billingclient/api/BillingFlowParams;

    move-result-object v0

    iget-object v1, p0, Lb/a/b$2;->CD:Lb/a/b;

    invoke-static {v1}, Lb/a/b;->c(Lb/a/b;)Lcom/android/billingclient/api/BillingClient;

    move-result-object v1

    iget-object v2, p0, Lb/a/b$2;->CD:Lb/a/b;

    invoke-static {v2}, Lb/a/b;->b(Lb/a/b;)Landroid/app/Activity;

    move-result-object v2

    invoke-virtual {v1, v2, v0}, Lcom/android/billingclient/api/BillingClient;->a(Landroid/app/Activity;Lcom/android/billingclient/api/BillingFlowParams;)I

    return-void
.end method
