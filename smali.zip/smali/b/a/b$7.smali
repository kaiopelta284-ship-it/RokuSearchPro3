.class Lb/a/b$7;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/android/billingclient/api/BillingClientStateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb/a/b;->a(Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic CD:Lb/a/b;

.field final synthetic CN:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Lb/a/b;Ljava/lang/Runnable;)V
    .locals 0

    iput-object p1, p0, Lb/a/b$7;->CD:Lb/a/b;

    iput-object p2, p0, Lb/a/b$7;->CN:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public cE(I)V
    .locals 2

    if-nez p1, :cond_0

    iget-object v0, p0, Lb/a/b$7;->CD:Lb/a/b;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lb/a/b;->a(Lb/a/b;Z)Z

    iget-object v0, p0, Lb/a/b$7;->CN:Ljava/lang/Runnable;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lb/a/b$7;->CN:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_0
    iget-object v0, p0, Lb/a/b$7;->CD:Lb/a/b;

    invoke-static {v0, p1}, Lb/a/b;->a(Lb/a/b;I)I

    return-void
.end method

.method public os()V
    .locals 2

    iget-object v0, p0, Lb/a/b$7;->CD:Lb/a/b;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lb/a/b;->a(Lb/a/b;Z)Z

    return-void
.end method
